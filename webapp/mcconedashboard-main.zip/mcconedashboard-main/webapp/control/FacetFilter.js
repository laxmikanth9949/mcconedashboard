sap.ui.define([
	"sap/m/FacetFilter",
	"sap/m/FacetFilterRenderer",
	"sap/m/MessageToast",
	"sap/ui/core/IconPool"
], function (FacetFilter, FacetFilterRenderer, MessageToast, IconPool) {
	"use strict";

	return FacetFilter.extend("com.sap.mcconedashboard.control.FacetFilter", {

		/**
		 * add new Ui element for reset of filters in facet filter selection
		 */
		_createSelectAllCheckboxBar: function (oList) {
			//create select All
			var oBar = FacetFilter.prototype._createSelectAllCheckboxBar.apply(this, arguments);

			oList.attachListClose(function () {
				this._removeFooterInfo();
			}.bind(this));

			var oSelectAllListEntry = oBar.getAggregation("contentLeft")[0];
			oSelectAllListEntry.setTooltip("Select all list entries");
			oSelectAllListEntry.setText("Select all list entries");

			//create a new button for reset of filters
			var oBtn = new sap.m.Button({
				icon: "sap-icon://undo",
				press: [this._deselect, oList],
				tooltip: "Clear Selection"
			});

			oBar.addContentRight(oBtn);

			if (oList.getItems().length === 100) {
				this._showFooterInfo();
			}
			//styling issue with 1.52 select All label next to checkbox is hidden with 1.52
			//oBar.addStyleClass("MCSDashboardFacetFilterSelectAllOverflowVisible");

			return oBar;
		},

		_deselect: function () {
			this.removeSelectedKeys();
			//when the region filter is reseted, WORLD needs to be selected
			if (this.getProperty("title") === "Region") {
				this.setSelectedKeys(JSON.parse('{"WORLD":"World"}'));
			}
		},

		_showFooterInfo: function () {
			var oDialog = FacetFilter.prototype._getFacetDialog.apply(this, arguments);

			if (oDialog) {
				var oInfoButton = new sap.m.Button({
					text: "More than 100 items found",
					type: sap.m.ButtonType.Ghost,
					tooltip: "More than 100 items found",
					enabled: false

				});
				oDialog.setEndButton(oInfoButton);
			}
			return oDialog;
		},

		_removeFooterInfo: function () {
			var oDialog = FacetFilter.prototype._getFacetDialog.apply(this, arguments);

			if (oDialog && oDialog.getButtons().length >= 2) {
				oDialog.getButtons()[1].setVisible(false);
			}

		},

		/**
		 * Gets the facet button for the given list (it is created if it doesn't exist yet).
		 * The button text is set with the given list title.
		 *
		 * @param {sap.m.FacetFilterList} oList The list displayed when the button is pressed
		 * @returns {sap.m.Button} The button for the list
		 * @private
		 */
		_getButtonForList: function (oList) {

			if (this._buttons[oList.getId()]) {

				this._setButtonText(oList);
				return this._buttons[oList.getId()];
			}

			var that = this;
			var oButton = new sap.m.Button({

				type: sap.m.ButtonType.Transparent,
				press: function (oEvent) {
					/*eslint-disable consistent-this */
					var oThisButton = this;
					/*eslint-enable consistent-this */
					var fnOpenPopover = function () {
						var oPopover = that._getPopover();
						that._openPopover(oPopover, oThisButton);
					};

					if (oList.getMode() === sap.m.ListMode.MultiSelect) {
						oList._preserveOriginalActiveState();
					}

					var oPopover = that._getPopover();
					if (oPopover.isOpen()) {
						// create a deferred that will be triggered after the popover is closed
						setTimeout(function () {
							if (oPopover.isOpen()) {
								return;
							}
							that._oOpenPopoverDeferred = jQuery.Deferred();
							that._oOpenPopoverDeferred.promise().done(fnOpenPopover);
						}, 100);
					} else {
						setTimeout(fnOpenPopover.bind(this), 100);
					}
				}
			});
			//MCC One Dashboard Specific implementation START
			//we need to hide some of the facet filters in specific views, because they are not supported or not needed
			// the implementation needs to be in several places
			//Hide the MCC Tags Button for the Charts view and MCC Operational Charts view
			if (oList.getTitle().startsWith("MCC Tag") && (this.getModel("settings").getProperty("/isInChartsTile") || this.getModel("settings")
					.getProperty("/isInOperationalKPITile"))) {
				oButton.addStyleClass("MCCOneHidden");
			} else
			//hide all other buttons, but Region, in the MCC Operational Charts view
			if (!oList.getTitle().startsWith("Region") && this.getModel("settings").getProperty("/isInOperationalKPITile")) {
				oButton.addStyleClass("MCCOneHidden");
			}

			////MCC One Dashboard Specific implementation END
			this._buttons[oList.getId()] = oButton;
			this.addAggregation("buttons", oButton); // Insures that the button text is updated if FacetFilterList.setTitle() is called
			oButton.setAssociation("list", oList.getId(), true);
			this._setButtonText(oList);
			return oButton;
		},

		renderer: FacetFilterRenderer
	});

});