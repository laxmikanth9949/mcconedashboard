sap.ui.define([
	"sap/ui/core/Control",
	"sap/m/ObjectStatus"
], function (Control, ObjectStatus) {
	"use strict";
	return Control.extend("com.sap.mcconedashboard.control.CustomDashboardTileItem", {
		metadata: {
			properties: {
				text: {
					type: "string",
					defaultValue: ""
				},
				value: {
					type: "string",
					defaultValue: ""
				},
				tooltip: {
					type: "string",
					defaultValue: ""
				},
				state: {
					type: "string",
					defaultValue: "Information"
				}
			},
			aggregations: {
				_item: {
					type: "sap.m.ObjectStatus",
					multiple: false,
					visibility: "hidden"
				}
			},
			events: {
				press: {
					parameters: {}
				}
			}
		},

		setValue: function (sValue) {
			this.setProperty("value", sValue);
		},

		onBeforeRendering: function () {
			this.setAggregation("_item", new ObjectStatus({
				text: this.getText() + " (" + this.getValue() + ")",
				tooltip: this.getTooltip(),
				state: this.getState(),
				visible: this.getText() !== "GEM" ? true : !this.getModel("settings").getProperty("/isAnonymizedMode"),
				active: true,
				inverted: true,
				layoutData: new sap.m.FlexItemData({
					growFactor: 1
				}),
				press: function (oEv) {
					if (this.mEventRegistry.press[0].oData.oListener) {
						this.mEventRegistry.press[0].oData.fFunction.call(this.mEventRegistry.press[0].oData.oListener.oView.getController(), oEv,
							this.getText());
					} else {
						this.mEventRegistry.press[0].oData.fFunction.call(this.data("controller"), this.data("key"), this.data("description"), this.data(
							"serviceTeams"), this.data("tagName"));
					}
				}.bind(this)
			}).addStyleClass("mccOneDashboardObjectStatusFormatting"));
		},

		renderer: function (oRm, oControl) {
			oRm.openStart("div", oControl);
			oRm.class("sapUiTinyMarginEnd");
			oRm.class("MCCOneDashboardObjectTypePadding");
			oRm.openEnd();
			oRm.renderControl(oControl.getAggregation("_item"));
			oRm.close("div");
		},
		//specific stylesheet example related to custom class added above
		//please do not delete, maybe we need it still for some special handling
		// onAfterRendering: function () {
		// var sColorSapUiAccentError = sap.ui.core.theming.Parameters.get("sapUiAccent3");
		// var sColorSapUiAccentInfo = sap.ui.core.theming.Parameters.get("sapUiAccent7");
		// var sColorSapUiAccentBackgroundColorError  = sap.ui.core.theming.Parameters.get("sapUiAccentBackgroundColor3");
		// var sColorSapUiAccentBackgroundColorInfo = sap.ui.core.theming.Parameters.get("sapUiAccentBackgroundColor7");
		// $("document").ready(function () {
		// 	$(".sapMObjStatusError.mccOneDashboardObjectStatusFormatting .sapMObjStatusText").css("background-color",
		// 		sColorSapUiAccentError);
		// 	$(".sapMObjStatusInformation.mccOneDashboardObjectStatusFormatting .sapMObjStatusText").css("background-color",
		// 		sColorSapUiAccentInfo);
		// 	$(".sapMObjStatusError.mccOneDashboardObjectStatusFormatting .sapMObjStatusText").css("color",
		// 		sColorSapUiAccentBackgroundColorError);
		// 	$(".sapMObjStatusInformation.mccOneDashboardObjectStatusFormatting .sapMObjStatusText").css("color",
		// 		sColorSapUiAccentBackgroundColorInfo);
		// 	//	$(".sapMObjStatusInverted.sapMObjStatusError.sapMObjStatusText").css("background-color", "#85bb00"); 
		// });
		// },
	});
});