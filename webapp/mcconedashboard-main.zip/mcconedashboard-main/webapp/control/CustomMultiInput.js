sap.ui.define([
	"sap/ui/core/Control",
	'sap/m/MultiInput',
	'sap/m/Select',
	'sap/m/Input',
	'sap/m/MultiComboBox',
	'sap/m/Token',
	"sap/ui/model/json/JSONModel"

], function (Control, MultiInput, Select,Input, MultiComboBox,Token,JSONModel) {
	"use strict";
	return Control.extend("com.sap.mcconedashboard.control.CustomMultiInput", {
		metadata : {
			properties : {
				value: {type : "array", defaultValue : []},
				type: {type: "string"},
				enabled:{type:"boolean"}
			},
			aggregations : {
				_comboBox : {type : "sap.ui.core.Control", multiple: false, visibility : "hidden"},
				_multiInputA : {type : "sap.ui.core.Control", multiple: false, visibility : "hidden"},
				_InputA : {type : "sap.ui.core.Control", multiple: false, visibility : "hidden"}
			},
			events : {
				valueHelpRequest : {
					parameters : {
						
					}
				},
				suggestionItemSelected : {
					parameters : {
						selectedItem:{type:"object"}
					}
				},
				suggest:{
					parameters:{
						suggestValue:{type:"string"},
						type:{type:"string"}
					}
				}
			}
		},
		init : function () {
			var that = this;
			var combobox = new MultiComboBox({
				// selectedKeys:this.getValue(),
				// name: this.
				// items:{
				// 	path:"viewModel>/regions",
				// 	template: new sap.ui.core.Item({key:"{viewModel>key}",text:"{viewModel>text}"}),
				// 	templateShareable: true,
				// },
			});
			var multiInput = new MultiInput({
				// tokens:{
				// 	path: 'filterValue',
				// 	template: new sap.m.Token({key:"{key}",text:"{text}"}),
				// 	templateShareable: true
				// },
				valueHelpOnly:true,
				valueHelpRequest: function(){
					that.fireEvent("valueHelpRequest", {});
				},
				suggestionItemSelected:function(e){
					var selectedItem = e.getParameters().selectedItem;
					that.fireEvent("suggestionItemSelected", {selectedItem:selectedItem});
				}
			});
			var textInput = new Input();
			
			this.setAggregation("_comboBox", combobox);
			this.setAggregation("_multiInputA", multiInput);
			this.setAggregation("_InputA", textInput);
			
			// this.setAggregation("_rating", new RatingIndicator({
			// 	value: this.getValue(),
			// 	iconSize: "2rem",
			// 	visualMode: "Half",
			// 	liveChange: this._onRate.bind(this)
			// }));
		},

		setValue: function (aValue) {
			this.setProperty("value", aValue, true);
			// var inputControl = this.getAggregation("_comboBox");
			// var type = this.getType();
			// if(type === "subregion"){
			// 	inputControl.setSelectedKeys(aValue);
			// }
		},
		getName: function (){
			return this.getProperty("type");
		},
		getEnabled: function (){
			return this.getProperty("enabled");
		},
		getTokens: function(){
			return this.getAggregation("_multiInputA").getTokens();
		},
		setTokens: function(aTokens){
			this.getAggregation("_multiInputA").setTokens(aTokens);
		},
		formatToken: function(key){
			var type = this.getType();
			var oViewModelData = this.getModel("viewModel").getData();
			var oCustomerModelData = this.getModel("customerModel").getData();
			var dataSet = [];
			if(type === "ProductLine"){
				dataSet = oViewModelData.productLines;
			}
			if(type === "Product"){
				dataSet = oViewModelData.products;
			}
			if(type === "Customer" || type === "GlobalUltimate"){
				dataSet = oCustomerModelData.customers;
			}
			for(var i = 0; i < dataSet.length; i++){
				if(dataSet[i].ValueKey === key){
					return dataSet[i].ValueText;
				}
			}
			return "";
		},
		// _onSubmit : function (oEvent) {
		// 	var oResourceBundle = this.getModel("i18n").getResourceBundle();

		// 	this.getAggregation("_rating").setEnabled(false);
		// 	this.getAggregation("_label").setText(oResourceBundle.getText("productRatingLabelFinal"));
		// 	this.getAggregation("_button").setEnabled(false);
		// 	this.fireEvent("change", {
		// 		value: this.getValue()
		// 	});
		// },
		suggest: function(oEvent){
			var sValue = oEvent.getParameter("suggestValue");
			var sType = this.getType();
			clearTimeout(this._tId);
		    this._tId= setTimeout(function(){
		        this.fireEvent("suggest", {
					suggestValue:sValue,
					type:sType
				});
		    }.bind(this), 600);
			
		},
		renderer : function (oRm, oControl) {
			var type = oControl.getType();
			var enabled = oControl.getEnabled();
			console.log(enabled);
			var valuePath =  oControl.getBinding("value").getPath();
			var input;
			oRm.write("<div");
            oRm.writeControlData(oControl);
            oRm.addClass("nsBook");
            oRm.writeClasses();
            oRm.writeStyles();
            oRm.write(">");
            if(type === "subregion" ||
            	type === "SolutionArea" ||
            	type === "ProductCategory" ||
            	type === "country"){
            	input = oControl.getAggregation("_comboBox");
            	var itemPath = "";
            	var keyName = "ValueKey";
            	var textName = "ValueText";
            	if(type === "subregion"){
            		itemPath = "viewModel>/regions";
            	}
            	if(type === "SolutionArea"){
            		itemPath = "viewModel>/MCCSolution";
            		keyName = "SolKey";
            		textName = "Description";
            	}
            	if(type === "ProductCategory"){
            		itemPath = "viewModel>/productCategories";
            	}
            	if(type === "country"){
            		itemPath = "viewModel>/country";
            	}
            	var aSelectedKeys = input.getSelectedKeys();
            	input.bindItems({
					path:itemPath,
					template: new sap.ui.core.Item({key:"{viewModel>"+keyName+"}",text:"{viewModel>"+textName+"}"}),
					templateShareable: true,
				});
				input.bindProperty("selectedKeys",valuePath);
				if(aSelectedKeys.length){
					input.setSelectedKeys(aSelectedKeys);
				}
				
            	// input.setSelectedKey(this.getValue());
            }else if(type === "ProductLine" || type === "Product" || type === "Customer" || type === "GlobalUltimate"){
            	input = oControl.getAggregation("_multiInputA");
            	// if(type === "Customer" || type === "GlobalUltimate"){
            		input.setShowValueHelp(false);
            		input.setValueHelpOnly(false);
            		input.setShowSuggestion(true);
            		input.setFilterSuggests(false);
            		input.bindAggregation("suggestionItems",{
						path: "suggestionModel>/items",
						template: new sap.ui.core.Item({key:"{suggestionModel>key}",text:"{suggestionModel>text}{suggestionModel>description}"},oControl),
						templateShareable: true
					});
					input.attachSuggest(oControl.suggest.bind(oControl));
            	// }else{
            	// 	input.setShowValueHelp(true);
            	// 	input.setValueHelpOnly(true);
            	// }
            	input.bindAggregation("tokens",{
					path: valuePath,
					template: new sap.m.Token({key:"{}",text:"{path:'',formatter:'.formatToken'}"},oControl),
					templateShareable: true
				});
            }else if(type === "caseID"){
            	input = oControl.getAggregation("_InputA");
            	input.bindValue({
            		path:valuePath
            	});
            }
            if(input){
            	input.setName(type);
            	
				oRm.renderControl(input);
            }
			oRm.write("</div>");
		}
	});
});