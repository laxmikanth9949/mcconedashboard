sap.ui.define([
	'sap/ui/core/Control',
	'sap/m/ScrollContainer',
	'sap/m/HBox',
	'sap/m/VBox',
	'sap/m/Button',
	'sap/m/SegmentedButton',
	'sap/m/SegmentedButtonItem',
	'sap/m/Text',
	'sap/m/Link',
	'sap/m/Popover',
	'com/sap/mcconedashboard/control/CustomAppointment'
], function (
	Control,
	ScrollContainer,
	HBox,
	VBox,
	Button,
	SegmentedButton,
	SegmentedButtonItem,
	Text,
	Link,
	Popover,
	CustomAppointment
) {

	const today = new Date();
	return Control.extend('com.sap.mcconedashboard.controlCustomSinglePlanningCalendar', {
		metadata: {
			properties: {
				startDate: {
					type: 'string',
					defaultValue: today
				},
				firstVisibleMonthStart: {
					type: 'string',
					defaultValue: today
				},
				type: {
					type: 'string',
					defaultValue: 'full'
				},
				viewMode: {
					type: 'string',
					defaultValue: 'year'
				},
				isDetailed: {
					type: 'boolean',
					defaultValue: 'true'
				},
				isSubEventsVisible: {
					type: 'boolean',
					defaultValue: 'false'
				},
				isCard: {
					type: 'boolean',
					defaultValue: 'false'
				},
			},
			aggregations: {
				_scrollContainer: {
					type: 'sap.m.ScrollContainer',
					multiple: false
				},
				appointments: {
					type: 'com.sap.mcconedashboard.control.CustomAppointment',
					multiple: true
				},
				popover: {
					type: 'sap.m.Popover',
					multiple: false
				}
			},
			events: {
				change: {
					parameters: {
						value: {
							type: "string"
						}
					}
				}
			},
			defaultAggregation: 'appointments'
		},

		_getDaysInMonth: function (date) {
			const daysInMonth = 33 - new Date(date.getFullYear(), date.getMonth(), 33).getDate();

			return daysInMonth;
		},

		init: function () {
			const scrollContainer = new ScrollContainer;
			this.setAggregation('_scrollContainer', scrollContainer);
		},

		/*_getMonthViewName: function (date) {
			const monthName = new Date(date).toLocaleString('en', {
				month: 'long'
			});
			const year = new Date(date).getFullYear();
			const todayName = `${monthName} ${year}`;

			return todayName;
		},

		_getQuarterName: function (date) {
			const quarter = Math.floor((new Date(date).getMonth() + 3) / 3);
			const currentYear = new Date(date).getFullYear();
			const quarterName = `${currentYear}, Quarter ${quarter}`;

			return quarterName;
		},*/

		_getYearName: function (date) {
			const year = new Date(date).getFullYear();

			return year;
		},

		_getTodayName: function (date) {
			const viewMode = this.getViewMode();

			switch (viewMode) {
				/*case 'month':
					return this._getMonthViewName(date);
				case 'quarter':
					return this._getQuarterName(date);*/
			case 'year':
				return this._getYearName(date);
			}
		},

		_setStartDate: function (event) {
			const startDate = new Date(this.getStartDate());
			const icon = event.getSource().getIcon();
			const button = event.getSource().getText();
			if (button === 'Today') {
				this.setStartDate(new Date());
			} else {
				let previousDate;
				let nextDate;
				const viewMode = this.getViewMode();
				switch (viewMode) {
					/*	case 'month':
							previousDate = new Date(startDate.getFullYear(), startDate.getMonth() - 1, 1);
							nextDate = new Date(startDate.getFullYear(), startDate.getMonth() + 1, 1);
							break;
						case 'quarter':
							previousDate = new Date(startDate.getFullYear(), startDate.getMonth() - 3, 1);
							nextDate = new Date(startDate.getFullYear(), startDate.getMonth() + 3, 1);
							break;*/
				case 'year':
					previousDate = new Date(startDate.getFullYear(), startDate.getMonth() - 12, 1);
					nextDate = new Date(startDate.getFullYear(), startDate.getMonth() + 12, 1);
					break;
				}
				if (icon === 'sap-icon://navigation-left-arrow') {
					this.setStartDate(previousDate);
				}
				if (icon === 'sap-icon://navigation-right-arrow') {
					this.setStartDate(nextDate);
				}
			}
			this._addContentToScrollContainer();
			//	this.fireEvent("dateChange");
		},

		_getFullCalendarHeader: function () {
			const todayName = this._getTodayName(this.getStartDate());
			/*	const todayContainer = new HBox({
					width: '30%',
					justifyContent: 'Start'
				});*/
			/*const todayLabel = new Text({
				text: todayName
			});*/
			//	todayLabel.addStyleClass(`today-label`);
			//	todayContainer.addItem(todayLabel);

			/*		function onViewModeSelected(event) {
					let viewModeButton = event.getSource();
					let viewMode = viewModeButton.getSelectedKey();
					this.setViewMode(viewMode);
					this.fireEvent("dateChange");
				}

				const scaleContainer = new HBox({
					width: '50%',
				});
				const scaleSwitcher = new SegmentedButton({
					selectionChange: onViewModeSelected.bind(this)
				});
				scaleContainer.addItem(scaleSwitcher);

			const monthScale = new SegmentedButtonItem({
					text: 'Month',
					key: 'month',
					width: '100px'
				});
				const quarterScale = new SegmentedButtonItem({
					text: 'Quarter',
					key: 'quarter',
					width: '100px'
				});
				const yearScale = new SegmentedButtonItem({
					text: 'Year',
					key: 'year',
					width: '100px'
				});
				const segmentedButtonItems = [  yearScale];
				segmentedButtonItems.forEach((segmentedButtonItem) => scaleSwitcher.addItem(segmentedButtonItem));
				scaleSwitcher.setSelectedKey(this.getViewMode())*/

			const previousButton = new Button({
				icon: 'sap-icon://navigation-left-arrow',
				type: 'Transparent',
				press: this._setStartDate.bind(this)
			});

			const yearName = new Text({
				text: todayName
			});

			const nextButton = new Button({
				icon: 'sap-icon://navigation-right-arrow',
				type: 'Transparent',
				press: this._setStartDate.bind(this)
			});

			//const navigationContainer = new HBox();

			const header = new HBox({
				width: '100%',
				alignItems: 'Center',
				justifyContent: 'Center'
			});
			header.addItem(previousButton);
			header.addItem(yearName);
			header.addItem(nextButton);
			//	header.addItem(todayLabel);
			//	header.addItem(navigationContainer);
			//	header.addItem(todayContainer);
			//	header.addItem(scaleContainer);

			return header;
		},

		/*_getCompactCalendarHeader: function () {
			const previousButton = new Button({
				icon: 'sap-icon://navigation-left-arrow',
				type: 'Transparent',
				press: this._setStartDate.bind(this)
			});

			const startDate = new Date(this.getStartDate());
			const monthName = startDate
				.toLocaleString('en', {
					month: 'long'
				});
			const startDateYear = startDate.getFullYear();
			const buttonText = `${monthName}. ${startDateYear}`
			const monthButton = new Text({
				text: buttonText
			});

			const nextButton = new Button({
				icon: 'sap-icon://navigation-right-arrow',
				type: 'Transparent',
				press: this._setStartDate.bind(this)
			});

			const navigationContainer = new HBox({
				justifyContent: 'Center',
				alignItems: 'Center'
			});
			navigationContainer.addItem(previousButton);
			navigationContainer.addItem(monthButton);
			navigationContainer.addItem(nextButton);

			const header = new HBox({
				width: '100%',
				alignItems: 'Center',
				justifyContent: 'SpaceAround'
			});
			header.addItem(navigationContainer);

			return header;
		},*/

		_getCalendar: function (calendarType, startDate) {
			const popover = this.getPopover();
			const cssClass = calendarType === 'full' ? 'rma' : 'rma-small';

			const appointmentsControls = this.getAppointments();
			let appointments = appointmentsControls.map((appointmentsControl) => {
				const event = appointmentsControl.getEvent();

				return event;
			});
			const _getMonth = (date) => {
				const daysInMonth = 33 - new Date(date.getFullYear(), date.getMonth(), 33).getDate();
				let month = [];
				for (let i = 1; i <= daysInMonth; i++) {
					month.push(new Date(date.getFullYear(), date.getMonth(), i));
				}

				return month;
			};

			const _getQuarter = (date) => {
				const previousDate = new Date(date.getFullYear(), date.getMonth() - 1, 1);
				const previousMonth = _getMonth(previousDate);
				const currentMonth = _getMonth(date);
				const nextDate = new Date(date.getFullYear(), date.getMonth() + 1, 1);
				const nextMonth = _getMonth(nextDate);
				let quarter = [previousMonth, currentMonth, nextMonth];

				return quarter;
			};

			const _getWeeksCount = (year, month) => {
				const startDate = new Date(year, month + 1, 0);
				const weekCount = Math.ceil((startDate.getDate() - (startDate.getDay() ? startDate.getDay() : 7)) / 7) + 1;
				return weekCount;
			};

			const _getVisibleDaysInWeeks = (quarter, startWeekDayNumber) => {
				const startDateTime = new Date(startDate);
				const year = startDateTime.getFullYear();
				const month = startDateTime.getMonth();
				const weekCount = _getWeeksCount(year, month);
				const daysInWeeks = weekCount * 7;
				const cellsCount = this.getIsDetailed() ? 42 : daysInWeeks;
				let daysOfCurrentMonth = quarter[1];
				if (startWeekDayNumber === 0) {
					let nextMonthDays = quarter[2].slice(0, cellsCount - quarter[1].length);
					daysOfCurrentMonth.push(nextMonthDays);
				} else if (startWeekDayNumber === -1) {
					let previousMonthDays = quarter[0].slice(0 - 6);
					let nextMonthDays = quarter[2].slice(0, cellsCount - (quarter[1].length + previousMonthDays.length));
					daysOfCurrentMonth.unshift(previousMonthDays);
					daysOfCurrentMonth.push(nextMonthDays);

				} else {
					let previousMonthDays = quarter[0].slice(0 - startWeekDayNumber);
					let nextMonthDays = quarter[2].slice(0, cellsCount - (quarter[1].length + previousMonthDays.length));
					daysOfCurrentMonth.unshift(previousMonthDays);
					daysOfCurrentMonth.push(nextMonthDays);
				}
				daysOfCurrentMonth = daysOfCurrentMonth.flat(1);

				const splitForWeeks = (array, chunk) => {
					const newArray = [];
					for (let i = 0; i < array.length; i += chunk) {
						newArray.push(array.slice(i, i + chunk));
					}

					return newArray;
				};

				const weeksCount = 7;
				const daysPerWeeks = splitForWeeks(daysOfCurrentMonth, weeksCount);

				return daysPerWeeks;
			};

			const firstDay = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
			let quarter = _getQuarter(firstDay);
			let startWeekDayNumber = firstDay.getDay() - 1;

			const visibleWeeks = _getVisibleDaysInWeeks(quarter, startWeekDayNumber);
			const calendarContainer = new HBox({
				wrap: 'Wrap',
				alignItems: 'Start'
			});
			calendarContainer.addStyleClass(`${cssClass}-calendar`);

			const dayNames = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
			dayNames.forEach((day, index) => {
				const dayNameCell = new VBox({
					wrap: 'Wrap'
				});

				const dayNameCellClass = index > 4 ? `${cssClass}-days-names-weekend` : `${cssClass}-days-names`;
				dayNameCell.addStyleClass(dayNameCellClass);
				const text = new Text({
					text: day
				});
				text.addStyleClass(`rma-calendar-days-names`);
				dayNameCell.addItem(text);
				calendarContainer.addItem(dayNameCell);
			});

			const _findAppointmentPlaceholderForDay = (date, appointments) => {
				const appointmentForDay = appointments.filter((appointment) => {
					const appointmentStartDate = new Date(appointment.StartDateTime);
					const appointmentEndDate = new Date(appointment.EndDateTime);
					return new Date(date.getFullYear(), date.getMonth(), date.getDate(), appointmentStartDate.getHours(), appointmentStartDate.getMinutes()) >=
						appointmentStartDate && new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0) <= appointmentEndDate;
				});
				return appointmentForDay;
			};

			const _checkIsThisStartDay = (appointment, date) => {
				const appointmentStartDate = new Date(appointment.StartDateTime);
				const eventStartDate = new Date(appointmentStartDate.getFullYear(), appointmentStartDate.getMonth(), appointmentStartDate.getDate(),
					appointmentStartDate.getHours(), appointmentStartDate.getMinutes());
				const startDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), appointmentStartDate.getHours(),
					appointmentStartDate.getMinutes());
				const isThisStartDay = +startDate === +appointmentStartDate;

				return isThisStartDay;
			};

			const _getAppointmentsDuration = (appointment) => {
				const startDate = new Date(appointment.StartDateTime);
				const startDay = startDate.getDate();
				const endDate = new Date(appointment.EndDateTime);
				const endDay = endDate.getDate();
				if (startDay !== endDay) {
					endDate.setHours(23);
				}
				const daysLag = Math.ceil(Math.abs(endDate.getTime() - startDate.getTime()) / (1000 * 3600 * 24));

				return daysLag;
			};

			const addDays = (date, days) => {
				let result = new Date(date);
				result.setDate(result.getDate() + days);
				return result;
			};

			const minusDays = (date, days) => {
				let result = new Date(date);
				result.setDate(result.getDate() - days);
				return result;
			};

			const _handleBorderReached = (appointment, dateOfWeekEnd) => {
				const firstPartOfAppointment = JSON.parse(JSON.stringify(appointment));
				firstPartOfAppointment.EndDateTime = minusDays(dateOfWeekEnd, 1);

				const secondPartOfAppointment = JSON.parse(JSON.stringify(appointment));
				secondPartOfAppointment.StartDateTime = dateOfWeekEnd;
				appointments.push(secondPartOfAppointment);

				return {
					firstPartOfAppointment,
					secondPartOfAppointment
				};
			};

			const _checkIfBorderReached = (weekDay, appointmentDuration) => {
				const ifBorderReached = (7 - weekDay) < appointmentDuration;
				return ifBorderReached;
			};

			const _getEuroWeekDay = (date) => {
				let day = date.getDay();
				if (day == 0) {
					day = 7;
				}
				return day - 1;
			};

			const _getSplittedAppointment = (appointment) => {
				const splittedAppointment = [];

				const _splitAppointment = (appointment) => {
					const startDate = new Date(appointment.StartDateTime);
					const weekDay = _getEuroWeekDay(startDate);
					const appointmentDuration = _getAppointmentsDuration(appointment);

					const daysUntilWeekEnd = 7 - weekDay;
					const weekEnd = addDays(startDate, daysUntilWeekEnd);

					if (_checkIfBorderReached(weekDay, appointmentDuration)) {
						const splitted = _handleBorderReached(appointment, weekEnd);
						splittedAppointment.push(splitted.firstPartOfAppointment);
						_splitAppointment(splitted.secondPartOfAppointment);
					} else {
						splittedAppointment.push(appointment);
					}
				};
				_splitAppointment(appointment);

				return splittedAppointment;
			};

			const _getSplittedAppointments = (appointments) => {
				const splittedAppointments = [];
				appointments.forEach((appointment) => {
					splittedAppointments.push(_getSplittedAppointment(appointment));
				});

				return splittedAppointments.flat(1);
			};

			const splittedAppointments = _getSplittedAppointments(appointments);
			const _getLevelMatrixForWeek = () => {
				const levelMatrixForWeek = [];
				for (let i = 0; i < 7; i++) {
					const levelMatrixForDay = [];
					for (let j = 0; j < 3; j++) {
						const level = {
							level: j,
							empty: true
						};
						levelMatrixForDay.push(level);
					}
					levelMatrixForWeek.push(levelMatrixForDay);
				}

				return levelMatrixForWeek;
			};
			const _getAppointmentFromPreviousDay = (date, appointments, id) => {
				if (date) {
					const appointmentsPlaceholderForPreviousDay = _findAppointmentPlaceholderForDay(date, appointments);
					const currentAppointmentFromPreviousDay = appointmentsPlaceholderForPreviousDay.find((item) => item.EventID === id);

					return currentAppointmentFromPreviousDay;
				}
			};

			const _addLevelToMatrix = (matrix, day, duration, level) => {
				for (let d = 0; d < duration; d++) {
					matrix[day + d].push({
						level,
						empty: false
					});
				}
			};

			const _setLevelToAppointment = (appointments) => {
				for (let i = 0; i < visibleWeeks.length; i++) {
					const visibleDays = visibleWeeks[i];
					const currentWeekMatrix = _getLevelMatrixForWeek();
					for (let j = 0; j < visibleDays.length; j++) {
						let appointmentsPlaceholderForDay = _findAppointmentPlaceholderForDay(visibleDays[j], appointments)
							.sort((nextEvent, currentEvent) => {
								if (nextEvent.delivery > currentEvent.delivery) {
									return -1;
								}
							});
						/*	appointmentsPlaceholderForDay.sort((nextEvent, currentEvent) => {
								if (nextEvent.displayName.includes("Flexible") && !currentEvent.displayName.includes("Flexible")) {
									return -1;
								} else if (currentEvent.displayName.includes("Flexible") && nextEvent.displayName.includes("Release")) {
									return 1;
								} else if (nextEvent.displayName.includes("Release") && (!currentEvent.displayName.includes("Release") && !currentEvent.displayName
										.includes("Flexible"))) {
									return -1;
								}
								return 0;
							});*/

						appointmentsPlaceholderForDay.forEach((appointment) => {
							const currentAppointmentFromPreviousDay = _getAppointmentFromPreviousDay(visibleWeeks[i][j - 1], appointments, appointment.EventID);

							const appointmentDuration = _getAppointmentsDuration(appointment);
							/*	if (appointment.EventType === 'DELIVERY_EVENT') {
									const appointmentDelivery = appointment.delivery;
									const mainEvent = appointmentsPlaceholderForDay.find((event) => event.delivery === appointmentDelivery);
									let nextLevel = mainEvent.level + 1;
									const hasMainEvent = appointmentsPlaceholderForDay.find((event) => event.type === "DELIVERY");
									if (!hasMainEvent) {
										let eventsWithLevel = appointmentsPlaceholderForDay.filter(event => event.hasOwnProperty('level'));
										if (eventsWithLevel.length === appointmentsPlaceholderForDay.length) {
											appointmentsPlaceholderForDay.forEach((event) => delete event.level);
											eventsWithLevel = [];
										}
										if (eventsWithLevel.length === 0) {
											nextLevel = 0;
										} else {
											const previousEvent = eventsWithLevel.reduce((acc, curr) => acc.level > curr.level ? acc : curr);
											nextLevel = previousEvent.level + 1;
										}
									}
									const nextLevelMatrix = currentWeekMatrix[j][nextLevel];

									if (nextLevelMatrix && nextLevelMatrix.empty) {
										appointment.level = nextLevel;
										if (nextLevel < 3) {
											for (let d = 0; d < appointmentDuration; d++) {
												currentWeekMatrix[j + d][nextLevel].empty = false;
											}
										} else {
											_addLevelToMatrix(currentWeekMatrix, j, appointmentDuration, nextEmptyLevel);
										}
									} else {
										let nextEmptyLevel = nextLevel + 1;
										let emptyLevelMatrix = currentWeekMatrix[j][nextEmptyLevel];
										while (emptyLevelMatrix && emptyLevelMatrix.empty === false) {
											nextEmptyLevel++;
											emptyLevelMatrix = currentWeekMatrix[j][nextEmptyLevel];
										}
										appointment.level = nextEmptyLevel;
										if (nextEmptyLevel < 3) {
											for (let d = 0; d < appointmentDuration; d++) {
												currentWeekMatrix[j + d][nextEmptyLevel].empty = false;
											}

										} else {
											_addLevelToMatrix(currentWeekMatrix, j, appointmentDuration, nextEmptyLevel);
										}
									}

								} else {*/
							const emptyLevel = currentWeekMatrix[j].find((level) => level.empty);
							if (!currentAppointmentFromPreviousDay) {
								if (emptyLevel) {
									let level = emptyLevel.level;
									appointment.level = level;

									for (let d = 0; d < appointmentDuration; d++) {
										if (currentWeekMatrix[j + d]) currentWeekMatrix[j + d][level].empty = false;
									}
								} else {
									const nextFreeLevel = currentWeekMatrix[j].reduce((acc, curr) => acc.b > curr.b ? acc : curr).level + 1;
									appointment.level = nextFreeLevel;
									_addLevelToMatrix(currentWeekMatrix, j, appointmentDuration, nextFreeLevel);
								}
							}
							//	}
						});
					}
				}
			};

			_setLevelToAppointment(splittedAppointments);
			const startDateMonth = new Date(startDate).getMonth();
			for (let i = 0; i < visibleWeeks.length; i++) {
				const visibleDays = visibleWeeks[i];
				for (let j = 0; j < visibleDays.length; j++) {
					const currentDate = visibleDays[j];
					const dayCell = new VBox({
						// wrap: 'Wrap',
					});
					if (j > 4) {
						dayCell.addStyleClass(`${cssClass}-calendar-cell-weekend`);
					} else {
						dayCell.addStyleClass(`${cssClass}-calendar-cell`);
					}

					let oFormat = sap.ui.core.format.DateFormat.getInstance({
						format: "yMMMd"
					});
					const tDay = oFormat.format(new Date());
					const curDate = oFormat.format(currentDate);
					if (tDay === curDate) {
						dayCell.addStyleClass(`${cssClass}-calendar-cell-today`);
						const dayNameContainer = new HBox({});
						dayNameContainer.addStyleClass(`${cssClass}-day-container`);
						dayCell.addItem(dayNameContainer);
						calendarContainer.addItem(dayCell);
					}
					const dayNameContainer = new HBox({});
					dayNameContainer.addStyleClass(`${cssClass}-day-container`);
					const text = new Text({
						text: visibleDays[j].getDate()
					});

					if (startDateMonth !== currentDate.getMonth()) {
						text.addStyleClass(`not-current-month-day`);
					}
					if (tDay === curDate) {
						text.addStyleClass(`${cssClass}-calendar-cell-tday`);
					}
					dayNameContainer.addItem(text);
					dayCell.addItem(dayNameContainer);
					let appointmentsPlaceholderForDay = _findAppointmentPlaceholderForDay(visibleDays[j], splittedAppointments)
						.sort((prev, next) => {
							if (prev.level < next.level) {
								return -1;
							}
						});

					const appointmentContainer = new VBox({});
					appointmentContainer.addStyleClass(`${cssClass}-appointments-container`);

					/*	const buttonMoreContainer = new HBox();
					buttonMoreContainer.addStyleClass(`${cssClass}-button-more-container`);

				function onMoreButtonPressed() {
						const appointmentHeight = 22;
						const view = this.getParent().getParent();
						const sortedAppointment = _findAppointmentPlaceholderForDay(visibleDays[j], splittedAppointments)
							.sort((prev, next) => {
								if (prev.level < next.level) {
									return -1;
								}
							});
						const popoverAppointmentsContainer = new VBox({});
						const popoverWidth = '375px';
						const calendarType = 'full';

						sortedAppointment.forEach((appointmentForDay) => {
							const appointmentPlaceholder = new HBox({
								height: `${appointmentHeight}px`
							});
							const appointment = new CustomAppointment({
								event: appointmentForDay,
								color: appointmentForDay.color,
								width: popoverWidth,
								calendarType,
								popover,
								isPopover: true
							});
							appointmentPlaceholder.addItem(appointment);
							appointment.addStyleClass(`${cssClass}-popover-appointment`);
							popoverAppointmentsContainer.addItem(appointmentPlaceholder);
						});

						const overallPopoverContentHeight = sortedAppointment.length * appointmentHeight;
						const overallPopover = new Popover({
							contentWidth: popoverWidth,
							contentHeight: `${overallPopoverContentHeight}px`,
							horizontalScrolling: false,
							showArrow: false,
							placement: 'Bottom',
							showHeader: false
						});
						overallPopover.addStyleClass(`${cssClass}-calendar-overall-popover`);

						overallPopover.addContent(popoverAppointmentsContainer);
						if (overallPopover) {
							if (overallPopover.isOpen()) {
								overallPopover.close();
							} else {
								overallPopover.openBy(dayNameContainer);
							}
						} else {
							view.addDependent(appointmentPopover);
							overallPopover.openBy(dayNameContainer);
						}

					}*/

					/*	if (calendarType === 'full') {
							const invisibleAppointment = appointmentsPlaceholderForDay.filter((appointment) => appointment.level > 2);

							if (invisibleAppointment.length) {
								appointmentsPlaceholderForDay = appointmentsPlaceholderForDay.slice(0, 3);
								const moreText = new Link({
									text: `+${invisibleAppointment.length} more`,
									press: onMoreButtonPressed.bind(this),
								});
								buttonMoreContainer.addItem(moreText);
							}
						}*/
					let placeHolderVBoxes = [];
					for (let level = 0; level <= 2; level++) {
						const placeHolderVBox = new VBox();
						placeHolderVBox.addStyleClass(`${cssClass}-appointment-placeholder`);
						appointmentContainer.addItem(placeHolderVBox);

						placeHolderVBoxes.push(placeHolderVBox);
					}

					appointmentsPlaceholderForDay
						.forEach((appointmentPlaceholderForDay, index) => {
							const level = appointmentPlaceholderForDay.level;
							if (level !== null) {
								const placeHolderVBox = placeHolderVBoxes[level];
								if (placeHolderVBox && _checkIsThisStartDay(appointmentPlaceholderForDay, visibleDays[j])) {
									const appointment = new CustomAppointment({
										event: appointmentPlaceholderForDay,
										color: appointmentPlaceholderForDay.color,
										calendarType,
										popover
									});
									placeHolderVBox.addItem(appointment);
								}
							}
						});
					dayCell.addItem(appointmentContainer);
					//		dayCell.addItem(buttonMoreContainer);
					calendarContainer.addItem(dayCell);
				}
			}

			if (calendarType === 'compact') {
				const calendarClicked = () => {
					this.fireEvent("change", {
						value: startDate
					});

					//this.setViewMode('month');
					//this.setStartDate(startDate);
				};
				calendarContainer.attachBrowserEvent(
					'click',
					calendarClicked.bind(this),
					this
				);
			}
			return calendarContainer;
		},

		/*_getQuarterCalendarContent: function () {
			const quarters = [
				[0, 1, 2],
				[3, 4, 5],
				[6, 7, 8],
				[9, 10, 11]
			];
			const calendarStartDate = new Date(this.getStartDate());
			const currentMonth = calendarStartDate.getMonth();
			const currentYear = calendarStartDate.getFullYear();
			const currentQuarter = quarters.find((quarter) => quarter.includes(currentMonth));
			const firstVisibleMonthStartDate = new Date(currentYear, currentQuarter[0], 1);
			this.setFirstVisibleMonthStart(firstVisibleMonthStartDate);
			const calendarContainer = new HBox({
				wrap: 'Wrap',
				justifyContent: 'SpaceAround'
			});
			const calendarType = 'compact';
			currentQuarter.forEach((month) => {
				const startDate = new Date(currentYear, month, 1);
				const container = new VBox({
					height: '80vh',
					alignItems: 'Center',
					justifyContent: 'Center'
				});
				const monthName = new Date(startDate).toLocaleString('en', {
					month: 'long'
				});
				const textMonthName = new Text({
					text: monthName,
					width: '285px',
					textAlign: 'Center'
				});
				textMonthName.addStyleClass(`small-calendar-month-name`);
				container.addItem(textMonthName);
				const compactContainer = this._getCalendar(calendarType, startDate);
				container.addItem(compactContainer);
				calendarContainer.addItem(container);
			});
			return calendarContainer;
		},*/

		_getYearCalendarContent: function () {
			const calendarYear = new Date(this.getStartDate()).getFullYear();
			const startDates = [
				new Date(calendarYear, 0, 1), new Date(calendarYear, 1, 1), new Date(calendarYear, 2, 1),
				new Date(calendarYear, 3, 1), new Date(calendarYear, 4, 1), new Date(calendarYear, 5, 1),
				new Date(calendarYear, 6, 1), new Date(calendarYear, 7, 1), new Date(calendarYear, 8, 1),
				new Date(calendarYear, 9, 1), new Date(calendarYear, 10, 1), new Date(calendarYear, 11, 1)
			];

			const firstVisibleMonthStartDate = new Date(calendarYear, 0, 1);
			this.setFirstVisibleMonthStart(firstVisibleMonthStartDate);
			const calendarContainer = new HBox({
				wrap: 'Wrap',
				justifyContent: 'SpaceAround'
			});
			const calendarType = 'compact';
			startDates.forEach((startDate) => {
				const container = new VBox();
				const monthName = new Date(startDate).toLocaleString('en', {
					month: 'long'
				});
				const textMonthName = new Text({
					text: monthName,
					width: '285px',
					textAlign: 'Center'
				});
				textMonthName.addStyleClass(`small-calendar-month-name`);
				container.addItem(textMonthName);
				const compactContainer = this._getCalendar(calendarType, startDate);
				container.addItem(compactContainer);
				calendarContainer.addItem(container);
			});
			return calendarContainer;
		},

		/*_getCompactCalendar: function (startDate) {
			const calendarType = 'compact';
			const calendar = this._getCalendar(calendarType, startDate);

			return calendar;
		},*/

		_getFullCalendar: function (startDate) {
			const calendarType = 'full';
			const viewMode = this.getViewMode();
			let calendar;
			switch (viewMode) {
				/*case 'month':
					this.setFirstVisibleMonthStart(startDate);
					calendar = this._getCalendar(calendarType, startDate);
					break;
				case 'quarter':
					calendar = this._getQuarterCalendarContent();
					break;*/
			case 'year':
				calendar = this._getYearCalendarContent();
				break;
			}

			return calendar;
		},

		_addContentToScrollContainer: function () {
			this.setBusy(true);
			this.getParent().setBusy(true);
			const calendarType = this.getType();
			const startDate = new Date(this.getStartDate());

			let header;
			let calendar;
			if (calendarType === 'full') {
				header = this._getFullCalendarHeader();
				calendar = this._getFullCalendar(startDate);
			}
			/*else {
				header = this._getCompactCalendarHeader();
				calendar = this._getCompactCalendar(startDate);
			}*/
			const scrollContainer = this.getAggregation('_scrollContainer');
			scrollContainer.destroyContent();
			if (this.getIsCard() !== true) {
				scrollContainer.addContent(header);
			}
			scrollContainer.addContent(calendar);
			this.setBusy(false);
			this.getParent().setBusy(false);
		},

		renderer: function (oRm, oControl) {
			const calendarType = oControl.getType();
			const cssClass = calendarType === 'full' ? 'rma' : 'rma-small';
			var currYear = new Date(oControl.getStartDate()).getFullYear();
			var scrollContent = oControl.getAggregation("_scrollContainer").getContent();
			if (scrollContent.length > 0) var yearHeader = scrollContent[0].getItems()[1].getText();
			if (!yearHeader || currYear.toString() !== yearHeader) oControl._addContentToScrollContainer();
			oRm.write('<div');
			oRm.addClass(`${cssClass}-calendar-container`);
			oRm.writeClasses(oControl);
			oRm.writeControlData(oControl);
			oRm.write('>');

			const scrollContainer = oControl.getAggregation('_scrollContainer');
			oRm.renderControl(scrollContainer);
			oRm.write('</div>');
		},

		onAfterRendering: function () {
			if (sap.ui.core.Control.prototype.onAfterRendering) {
				sap.ui.core.Control.prototype.onAfterRendering.apply(this, arguments);
			}
		}
	});
});