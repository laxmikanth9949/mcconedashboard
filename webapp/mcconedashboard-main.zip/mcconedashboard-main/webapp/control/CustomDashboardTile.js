sap.ui.define([
	"sap/ui/core/Control",
	"sap/f/Card",
	"com/sap/mcconedashboard/control/CustomDashboardTileItem"
], function (Control, Card, CustomDashboardTileItem) {
	"use strict";
	return Control.extend("com.sap.mcconedashboard.control.CustomDashboardTile", {
		metadata: {
			properties: {
				headerFilterIconSrc: {
					type: "string",
					defaultValue: ""
				},
				headerInfoIconText: {
					type: "string",
					defaultValue: ""
				},
				headerTitle: {
					type: "string",
					defaultValue: ""
				},
				subheaderTitle: {
					type: "string",
					defaultValue: ""
				},
				numberAll: {
					type: "string",
					defaultValue: "0"
				},
				showNumberAll: {
					type: "boolean",
					defaultValue: true
				},
				headerTitleIconSrc: {
					type: "string",
					defaultValue: ""
				},
				icon: {
					type: "string",
					defaultValue: ""
				},
				iconColor: {
					type: "string",
					defaultValue: ""
				},
				busyAll: {
					type: "boolean",
					defaultValue: true
				}
			},
			aggregations: {
				_card: {
					type: "sap.f.Card",
					multiple: false,
					visibility: "hidden"
				},
				items: {
					type: "com.sap.mcconedashboard.control.CustomDashboardTileItem",
					multiple: true
				},
				defaultAggregation: "items"
			},
			events: {
				press: {
					parameters: {}
				}
			}
		},

		onBeforeRendering: function () {
			this.setBusyIndicatorDelay(0);
			this._initCard();
		},

		onAfterRendering: function () {
			//attach click even
			$("#" + this.getAggregation("_card").getId()).click(function (oEv) {
				if (oEv.target.className !== "sapMObjStatusText") {
					this.firePress();
				}
			}.bind(this));
		},

		_initCard: function () {
			var oCard = new Card({
				width: "12rem",
				height: "11rem",
				tooltip: this.getHeaderInfoIconText()
			});
			if ((this.getHeaderTitle() === "Global Customer Escalations" || this.getHeaderTitle() === "Cross Issue Management") && this.getModel(
					"settings").getProperty("/isAnonymizedMode")) {
				oCard.addStyleClass("NoHoverTile");
			} else {
				oCard.addStyleClass("customTile");
			}

			var oCardContainer = this._getCardContainer();
			oCard.setContent(oCardContainer);
			oCard.addStyleClass("MCCOneCardMinWidth");
			this.setAggregation("_card", oCard);
		},

		_getCardContainer: function () {
			var oContainer = new sap.m.VBox({
				width: "100%"
			});
			oContainer.addStyleClass("sapUiSmallMargin");

			//add header
			this._addCardContainerHeader(oContainer);
			//add filter text
			this._addCardContainerFilter(oContainer);

			var oHorizontalBox = new sap.m.HBox({
				height: "100%"
			});

			//add all number
			this._addCardContainerAllNumber(oHorizontalBox);
			//add items
			this._addCardContainerItems(oHorizontalBox);

			oContainer.addItem(oHorizontalBox);

			return oContainer;
		},

		_addCardContainerHeader: function (oContainer) {
			var oBox = new sap.m.HBox({
				alignItems: "Start",
				justifyContent: "SpaceBetween",
				height: "4rem",
				width: "100%"
			});

			var oTextTitle = new sap.m.Title({
				text: this.getHeaderTitle(),
				titleStyle: "H5",
				wrapping: true,
			}).addStyleClass("MCCOneDashboardTileHeader");
			oBox.addItem(oTextTitle);
			//use icon or text
			if (this.getHeaderTitleIconSrc() && this.getHeaderTitleIconSrc() !== "") {
				oBox.setBusy(true);
				var oImageTitle = new sap.m.Image({
					src: this.getHeaderTitleIconSrc(),
					tooltip: this.getHeaderTitle(),
					alt: this.getHeaderTitle(),
					load: function () {
						oTextTitle.setVisible(false);
						oBox.setBusy(false);
					},
					error: function () {
						oImageTitle.setVisible(false);
						oBox.setBusy(false);
					}
				}).addStyleClass("MCCOneDashboardTileHeaderIcon");
				oBox.addItem(oImageTitle);
			}

			oBox.addItem(new sap.ui.core.Icon({
				src: !this.getBindingInfo("headerFilterIconSrc") ? this.getHeaderFilterIconSrc() : "{" + this.getBindingInfo(
					"headerFilterIconSrc").parts[0].model + ">" + this.getBindingInfo(
					"headerFilterIconSrc").parts[0].path + "}",
				width: "1rem"
			}));

			/*oBox.addItem(new sap.ui.core.Icon({
				src: "sap-icon://message-information",
				width: "1rem",
				tooltip: this.getHeaderInfoIconText(),
				press: function (oEv) {
					var headerTitle = this.getHeaderTitle();
					var headerText = this.getHeaderInfoIconText();
					if (!this.cardInfoPopover) {
						this.cardInfoPopover = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.ObjectInfoCard", this);
					}
					this.cardInfoPopover.setModel(new sap.ui.model.json.JSONModel({
						title: headerTitle,
						msg: headerText
					}), "infoPopup");
					this.cardInfoPopover.openBy(oEv.getSource());
				}.bind(this)
			}));*/

			oContainer.addItem(oBox);
		},

		_addCardContainerFilter: function (oContainer) {
			var oBox = new sap.m.HBox({
				justifyContent: "SpaceBetween"
			});

			if (this.getSubheaderTitle() && this.getSubheaderTitle() === "HIDDEN") {
				//for some tiles we do not want to show anything and therefore nothing should be added
			} else if (this.getSubheaderTitle() && this.getSubheaderTitle() !== "") {
				oBox.addItem(new sap.m.Label({
					text: this.getSubheaderTitle(),
					tooltip: this.getSubheaderTitle(),
					width: "13rem"
				}));
			} else {
				oBox.addItem(new sap.m.Label({
					text: "{= ${filterModel>/region} === '' ? 'Global' : ${filterModel>/regionText}}",
					tooltip: "{= ${filterModel>/region} === '' ? 'Global' : ${filterModel>/regionText}}",
					width: "13rem"
				}));
			}

			oContainer.addItem(oBox);
		},

		_addCardContainerAllNumber: function (oContainer) {
			var oBox = new sap.m.HBox({
				width: "2rem",
				alignItems: "End"
			});

			if (this.getIcon()) {
				oBox.addItem(new sap.ui.core.Icon({
					src: this.getIcon(),
					color: this.getIconColor()
				}).addStyleClass("sapMNCIconImage"));
			}
			if (this.getShowNumberAll()) {
				var oLabel = new sap.m.Label({
					text: this.getNumberAll(),
					busy: this.getBindingInfo("busyAll") && this.getBindingInfo("busyAll").parts ? "{" + this.getBindingInfo("busyAll").parts[0].model +
						">" + this.getBindingInfo("busyAll").parts[0].path + "}" : false,
					width: "4rem"
				}).addStyleClass("MCCOneAllNumberLabel");
				oBox.addItem(oLabel);
			}

			oContainer.addItem(oBox);
		},

		_addCardContainerItems: function (oContainer) {
			var oFlexBox = new sap.m.VBox({
				alignItems: "End",
				width: "100%",
				height: "4.5rem"
			});
			var aItems = this.getItems();
			if (aItems && aItems.length > 0) {
				aItems.forEach(function (item, i) {
					var oItem = null;
					oItem = new com.sap.mcconedashboard.control.CustomDashboardTileItem({
						text: !item.getBindingInfo("text") ? item.getText() : "{" + item.getBindingInfo("text").parts[0].model + ">" + item.getBindingInfo(
							"text").parts[0].path + "}",
						value: !item.getBindingInfo("value") ? item.getValue() : "{" + item.getBindingInfo("value").parts[0].model + ">" + item.getBindingInfo(
							"value").parts[0].path + "}",
						state: !item.getBindingInfo("state") ? item.getState() : "{" + item.getBindingInfo("state").parts[0].model + ">" + item.getBindingInfo(
							"state").parts[0].path + "}",
						busy: !item.getBindingInfo("busy") ? item.getBusy() : "{" + item.getBindingInfo("busy").parts[0].model + ">" + item.getBindingInfo(
							"busy").parts[0].path + "}",
						tooltip: !item.getBindingInfo("tooltip") ? item.getTooltip() : "{" + item.getBindingInfo("tooltip").parts[0].model + ">" +
							item.getBindingInfo(
								"tooltip").parts[0].path + "}",
						press: item.mEventRegistry.press
					}).data("controller", item.data("controller")).data("key", item.data("key")).data("description", item.data("description")).data(
						"serviceTeams", item.data("serviceTeams")).data("tagName", item.data("tagName"));

					if (i < (aItems.length - 1)) {
						oItem.addStyleClass("tinyMarginBottom");
					}
					oFlexBox.addItem(oItem);
				}.bind(this));
			}
			oContainer.addItem(oFlexBox);
		},

		renderer: function (oRm, oControl) {
			oRm.openStart("div", oControl);
			oRm.class("sapUiSmallMargin");
			oRm.openEnd();
			oRm.renderControl(oControl.getAggregation("_card"));
			oRm.close("div");
		}
	});
});