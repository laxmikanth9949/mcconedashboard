sap.ui.define([
	"sap/m/FacetFilterList",
	"sap/m/FacetFilterListRenderer",
	"sap/ui/model/Filter"
], function (FacetFilterList, FacetFilterListRenderer, Filter) {
	"use strict";

	return FacetFilterList.extend("com.sap.mcconedashboard.control.CustomFacetFilterListRegion", {

		/**
		 * Handles the selection/deselection of all items at once.
		 * @param {boolean} bSelected All selected or not
		 * @private
		 */
		_handleSelectAllClick: function (bSelected) {
			if (bSelected) {
				this.setSelectedKeys(JSON.parse(
					'{"APJ":"APJ","EMEA_NORTH":"EMEA North","EMEA_SOUTH":"EMEA South","GTC":"GTC","LAC":"LAC","MEE":"MEE","NA":"NA"}'));
				//in this specific case, we define "select all" as all Regions, but WORLD
				// this.removeSelectedKeys();
				// var aItems = this._getNonGroupItems();
				// aItems.forEach(function (oItem) {
				// 	if (oItem.getKey() === "WORLD") {
				// 		this._removeSelectedKey(oItem.getKey(), oItem.getText());
				// 		oItem.setSelected(bSelected, false);
				// 	} else {
				// 		this._addSelectedKey(oItem.getKey(), oItem.getText());
				// 		oItem.setSelected(bSelected, true);
				// 	}

				// }, this);
			} else { //if select all is unchecked, only WORLD should be selected
				this.setSelectedKeys(JSON.parse('{"WORLD":"World"}'));
			}
			var oCheckbox = sap.ui.getCore().byId(this.getAssociation("allcheckbox"));
			oCheckbox.setSelected(bSelected);
			oCheckbox.rerender();
		},

		renderer: FacetFilterListRenderer
	});

});