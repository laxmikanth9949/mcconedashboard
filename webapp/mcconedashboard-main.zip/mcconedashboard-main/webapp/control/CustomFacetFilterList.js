sap.ui.define([
	"sap/m/FacetFilterList",
	"sap/m/FacetFilterListRenderer",
	"sap/ui/model/Filter"
], function (FacetFilterList, FacetFilterListRenderer, Filter) {
	"use strict";

	return FacetFilterList.extend("com.sap.mcconedashboard.control.CustomFacetFilterList", {

		/**
		 * Filters list items with the given search value.
		 * If an item's text value does not contain the search value then it is filtered out of the list.
		 *
		 * No search is done if the list is not bound to a model.
		 *
		 * @private
		 */

		_search: function (sSearchVal, force) {
			//	FacetFilterList.prototype._search.apply(this, arguments);

			var bindingInfoaFilters;
			var numberOfsPath = 0;

			//Checks whether given model is one of the OData Model(s)
			function isODataModel(oModel) {
				return oModel instanceof sap.ui.model.odata.ODataModel || oModel instanceof sap.ui.model.odata.v2.ODataModel;
			}

			if (force || (sSearchVal !== this._searchValue)) {
				this._searchValue = sSearchVal;
				var oBinding = this.getBinding("items");
				var oBindingInfo = this.getBindingInfo("items");
				if (oBindingInfo && oBindingInfo.binding) {
					bindingInfoaFilters = oBindingInfo.binding.aFilters;
					if (bindingInfoaFilters.length > 0) {
						numberOfsPath = bindingInfoaFilters[0].aFilters.length;
						if (this._firstTime) {
							this._saveBindInfo = bindingInfoaFilters[0].aFilters[0];
							this._firstTime = false;
						}
					}
				}
				if (oBinding) { // There will be no binding if the items aggregation has not been bound to a model, so search is not
					// possible
					if (sSearchVal || numberOfsPath > 0) {
						var path = this.getBindingInfo("items").template.getBindingInfo("text").parts[0].path;
						if (path || path === "") { // path="" will be resolved relativelly to the parent, i.e. actual path will match the parent's one.
							//standard SAPUI5 implementation  var oUserFilter = new Filter(path, sap.ui.model.FilterOperator.Contains, sSearchVal);
							//new for MCC Crit Sit DB
							var oUserFilter = new Filter(path, sap.ui.model.FilterOperator.EQ, sSearchVal);
							if (this.getEnableCaseInsensitiveSearch() && isODataModel(oBinding.getModel())) {
								//notice the single quotes wrapping the value from the UI control!

								//standard SAPUI5 implementation var sEncodedString = "'" + String(sSearchVal).replace(/'/g, "''") + "'";
								//new for MCC Crit Sit DB
								var sEncodedString = String(sSearchVal).toUpperCase();
								//standard SAPUI5 implementation 	oUserFilter = new Filter("tolower(" + path + ")", sap.ui.model.FilterOperator.Contains, sEncodedString);
								//new for MCC Crit Sit DB
								oUserFilter = new Filter(path, sap.ui.model.FilterOperator.EQ, sEncodedString);
							}
							if (numberOfsPath > 1) {
								//changed for MCC Crit Sit DB - order of filter in array
								var oFinalFilter = new Filter([this._saveBindInfo, oUserFilter], true);
							} else {
								if (this._saveBindInfo > "" && oUserFilter.sPath != this._saveBindInfo.sPath) {
									//changed for MCC Crit Sit DB - order of filter in array
									var oFinalFilter = new Filter([this._saveBindInfo, oUserFilter], true);
								} else {
									if (sSearchVal == "") {
										var oFinalFilter = [];
									} else {
										//standard SAPUI5 implementation var oFinalFilter = new Filter([oUserFilter], true);
										//new for MCC Crit Sit DB
										var oFinalFilter = new Filter([oBindingInfo.filters.aFilters[0], oUserFilter].filter(Boolean), true);
									}
								}
							}
							//oBindingInfo.filters=[];
							oBinding.filter(oFinalFilter, sap.ui.model.FilterType.Control);
							//new for MCC Crit Sit DB
							//	oBindingInfo.filters.aFilters[1]= oUserFilter;
						}
					} else {
						//new for MCC Crit Sit DBoBindingInfo.filters.aFilters[1]= oUserFilter;
						oBinding.filter([], sap.ui.model.FilterType.Control);
					}
				} else {
					jQuery.sap.log.warning("No filtering performed", "The list must be defined with a binding for search to work",
						this);
				}
			}

		},

		renderer: FacetFilterListRenderer
	});

});