sap.ui.define(['sap/m/PlanningCalendarLegend', 'sap/ui/unified/CalendarAppointment', 'sap/ui/core/Core',
		'sap/m/PlanningCalendarLegendRenderer'
	],
	function (CalendarLegend, CalendarAppointment, Core, PlanningCalendarLegendRenderer) {
		"use strict";

		var CustomCalendarLegend = CalendarLegend.extend("com.sap.mcconedashboard.control.CustomCalendarLegend", /** @lends sap.m.PlanningCalendarLegend.prototype */ {
			metadata: {
				properties: {
					extraItemsHeader: {
						type: "string",
						group: "Appearance"
					}
				},
				aggregations: {
					extraItems: {
						type: "sap.ui.unified.CalendarLegendItem",
						multiple: true,
						singularName: "extraItem"
					}
				},
				designtime: "sap/m/designtime/PlanningCalendarLegend.designtime"
			}
		});

		/*
		 * Finds the legend text for a given appointment or legend item.
		 *
		 * @param {sap.m.PlanningCalendarLegend} oLegend A legend
		 * @param {sap.ui.unified.CalendarLegendItem|sap.ui.unified.CalendarAppointment} oSpecialItem An appointment or a legend type
		 * @returns {string} The matching legend item's default text.
		 * @private
		 */
		CustomCalendarLegend.findLegendItemForItem = function (oLegend, oSpecialItem) {
			var aLegendAppointments = oLegend ? oLegend.getAppointmentItems() : null,
				aLegendItems = oLegend ? oLegend.getItems() : null,
				aExtraItems = oLegend ? oLegend.getExtraItems() : null,
				bAppointmentItem = oSpecialItem instanceof CalendarAppointment,
				aItems = bAppointmentItem ? aLegendAppointments : aLegendItems,
				oItemType = bAppointmentItem ? oSpecialItem.getType() : oSpecialItem.type,
				oItem,
				sLegendItemText,
				i;
			debugger
			if (aItems && aItems.length) {
				for (i = 0; i < aItems.length; i++) {
					oItem = aItems[i];
					if (oItem.getType() === oItemType) {
						sLegendItemText = oItem.getText();
						break;
					}
				}
			}

			// if the special item's type is not present in the legend's items,
			// the screen reader has to read it's type
			if (!sLegendItemText) {
				sLegendItemText = oItemType;
			}

			return sLegendItemText;
		};

		CustomCalendarLegend.prototype._getExtraItemsHeader = function () {
			var sAppointmentItemsHeader = this.getExtraItemsHeader();

			if (sAppointmentItemsHeader === undefined) {
				return Core.getLibraryResourceBundle('sap.m').getText("PLANNING_CALENDAR_LEGEND_APPOINTMENT_ITEMS_HEADER");
			}

			return sAppointmentItemsHeader;
		};

		return CustomCalendarLegend;
	});