sap.ui.define(["sap/m/SuggestionItem"],
	function (SuggestionItem) {
		"use strict";

		return SuggestionItem.extend("com.sap.mcconedashboard.control.CustomSuggestionItem", {
			metadata: {
				properties: {},
				aggregations: {
					infoLabel: {
						type: "sap.tnt.InfoLabel",
						multiple: false
					},
					topMatchLabel: {
						type: "sap.tnt.InfoLabel",
						multiple: false
					},
					favbutton: {
						type: "sap.m.Button",
						multiple: false
					}
				},
				events: {
					itemSelected: {
						parameters: {
							customerId: {
								type: "string"
							}
						}
					}
				}
			},

			render: function (oRenderManager, oItem, sSearch, bSelected) {
				oRenderManager.openStart("div").class("MCCCritSitDashboardSearchField");
				oRenderManager.openEnd();
				SuggestionItem.prototype.render.call(this, oRenderManager, oItem, sSearch, bSelected);
				oRenderManager.renderControl(oItem.getAggregation("topMatchLabel"));
				oRenderManager.renderControl(oItem.getAggregation("infoLabel"));
				oRenderManager.renderControl(oItem.getAggregation("favbutton"));
				oRenderManager.close("div");
			}

		});
	});