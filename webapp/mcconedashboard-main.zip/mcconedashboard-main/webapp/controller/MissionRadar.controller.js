sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"sap/ui/core/HTML",
	"./../connector/TranslationConnector",
	"sap/m/MessageBox",
	"sap/base/Log",

], function (BaseController, formatter, HTML, TranslationConnector, MessageBox, Logger) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.MissionRadar", {

		formatter: formatter,

		onInit: function () {


			// set explored app's demo model on this sample

			this.getView().setModel(new sap.ui.model.json.JSONModel({
				bLoadingState: false,
				bLoadingStatePA: false,
				showObjectType: false
			}), "viewModel");

			this.getRouter().getRoute("MissionRadar").attachPatternMatched(this._onObjectMatched, this);

			var oIconTabBar = this.getView().byId("idIconTabBarMissionRadar");
			oIconTabBar.attachSelect(this.onTabSelect, this);
		},

		onAfterRendering: function () {
		},

		_onObjectMatched: function (oEvent) {
			if (this.getOwnerComponent().getModel("data").getProperty("/reloadMissionRadar")) {
				this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "mrGoLivesData");
				this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "mrCriticalCustomerData");
				this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "mrGoLiveTrendData");
				this.getOwnerComponent().getModel("data").setProperty("/reloadMissionRadar", false);
			}

			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			var that = this;
			this._handleFeatureFlags(oArgs, function (flags) {
				if (flags.showAiSummary !== true) {
					var oTable = that.byId("mrCCtable");
					var oColumn = that.byId("mrAiSummaryColumn");
					var oColumnGoLives = that.byId("mrAiSummaryColumnGoLives");
					oTable.removeColumn(oColumn);
					oTable.removeColumn(oColumnGoLives);
				}
			});

			this.updateCriticalCustomers();
			this.updateGoLivesFromHPI();
		},

		onTabSelect: function (oEvent) {
			var oIconTabBar = this.getView().byId("idIconTabBarMissionRadar");
			var sSelectedKey = oIconTabBar.getSelectedKey();

			if (sSelectedKey === "missionRadarCriticalCustomers") {
				//		this.updateCriticalCustomers();
			} else if (sSelectedKey === "missionRadarGoLives") {
				//		this.updateGoLivesFromHPI();
			}
		},

		updateCriticalCustomers: function () {
			var viewModel = this.getView().getModel("viewModel");
			viewModel.setProperty("/bLoadingStateCriticalCustomers", true);

			var oModel = new sap.ui.model.json.JSONModel();
			this.getOwnerComponent().setModel(oModel, "mrCriticalCustomerData");

			var that = this;
			this.readMissionRadarCriticalCustomers(oModel, function () {
				var oData = oModel.getData();

				if (oData && oData.items && Array.isArray(oData.items)) {
					// Use Map to store unique items based on CUSTOMER_ID
					var uniqueCustomers = new Map();

					oData.items.forEach(function (item) {
						var customerId = item.CUSTOMER_ID.key;
						var mainSolArea = that.shortenSolutionAreaName(item.MCC_SOL_AREA.key);

						// Treat "unassigned" as rank 99 so it is never the Main Sol Area
						if (item.MCC_SOL_AREA.key === "unassigned") {
							item.MCC_SOL_AREA_RANK.key = 99;
							mainSolArea = "";
						}

						if (!uniqueCustomers.has(customerId)) {
							// Initialize the structure for uniqueCustomers
							uniqueCustomers.set(customerId, {
								...item,
								MAIN_SOL_AREA: mainSolArea !== "unassigned" ? mainSolArea : "",
								SEC_SOL_AREAS: []
							});
						} else {
							var existingCustomer = uniqueCustomers.get(customerId);

							// Check if the current item has a lower MCC_SOL_AREA_RANK
							if (item.MCC_SOL_AREA_RANK.key < existingCustomer.MCC_SOL_AREA_RANK.key) {
								// Move the current MAIN_SOL_AREA to SEC_SOL_AREAS if it is not "unassigned"
								if (existingCustomer.MAIN_SOL_AREA && existingCustomer.MAIN_SOL_AREA !== "unassigned" && existingCustomer.MAIN_SOL_AREA !== "") {
									existingCustomer.SEC_SOL_AREAS.push(existingCustomer.MAIN_SOL_AREA);
								}
								// Update MAIN_SOL_AREA with the new item if it is not "unassigned"
								if (mainSolArea && mainSolArea !== "unassigned" && mainSolArea !== "") {
									existingCustomer.MAIN_SOL_AREA = mainSolArea;
								}
								existingCustomer.MCC_SOL_AREA_RANK = item.MCC_SOL_AREA_RANK; // Update the rank
							} else {
								// Add the current MCC_SOL_AREA to SEC_SOL_AREAS if it is not "unassigned"
								if (mainSolArea && mainSolArea !== "unassigned" && mainSolArea !== "") {
									existingCustomer.SEC_SOL_AREAS.push(mainSolArea);
								}
							}
						}
					});

					// Convert uniqueCustomers Map back to array
					oData.items = Array.from(uniqueCustomers.values());

					oData.items.forEach(function (item) {
						item.SEC_SOL_AREAS = item.SEC_SOL_AREAS.join(", ");
						item.MCCiRounded = Math.round(item.MCCI.value);
						item.TrendRounded = Math.round(item.TREND_28_DAYS.value);
						item.TrendRoundedThreeDays = Math.round(item.TREND_3_DAYS.value);
						item.OtherCases = item.CPC_CASES.value + item.CCM_CASES.value + item.TF_CASES.value;
						that.addTrendCalculations(item, that);
					});
				}

				oModel.setData(oData);
				viewModel.setProperty("/bLoadingStateCriticalCustomers", false);
			});
		},


		shortenSolutionAreaName: function (SolutionAreaName) {
			switch (SolutionAreaName) {
				case "Digital Supply Chain":
					return "DSC";
				case "Intelligent Spend and Business Network":
					return "ISBN";
				case "Cloud ERP":
					return "Cloud ERP";
				case "Human Experience Management":
					return "HEM";
				case "Human Capital Management":
					return "HCM";
				case "Business Technology Platform":
					return "BTP";
				case "Customer Experience":
					return "CX";
				case "unassigned":
					return "unassigned";
				default:
					return SolutionAreaName;
			}
		},

		updateGoLivesFromHPI: function () {
			this.getView().getModel("viewModel").setProperty("/bLoadingStateGoLives", true);
			var oModel = new sap.ui.model.json.JSONModel();
			this.getOwnerComponent().setModel(oModel, "mrGoLivesData");

			var readMissionRadarGoLivesPromise = new Promise((resolve) => {
				this.readMissionRadarGoLives(oModel, function () {
					var oData = oModel.getData();
					if (oData && oData.items && Array.isArray(oData.items)) {
						oData.items.forEach(function (item) {
							item.Source = "HPI";
						});
					}
					resolve(); // Resolve the Promise, when function is done
				});
			});
			readMissionRadarGoLivesPromise.then(() => {
				this.addGoLivesFromMCC(oModel);
			});
		},

		addGoLivesFromMCC: function (oHPIModel) {
			var oMCCModel = new sap.ui.model.json.JSONModel();
			this.getOwnerComponent().setModel(oMCCModel, "mrGoLivesDataMCC");
			var that = this;

			var readMissionRadarGoLivesFromMCCPromise = new Promise((resolve) => {
				var oMCCModel = new sap.ui.model.json.JSONModel();
				that.getOwnerComponent().setModel(oMCCModel, "mrGoLivesDataMCC");
				that.readMissionRadarGoLivesFromMCC(oMCCModel, function () {
					var oDataMCC = oMCCModel.getData();
					if (oDataMCC && oDataMCC.items && Array.isArray(oDataMCC.items)) {
						oDataMCC.items.forEach(function (item) {
							item.Source = "MCC";

							// Renaming
							item.Calculated_Go_Live_Date = item.Overview_Go_Live_Date;
							item.Customer_ERP_ID = item.Customer_ERP_Account_ID;
							item.Customer = item.Customer_ERP_Account;
							item.Customer_Country = item.Case_Main_Partner_Country;
							item.Product = item.PPMS_Product_Name;
							item.Customer_Region = that.getRegionByCountry(item.Case_Main_Partner_Country);
							item.Customer_Global_Ultimate = item.Global_Ultimate;

							// Deleting Old Names
							delete item.Overview_Go_Live_Date;
							delete item.Customer_ERP_Account_ID;
							delete item.Case_Main_Partner_Country;
							delete item.Customer_ERP_Account;
							delete item.PPMS_Product_Name;
							delete item.Global_Ultimate;
						});

						// Add MCC-Data into HPI-Model
						var oDataHPI = oHPIModel.getData();
						if (!oDataHPI.items) {
							oDataHPI.items = [];
						}
						oDataHPI.items = oDataHPI.items.concat(oDataMCC.items);

						// Sort Calculated_Go_Live_Date and then Customer_ERP_Account_ID
						oDataHPI.items.sort(function (a, b) {
							var dateA = a.Calculated_Go_Live_Date.key ? new Date(a.Calculated_Go_Live_Date.key) : null;
							var dateB = b.Calculated_Go_Live_Date.key ? new Date(b.Calculated_Go_Live_Date.key) : null;

							if (!dateA && !dateB) return 0;
							if (!dateA) return -1;
							if (!dateB) return 1;

							if (dateA < dateB) return -1;
							if (dateA > dateB) return 1;

							// If dates are equal, compare Customer_ERP_IDs
							return a.Customer_ERP_ID.key.localeCompare(b.Customer_ERP_ID.key);
						});

						oHPIModel.refresh();
					}

					resolve();
				});
			});

			readMissionRadarGoLivesFromMCCPromise.then(() => {
				that.updateGoLiveMCCiTrend(oHPIModel); // Run updateGoLiveMCCiTrend, when readMissionRadarGoLivesFromMCC is resolved
			});
		},

		getRegionByCountry: function (oCountry) {
			var oRegion = [];
			var aRegionHelp = this.getModel("countryRegionModel").getData();
			// Find Entry in the Array, which fits the Country
			const countryEntry = aRegionHelp.RegionHelp.find(entry => entry.country === oCountry.title);

			if (countryEntry) {
				switch (countryEntry.region) {
					case "EMEA":
						if (countryEntry.subsubregion == "EMEA South") {
							oRegion.title = "EMEA South";
							oRegion.key = "EMS";
							break;
						}
						if (countryEntry.subsubregion == "EMEA North") {
							oRegion.title = "EMEA North"
							oRegion.key = "EMS";
							break;
						}
						if (countryEntry.subregion == "MEE") {
							oRegion.title = "Middle and Eastern Europe"
							oRegion.key = "MEE";
							break;
						}
					case "NA":
						oRegion.title = "North America";
						oRegion.key = "NA";
						break;
					case "APJ":
						if (countryEntry.subregion == "GTC") {
							oRegion.title = "Greater China"
							oRegion.key = "GCH";
							break;
						} else {
							oRegion.title = "Asia Pacific Japan";
							oRegion.key = "APJ";
							break;
						}
					case "LAC":
						oRegion.title = "Latin America";
						oRegion.key = "LA";
						break;
					default:
						break;
				}
			}

			return oRegion;
		},

		updateGoLiveMCCiTrend: function (oGoLiveModel) {
			var oTrendModel = new sap.ui.model.json.JSONModel();
			this.getOwnerComponent().setModel(oTrendModel, "mrGoLiveTrendData");
			var that = this;

			//Create an Array of all Customer IDs in the oGoLiveModel to search for specific CustomerIDs in the TrendData 
			var aERPAccounts = [];
			var readERPAccountsPromise = new Promise((resolve) => {
				var oData = oGoLiveModel.getData();
				if (oData && oData.items && Array.isArray(oData.items)) {
					oData.items.forEach(function (item) {
						if (item.Customer_ERP_ID.key) {
							aERPAccounts = aERPAccounts.concat(item.Customer_ERP_ID.key);
						}
					});
				}
				resolve();
			});

			readERPAccountsPromise.then(() => {
				var readMissionRadarGoLiveTrendDataPromise = new Promise((resolve) => {
					if (aERPAccounts.length > 0) {
						this.readMissionRadarGoLiveTrendData(oTrendModel, aERPAccounts, function () {
							var oData = oTrendModel.getData();
							if (oData && oData.items && Array.isArray(oData.items)) {
								oData.items.forEach(function (item) {
									item.MCCiRounded = Math.round(item.MCCI.value);
									item.TrendRounded = Math.round(item.TREND_28_DAYS.value);
									item.TrendRoundedThreeDays = Math.round(item.TREND_3_DAYS.value);
									item.OtherCases = item.CPC_CASES.value + item.CCM_CASES.value + item.TF_CASES.value;
									that.addTrendCalculations(item, that);
								});
							}
							oTrendModel.setData(oData);
							resolve();
						});
					} else {
						resolve();
					}
				});

				readMissionRadarGoLiveTrendDataPromise.then(() => {
					that.mergeTrendDataIntoGoLiveModel(oGoLiveModel, oTrendModel);
					that.getView().getModel("viewModel").setProperty("/bLoadingStateGoLives", false);
				});
			});
		},

		addTrendCalculations: function (item, that) {
			item.preventionScoreDesc = that.formatter._formatTrendDesc(Math.round(item.TREND_28_DAYS.value));
			item.preventionScoreColor = that.formatter._formatTrendColor(Math.round(item.TREND_28_DAYS.value));
			item.preventionScoreIcon = that.formatter._formatTrendIcon(Math.round(item.TREND_28_DAYS.value));
			item.preventionScoreThreeDaysDesc = that.formatter._formatTrendDesc(Math.round(item.TREND_3_DAYS.value));
			item.preventionScoreThreeDaysColor = that.formatter._formatTrendColor(Math.round(item.TREND_3_DAYS.value));
			item.preventionScoreThreeDaysIcon = that.formatter._formatTrendIcon(Math.round(item.TREND_3_DAYS.value));
		},

		mergeTrendDataIntoGoLiveModel: function (oGoLivesModel, oGoLiveTrendModel) {
			if (!oGoLivesModel || !oGoLiveTrendModel) {
				// No Models - abort
				return;
			}

			var oGoLivesData = oGoLivesModel.getProperty("/items");
			var oGoLiveTrendData = oGoLiveTrendModel.getData();

			if (!oGoLivesData || !oGoLiveTrendData) {
				// No data - abort
				return;
			}

			// Create a Map-Object for fast usage of trend data
			var trendDataMap = new Map();
			if (oGoLiveTrendData.items) {
				oGoLiveTrendData.items.forEach(function (trendItem) {
					trendDataMap.set(trendItem.ERP_Account.key, trendItem);
				});
			}

			// Go threw GoLives-Data and merge
			oGoLivesData.forEach(function (goLiveItem) {
				var key = goLiveItem.Customer_ERP_ID.title;
				if (trendDataMap.has(key)) {
					var trendItem = trendDataMap.get(key);
					//goLiveItem.preventionScore = trendItem.PREVENTION_SCORE.value;
					goLiveItem.preventionScoreDesc = trendItem.preventionScoreDesc;
					goLiveItem.preventionScoreColor = trendItem.preventionScoreColor;
					goLiveItem.preventionScoreIcon = trendItem.preventionScoreIcon;
					goLiveItem.Trend = trendItem.Trend;
					goLiveItem.MCCI = trendItem.MCCI;
					goLiveItem.TrendRounded = trendItem.TrendRounded;
					goLiveItem.MCCiRounded = trendItem.MCCiRounded;
					goLiveItem.TrendRoundedThreeDays = trendItem.TrendRoundedThreeDays;
					goLiveItem.TREND_3_DAYS = trendItem.TREND_3_DAYS;
					goLiveItem.TREND_28_DAYS = trendItem.TREND_28_DAYS;
					goLiveItem.OPEN_NOW_P1 = trendItem.OPEN_NOW_P1;
					goLiveItem.OPEN_NOW_P2 = trendItem.OPEN_NOW_P2;
					goLiveItem.GEM_CASES = trendItem.GEM_CASES;
					goLiveItem.CPC_CASES = trendItem.CPC_CASES;
					goLiveItem.TC2_CASES = trendItem.TC2_CASES;
					goLiveItem.TF_CASES = trendItem.TF_CASES;
					goLiveItem.CCM_CASES = trendItem.CCM_CASES;
					goLiveItem.Internal_Sales_Segment = trendItem.Internal_Sales_Segment;
					goLiveItem.OtherCases = trendItem.OtherCases;
				}
			});

			// Check and set MCCiRounded to -1 if still no value to sort them at the bottom for desc ordering
			oGoLivesData.forEach(function (goLiveItem) {
				if (goLiveItem.MCCiRounded === undefined || goLiveItem.MCCiRounded === null) {
					goLiveItem.MCCiRounded = -1;
				}
			});

			// Set new data mrGoLivesData Model
			oGoLivesModel.setProperty("/items", oGoLivesData);
		},


		onCustomer: function (oEv) {
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			var sCustomerErpNo;
			var oBindingContext = oEv.getSource().getBindingContext("mrCriticalCustomerData") || oEv.getSource().getBindingContext("mrGoLivesData");

			if (oBindingContext) {
				sCustomerErpNo = oBindingContext.getObject().ERP_Account?.key || oBindingContext.getObject().Customer_ERP_ID?.title;
				sCustomerErpNo = this._removeLeadingZeros(sCustomerErpNo);
			}

			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("Customer", {
				ErpCustNo: sCustomerErpNo,
				"?query": this._getQueryParameter()
			});
		},

		onCustomerNewTab: function (oEv) {
			var sCustomerErpNo;
			var oBindingContext = oEv.getSource().getBindingContext("mrCriticalCustomerData") || oEv.getSource().getBindingContext("mrGoLivesData");

			if (oBindingContext) {
				sCustomerErpNo = oBindingContext.getObject().ERP_Account?.key || oBindingContext.getObject().Customer_ERP_ID?.title;
				sCustomerErpNo = this._removeLeadingZeros(sCustomerErpNo);
			}

			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this._openCustomerInNewTab(sCustomerErpNo);
		},

		onMCCiMissionRadarPress: function (oEv) {
			var isAnonymized = this.getModel("settings").getProperty("/isAnonymizedMode")
			if (!isAnonymized) {
				var sCustomerErpNo;
				var oBindingContext = oEv.getSource().getBindingContext("mrCriticalCustomerData") || oEv.getSource().getBindingContext("mrGoLivesData");
				if (oBindingContext) {
					sCustomerErpNo = oBindingContext.getObject().ERP_Account?.key || oBindingContext.getObject().Customer_ERP_ID?.title;
					sCustomerErpNo = this._removeLeadingZeros(sCustomerErpNo);
				}
				var sUrl = this.getResourceBundle().getText("mccMissionRadarURL") + this.pad(sCustomerErpNo, 10) + "&page=25531575-1196-4236-9ffb-815c95f5af1f&mode=view&f01Model=t.3:Ccktks07u5dfgma9urn1gm6h969&f01Dim=CUSTOMER_ID";
				this._openWindow(sUrl);
			} else {
				sap.m.MessageToast.show("Can't open SAC because Anonymized Mode is active");
			}
		},

		loadAiSummaryForCustomer: function (oEv) {
			var oFeatureFlagsModel = this.getModel("featureFlags");
			this.getView().getModel("viewModel").setProperty("/bLoadingStateAISummary", true);
			if (!this.getView().getModel("oLanguageModel")) {
				var oLanguageModel = TranslationConnector.createLanguageModel(this.getView().getModel("userProfile"));
				this.getView().setModel(oLanguageModel, "oLanguageModel");
			}

			//Check if AI Button got pressed in Critical Customer oder Go Lives View and change variables
			if (oEv.getSource().getBindingContext("mrCriticalCustomerData")) {
				var oData = oEv.getSource().getBindingContext("mrCriticalCustomerData").getObject();
				var sErpCustNo = oData.ERP_Account.key;
			} else {
				var oData = oEv.getSource().getBindingContext("mrGoLivesData").getObject();
				var sErpCustNo = oData.Customer_ERP_ID.key;
			}

			// Check if there is already an AISummary
			if (oData && !oData.AISummary) {
				// Use the ScenarioID from the ccsPreview FeatureFlag
				if (oFeatureFlagsModel && oFeatureFlagsModel.getProperty("/ccsPreview") && (oFeatureFlagsModel.getProperty("/ccsPreview") !== true) ) {
					var requestData = {
						//"inputID": sErpCustNo, OLD APPROACH
						"ScenarioID": oFeatureFlagsModel.getProperty("/ccsPreview"),
						"CustomBody": {
							"jsonEncoded": "{\"customerID\":\""+sErpCustNo+"\"}"
						}
					};
					var mcccacheKey = oFeatureFlagsModel.getProperty("/ccsPreview") + "_" + sErpCustNo;
				} else {
					var requestData = {
						//"inputID": sErpCustNo,
						"ScenarioID": "9649ee30-0204-4e9c-aaf8-04a96ff0cc07",
						"CustomBody": {
							"jsonEncoded": "{\"customerID\":\""+sErpCustNo+"\"}"
						}
					};
					var mcccacheKey = "9649ee30-0204-4e9c-aaf8-04a96ff0cc07_" + sErpCustNo;
				}

				sap.m.MessageToast.show(this.getView().getModel("i18n").getProperty("customerIntelligentSummaryFetchingAI"));
				var ajaxPromise = new Promise(function (resolve, reject) {
					$.ajax({
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/mcc-aimanager/odata/v4/MCCAIManager/processScenario", //"/apimcf/mcc-aiservice/odata/v4/MCCAIManagerService/getAISummary",
						method: "POST",
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU" //,
							//	"mcccachekey": mcccacheKey
						},

						contentType: "application/json",
						data: JSON.stringify(requestData),
						success: function (data, textStatus, jqXHR) {
							resolve(data);
						},
						error: function (oError) {
							Logger.error("Error while retrieving AI Summary", "", "", oError);
							sap.m.MessageBox.error(oError.responseJSON.error.message + "Can't reach AI-Service currently. Please try again later.", {
								title: "Error " + oError.status
							});
							reject(oError);
						}
					});
				});

				// Wait for Response
				ajaxPromise.then(function (data) {
					oData.AISummary = data;
					this.openStatusReportPopover(oEv);
					this.getView().getModel("viewModel").setProperty("/bLoadingStateAISummary", false);
				}.bind(this)).catch(function (error) {
					this.getView().getModel("viewModel").setProperty("/bLoadingStateAISummary", false);
					console.error("Can't load GPT Response:", error);
				}.bind(this));
			} else if ((oData && oData.AISummary)) {
				this.openStatusReportPopover(oEv);
				this.getView().getModel("viewModel").setProperty("/bLoadingStateAISummary", false);
			}
		},


		openStatusReportPopover: function (oEv) {

			//Check if AI Button got pressed in Critical Customer oder Go Lives View and change variables
			if (oEv.getSource().getBindingContext("mrCriticalCustomerData")) {
				var oData = oEv.getSource().getBindingContext("mrCriticalCustomerData").getObject();
			} else {
				var oData = oEv.getSource().getBindingContext("mrGoLivesData").getObject();
			}

			var sMessage;
			var oAISummary;
			if (oData.AISummary) {
				sMessage = oData.AISummary.responseText;
				oAISummary = oData.AISummary;
			} else {
				sMessage = "Can't load AI Summary for this customer"
			}

			if (!oData.AISummary.responseID) {
				this.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", true);
				this.getView().getModel("viewModel").setProperty("/AISummaryFeedbackValue", 0);
			} else {
				this.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", false);
				this.getView().getModel("viewModel").setProperty("/AISummaryFeedbackValue", 0);
			}

			if (!this.openGPTReportPopover) {
				this.openGPTReportPopover = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.GPTReport", this);
				this.getView().addDependent(this.openGPTReportPopover);
			}
			oData.sMessage = sMessage;
			oData.sOriginalMessage = sMessage;
			oData.bIsTranslated = false;
			oData.oAISummary = oAISummary;
			this.openGPTReportPopover.setModel(new sap.ui.model.json.JSONModel(
				oData
			), "data");
			this.openGPTReportPopover.openBy(oEv.getSource());
			this.trackEvent("AI Summary: show Popover");
		},

		handleFeedbackChange: function (oEv) {
			this.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", true);
			var iRating = oEv.getParameter("value");
			var oModel = oEv.getSource().getModel("data");
			var oFeatureFlagsModel = this.getModel("featureFlags");
			var that = this;
			if (oModel.getProperty("/oAISummary")) {
				var sResponseID = oModel.getProperty("/oAISummary/responseID");

				if (sResponseID) {
					this.trackEvent("AI Summary: Feedback");
					// Use the ScenarioID from the ccsPreview FeatureFlag
					if (oFeatureFlagsModel && oFeatureFlagsModel.getProperty("/ccsPreview") && (oFeatureFlagsModel.getProperty("/ccsPreview") !== true)) {
						var requestData = {
							"Body": {
								"scenarioID": oFeatureFlagsModel.getProperty("/ccsPreview"),
								"xPlainID": sResponseID,
								"rating": iRating,
								"comment": ""
							}
						};
					} else {
						var requestData = {
							"Body": {
								"scenarioID": "9649ee30-0204-4e9c-aaf8-04a96ff0cc07",
								"xPlainID": sResponseID,
								"rating": iRating,
								"comment": ""
							}
						};
					}

					$.ajax({
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/mcc-aimanager/odata/v4/MCCAIManager/postFeedback",
						method: "POST",
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						contentType: "application/json",
						data: JSON.stringify(requestData),
						success: function (textStatus, jqXHR) {
							that.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", true);
							sap.m.MessageToast.show("Feedback submitted successfully");
						},
						error: function (jqXHR, textStatus, errorThrown) {
							that.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", false);
							console.error("Can't load GPT Response:", textStatus, errorThrown);
							sap.m.MessageToast.show("Feedback could not be submitted");

						}
					});
				}

			} else {
				that.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", true);
			}
		},

		handleTranslationPress: async function (oEv) {
			let translation;
			let oDataModel = this.openGPTReportPopover.getModel("data");
			let oLanguageModel = this.getView().getModel("oLanguageModel");
			let sSelectedKey = oLanguageModel.getProperty("/preselectedOption");
			if (oDataModel.oData.bIsTranslated) {
				oDataModel.oData.sMessage = oDataModel.oData.sOriginalMessage;
				oDataModel.oData.bIsTranslated = false;
			} else {
				try {
					translation = await TranslationConnector.translateText(oDataModel.oData.sOriginalMessage, sSelectedKey);
					oDataModel.oData.sMessage = translation;
					oDataModel.oData.bIsTranslated = true;
				} catch (error) {
					var errorMessage = "An unknown error occurred.";
					if (!!error.responseJSON && !!error.responseJSON.error && !!error.responseJSON.error.code) {
						errorMessage = error.responseJSON.error.message;
					} else {
						if (typeof error === 'object' && error.message) {
							errorMessage = "An unknown error occurred: " + error.message;
						}
					}
					MessageBox.error(errorMessage);
				}
			}
			oDataModel.refresh(true)
		},


		onSourcePress: function (oEv) {
			var isAnonymized = this.getModel("settings").getProperty("/isAnonymizedMode");
			var oBindingContext = oEv.getSource().getBindingContext("mrGoLivesData");

			if (oBindingContext) {
				if (oBindingContext.getObject().Source == "HPI") {
					if (!isAnonymized) {
						var sHPICustProjNr = oBindingContext.getObject().Project_ID.title;
						var sUrl = this.getResourceBundle().getText("mccMissionRadarHPICustomerURL") + sHPICustProjNr;
						this._openWindow(sUrl);
						sap.m.MessageToast.show("Showing link in new tab");
					} else {
						sap.m.MessageToast.show("Can't open HPI because Anonymized Mode is active");
					}
				} else if (oBindingContext.getObject().Source == "MCC") {
					var sCaseId = oBindingContext.getObject().Case_ID.key;
					this.getOwnerComponent().getModel("case").setProperty("/reload", true);
					this.getRouter().navTo("CaseDetails", {
						"CaseId": sCaseId,
						"?query": this._getQueryParameter()
					});
				}
			}

		},


	});
});