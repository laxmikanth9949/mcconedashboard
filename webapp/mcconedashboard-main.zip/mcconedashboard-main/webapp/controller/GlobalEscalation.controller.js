sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/model/Constants"
], function (BaseController, formatter, Constants) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.GlobalEscalation", {

		formatter: formatter,

		onInit: function () {

			//create local model to read customer related data, should be this name, cause fragment reused
			var oCustomerData = {
				reload: true
			};
			var oCustomerModel = new sap.ui.model.json.JSONModel(oCustomerData);
			this.getOwnerComponent().setModel(oCustomerModel, "globalEscalations");

			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				iTabFiltered: 0,
				bLoadingState: false
			}), "viewModel");

			this._oGlobalFilter = null;
			this._oPriceFilter = null;
			this._tblRendered = false;
			this.getRouter().getRoute("GlobalEscalation").attachPatternMatched(this._onObjectMatched, this);

		},

		onAfterRendering: function () {
			/*this.getView().byId("tabInc").setVisibleRowCount(8);
			this.getView().byId("tabInc").setVisibleRowCountMode("Auto");*/
			this.getView().byId("tabInc").addEventDelegate({
				"onAfterRendering": function (oEv) {
					if (!this._tblRendered) {
						setTimeout(function () {
							oEv.srcControl.invalidate();
						}, 300);

						this._tblRendered = true;
					}
				}.bind(this)
			});

			var oTable = this.getView().byId("tabInc");
			oTable.attachFilter(function (oEvent) {
				setTimeout(function () {
					this._updateFilteredCount();
				}.bind(this), 200); //Wait for filter execution
			}, this);
            
            //Attach Listener in case a global Filter is applied
			var oSearchField = this.getSearchField(oTable);
			oSearchField.attachSearch(function (oEvent) {
				this._updateFilteredCount();
			}, this);
		},

		_onObjectMatched: function (oEvent) {
			if (this.getModel("globalEscalations") && this.getModel("globalEscalations").getData() && this.getModel("globalEscalations").getProperty(
					"/reload")) {
				this.getModel("globalEscalations").setProperty("/reload", false);
				this._updateTable();
			}
			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
		},

		_updateTable: function () {
			var aFilters = [];
			var oFilterModel = this.getModel("filterModel");
			var aCaseIdsRequestingUnitFromHana = null;
			var oSettings = this.getOwnerComponent().getModel("settings").getData();
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/globalEscalationsCaseState");
			var bCaseFilter = this.getOwnerComponent().getModel("data").getProperty("/globalEscalationsCaseFilter");
			this.getView().byId("dataIconTabBar").setSelectedKey("All");
			if (!bCaseState) {
				bCaseState = "open";
			}

			this.getView().byId("dataIconTabBar").setSelectedKey("All");

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			if (bCaseState === "closed" || bCaseState === "all") {

				var dateOffset = (24 * 60 * 60 * 1000) * Constants.closedCasesPastDays;
				var dateInPast = new Date();
				dateInPast.setTime(dateInPast.getTime() - dateOffset);

				var tileSpecificFilters1 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
								new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "40")
							],
							false),
						new sap.ui.model.Filter({
							path: "ClosingDate",
							operator: sap.ui.model.FilterOperator.GE,
							value1: dateInPast
						})
					],
					true
				);

			}
			if (bCaseState === "open" || bCaseState === "all") {
				//ALL ongoing 
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20"), new sap.ui.model.Filter(
							"Status", sap.ui.model.FilterOperator.EQ, "30")], false)
					],
					true
				);
			}

			//read all Requestîng Units from the HANA DB for GEM
			this.getModel("subModel").read("/Cases", {
				filters: [new sap.ui.model.Filter(
					[new sap.ui.model.Filter("UseCaseType", sap.ui.model.FilterOperator.EQ, "mcs-gem")].filter(Boolean),
					true
				)],
				urlParameters: {
					"$select": "CaseID,RequestingUnit,RequestingUnitName"
				},
				success: function (oData) {
					if (oData.results) {
						aCaseIdsRequestingUnitFromHana = oData.results;
					}
				},
				error: function () {}
			});

			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
						tileSpecificFilters1,
						tileSpecificFilters2
					],
					false
				));
			}

			this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", true);

			var oICModel = this.getModel();

			oICModel.read("/GlobalEscalationsSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);

					this._calculateRating(data);
					data.results.forEach(function (oCase) {
						if (oCase.Rating === "") {
							oCase.Rating = "unrated";
						}
						if (oCase.DbsMaintenanceRanking === "0") {
							oCase.DbsMaintenanceRanking = "";
						}
						oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);
						//add data for requesting unit to result list
						if (aCaseIdsRequestingUnitFromHana) {
							var index = aCaseIdsRequestingUnitFromHana.findIndex(item => item.CaseID.toString() === oCase.CaseId);
							if (index > -1) {
								oCase.ReqestingUnit = aCaseIdsRequestingUnitFromHana[index].RequestingUnit;
								oCase.RequestingUnitT = aCaseIdsRequestingUnitFromHana[index].RequestingUnitName; //this.formatter.getRequestingUnitText(oCase.ReqestingUnit, this._oResourceBundle);
							}
						}

					}.bind(this));
					this.getModel("globalEscalations").setProperty("/GlobalEscalationsSet", data.results);
					this.loadProducts(aFilters);
					//MISSIONRADAR 2211	
					this.readMissionRadarValues(this.getModel("globalEscalations"), "GlobalEscalationsSet");

					if (bCaseFilter !== "none") {
						var oIconTabBar = this.getView().byId("dataIconTabBar");
						oIconTabBar.setSelectedKey(bCaseFilter);
						oIconTabBar.fireSelect();
					}

				}.bind(this),
				error: function (data) {
					this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
				}.bind(this)
			});

		},

		loadProducts: function (aFilters) {
			this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", true);

			var oICModel = this.getModel();
			oICModel.read("/GlobalEscalationsSet", {
				urlParameters: {
					"$expand": "toProducts"
				},
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					var oModel = this.getModel("globalEscalations");
					var aAlreadyAdded = oModel.getProperty("/GlobalEscalationsSet");
					this._updateFilteredCount();
					//concat toProducts properties
					data.results.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVersion = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.CaseId === result.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVersion = result.ProductVersion;
							});
						}

					}, this);
					this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
				}.bind(this),
				error: function (data) {
					this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
				}.bind(this)
			});
		},

		loadNotes: function (oControl, id) {
			var oICModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oICModel.read("/GlobalEscalationsSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		handleCustomerPress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("globalEscalations").getPath();
			var oProperty = this.getModel("globalEscalations").getProperty(sPath);
			var sErpCustNo = oProperty.CustomerErpNo || oProperty.ErpCustNo || oProperty.CustomerNo;
			var oRouter = this.getRouter();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("globalEscalations").getPath();
			var oProperty = this.getModel("globalEscalations").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("globalEscalations").getObject();
			var sObjectType = "";
			var sId = oData.CaseId;
			this.loadNotes(oEv.getSource(), sId, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},

		handleCasePress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("globalEscalations").getPath();
			var oProperty = this.getModel("globalEscalations").getProperty(sPath);
			var sCaseId = oProperty.CaseId;
			var oRouter = this.getRouter();
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);
			oRouter.navTo("CaseDetails", {
				"?query": this._getQueryParameter(),
				CaseId: sCaseId
			});
		},

		onCaseNewTab: function (oEv) {
			var sPath = oEv.getSource().getParent().getBindingContext("globalEscalations").getPath();
			var oProperty = this.getModel("globalEscalations").getProperty(sPath);
			var sCaseId = oProperty.CaseId;
			this._openCaseInNewTab(sCaseId);
		},

		changeCaseState: function () {
			this._updateTable();
		},

		_calculateRating: function (data) {
			var oViewModel = this.getView().getModel("viewModel");
			var iGreen = 0;
			var iYellow = 0;
			var iRed = 0;
			var iUnrated = 0;
			data.results.forEach(function (oCase) {
				switch (oCase.Rating) {
				case "A":
					iGreen++;
					break;
				case "B":
					iYellow++;
					break;
				case "C":
					iRed++;
					break;
				default:
					iUnrated++;
				}
			});
			oViewModel.setProperty("/iTabAll", data.results.length);
			oViewModel.setProperty("/iTabGreen", iGreen);
			oViewModel.setProperty("/iTabYellow", iYellow);
			oViewModel.setProperty("/iTabRed", iRed);
			oViewModel.setProperty("/iTabUnrated", iUnrated);
			this._updateFilteredCount();
		},

		_updateFilteredCount: function () {
			var oTable = this.getView().byId("tabInc");
			var iFilteredCount = oTable.getBinding("rows").getLength();
			var aFilters = oTable.getBinding("rows").aFilters;
			if (aFilters && aFilters.length > 0) {
				var iLengths = oTable.getBinding("rows").iLengths;
				if (iLengths) {
					iFilteredCount = oTable.getBinding("rows").iLength - iLengths.sum();
				} else {
					iFilteredCount = oTable.getBinding("rows").iLength;
				}
			}
			this.getView().getModel("viewModel").setProperty("/iTabFiltered", iFilteredCount);
		},

		handleRatingIconTabBarSelect: function (oEv) {
			var oTable = this.getView().byId("tabInc");
			var sRatingKey = oEv.getSource().getSelectedKey();
			var aFilter = [];

			// Reset all table filters
			oTable.getColumns().forEach(function (oColumn) {
				oColumn.filter(null);
				oColumn.setFilterValue("");
			});
			this.clearSearchField(oTable);

			if (sRatingKey !== "All") {
				aFilter.push(new sap.ui.model.Filter("Rating", "EQ", sRatingKey));
			}
			oTable.getBinding("rows").filter(aFilter);
			this._updateFilteredCount();
		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("globalEscalations").getObject();
			var sCaseId = oProperty.CaseId;
			this._shopTopIssuesCountPopover(sCaseId, oEv.getSource());
		},
		customSorting: function (oEvent) {
			var oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingColumn");
			var oMCCiColumn = this.byId("mcci");
			var oPreventionScoreColumn = this.byId("preventionScore");
			var oCurrentColumn = oEvent.getParameter("column");
			if (oCurrentColumn !== oGUMaintenanceRankingColumn && oCurrentColumn !== oMCCiColumn && oCurrentColumn !== oPreventionScoreColumn) {
				//oGUMaintenanceRankingColumn.setSorted(false); //No multi-column sorting
				return;
			}
			oEvent.preventDefault();
			var sOrder = oEvent.getParameter("sortOrder");
			if (oCurrentColumn == oMCCiColumn || oCurrentColumn == oPreventionScoreColumn) {
				this.customSortingBaseFloat(oCurrentColumn, sOrder, "tabInc");
			} else {
				this.customSortingBase(oCurrentColumn, sOrder, oGUMaintenanceRankingColumn, "tabInc");
			}
		},

		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("globalEscalations").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		}
	});
});