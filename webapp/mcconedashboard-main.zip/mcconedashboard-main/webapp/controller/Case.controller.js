sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"sap/ui/core/routing/History",
	"com/sap/mcconedashboard/model/formatter",
	"sap/ui/model/json/JSONModel",
	"com/sap/mcconedashboard/controller/mcs/ReportDownloadHandler",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, History, formatter, JSONModel, ReportDownloadHandler, Fragment, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.Case", {

		formatter: formatter,
		reportDownloadHandler: ReportDownloadHandler,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.mcconedashboard.view.Customer
		 */
		onInit: function () {
			if (this.getRouter().getRoute("CaseDetails")) {
				this.getRouter().getRoute("CaseDetails").attachPatternMatched(this._onObjectMatchedMCC, this);
			}
			if (this.getRouter().getRoute("CCMDetails")) {
				this.getRouter().getRoute("CCMDetails").attachPatternMatched(this._onObjectMatchedMCC, this);
			}

			var oCase = {
				reload: true
			};
			var oCaseModel = new sap.ui.model.json.JSONModel(oCase);
			this.getOwnerComponent().setModel(oCaseModel, "case");

			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

			var oModel = new JSONModel(sap.ui.require.toUrl("com/sap/mcconedashboard/json/Timeline.json"));
			this.getView().setModel(oModel, "jModel");

			this._initCheckpointsTable();
		},
		hideClosedTopIssues: function (oEvent) {
			console.log(oEvent, " this is the event object")
			var aFilters = [];
			//	if (oEvent.getSource().getChecked()) {
			if (!oEvent.getSource().getSelected()) {
				aFilters.push(new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("StatusID", sap.ui.model.FilterOperator.NE, "E0013"),
						new sap.ui.model.Filter("StatusID", sap.ui.model.FilterOperator.NE, "E0012"),
					],
					and: true
				}));
			}
			var oList = this.getView().byId("topIssueLayout");
			var oBinding = oList.getBinding("content");
			oBinding.filter(aFilters);
		},

		hideClosedFocusAreas: function (oEvent) {
			var aFilters = [];
			//	if (oEvent.getSource().getChecked()) {
			if (!oEvent.getSource().getSelected()) {
				aFilters.push(new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.NE, "90")
					],
					and: true
				}));
			}
			var oList = this.getView().byId("tableFocusAreas");
			var oBinding = oList.getBinding("rows");
			oBinding.filter(aFilters);
		},

		_onObjectMatchedMCC: function (oEvent) {
			if (!this.getOwnerComponent().getModel("case").getProperty("/reload")) {
				return null;
			}
			var oArgs = oEvent.getParameter("arguments");
			this.getOwnerComponent().getModel("case").setProperty("/reload", false);

			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);

			this.getView().setModel(new JSONModel({
				caseType: "",
				showNotesLatestStatus: false,
				showNotesManagementSummary: false,
				showNotesAdditionalInformation: false,
				showNotesNextSteps: false,
				showNotesCurrentSituation: false,
				showNotesIssueImpact: false,
				showNotesEmptyMsg: false,
				showSubscriptionButton: false,
				showPDFDownloadButton: false,
				subscriptionAction: "ADD",
				subscriptionID: "",
				isTC2: false,
				isTaskType: false
			}), "viewModel");

			//set 1st section selected
			if (oArgs["?query"] && oArgs["?query"].tab) {
				var oSection = this.getView().byId("ObjectPageLayout").getSections().find(function (section) {
					return section.getId().indexOf(oArgs["?query"].tab) > -1;
				});
				if (oSection) {
					this.getView().byId("ObjectPageLayout").setSelectedSection(oSection.getId());
					this.getView().byId("ObjectPageLayout").fireSectionChange({
						section: oSection
					});
				} else {
					this.getView().byId("ObjectPageLayout").setSelectedSection(this.getView().byId("ObjectPageLayout").getSections()[0].getId());
				}
			} else if (jQuery.sap.getUriParameters()._get("section") && jQuery.sap.getUriParameters()._get("section") !== "") {
				var oSection = this.getView().byId("ObjectPageLayout").getSections().find(function (section) {
					return section.getId().indexOf(jQuery.sap.getUriParameters()._get("section")) > -1;
				});
				if (oSection) {
					this.getView().byId("ObjectPageLayout").setSelectedSection(oSection.getId());
					this.getView().byId("ObjectPageLayout").fireSectionChange({
						section: oSection
					});
				} else {
					this.getView().byId("ObjectPageLayout").setSelectedSection(this.getView().byId("ObjectPageLayout").getSections()[0].getId());
				}

			} else {
				this.getView().byId("ObjectPageLayout").setSelectedSection(this.getView().byId("ObjectPageLayout").getSections()[0].getId());
			}

			var sCaseId = oEvent.getParameter("arguments").CaseId;
			this.caseId = sCaseId;
			this.caseType;
			var oICModel = this.getOwnerComponent().getModel();
			var oAppDepModel = this.getOwnerComponent().getModel("appDepModel");

			//set case type by case id
			this._setCaseTypeById(sCaseId);

			//get entityset by case id
			var sEntitySet = this._getEntitySetByCaseId(sCaseId);
			var sCaseType = this._getCaseTypeByCaseId(sCaseId);

			//Check for ZS01 Global Escalation and if so, show the duration
			this.durationText = this.getView().byId("durationID");

			if (sCaseType === "ZS01") {
				this.getOwnerComponent().getModel("settings").setProperty("/showDetailTimelineTab", true); //Set to "true for activation"
				this.durationText.setVisible(true);
			} else {
				this.getOwnerComponent().getModel("settings").setProperty("/showDetailTimelineTab", false);
				this.durationText.setVisible(false);
			}

			//for anonymous mode check, if it is a GEM Case. If so, then do NOT show any data
			if (this.getOwnerComponent().getModel("settings").getProperty("/isAnonymizedMode") && sCaseType === "ZS01") {
				return null;
			}
			sap.ui.core.BusyIndicator.show(0);
			var aPromises = [];
			// in case of global Escalations/Business Down ZS01 we need to call a different entity set in order to have the auth checks applied correctly
			//GlobalEscalationsSet?$expand=toProducts%2CtoLastNotes&$filter=CaseId eq '10021581'
			if (sCaseType === "ZS01") {
				var aFilters = [];
				aFilters.push(new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.EQ, sCaseId));
				aPromises.push(new Promise(function (resolve) {
					oICModel.read("/GlobalEscalationsSet", {
						filters: aFilters,
						urlParameters: {
							"$expand": "toProducts,toLastNotes"
						},
						success: function (data) {
							resolve(data.results[0]);
						}.bind(this),
						error: function (data) {
							resolve(data);
						}.bind(this)
					});
				}));
			} else {
				aFilters = [];
				if (sEntitySet === "/CustomerEngagementSet") {
					aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
				}
				aPromises.push(new Promise(function (resolve) {
					oICModel.read(sEntitySet + "('" + sCaseId + "')", {
						filters: aFilters,
						urlParameters: {
							"$expand": "toProducts,toLastNotes"
						},
						success: function (data) {
							resolve(data);
						}.bind(this),
						error: function (data) {
							resolve(data);
						}.bind(this)
					});
				}));
			}

			aPromises.push(new Promise(function (resolve) {
				var aCaseDetailsPrmises = [];

				oAppDepModel.read("/CaseSet(CaseID='" + sCaseId + "',CaseType='" + sCaseType + "',CaseObject='C')", {
					success: function (data) {
						aCaseDetailsPrmises.push(new Promise(function (resolveDetails1) {
							resolveDetails1(data);
						}));
						var aIssueFilter = [];
						// the creation time check is not needed anymore
						//defined with Marvin in the MCC Tools call on 19.04.2022
						//it leads to issues with the AGGR profile in combination with the confidential creation date
						// if (data.CreateTime.getTime() < new Date("2021-01-01").getTime()) {
						// 	var oFilter = new sap.ui.model.Filter({
						// 		filters: [
						// 			new sap.ui.model.Filter("CategoryID", sap.ui.model.FilterOperator.EQ, "ZYO"),
						// 			new sap.ui.model.Filter("CategoryID", sap.ui.model.FilterOperator.EQ, "ZYP")
						// 		],
						// 		and: false
						// 	});
						// } else {
						var oFilter = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("CategoryID", sap.ui.model.FilterOperator.EQ, "ZYP")
							],
							and: false
						});
						//	}

						aIssueFilter.push(new sap.ui.model.Filter("ActivityType", sap.ui.model.FilterOperator.EQ, "ZS46"));
						aIssueFilter.push(new sap.ui.model.Filter("RefDocID", sap.ui.model.FilterOperator.EQ, sCaseId));
						aIssueFilter.push(oFilter);
						aCaseDetailsPrmises.push(new Promise(function (resolveDetails2) {
							oAppDepModel.read("/CaseSet(CaseID='" + sCaseId + "',CaseType='" + sCaseType + "',CaseObject='C')/toActivity", {
								filters: aIssueFilter,
								urlParameters: {
									"$expand": "toNote"
								},
								success: function (data) {
									resolveDetails2(data);
								},
								error: function (error) {
									resolveDetails2(error);
								}
							});
						}));
						aCaseDetailsPrmises.push(new Promise(function (resolveDetails3) {
							oAppDepModel.read("/CaseSet(CaseID='" + sCaseId + "',CaseType='" + sCaseType + "',CaseObject='C')/toTopIssue", {
								urlParameters: {
									"$expand": "toAffectedProduct,toNote"
								},
								success: function (data) {
									resolveDetails3(data);
								},
								error: function (error) {
									resolveDetails3(error);
								}
							});
						}));
						Promise.all(aCaseDetailsPrmises).then(function (results) {
							var aExtendedCallsPromises = [];
							var data = results[0];
							if (data.responseText && data.responseText.includes("Resource not found for segment 'Case'")) {
								data = [];
							}
							data.toActivity = results[1];
							data.toTopIssue = results[2];
							data.toActivity.results.forEach(function (activity) {
								if (activity.ActivityType !== "ZS31") {
									aExtendedCallsPromises.push(new Promise(function (resolveActivity) {
										oAppDepModel.read("/ActivitySet(ActivityID='" + activity.ActivityID + "',ActivityType='" + activity.ActivityType +
											"',ActivityObject='" + activity.ActivityObject + "')/toAffectedProduct", {
											success: function (dataActivity) {
												activity.toAffectedProduct.results = dataActivity.results;
												resolveActivity();
											},
											error: function () {
												resolveActivity();
											}
										});
									}));
								}
							});

							//load top issues
							//sort property
							data.toTopIssue.results.sort(function (a, b) {
								if (a.CreatedAt < b.CreatedAt) {
									return -1;
								}
								if (b.CreatedAt < a.CreatedAt) {
									return 1;
								}
								return 0;
							});

							//remove all which are not type ZS34
							data.toTopIssue.results = data.toTopIssue.results.filter(function (val) {
								return val.TopIssueType === "ZS34";
							});

							data.toTopIssue.results.forEach(function (topIssue, idx) {
								//set title
								//set title
								var sTitle = topIssue.DescriptionLong !== "" ? topIssue.DescriptionLong : topIssue.Description;
								topIssue.panelTitle = "Top Issue " + (idx + 1) + " - " + sTitle;

								//parse notes
								var aTmp = [];
								//Description
								aTmp = topIssue.toNote.results.filter(function (note) {
									return note.NoteType === "A001";
								});
								if (aTmp.length === 1) {
									topIssue.noteDescription = aTmp[0].Text;
								}

								//Exit Criteria
								aTmp = topIssue.toNote.results.filter(function (note) {
									return note.NoteType === "ZS05";
								});
								if (aTmp.length === 1) {
									topIssue.noteExitCriteria = aTmp[0].Text;
								}

								//Status Summary
								aTmp = topIssue.toNote.results.filter(function (note) {
									return note.NoteType === "ZSSS";
								});
								topIssue.noteStatusSummary = "";
								if (aTmp.length === 1) {
									topIssue.noteStatusSummary = aTmp[0].Text;
								}

								aExtendedCallsPromises.push(new Promise(function (resolveTopIssue) {
									oAppDepModel.read("/TopIssueSet(TopIssueID='" + topIssue.TopIssueID + "',TopIssueType='" + topIssue.TopIssueType +
										"',TopIssueObject='" + topIssue.TopIssueObject + "')/toCategory", {
										success: function (dataTopIssue) {
											topIssue.toCategory.results = dataTopIssue.results;
											resolveTopIssue();
										},
										error: function () {
											resolveTopIssue();
										}
									});
								}));
							});
							Promise.all(aExtendedCallsPromises).then(function () {
								resolve(data);
							});
						});
					}.bind(this),
					error: function () {
						resolve();
					}
				});

			}.bind(this)));

			//read implementation partner
			//check if metadata loaded
			aPromises.push(new Promise(function (resolve) {
				this.getModel("subModel").metadataLoaded().then(function () {
					this.getModel("subModel").read("/Cases", {
						filters: [new sap.ui.model.Filter("CaseID", sap.ui.model.FilterOperator.EQ, sCaseId)],
						success: function (oData) {
							resolve(oData);
						},
						error: function () {
							resolve();
						}
					});
				}.bind(this));
				this.getModel("subModel").attachMetadataFailed(null, function () {
					resolve(null);
				});
			}.bind(this)));

			//read mcs details....
			//mcs details
			if (this.caseType !== "ZS02") {
				if (this.getOwnerComponent().getModel("settings").getProperty("/show_crm_data")) {
					aPromises.push(new Promise(function (resolve) {
						this.getModel("mcsModel").read("/MCSDetailsSet('" + sCaseId + "')", {
							success: function (oData) {
								resolve(oData);
							},
							error: function () {
								resolve();
							}
						});
					}.bind(this)));
				}

				aPromises.push(new Promise(function (resolve) {
					this.getModel("mcsModel").read("/MCSDashboardSet('" + sCaseId + "')", {
						urlParameters: {
							"$expand": "toLastNotes",
							"$select": "toLastNotes"
						},
						success: function (oData) {
							resolve(oData);
						},
						error: function () {
							resolve();
						}
					});
				}.bind(this)));
			}
			//read escalation costs
			//this.getModel("bwp003DetailCostBWModel").metadataLoaded().then(function () {
			if (this.getOwnerComponent().getModel("settings").getProperty("/show_cost_data")) {
				aPromises.push(new Promise(function (resolve) {


					var bwp003DetailCostBWModel = new sap.ui.model.odata.v2.ODataModel(
						sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCASE_COST_ODA_003N_SRV", {
						"metadataUrlParams": {
							"sap-documentation": "heading"
						},
						"defaultCountMode": true,
						"useBatch": false,
						"headers": {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						}
					});
					bwp003DetailCostBWModel.read(
						"/MCASE_COST_ODA_003N(MCASE_CMM_YO_001='" + sCaseId +
						"',MCASE_HCS_MY_01_0SALESORG='',MCASE_NAM_ON_01_0SALESORG='')/Results", {
						urlParameters: {
							"$select": "A4MCASEX017CSM_EXID,A00O2TFCW5W1LNCK7YZ0OT6YGA,A00O2TFCW5W1LNCK7YZ0OT7NQI"
						},
						success: function (oData) {
							resolve(oData.results[0]);
						},
						error: function () {
							resolve();
						}
					});
				}.bind(this)));
			}
			//}.bind(this));

			Promise.all(aPromises).then(function (aResults) {
				sap.ui.core.BusyIndicator.hide();
				var data = aResults[0];
				if (!data) {
					data = [];
				}

				//set the data initially to ""
				data["EscalationManager"] = "";
				data["EscalationManagerId"] = "";
				data["DeEscalationArchitect"] = "";
				data["DeEscalationArchitectId"] = "";
				data["Requestor"] = "";
				data["Duration"] = "";
				data["ImplementationPartner"] = "";
				data["ImplementationPartnerId"] = "";
				data["RequestingUnit"] = "";
				data["RequestingUnitT"] = "";

				if (aResults[3] && (aResults[1].ProcessTypeId === "ZSPRCTYP02" || aResults[1].ProcessTypeId === "ZSPRCTYP01")) {
					data["ImplementationPartner"] = aResults[3].implementation_partner_text;
					data["ImplementationPartnerId"] = aResults[3].implementation_partner;
				} else if (aResults[2] && aResults[2].results && aResults[2].results.length === 1) {
					if (aResults[2].results[0].PartnerName !== null) {
						data["ImplementationPartner"] = aResults[2].results[0].PartnerName;
					}
				}

				//result of HANA Read for requesting unit
				if (aResults[2] && aResults[2].results && aResults[2].results.length === 1) {

					if (aResults[1].CaseType === "ZS01" && aResults[1].ProcessTypeId === "ZSPRCTYP01" || aResults[1].CaseType === "ZS02" &&
						aResults[1].CustomerTypeID === "ZSCUSTYP05") {
						data["AribaJiraID"] = aResults[2].results[0].AribaJiraID || "";
					} else {
						data["AribaJiraID"] = "";
					}

					if (aResults[2].results[0].RequestingUnit !== null) {
						data["RequestingUnit"] = aResults[2].results[0].RequestingUnit;
						data["RequestingUnitT"] = aResults[2].results[0].RequestingUnitName; //this.formatter.getRequestingUnitText(aResults[2].results[0].RequestingUnit, this._oResourceBundle);
					}
				}

				//mcs details ==== aResults 3
				if (aResults[3]) {
					//can be taken from main data data["FurtherAffectedProducts"] = aResults[3].product_text;
					//can be taken from main data data["CountryT"] = aResults[3].country_text;
					//can be taken from main data["CustomerSegment"] = aResults[3].master_code_text;

					data["EscalationManager"] = aResults[3].escalation_manager_text;
					data["EscalationManagerId"] = aResults[3].escalation_manager;
					data["DeEscalationArchitect"] = aResults[3].deescalation_architect_text;
					data["DeEscalationArchitectId"] = aResults[3].deescalation_architect_id;
					data["Requestor"] = aResults[3].requestor_name;
					data["RequestorId"] = aResults[3].requestor_id;
					data["Duration"] = aResults[3].duration;
				}

				//for the display of the Checkpoints and Action Plan Tabs check the ProcessTypeId 
				//should be only shown for GEM and Product Escalations
				if (aResults[3] && (aResults[3].process_type === "ZSPRCTYP06" || aResults[3].process_type === "ZSPRCTYP01")) {
					this.getOwnerComponent().getModel("settings").setProperty("/showDetailCheckpointsTab", true);
					this.getOwnerComponent().getModel("settings").setProperty("/showDetailTopIssuesTab", true);
					//	data["ProcessTypeId"]= aResults[3].process_type;
					//	data["ProcessTypeText"]= aResults[3].process_type;
				} else {
					this.getOwnerComponent().getModel("settings").setProperty("/showDetailCheckpointsTab", false);
					this.getOwnerComponent().getModel("settings").setProperty("/showDetailTopIssuesTab", false);
				}

				if (aResults[5]) {
					data["AcualCost"] = this.formatter.numberFormatter(aResults[5].A00O2TFCW5W1LNCK7YZ0OT6YGA); //TOTAL_ACTUAL_COST
					data["ForecastCost"] = this.formatter.numberFormatter(aResults[5].A00O2TFCW5W1LNCK7YZ0OT7NQI); //TOTAL_FORECAST_COST
					//for testing
					//data["AcualCost"] = this.formatter.numberFormatter("37738043.07"); //TOTAL_ACTUAL_COST
					//data["ForecastCost"] = this.formatter.numberFormatter("5028196.69"); //TOTAL_FORECAST_COST
				}

				//merge data
				for (var property in aResults[1]) {
					if (property === "Processor") {
						data.ProcessorId = aResults[1][property];
					}
					if (property === "CaseID") {
						data.CaseId = aResults[1][property];
					}
					if (property === "CustomerBpId") {
						data.CustomerCrmNo = aResults[1][property];
					}
					if (!data[property]) {
						data[property] = aResults[1][property];
					}
					//for BusinessDown information data is only read from DEP oData, which has no LinkToCase
					if (!data["LinkToCase"]) {
						data["LinkToCase"] = "";
					}
				}
				if (!data.CaseId || data.CaseId === "") {
					this._caseNotFound(sCaseId);
				} else {
					var oModel = new JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "case");

					//load header image
					this._loadCustomerLogo(data.CustomerCrmNo);

					if (data.CustomerType && (data.CustomerType === "ZSCUSTYP06" || data.CustomerType === "Top Critical Customers")) {
						this.getView().getModel("viewModel").setProperty("/isTC2", true);
					}

					if (data.CustomerType && (data.CustomerType === "ZSCUSTYP07" || data.CustomerType === "Task Force")) {
						this.getView().getModel("viewModel").setProperty("/isTaskType", true);
					}

					//notes from mcs dashbiard
					if (aResults[4] && aResults[4].toLastNotes.results.length > 0) {
						this.parseNotes(aResults[4], data.CustomerType);
					} else {
						this.parseNotes(data, data.CustomerType);
					}

					//check if subscription button should be shown
					this.getView().getModel("viewModel").setProperty("/showSubscriptionButton", this._showSubscriptionButtonForSpecificCaseTypes(
						this.getView().getModel("case").getData()));
					if (this.getView().getModel("viewModel").getProperty("/showSubscriptionButton")) {
						//check in the existing subscriptions, if there is already an entry for this case
						this._checkSubscriptionStatusForCase(this.getView().getModel("case").getData());
					}

					//check if PDF Download Icon should be shown
					this.getView().getModel("viewModel").setProperty("/showPDFDownloadButton", this._checkShowDownloadPDFFile(
						this.getView().getModel("case").getData()));

				}

			}.bind(this));

			//TC² Scope section 
			//set gantt start / end time
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMddhhMMss"
			});
			var hierarchy = {};
			hierarchy.StartDate = oFormat.format(this._getGanttStartDate(new Date()));
			hierarchy.EndDate = oFormat.format(this._getGanttEndDate(12));
			hierarchy.children = [];
			this.getView().setModel(new JSONModel(hierarchy), "FAHierarchy");

			//initiate Focus area model
			this.getView().setModel(new JSONModel({}), "focusAreas");

			//initiate Impacted Customers model
			this.getView().setModel(new JSONModel({}), "impactedCustomers");

			//initiate Linked Objects model
			this.getView().setModel(new JSONModel({}), "linkedObjects");

		},

		onSectionChange: function (oEv) {
			if (oEv.getParameter("section").getTitle() === "Action Plan") {
				this._bindActionPlan(this.caseId);
			} else if (oEv.getParameter("section").getTitle() === "Checkpoints") {
				this._bindCheckpoints(this.caseId);
			} else if (oEv.getParameter("section").getTitle() === "Timeline") {
				this._bindTimeline(this.caseId);
			} else if (oEv.getParameter("section").getTitle() === "TC² Support Plan") {
				this._bindSupportPlan();
			} else if (oEv.getParameter("section").getTitle() === "TC² Focus Areas") {
				this._bindFocusAreas(this.caseId);
			} else if (oEv.getParameter("section").getTitle() === "Impacted Customers") {
				this._bindImpactedCustomers(this.caseId);
			} else if (oEv.getParameter("section").getTitle() === "Initiated Cross Issues") {
				this.loadLinkedObjects(this.caseId).then(function () {
					this._bindInitiatedCrossIssues();
				}.bind(this));
			}
		},

		loadLinkedObjects: function (id) {
			var oModel = this.getView().getModel("subModel");
			return new Promise(function (resolve, reject) {
				var oFilter = new Filter("TopIssueID", FilterOperator.EQ, id);
				oModel.read("/LinkedObjects", {
					filters: [oFilter],
					success: function (oData) {
						this.getView().setModel(new JSONModel(oData.results), "linkedObjects");
						resolve();
					}.bind(this),
					error: function (err) {
						this.getView().setModel(new JSONModel([]), "linkedObjects");
						resolve();
					}.bind(this)
				});
			}.bind(this));
		},

		_bindActionPlan: function (caseId) {
			var oActionplanTable = this.getView().byId("actionPlanTable");
			oActionplanTable.setBusyIndicatorDelay(0);
			oActionplanTable.setBusy(true);
			this.getModel("mcsModel").read("/TotalEffortSet", {
				filters: [new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.EQ, caseId)],
				success: function (oData) {
					oActionplanTable.setBusy(false);
					var oActionPlanModel = new JSONModel(oData);
					this.getView().setModel(oActionPlanModel, "actionPlanModel");
				}.bind(this)
			});

			var oLayout = this.getView().byId("actionPlanTopIssuesContainer");
			oActionplanTable.setBusyIndicatorDelay(0);
			oActionplanTable.setBusy(true);

			//read top issue data
			this.getModel("mcsModel").read("/TopIssuesSet", {
				filters: [new sap.ui.model.Filter("case_id", sap.ui.model.FilterOperator.EQ, caseId)],
				urlParameters: {
					"$expand": "TOPI_ActionPlan"
				},
				success: function (oData) {
					oLayout.setBusy(false);
					oLayout.removeAllContent();
					this.getView().setModel(new JSONModel(oData.results), "topIssues");
					if (oData.results.length === 0) {
						oLayout.addContent(new sap.m.Text({
							text: "{i18n>noActionPlans}"
						}).addStyleClass("sapUiResponsiveMargin"));
					}
					oData.results.forEach(function (oElement, index) {
						var oTopIssueOverviewElement = new sap.m.Panel({
							expandable: true,
							expanded: false,
							width: "auto"
						});
						var sTitle = oElement.descriptionlong !== "" ? oElement.descriptionlong : oElement.description;
						oTopIssueOverviewElement.setHeaderToolbar(this._generateHeadeToolbarForTopIssueOverview(
							this.formatter, sTitle, oElement.issue_no, oElement.rating, oElement.status));

						//that.getView().getModel().getProperty("/MCSDetailsSet('10001017')").TopIssues;
						var sBindingPath = "/" + index + "/TOPI_ActionPlan/results";
						var oActionPlanTable = this._createActionPlanTable(sBindingPath);

						oTopIssueOverviewElement.addContent(new sap.m.Text({
							text: oElement.text,
							width: "100%"
						}).addStyleClass("sapUiTinyMarginTop sapUiMediumMarginBottom"));

						oTopIssueOverviewElement.addContent(new sap.m.Toolbar({
							content: [new sap.m.Title({
								titleStyle: "H4",
								text: this._oResourceBundle.getText("actionPlan")
							})]
						}));

						oTopIssueOverviewElement.addContent(oActionPlanTable);
						oLayout.addContent(oTopIssueOverviewElement);
					}.bind(this));
				}.bind(this)
			});
		},

		_bindCheckpoints: function (caseId) {
			if (this.caseType !== "ZS02") {
				var oModel = this.getModel("mcsModel");
				// Daten laden bevor das Binding erstellt wird
				oModel.read(`/MCSDetailsSet('${caseId}')/Checkpoints`, {
					success: function (oData) {
						// Nach erfolgreichem Laden der Daten binde die Checkpoints
						this._bindTableWithData(oData, caseId);
					}.bind(this),
					error: function (oError) {
						// Fehlerbehandlung, falls der Aufruf fehlschlägt
						sap.m.MessageToast.show("Fehler beim Laden der Daten");
					}
				});
			}
		},

		_bindTableWithData: function (oData, caseId) {
			var oCheckpointsTable = this._oCheckpointsTable;
			var oModel = this.getModel("mcsModel");

			// Sortierer definieren
			var oSorter = new sap.ui.model.Sorter("Number", false);

			// BindingInfo definieren
			var oBindingInfo = {
				path: `/MCSDetailsSet('${caseId}')/Checkpoints`,
				template: this._oCheckpointsTableRow,
				sorter: oSorter,
				model: "mcsModel"
			};

			// Tabelle binden
			oCheckpointsTable.bindItems(oBindingInfo);

			// Modell zur Tabelle setzen (falls noch nicht gesetzt)
			if (oCheckpointsTable.getModel("mcsModel") !== oModel) {
				oCheckpointsTable.setModel(oModel, "mcsModel");
			}
		},

		_loadCustomerLogo: function (sErpCustNo) {
			if (sErpCustNo && sErpCustNo !== "" && sErpCustNo !== null) {
				var oSettings = this.getOwnerComponent().getModel("settings");
				var oHeader = this.getView().byId("caseObjectPageHeader");
				sErpCustNo = oSettings.getProperty("/isAnonymizedMode") ? "" : sErpCustNo;

				var sPath = sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/ic/sap/opu/odata/sap/";
				var sUrl = sPath + "ZS_APP_DEP_SRV/CustomerSet('" + sErpCustNo + "')/$value";

				function waitForObjectImageAndSetProperty() {
					return new Promise(function (resolve) {
						function checkObjectImage() {
							var oObjectImage = oHeader.getAggregation("_objectImage");
							if (oObjectImage) {
								resolve(oObjectImage);
							} else {
								setTimeout(checkObjectImage, 100);
							}
						}

						checkObjectImage();
					});
				}

				this._getImageStream(sUrl).then(function (sBase64) {
					oHeader.setObjectImageURI(sBase64);
					return waitForObjectImageAndSetProperty();
				}).then(function (oObjectImage) {
					oObjectImage.setProperty("backgroundSize", "contain");
				});
			}
		},

		_caseNotFound: function (sCaseId) {
			//in case of missing global escal auth profile it can happen, that the global escal case information is not returned to the end user
			if (sCaseId.substring(0, 3) === "100") {
				sap.m.MessageBox.error(this._oResourceBundle.getText("caseDetailsGEMNotFoundErrorMessage", [sCaseId]));
			} else {
				sap.m.MessageBox.error(this._oResourceBundle.getText("caseDetailsNotFoundErrorMessage", [sCaseId]));
			}
		},

		parseNotes: function (data, sObjectType) {
			var oModel = new JSONModel();
			var oNotes = {};
			var oViewModel = this.getView().getModel("viewModel");
			this.getView().getModel("case").setProperty("/showExecutiveSummary", false);
			this.getView().getModel("case").setProperty("/showEscReason", false);
			var bEscalationReasonAlreadyExists = false;
			var bExecuteSummaryAlreadyExists = false;
			var bAdditionalInformationAlreadyExists = false;
			var bNotesNextStepsAlreadyExists = false;
			var bNotesCurrentSituationAlreadyExists = false;
			var bNotesIssueImpactAlreadyExists = false;

			if (data.toLastNotes) {
				//sort by date
				data.toLastNotes.results = data.toLastNotes.results.sort(function (a, b) {
					//format time, which comes in format <d:created_at>PT15H46M10S</d:created_at> to be shown as 15:46:10
					var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
					var aTMPTime = new Date(a.CreatedAt.ms + TZOffsetMs);
					var bTMPTime = new Date(b.CreatedAt.ms + TZOffsetMs);
					b.CreatedOn.setHours(bTMPTime.getHours());
					a.CreatedOn.setHours(aTMPTime.getHours());
					b.CreatedOn.setMinutes(bTMPTime.getMinutes());
					a.CreatedOn.setMinutes(aTMPTime.getMinutes());
					b.CreatedOn.setSeconds(bTMPTime.getSeconds());
					a.CreatedOn.setSeconds(aTMPTime.getSeconds());
					return b.CreatedOn.getTime() - a.CreatedOn.getTime();
				});

				data.toLastNotes.results.forEach(function (note) {
					switch (note.NoteType) {
						case "0007":
							if (!bExecuteSummaryAlreadyExists) {
								oViewModel.setProperty("/showNotesLatestStatus", true);
								oNotes.latestStatus = note;
								bExecuteSummaryAlreadyExists = true;
								if (note.CaseId.startsWith("100")) {
									// in case of Global Escalations i.e. Case starts with 100..
									// !! Ignore Case 
									// text between "Executive status summary on overall situation:"  and "Status details:"
									//get executive summary
									var text = this.getParsedNote(note.Text, "Executive Status Summary on overall situation:", "STATUS DETAILS:");
									if (text !== "") {
										this.getView().getModel("case").setProperty("/executiveSummary", text.replace(/^(\:)/, ""));
										this.getView().getModel("case").setProperty("/showExecutiveSummary", true);
									}
								} else if (note.CaseId.startsWith("20")) {
									//in case of Engagement Cases   i.e. Case starts with 200..  --> CPC & CCM ,....
									// !! Ignore Case 
									// text between "Executive Summary"  and "Status Details:"
									//get executive summary
									var text = "";
									var texttc2Delta = "";
									var texttc2Actions = "";
									if (sObjectType && (sObjectType === "ZSCUSTYP05" || sObjectType === "Critical Customer Management" || sObjectType ===
										"ZSCUSTYP04" || sObjectType === "Critical Period Coverage")) { //“MCC Critical Customer Management” with id “ZSCUSTYP05; “MCC Critical Period Coverage” with id “ZSCUSTYP04”
										text = this.getParsedNote(note.Text, "Status summary on overall situation:", "DELTA SINCE LAST REPORT:");
									} else if (sObjectType && (sObjectType === "ZSCUSTYP06" || sObjectType === "Top Critical Customers") || sObjectType === "ZSCUSTYP07") { //“Top Critical Customer” with id “ZSCUSTYP06”
										text = this.getParsedNote(note.Text, "Executive status summary on overall situation:", "DELTA SINCE LAST REPORT:");
										texttc2Delta = this.getParsedNote(note.Text, "Delta since last report:", "Next major action(s):");
										texttc2Actions = this.getParsedNote(note.Text, "Next major action(s):");
										this.getView().getModel("case").setProperty("/executiveSummaryTC2Delta", texttc2Delta.replace(/^(\:)/, ""));
										this.getView().getModel("case").setProperty("/executiveSummaryTC2Actions", texttc2Actions.replace(/^(\:)/, ""));
									} else {
										text = this.getParsedNote(note.Text, "Executive Summary", "STATUS DETAILS");
									}
									if (text !== "") {
										this.getView().getModel("case").setProperty("/executiveSummary", text.replace(/^(\:)/, ""));
										this.getView().getModel("case").setProperty("/showExecutiveSummary", true);
									}
								}
							}
							break;
						case "0005":
							var sTmp = [];
							if (!bEscalationReasonAlreadyExists) {
								oViewModel.setProperty("/showNotesManagementSummary", true);
								oNotes.managementSummary = note;
								bEscalationReasonAlreadyExists = true;
								if (note.CaseId.startsWith("100")) {
									// in case of Global Escalations i.e. Case starts with 100..
									// !! Ignore Case 
									// text between "Escalation reason & Customer business impact:"  and "De-escalation strategy to overcome critical situation"
									//get escalation reason
									var text = this.getParsedNote(note.Text, "Escalation reason & Customer business impact:",
										"DE-ESCALATION STRATEGY TO OVERCOME CRITICAL SITUATION:");
									if (text !== "") {
										this.getView().getModel("case").setProperty("/escalationReason", text.replace(/^(\:)/, ""));
										this.getView().getModel("case").setProperty("/showEscReason", true);
									}
								} else if (note.CaseId.startsWith("20")) {
									//in case of Engagement Cases   i.e. Case starts with 200..  --> CPC & CCM ,....
									// !! Ignore Case 
									// text between "Engagement Reason & Business Impact"  and "Initial Action Plan"
									//get escalation reason
									var text = "";
									var texttc2 = "";
									var texttf = "";
									if (sObjectType && (sObjectType === "ZSCUSTYP05" || sObjectType === "Critical Customer Management" || sObjectType ===
										"ZSCUSTYP04" || sObjectType === "Critical Period Coverage")) { //“MCC Critical Customer Management” with id “ZSCUSTYP05; “MCC Critical Period Coverage” with id “ZSCUSTYP04”
										text = this.getParsedNote(note.Text, "Engagement reason:", "EXIT CRITERIA:");
									} else if (sObjectType && (sObjectType === "ZSCUSTYP06" || sObjectType === "Top Critical Customers")) { //“Top Critical Customer” with id “ZSCUSTYP06”
										text = this.getParsedNote(note.Text, "Engagement reason:", "SUCCESS/EXIT CRITERIA:");
										texttc2 = this.getParsedNote(note.Text, "Success/Exit Criteria:");
										this.getView().getModel("case").setProperty("/escalationReasonTC2", texttc2.replace(/^(\:)/, ""));
									} else if (sObjectType && (sObjectType === "ZSCUSTYP07")) { //Task Force
										text = this.getParsedNote(note.Text, "Task Force reason:", "EXIT CRITERIA:");
										texttf = this.getParsedNote(note.Text, "Exit criteria:");
										this.getView().getModel("case").setProperty("/escalationReasonTC2", texttf.replace(/^(\:)/, ""));

									} else {
										text = this.getParsedNote(note.Text, "Engagement Reason & Business Impact", "INITIAL ACTION PLAN");
									}
									if (text !== "") {
										this.getView().getModel("case").setProperty("/escalationReason", text.replace(/^(\:)/, ""));
										this.getView().getModel("case").setProperty("/showEscReason", true);
									}
								}
							}

							break;
						case "0009":
							if (!bAdditionalInformationAlreadyExists) {
								bAdditionalInformationAlreadyExists = true;
								oViewModel.setProperty("/showNotesAdditionalInformation", true);
								oNotes.additionalInformation = note;
							}
							break;
						case "ZS18":
							if (!bNotesNextStepsAlreadyExists) {
								bNotesNextStepsAlreadyExists = true;
								oViewModel.setProperty("/showNotesNextSteps", true);
								oNotes.nextSteps = note;
							}
							break;
						case "ZS17":
							if (!bNotesCurrentSituationAlreadyExists) {
								bNotesCurrentSituationAlreadyExists = true;
								oViewModel.setProperty("/showNotesCurrentSituation", true);
								oNotes.currentSituation = note;
							}
							break;
						case "ZS16":
							if (!bNotesIssueImpactAlreadyExists) {
								bNotesIssueImpactAlreadyExists = true;
								oViewModel.setProperty("/showNotesIssueImpact", true);
								oNotes.issueImpact = note;
							}
					}

				}.bind(this));
			}
			oModel.setData(oNotes);

			if (!oNotes.latestStatus && !oNotes.managementSummary && !oNotes.additionalInformation && !oNotes.nextSteps && !oNotes.currentSituation &&
				!oNotes.issueImpact) {
				this.getView().getModel("viewModel").setProperty("/showNotesEmptyMsg", true);
			}

			this.getView().setModel(oModel, "notes");
		},

		onNavBack: function (oEvent) {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", false);

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = this.getRouter();
				oRouter.navTo("Global", {
					"?query": this._getQueryParameter()
				});
			}
		},

		onNavHome: function (oEvent) {
			//nav back to start page of the MCC One Dashboard

			var oRouter = this.getRouter();
			oRouter.navTo("Global", {
				"?query": this._getQueryParameter()
			});
		},

		_setCaseTypeById: function (sCaseId) {
			var oViewModel = this.getView().getModel("viewModel");
			if (sCaseId.substring(0, 2) === "20") {
				oViewModel.setProperty("/caseType", "CustomerEngagement");
			} else if (sCaseId.substring(0, 3) === "100") {
				oViewModel.setProperty("/caseType", "GlobalEscalations");
			}
		},

		navToCustomer: function () {
			var oCase = this.getOwnerComponent().getModel("case").getData();
			var oRouter = this.getRouter();
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);

			var oRouter = this.getRouter();
			oRouter.navTo("Customer", {
				ErpCustNo: oCase.CustomerR3No || oCase.CustomerErpNo,
				"?query": this._getQueryParameter()
			});
		},

		navToGlobalUltimate: function () {
			var oCase = this.getOwnerComponent().getModel("case").getData();
			var oRouter = this.getRouter();
			oRouter.navTo("Customer", {
				ErpCustNo: oCase.GlobalUltimateR3No,
				"?query": this._getQueryParameter()
			});
		},

		navToParentCase: function () {
			var oCase = this.getOwnerComponent().getModel("case").getData();
			var oRouter = this.getRouter();
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);

			oRouter.navTo("CaseDetails", {
				CaseId: oCase.ParentCaseId,
				"?query": this._getQueryParameter()
			});
		},

		onParentCaseNewTab: function (oEv) {
			var sCaseId = this.getOwnerComponent().getModel("case").getData().ParentCaseId;
			this._openCaseInNewTab(sCaseId);
		},

		_getEntitySetByCaseId: function (sCaseId) {
			var sEntity = "";
			if (sCaseId.substring(0, 2) === "20") {
				sEntity = "/CustomerEngagementSet";
			} else if (sCaseId.substring(0, 3) === "100") {
				sEntity = "/GlobalEscalationsSet";
			}
			return sEntity;
		},

		_getCaseTypeByCaseId: function (sCaseId) {
			var sCaseType = "";
			if (sCaseId.substring(0, 2) === "20") {
				sCaseType = "ZS02";
				this.caseType = "ZS02";
			} else if (sCaseId.substring(0, 3) === "100") {
				sCaseType = "ZS01";
				this.caseType = "ZS01";
			}
			return sCaseType;
		},

		_openCaseInWebDynpro: function () {
			var oCase = this.getOwnerComponent().getModel("case").getData();
			this._openWindow(oCase.LinkToCase);
		},

		onOpenUser: function (oEv) {
			if (oEv.getSource().data("useridGEM")) {
				this.formatter.openUser(oEv, oEv.getSource().data("useridGEM"));
			} else if (oEv.getSource().data("userid")) {
				this.formatter.openUser(oEv, oEv.getSource().data("userid"));
			} else {
				this.formatter.openUser(oEv, oEv.getSource().data("useridBDM"));
			}
		},

		onOpenJiraTicket: function (oEv) {
			var sJiraId = oEv.getSource().getText();
			var sUrl = "";
			var sLandscape = this._getLandscapeID();

			if (sLandscape === "ICD" || sLandscape === "ICT") {
				sUrl = "https://jira-sit2.ariba.com/browse/" + sJiraId;
			} else {
				sUrl = "https://product-jira.ariba.com/browse/" + sJiraId;
			}
			window.open(sUrl, "_blank");
		},

		handleQuickViewtPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("case").getObject();
			var oDescription = oData.toNote.results.filter(function (note) {
				return note.NoteType === "A001";
			});
			var oInitialInformation = oData.toNote.results.filter(function (note) {
				return note.NoteType === "ZMM2";
			});
			//NoteTypeDesc.Description
			//NoteTypeDesc.InitialInformation
			if (!this.quickInfoDialog) {
				this.quickInfoDialog = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.QuickInfoNotes", this);
				this.getView().addDependent(this.quickInfoDialog);
			}
			this.quickInfoDialog.setModel(new JSONModel({
				description: oDescription.length > 0 ? oDescription[0].Text : "-",
				initialInformation: oInitialInformation.length > 0 ? oInitialInformation[0].Text : "-"
			}), "notes");

			this.quickInfoDialog.openBy(oEv.getSource());
		},

		handleQuickViewFocusAreaPressed: function (oEv) {
			var oCtx = oEv.getSource().getBindingContext("focusAreas");
			var oData = oCtx.getObject();
			if (!this.quickInfoFocusAreaDialog) {
				this.quickInfoFocusAreaDialog = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.QuickInfoFocusArea", this);
				this.getView().addDependent(this.quickInfoFocusAreaDialog);
			}
			this.quickInfoFocusAreaDialog.setBindingContext(oCtx, "focusAreas");
			/*			this.quickInfoFocusAreaDialog.setModel(new JSONModel({
							description: oData.Description,
							statusSummary : oData.StatusSummary
						}), "focusAreaQuickNotes");*/

			this.quickInfoFocusAreaDialog.openBy(oEv.getSource());
		},

		handleQuickViewImpactedCustomersPressed: function (oEv) {
			var oCtx = oEv.getSource().getBindingContext("impactedCustomers");
			var oData = oCtx.getObject();
			if (!this.quickInfoImpactedCustomersDialog) {
				this.quickInfoImpactedCustomersDialog = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.QuickInfoImpactedCustomers",
					this);
				this.getView().addDependent(this.quickInfoImpactedCustomersDialog);
			}
			this.quickInfoImpactedCustomersDialog.setBindingContext(oCtx, "impactedCustomers");
			this.quickInfoImpactedCustomersDialog.openBy(oEv.getSource());
		},

		openTicketURL: function (oEv) {
			var oData = oEv.getSource().getBindingContext("case").getObject();
			var currentUrl = window.location.href;
			var url = "";
			var id = "";
			var type = "";
			if (oData.BCPIncident !== "") {
				id = oData.BCPIncident;
				type = "BCP";
			} else if (oData.SNOWIncident !== "") {
				id = oData.SNOWIncident;
				type = "SNOW";
			}

			if (id !== "") {
				if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard")) {
					//we are in test envrionment
					if (type === "BCP") {
						url = "https://bcdmain.wdf.sap.corp/sap/support/message/" + id;
					} else if (type === "SNOW") {
						url = "https://dev.itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + id;
					}
				} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
					//we are in test envrionment
					if (type === "BCP") {
						url = "https://qa-support.wdf.sap.corp/sap/support/message/" + id;
					} else if (type === "SNOW") {
						url = "https://test.itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + id;
					}
				} else {
					if (type === "BCP") {
						url = "https://support.wdf.sap.corp/sap/support/message/" + id;
					} else if (type === "SNOW") {
						url = "https://itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + id;
					}
				}
				this._openWindow(url);
			}

		},
		_checkShowDownloadPDFFile: function (oCase) {
			//check if user has general access to at least the aggregation view
			var oSettings = this.getOwnerComponent().getModel("settings").getData();
			// we should not only check for Global Aggregation if (oSettings.ShowGlobalAggregation) {
			//GEM  Case Type = ZS01 ,Process Type = ZSPRCTYP01, 
			if (oCase.CaseType === "ZS01") {
				if (oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
			// } else {
			// 	return false;
			// }

		},
		_showSubscriptionButtonForSpecificCaseTypes: function (oCase) {
			//check if user has general access to at least the aggregation view
			var oSettings = this.getOwnerComponent().getModel("settings").getData();
			if (oSettings.ShowGlobalAggregation) {
				//GEM  Case Type = ZS01 ,Process Type = ZSPRCTYP01, 
				if (oCase.CaseType === "ZS01" && oCase.ProcessTypeId === "ZSPRCTYP01") {
					if (oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations) {
						return true;
					} else {
						return false;
					}
				} else
					// CCM Case Type = ZS02  CustomerType = “MCC Critical Customer Management” with id “ZSCUSTYP05
					if (oCase.CaseType === "ZS02" && oCase.CustomerTypeID === "ZSCUSTYP05") {
						return true;
					} else if (oCase.CaseType === "ZS02" && oCase.CustomerTypeID === "ZSCUSTYP04") { //CPC
						return true;
					} else if (oCase.CaseType === "ZS02" && oCase.CustomerTypeID === "ZSCUSTYP06") { //TC2
						//return true;
						return false;
					} else {
						return false;
					}
			} else {
				return false;
			}

		},
		_checkSubscriptionStatusForCase: function (oCase) {
			this.getModel("subModel").read("/MailRoles", {
				filters: [new sap.ui.model.Filter("caseID", sap.ui.model.FilterOperator.EQ, oCase.CaseID)],
				sorters: [new sap.ui.model.Sorter("createdAt")],
				success: function (response) {
					if (response.results.length > 0) {
						this.getView().getModel("viewModel").setProperty("/subscriptionID", response.results[0].RoleID);
						this.getView().getModel("viewModel").setProperty("/subscriptionAction", "DELETE");
					} else {
						this.getView().getModel("viewModel").setProperty("/subscriptionID", "");
						this.getView().getModel("viewModel").setProperty("/subscriptionAction", "ADD");
					}
				}.bind(this),
				error: function (err) {
					this.getView().getModel("viewModel").setProperty("/subscriptionID", "");
					this.getView().getModel("viewModel").setProperty("/subscriptionAction", "ERROR");
				}
			});

		},
		triggerSubscription: function () {
			var oSubModel = this.getModel("subModel");
			var sCustomerEngagement = "";
			var oCase = this.getView().getModel("case").getData();
			if (oCase.CaseType === "ZS01" && oCase.ProcessTypeId === "ZSPRCTYP01") {
				sCustomerEngagement = "GEM";
			} else
				// CCM Case Type = ZS02  CustomerType = “MCC Critical Customer Management” with id “ZSCUSTYP05
				if (oCase.CaseType === "ZS02" && oCase.CustomerTypeID === "ZSCUSTYP05") {
					sCustomerEngagement = "CCM";
				} else
					// CCM Case Type = ZS02  CustomerType = “MCC Critical Period Coverage” with id “ZSCUSTYP04”
					if (oCase.CaseType === "ZS02" && oCase.CustomerTypeID === "ZSCUSTYP04") {
						sCustomerEngagement = "CPC";
					} else
						// CCM Case Type = ZS02  CustomerType = “Top Critical Customer” with id “ZSCUSTYP06”
						if (oCase.CaseType === "ZS02" && oCase.CustomerTypeID === "ZSCUSTYP06") {
							sCustomerEngagement = "TC2";
						}
			var that = this;
			if (this.getView().getModel("viewModel").getProperty("/subscriptionAction") === "ADD") {
				oSubModel.create("/MailRoles", {
					RoleType: "SUB",
					Recipients: this.getModel("userapi").getProperty("/email"),
					UserID: this.getModel("userapi").getProperty("/name"),
					CustomerEngagement: sCustomerEngagement,
					caseID: parseInt(oCase.CaseID, 10)
				}, {
					success: function (response) {
						if (response) {
							that.getView().getModel("viewModel").setProperty("/subscriptionID", response.RoleID);
						}
						that.getView().getModel("viewModel").setProperty("/subscriptionAction", "DELETE");
					},
					error: function (err) {
						that.getView().getModel("viewModel").setProperty("/subscriptionID", "");
					}
				});
				this.trackEvent("Subscription: Case Add");
			} else if (this.getView().getModel("viewModel").getProperty("/subscriptionAction") === "DELETE") {
				oSubModel.remove("/MailRoles(guid'" + this.getView().getModel("viewModel").getProperty("/subscriptionID") + "')", {
					success: function (response) {
						that.getView().getModel("viewModel").setProperty("/subscriptionAction", "ADD");
						that.getView().getModel("viewModel").setProperty("/subscriptionID", "");
					},
					error: function (err) {
						that.getView().getModel("viewModel").setProperty("/subscriptionID", "");
					}
				});
			}

		},

		_generateHeadeToolbarForTopIssueOverview: function (oFormatter, sTitle, iNumber, sRating, sStatus) {
			var oRatingTitle = new sap.ui.core.Icon({
				src: formatter.ratingIcon(sRating),
				color: sRating === "C" ? "red" : sRating === "B" ? "orange" : "green"
			});
			var oStatusTitle = new sap.m.Title({
				titleStyle: "H5",
				text: this.formatter.showValueOrPlaceholder(sStatus),
				textAlign: sap.ui.core.TextAlign.End,
				width: "8rem"
			});
			var oToolbar = new sap.m.Toolbar({
				height: "3rem",
				content: [new sap.m.Title({
					titleStyle: "H4",
					wrapping: true,
					//text: this.formatter.showValueOrPlaceholder("#" + iNumber + ": " + sTitle)
					text: this.formatter.showValueOrPlaceholder(this._oResourceBundle.getText("numberTokenWithTitle", [iNumber, sTitle]))
				}), new sap.m.ToolbarSpacer(), oStatusTitle, oRatingTitle]
			});
			return oToolbar;
		},

		_createActionPlanTable: function (sBindingPath) {
			var aColumns = [
				new sap.m.Column({
					header: new sap.m.Text({
						text: '{i18n>actionItem}'
					})
				}),
				new sap.m.Column({
					header: new sap.m.Text({
						text: '',
						textAlign: sap.ui.core.TextAlign.Right,
						width: "100%"
					}),
					hAlign: sap.ui.core.TextAlign.Right,
					width: "7rem"
				}),
				new sap.m.Column({
					header: new sap.m.Text({
						text: '' //'{i18n>info}'
					}),
					width: "2rem"
				}),
				new sap.m.Column({
					header: new sap.m.Text({
						text: '{i18n>startAndEndDate}'
					}),
					demandPopin: true,
					popinDisplay: sap.m.PopinDisplay.Block,
					minScreenWidth: "10000rem"
				}),
				new sap.m.Column({
					header: new sap.m.Text({
						text: '{i18n>products}'
					}),
					demandPopin: true,
					popinDisplay: sap.m.PopinDisplay.Block,
					minScreenWidth: "10000rem"
				}),
				new sap.m.Column({
					header: new sap.m.Text({
						text: '{i18n>effortInDays}'
					}),
					demandPopin: true,
					popinDisplay: sap.m.PopinDisplay.Block,
					minScreenWidth: "10000rem"
				}),
				new sap.m.Column({
					header: new sap.m.Text({
						text: '{i18n>notCoveredEscalIO}'
					}),
					demandPopin: true,
					popinDisplay: sap.m.PopinDisplay.WithoutHeader,
					minScreenWidth: "10000rem"
				}),
				new sap.m.Column({
					header: new sap.m.Text({
						text: '{i18n>customResp}'
					}),
					demandPopin: true,
					popinDisplay: sap.m.PopinDisplay.WithoutHeader,
					minScreenWidth: "10000rem"
				}),
				new sap.m.Column({
					header: new sap.m.Text({
						text: '{i18n>responsible}'
					}),
					demandPopin: true,
					popinDisplay: sap.m.PopinDisplay.Block,
					minScreenWidth: "10000rem"
				})
			];

			var oRowTopIssueTitle = new sap.m.ObjectIdentifier({
				title: {
					path: 'ActionText',
					formatter: this.formatter.showValueOrPlaceholder
				}
			});
			var oRowTopIssueNumber = new sap.m.ObjectIdentifier({
				title: "{ActionNo}" + "."
			});
			var oRowTopIssueProducts = new sap.m.Text({
				text: {
					path: 'ProductT',
					formatter: this.formatter.showValueOrPlaceholder
				}
			});
			var oRowTopIssueStartDateEndDate = new sap.m.Text({
				text: {
					parts: [{
						path: 'StartDate'
					}, {
						path: 'EndDate'
					}],
					formatter: this.formatter.dateFormatTwoDatesWithSeperator
				},
				wrapping: true,
				maxLines: 2
			});
			var oRowTopIssueEmployeeResponsibility = new sap.m.Text({
				text: {
					parts: [{
						path: 'EmpRespName'
					}],
					formatter: this.formatter.showValueOrPlaceholder
				}
			});
			if (this.getModel("settings").getProperty("/isAnonymizedMode")) {
				oRowTopIssueEmployeeResponsibility = new sap.m.Text({
					text: this._oResourceBundle.getText("anonymizedText")
				});
			}

			var oRowTopIssueEffortComparison = new sap.suite.ui.microchart.BulletMicroChart({
				size: sap.m.Size.S,
				minValue: 0,
				maxValue: "{EffPlan}",
				targetValue: "{EffPlan}",
				showTargetValue: true,
				showActualValue: true,
				showValueMarker: true,
				actualValueLabel: "{EffConsum}" + " consumed",
				targetValueLabel: "{EffPlan}" + " planned",
				actual: {
					value: "{EffConsum}",
					color: {
						parts: [{
							path: "EffConsum"
						}, {
							path: "EffPlan"
						}],
						formatter: function (iEffConsum, iEffPlan) {
							if (iEffConsum > iEffPlan)
								return sap.m.ValueColor.Error;
							else
								return sap.m.ValueColor.Neutral;
						}
					}
				}
			});
			var oRowTopIssueCustomerResponsibility = new sap.m.CheckBox({
				text: '{i18n>customResp}',
				editable: false,
				useEntireWidth: false,
				wrapping: true,
				selected: {
					path: 'CustRespFlag',
					formatter: function (bFlag) {
						return bFlag !== "" ? true : false;
					}
				}
			});
			var oRowTopIssueNotCoveredByEscIO = new sap.m.CheckBox({
				text: '{i18n>notCoveredEscalIO}',
				editable: false,
				useEntireWidth: false,
				width: "15rem",
				wrapping: false,
				selected: {
					path: 'CoverageFlag',
					formatter: function (bFlag) {
						return bFlag !== "" ? true : false;
					}
				}
			});
			var oRowTopIssueStatus = new sap.m.Text({
				text: {
					path: 'StatusT',
					formatter: this.formatter.showValueOrPlaceholder
				},
				width: "100%"

			}).addStyleClass("topIssueTableStatus");
			var oIconActionItemInfo = new sap.ui.core.Icon({
				src: "sap-icon://message-information",
				useIconTooltip: false,
				color: sap.ui.core.IconColor.Default,
				size: "1.2rem",
				press: [this.handleActionItemInfoPopoverPress, this]
			}).addStyleClass("sapUiTinyMarginBegin").addStyleClass("topIssueTableIcon");

			oIconActionItemInfo.bindElement({
				path: sBindingPath,
				model: "topIssues"
			});

			var oTemplate = new sap.m.ColumnListItem({
				cells: [
					//oRowTopIssueNumber,
					oRowTopIssueTitle,
					oRowTopIssueStatus,
					oIconActionItemInfo,
					oRowTopIssueStartDateEndDate,
					oRowTopIssueProducts,
					oRowTopIssueEffortComparison,
					oRowTopIssueNotCoveredByEscIO,
					oRowTopIssueCustomerResponsibility,
					oRowTopIssueEmployeeResponsibility
				]
			});

			var oActionPlanTable = new sap.m.Table({
				popinLayout: sap.m.PopinLayout.GridSmall,
				columns: aColumns
			});

			oActionPlanTable.setBusyIndicatorDelay(0);
			oActionPlanTable.setModel(this.getView().getModel("topIssues"));
			oActionPlanTable.bindAggregation("items", {
				path: sBindingPath, // <<<Your data path at runtime
				template: oTemplate
			});

			//sort by ActionNo.
			var binding = oActionPlanTable.getBinding("items");
			//sort ascending
			var aSorters = [];

			var oSorter = new sap.ui.model.Sorter("ActionNo", false);
			/*oSorter.fnCompare = function (value1, value2) {
				value2 = parseFloat(value2);
				value1 = parseFloat(value1);
				if (value1 < value2) return -1;
				if (value1 == value2) return 0;
				if (value1 > value2) return 1;
			};
			*/
			aSorters.push(oSorter);
			binding.sort(aSorters);

			return oActionPlanTable;
		},

		handleActionItemInfoPopoverPress: function (oEvent) {

			var oControl = oEvent.getSource();

			// create new or use existing
			this._oActionItemInfoPopover = this._oActionItemInfoPopover || new sap.m.Popover({
				title: this._oResourceBundle.getText("actionItemInfoPopoverTitle"),
				placement: sap.m.PlacementType.HorizontalPreferredLeft,
				content: [
					new sap.m.VBox({
						width: "auto"
					})
						.addItem(
							new sap.m.Label({
								text: this._oResourceBundle.getText("lastChangeBy")
							}))
						.addItem(
							new sap.m.Text({
								text: ''
							}).addStyleClass("sapUiSmallMarginBottom"))
						.addItem(
							new sap.m.Label({
								text: this._oResourceBundle.getText("lastChangedOn")
							}))
						.addItem(
							new sap.m.Text({
								text: ''
							}))

				],
				footer: [
					new sap.m.Toolbar({
						content: [
							new sap.m.ToolbarSpacer({}),
							new sap.m.Button({
								text: this._oResourceBundle.getText("close"),
								press: function () {
									this.getParent().getParent().close();
								}
							})
						]
					})
				]
			}).addStyleClass("sapUiPopupWithPadding");

			var sBindingPath = oControl.getBindingContext().getPath();
			var oChangedAt = this.getView().getModel("topIssues").getProperty(sBindingPath + "/ChangedAt");
			var sChangedBy = this.getView().getModel("topIssues").getProperty(sBindingPath + "/ChangedBy");

			this._oActionItemInfoPopover.getContent()[0].getItems()[1].setText(this.formatter.showValueOrPlaceholder(sChangedBy));
			this._oActionItemInfoPopover.getContent()[0].getItems()[3].setText(this.formatter.dateTimeFormatOneDateTime(oChangedAt));

			this._oActionItemInfoPopover.bindElement(sBindingPath);
			this._oActionItemInfoPopover.openBy(oControl);
		},

		_initCheckpointsTable: function () {
			this._oCheckpointsTable = new sap.m.Table("checkpointsTable", {
				width: "auto"
			}).addStyleClass("sapUiSmallMargin sapUiNoMarginTop");
			this._oCheckpointsTableRow = new sap.m.ColumnListItem();
			// "cells"
			var oCheckpointNumber = new sap.m.Text({
				text: "{mcsModel>Number}"
			});
			var oCheckpointName = new sap.m.Text({
				text: "{mcsModel>Description}"
			});
			var oCheckpointToBeDate = new sap.m.VBox({
				alignContent: sap.m.FlexAlignContent.SpaceBetween
			})
				.addItem(new sap.m.Text({
					text: {
						path: "mcsModel>ToBeDate",
						formatter: this.formatter.dateFormatOneDate //dateFormatOneDate
					}
				}))
				.addItem(new sap.m.Text({
					text: {
						path: "mcsModel>ToBeDate",
						formatter: this.formatter.dateFormatOneTime //dateFormatOneDate
					}
				}));

			var oCheckpointAsIsDate = new sap.m.VBox({
				alignContent: sap.m.FlexAlignContent.SpaceBetween
			})
				.addItem(new sap.m.Text({
					text: {
						path: "mcsModel>AsIsDate",
						formatter: this.formatter.dateFormatOneDate //dateFormatOneDate
					}
				}))
				.addItem(new sap.m.Text({
					text: {
						path: "mcsModel>AsIsDate",
						formatter: this.formatter.dateFormatOneTime //dateFormatOneDate
					}
				}));

			var oCheckpointStatus = new sap.m.Text({
				text: "{mcsModel>StatusText}"
			});
			var oCheckPointNote = new sap.ui.core.Icon({
				src: '{= ${mcsModel>Note} !== "" ? "sap-icon://notes" : "" }',
				useIconTooltip: false,
				color: sap.ui.core.IconColor.Default,
				size: "1.2rem",
				press: [this.handlePopoverPress, this]
			});

			// corresponding columns
			var oColissueCheckpointNumber = new sap.m.Column({
				header: new sap.m.Text({
					text: "#"
				}),
				width: "5%"
			});
			var oColCheckpointName = new sap.m.Column({
				header: new sap.m.Text({
					text: "{i18n>name}"
				}),
				width: "auto"
			});
			var oColCheckpointToBeDate = new sap.m.Column({
				header: new sap.m.Text({
					text: "{i18n>toBeDate}"
				}),
				width: "17%"
			});

			var oColCheckpointAsIsDate = new sap.m.Column({
				header: new sap.m.Text({
					text: "{i18n>asIsDate}"
				}),
				width: "17%"
			});
			var oColCheckpointStatus = new sap.m.Column({
				header: new sap.m.Text({
					text: "{i18n>tabTopIssuesStatus}"
				}),
				width: "10%"
			});
			// var oColCheckpointRating = new sap.m.Column({
			// 	header: new sap.m.Text({
			// 		text: "{i18n>tabTopIssuesRating}"
			// 	}),
			// 	width: "8%",
			// 	hAlign: "Center"
			// });
			var oColCheckpointNote = new sap.m.Column({
				header: new sap.m.Text({
					text: "{i18n>note}"
				}),
				width: "7%",
				hAlign: "Center"
			});
			// row template
			this._oCheckpointsTableRow
				.addCell(oCheckpointNumber)
				.addCell(oCheckpointName)
				.addCell(oCheckpointToBeDate)
				.addCell(oCheckpointAsIsDate)
				.addCell(oCheckpointStatus)
				// .addCell(oCheckpointRating)
				.addCell(oCheckPointNote);

			// table
			this._oCheckpointsTable.setBusyIndicatorDelay(0);
			this._oCheckpointsTable
				.addColumn(oColissueCheckpointNumber)
				.addColumn(oColCheckpointName)
				.addColumn(oColCheckpointToBeDate)
				.addColumn(oColCheckpointAsIsDate)
				.addColumn(oColCheckpointStatus)
				// .addColumn(oColCheckpointRating)
				.addColumn(oColCheckpointNote);

			var iconTabBarCheckpointsPanel = this.byId("iconTabBarCheckpoints");

			iconTabBarCheckpointsPanel.addContent(new sap.m.Toolbar({
				content: [new sap.m.Title({
					titleStyle: "H4",
					text: this._oResourceBundle.getText("tabCheckpoints")
				})]
			}).addStyleClass("sapUiSmallMargin sapUiNoMarginBottom"));
			iconTabBarCheckpointsPanel.addContent(this._oCheckpointsTable);
		},

		handlePopoverPress: function (oEvent) {
			var oModel = new JSONModel(oEvent.getSource().getBindingContext("mcsModel").getObject());

			// create popover
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.Case.CheckpointsPopover", this);
				this.getView().addDependent(this._oPopover);
				this._oPopover.attachAfterOpen(function (oEv) {
					this._oPopover.$().removeAttr("aria-hidden");
				}, this);
				this._oPopover.attachAfterClose(function (oEv) {
					this._oPopover.$().attr("aria-hidden", "true");
				}, this);
			}
			this._oPopover.setModel(oModel);
			// delay because addDependent will do a async rerendering and the actionSheet will immediately close without it.
			var oControl = oEvent.getSource();
			this._oPopover.openBy(oControl);

		},

		handleActionPress: function (oEvent) {
			oEvent.getSource().getParent().getParent().close();
			//button->toolbar->popover.close();
		},

		onPressAdobe: function () {
			this.trackEvent("Export/Detail:PDF");
			this.reportDownloadHandler.resetMimeFilterModel(this);
			this.getModel("extReportFilters").setProperty("/id", [this.getView().getModel("case").getData().CaseID]);
			this.reportDownloadHandler.onPressGenerateMIME(this, "PDF");
		},
		//Timeline Code:
		loadAllData: async function (that, sCaseType, caseId) {

			var showMe = this.getOwnerComponent().getModel("settings").getProperty("/showDetailTimelineTab");

			this.byId("TimelineSection").setBusy(true);
			if (showMe === true) { //might be unnecessary

				try {

					var sPath = "/CaseSet(CaseID='" + caseId + "',CaseType='" + sCaseType + "',CaseObject='C')/";
					await that.createModel(that, sPath, "");

					await that.createModel(that, sPath, "toCheckPoint");

					await that.createModel(that, sPath, "toTopIssue");

					await that.createModel(that, sPath, "Milestones");

					this.refreshTimeline(this); // applies all data changes to the objects
				} catch (error) {
					console.error(error);
				}
			}
		},
		refreshTimeline: function (that) {

			this.getView().byId("refresher").setVisible(false);
			this.getView().byId("refresher").setVisible(true);

			this.byId("TimelineSection").setBusy(false);
		},
		_bindTimeline: async function (caseId, that) {

			var that = this;
			var sCaseType = this._getCaseTypeByCaseId(caseId);
			if (this.checkpointsArranged !== caseId) {

				var oModel = new JSONModel(sap.ui.require.toUrl("com/sap/mcconedashboard/json/Timeline.json"));
				this.getView().setModel(oModel, "jModel");
				this.byId("TimelineSection").setBusy(true);
				await this.loadMilestones(this);
				await this.loadAllData(that, sCaseType, this.caseId);
			}
			await new Promise(resolve => setTimeout(resolve, 100)); // Delay to allow rendering
			if (this.checkpointsArranged !== caseId) {
				this.arrangeCheckpoints(this);

				var aLegends = ["checkpointLegend", "milestoneLegend"];
				aLegends.forEach(function (legendId) {
					that.oView.byId(legendId).addEventDelegate({
						"onAfterRendering": function (oEv) {
							if (!this.legendRendered) {
								var items = oEv.srcControl.getItems();
								items.forEach(function (element) {
									if (element.getVisible()) {
										var shape = element.getShape();
										var height = document.getElementById(element.getId()).style.height.slice(0, -2);
										shape.setHeight(height / 2);
										shape.setWidth(height / 2);
										shape.setYBias(height * 0.7);
										//	shape.rerender();
									}
								});
								that.oView.byId(legendId).rerender();
								this.legendRendered = true;
							}
						}
					});
				})
			}
			var oTreeTable = this.getView().byId("treeTable");
			if (oTreeTable) {
				var rowCount = oTreeTable.getBinding("rows").getLength();
				var containerHeight = ((rowCount + 3) * 43) + "px"
				this.getView().byId("timelineGCContainer").setHeight(containerHeight);
			}

		},


		getCheckpointIDs: function (that) { // loads the checkpoint elements' id's into the json file
			return new Promise(function (resolve) {
				var aCheckpoints = that.getView().getModel("jModel").getProperty("/root").children[0].children[0].subtask;
				var qIcon = $("[id*='baseImageUniqueId-99']"); // gets all visible Checkpoints
				for (var i = 0; i < qIcon.length; i++) {
					var sId = $(qIcon[i]).attr("data-sap-ui");
					var iPos = sId.charAt(sId.length - 1);
					aCheckpoints[iPos].id = sId;
				}
				resolve();
			});
		},
		arrangeCheckpoints: async function (that) { // moves the checkpoints, so they are all visible
			var aData = that.getView().getModel("jModel").getProperty("/root").children[0].children[0].subtask;
			that.getView().getModel("jModel").getProperty("/root").children[0].children[0].overlapping = 0;
			var overlapping = 0;

			await this.getCheckpointIDs(that);
			for (var i = 0; i < aData.length; i++) {
				if (aData[i].time) {
					try {
						aData[i].X = sap.ui.getCore().byId(aData[i].id).getX();
					} catch (error) {
						console.error(error);
					}
				}
				aData[i].yBias = 0;
			}
			for (var y = 0; y < 10; y++) {
				for (var j = 0; j < aData.length - 1; j++) { // algorithm that compares all positions and declares necessary offsets
					for (var k = j + 1; k < aData.length; k++) {
						if (aData[j].X && aData[k].X) { // check if both CPs are loaded
							if (Math.abs(aData[j].X - aData[k].X) < 20 && Math.abs(aData[j].yBias - aData[k].yBias) < 19) {
								if (aData[j].X < aData[k].X) {
									aData[k].yBias += 10;
									aData[j].yBias -= 10;
								} else {
									aData[j].yBias += 10;
									aData[k].yBias -= 10;
								}
								overlapping = that.getView().getModel("jModel").getProperty("/root").children[0].children[0].overlapping;
								if (overlapping * 10 <= Math.abs(aData[j].yBias) || overlapping * 10 <= Math.abs(aData[k].yBias)) {
									that.getView().getModel("jModel").getProperty("/root").children[0].children[0].overlapping += 1;
								}
							}
						}
					}
				}
			}
			var root = that.getView().getModel("jModel").getProperty("/root");
			var conHeight = root.children[1].children.length * 42 + Math.max(overlapping, 1) * 21 + 205;
			root.containerHeight = conHeight;
			sap.ui.getCore().byId(aData[0].id).setYBias(aData[0].yBias + 0.01); // sets some data, so checkpoints get refreshed
			this.checkpointsArranged = this.caseId;
		},

		mapData: function (that, oData) { // maps the OData-data into the json file
			var type = oData.type;
			var data1 = that.getView().getModel("jModel").getProperty("/root");

			if (type === "") { // if general case info
				// root
				data1.escalationStart = oData.EscalationStartDate;
				if (oData.ClosingTime) {
					data1.closed = true;
					data1.escalationEnd = oData.ClosingTime;
					data1.todayOrPlanned = oData.ClosingTime;
					data1.children[0].task[2].endTime = oData.ClosingTime;
				} else {
					data1.closed = false;
					var today = new Date();
					var closeDate = oData.PlannedCloseDate;
					if (closeDate) {
						if (today < closeDate) {
							data1.escalationEnd = oData.PlannedCloseDate;
							data1.todayOrPlanned = today;
						} else {
							data1.escalationEnd = today;
							data1.todayOrPlanned = oData.PlannedCloseDate;
						}
					} else {
						data1.escalationEnd = today;
						data1.todayOrPlanned = today;
					}
				}
				data1.plannedClosure = oData.PlannedCloseDate;

				var timespan = new Date(data1.escalationEnd - data1.escalationStart);

				data1.horizonStart = new Date(data1.escalationStart - timespan * 0.05);
				data1.horizonEnd = new Date(data1.escalationEnd - (-timespan * 0.05));

				// Start for Rating + Checkpoint
				data1.children[0].task[0].startTime = data1.escalationStart;
				data1.children[0].children[0].subtask[0].time = data1.escalationStart;

			} else if (type === "Milestones") {
				// Milestones
				var array = oData.results;
				var someCustom = false;

				oData.results.forEach(function (element) {
					var dTime = element.StartDate;
					var sName = element.Title;
					var sDescription = element.Description;
					var sIcon = element.Link;
					var sPathCPs = data1.children[0].children[0].subtask;

					var oMilestone = {
						"time": dTime,
						"title": sName,
						"description": sDescription,
						"icon": sIcon,
						"custom": true
					}
					sPathCPs.push(oMilestone);
					someCustom = true;
				});
				if (someCustom) {
					data1.children[0].children[0].text = "Checkpoints / Milestones"
				}
			} else if (type === "toCheckPoint") {
				// Checkpoints

				oData.results.forEach(function (element) {
					var dTime = element.AsIsDate;
					var sName = element.Name;
					var iNum = element.Number;
					var sPathRating = data1.children[0].task;
					var sPathCPs = data1.children[0].children[0].subtask;

					if (iNum < 4) {
						sPathCPs[iNum].time = dTime;

					} else if (4 < iNum && iNum < 8) {
						sPathCPs[iNum - 1].time = dTime;
						// Re-Ratings
						if (sName === "MPTRY") {
							sPathRating[0].endTime = dTime;
							sPathRating[1].startTime = dTime;
						} else if (sName === "MPTYG") {
							for (let i = sPathRating.length - 1; i >= 0; i--) {
								const rating = sPathRating[i];
								if (rating.title === "Yellow" && !rating.endTime) {
									rating.endTime = dTime;
									break;
								}
							}
							sPathRating[2].startTime = dTime;
						}
					} else {
						var ratingLen = sPathRating.length;
						var len = sPathCPs.length;
						var aRating = {
							"startTime": "",
							"endTime": "",
							"color": "sapUiNegativeText",
							"title": "Red"
						};
						var aCheckpoint = {
							"time": "",
							"title": "Rerating to ",
							"icon": "sap-icon://inspect"
						}
						var hasCheckpointAlready = sPathCPs.some(function (cp) {
							return cp.name === sName
						});
						if (sName.includes("MPTYR_") && !hasCheckpointAlready) {
							sPathRating.push(aRating);
							sPathRating.find(function (rating) {
								if (rating.title === "Yellow" && !rating.endTime) {
									rating.endTime = dTime;
									return true;
								}
							});
							sPathRating[ratingLen].startTime = dTime;
							aCheckpoint.time = dTime;
							aCheckpoint.title += "Red";
							aCheckpoint.name = sName;
							sPathCPs.push(aCheckpoint);
						} else if (sName.includes("MPTRY_") && !hasCheckpointAlready) {
							aRating.color = "sapUiLegend1";
							aRating.title = "Yellow";
							sPathRating.push(aRating);
							sPathRating.find(function (rating) {
								if (rating.title === "Red" && !rating.endTime) {
									rating.endTime = dTime;
									return true;
								}
							});
							sPathRating[ratingLen].startTime = dTime;
							aCheckpoint.time = dTime;
							aCheckpoint.title += "Yellow";
							aCheckpoint.icon = "sap-icon://workflow-tasks";
							aCheckpoint.name = sName;
							sPathCPs.push(aCheckpoint);
						}
					}
				});

			} else if (type === "toTopIssue") {
				for (var i = 0; i < oData.results.length; i++) {
					data1.children[1].children[i] = {
						"title": "",
						"subtask": [{}]
					};

				}

				oData.results.sort(function (a, b) {
					return a.CreatedAt - b.CreatedAt;
				});
				oData.results.forEach(function (element, index) {

					var aTopIssue = data1.children[1].children;
					var dStart = element.CreatedAt;
					var dEnd = element.RequestedEndDate;
					var sDescription = ""

					if (element.Description && !element.DescriptionLong) {
						sDescription = element.Description;
					} else {
						sDescription = element.DescriptionLong;
					}

					aTopIssue[index] = {
						"title": "",
						"subtask": [{}]
					};

					var prefix = "Top Issue " + (index + 1);

					aTopIssue[index].text = prefix + " - " + sDescription;
					aTopIssue[index].subtask[0].title = sDescription;
					aTopIssue[index].subtask[0].RatingText = element.RatingText;
					aTopIssue[index].subtask[0].CreatedAt = dStart;
					aTopIssue[index].subtask[0].isIssue = "true";
					aTopIssue[index].subtask[0].StatusText = element.StatusText;
					aTopIssue[index].subtask[0].id = element.TopIssueID;
					aTopIssue[index].subtask[0].prefix = prefix;
					aTopIssue[index].overlapping = 2;

					var maxSolvedDate = new Date(Math.min(dEnd, data1.escalationEnd));
					aTopIssue[index].subtask[0].maxSolvedDate = maxSolvedDate;

					// load TopIssue Note (aka description)
					aTopIssue[index].subtask[0].description = element.noteDescription;

					/*
					var newData = element.toNote;
					newData.type = "toNote";
					that.mapData(that, newData);*/
				});

			}
			/* Keep in case Data loading different
			
						else if (type === "toNote") {
							var aTopIssue = data1.children[1].children;
							var oNote = {};
							try {
								oNote = oData.results[0];
							} //Enables loading via readOData
							catch {
								oNote = oData;
							}
							aTopIssue.forEach(function (element, index) {

								try {
									if (element.subtask[0].id === oNote.RefDocID) {
										element.subtask[0].description = oNote.Text;
									}
								} catch {
								}
							});

						}*/
			// apply data changes to model
			that.getView().getModel("jModel").setProperty("/root", data1);

		},
		createModel: function (that, sPath, model) { // Creates models from OData-data
			return new Promise(async (resolve, reject) => {
				var sPathN = sPath + model;
				var oData = {};
				if (model === "") {
					oData = that.getView().getModel("case").getData();
					oData.type = model;
					await new Promise(resolve => setTimeout(resolve, 100));
					that.mapData(that, oData);
				} else if (model === "toTopIssue") {
					oData = that.getView().getModel("case").getData().toTopIssue;
				} else if (model === "Milestones") {
					oData = that.getView().getModel("milestoneModel").getData();
				} else {
					var isElse = true;
					await that.readFromOData(that, sPathN).then(function (oData) {
						oData.type = model; // gets the type of data ("" = general case info, "toCheckPoint" = checkpoints ...)
						that.mapData(that, oData);
						resolve();
					});
				}
				if (!isElse) {
					oData.type = model;
					await that.mapData(that, oData);
					resolve();
				}
			});
		},
		readFromOData: function (that, sPath) { // Read OData
			return new Promise(function (resolve, reject) {
				that.byId("TimelineSection").setBusy(true);
				that.getOwnerComponent().getModel("appDepModel").read(sPath, {
					success: function (oData) {
						resolve(oData);
						that.byId("TimelineSection").setBusy(false);
					},
					error: function (err) {
						that.byId("TimelineSection").setBusy(false);
						reject(err);
					}
				});
			});
		},
		onShapeEnter: function (oEvent) { // Creates Popovers for the different shapes
			var sShapeID = oEvent.getParameter("shape"),
				oView = this.getView();
			var oDats = {};
			if (!sShapeID) {
				return;
			}

			oDats["title"] = sShapeID.getTitle();
			oDats["time"] = this.formatter.formatDate2Display(sShapeID.getTime());
			if (sShapeID.getEndTime()) {
				oDats["endTime"] = this.formatter.formatDate2Display(sShapeID.getEndTime());
			}

			var fragModel = new JSONModel(oDats);

			// determine type of popover
			var prefix = "sap.gantt.simple.";
			var name = sShapeID.getMetadata().getName();
			var shapeType = "";
			if (name === prefix + "shapes.Task") {
				shapeType = "Rating";
				oDats["trueEndTime"] = this.formatter.formatDate2Display(sShapeID.getCustomData()[0].getProperty("key"));
				oDats["trueStartTime"] = this.formatter.formatDate2Display(sShapeID.getCustomData()[0].getProperty("value"));
				oDats["plannedClosure"] = oView.getModel("jModel").getProperty("/root").plannedClosure;
			} else if (name === prefix + "BaseImage") {
				shapeType = "Checkpoint";
			} else if (name === prefix + "BaseChevron") {
				shapeType = "Issue";
				oDats["description"] = sShapeID.getCustomData()[0].getProperty("key");
				oDats["prefix"] = sShapeID.getCustomData()[0].getProperty("value").slice(0, 12);
				oDats["title"] = sShapeID.getTitle().slice(13);
			}
			// create popover
			this._pPopover = Fragment.load({
				name: "com.sap.mcconedashboard.view.fragment.Case.TimelinePopovers." + shapeType + "Pop",
				controller: this
			}).then(function (oPopover) {
				oView.addDependent(oPopover);
				return oPopover;
			});

			this._pPopover.then(function (oPopover) {
				oPopover.setModel(fragModel, "frag");
				oPopover.openBy(sShapeID);
			});
		},
		onTopIssueBtn: function (oEvent) {
			var issueButton = oEvent.getSource();
			var index = Number(issueButton.getText().slice(-2)) - 1;
			this.getView().byId("ObjectPageLayout").setSelectedSection(this.byId("TopIssueSection").getId());
			var oSections = this.byId("topIssueLayout").getContent();
			for (var i = 0; i < oSections.length; i++) {
				if (index != i) {
					oSections[i].setExpanded(false);
				}
			}
			oSections[index].setExpanded(true);
		},
		onErase: function (oEvent) { // Destroy Popover 
			var pop = oEvent.getSource();
			pop.destroy();
		},
		// Gantt display types (Table+Chart/ Chart)
		onDisplayBoth: function () {
			this.byId("ganttTimeline").setDisplayType("Both");
		},
		onDisplayChart: function () {
			this.byId("ganttTimeline").setDisplayType("Chart");
		},
		loadMilestones: function (that) {
			return new Promise(function (resolve, reject) {
				var subModel = that.getView().getModel("subModel");
				if (subModel.oMetadata.bLoaded) {
					subModel.read("/Milestones", {
						filters: [new Filter("CaseID", "EQ", that.caseId)],
						success: function (oData) {
							var oModel = new JSONModel(oData);
							oModel.getProperty("/results").sort(function (a, b) {
								return (a.StartDate > b.StartDate) ? -1 : 1;
							});
							that.oView.setModel(oModel, "milestoneModel");
							resolve();
						}.bind(that),
						error: function (err) {
							reject();
						}.bind(that)
					});

				} else {
					that.oView.setModel(new JSONModel({
						results: []
					}), "milestoneModel");
					resolve();
				}
			}.bind(that));
		},
		// End of Timeline-Code

		_bindSupportPlan: function () {
			this.getView().setModel(new JSONModel({}), "FAHierarchy");
			this.getView().byId("subGanttChart").setBusy(true);
			//for datepicker with formatted text, the twoway binding isnt working properly
			this.getView().byId("ganttStart").attachChange(function (oEvent) {
				var sNewValue = oEvent.getParameter("newValue");
				oEvent.getSource().getBindingInfo("value").binding.setValue(sNewValue);
			});
			this.getView().byId("ganttEnd").attachChange(function (oEvent) {
				var sNewValue = oEvent.getParameter("newValue");
				oEvent.getSource().getBindingInfo("value").binding.setValue(sNewValue);
			});

			//set gantt start / end time
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMddhhMMss"
			});
			var hierarchy = {};
			hierarchy.StartDate = oFormat.format(this._getGanttStartDate(new Date()));
			hierarchy.StartDatePicker = this._getGanttStartDate(new Date());

			hierarchy.EndDate = oFormat.format(this._getGanttEndDate(12));
			hierarchy.EndDatePicker = this._getGanttEndDate(12);

			hierarchy.children = [];
			this.getView().getModel("FAHierarchy").setData(hierarchy);
			var rowCount = 0,
				focusAreas = [],
				milestones = [];

			var getProjects = new Promise(function (resolve, reject) {
				this.getView().getModel("subModel").read("/MCCProject", {
					filters: [new sap.ui.model.Filter("CaseID", "EQ", this.caseId)],
					success: function (oData) {
						focusAreas = oData.results;
						resolve();
					}.bind(this),
					error: function (err) {
						reject();
						this.getView().byId("subGanttChart").setBusy(false);
					}.bind(this)
				});
			}.bind(this));
			var getMilestones = new Promise(function (resolve, reject) {
				this.getView().getModel("subModel").read("/Milestones", {
					filters: [
						new sap.ui.model.Filter("CaseID", "EQ", this.caseId),
						new sap.ui.model.Filter("Status", "NE", "MSSTAT04")
					],
					success: function (oData) {
						milestones = oData.results;
						resolve();
					}.bind(this),
					error: function (err) {
						reject();
						this.getView().byId("subGanttChart").setBusy(false);
					}.bind(this)
				});
			}.bind(this));

			Promise.all([getProjects, getMilestones]).then(function () {
				var aLoadCase = [];

				//milestones that are linked to a case have the status and dates of the case -> load case data 
				milestones.forEach(function (item) {
					if (item.Link) {
						aLoadCase.push(
							new Promise(function (resolve, reject) {
								this.getView().getModel("appDepModel").read("/CaseSet", {
									filters: [new sap.ui.model.Filter("CaseID", "EQ", item.Link)],
									success: function (oData) {
										if (oData.results.length > 0) {
											//status 90 = closed = completed, 80 = in process = accepted
											//start = EscalationStartDate
											//end = PlannedCloseDate
											if (oData.results[0].StatusID === "90") item.Status = "MSSTAT03";
											else item.Status = "MSSTAT02";
											item.StartDate = oData.results[0].EscalationStartDate;
											if (oData.results[0].PlannedCloseDate) item.EndDate = oData.results[0].PlannedCloseDate;
										}
										resolve();
									}.bind(this),
									error: function (err) {
										resolve();
									}
								});
							}.bind(this)));
					}
				}.bind(this));

				Promise.all(aLoadCase).then(function () {
					milestones.sort(function (a, b) {
						return (a.StartDate < b.StartDate) ? -1 : 1;
					});
					focusAreas.sort(function (a, b) {
						return (a.StartDate < b.StartDate) ? -1 : 1;
					});
					if (focusAreas.length > 0) hierarchy.StartDate = oFormat.format(this._getGanttStartDate(focusAreas[0].StartDate));
					if (focusAreas.length > 0) hierarchy.StartDatePicker = this._getGanttStartDate(focusAreas[0].StartDate);
					focusAreas.forEach(function (area) {
						var entry = {
							GUID: area.GUID,
							Project: area.Title,
							filter: area.Title,
							No: area.Priority,
							shapes: [{
								shapeId: "area-" + area.GUID,
								StartDate: formatter.fnTimeConverter(area.StartDate),
								EndDate: formatter.fnTimeConverter(area.EndDate),
								StartDateDisplay: area.StartDate,
								EndDateDisplay: area.EndDate,
								GoLiveDisplay: area.GoLiveDate,
								Description: "Focus area: " + area.Title,
								Scope: area.Description ? formatter.formatString(area.Description) : "",
								Summary: area.StatusSummary ? formatter.formatString(area.StatusSummary) : "",
								CustomerName: area.CustomerName,
								CustomerID: area.CustomerID,
								shape: 2
							}, {
								shapeId: "GoLiveDate-" + area.GUID,
								StartDate: formatter.fnTimeConverter(area.GoLiveDate),
								EndDate: formatter.fnTimeConverter(area.GoLiveDate),
								GoLiveDisplay: area.GoLiveDate,
								Description: "Go Live",
								shape: 0
							}],
							children: []
						};
						hierarchy.children.push(entry);
						rowCount++;
					});

					milestones.forEach(function (item, i) {
						hierarchy.children.forEach(function (area) {
							if (area.GUID === item.ParentID) {
								var entry = {
									GUID: item.GUID,
									filter: area.filter,
									shapes: [{
										shapeId: "ms-" + item.GUID,
										shape: 1,
										StartDate: formatter.fnTimeConverter(item.StartDate),
										EndDate: formatter.fnTimeConverter(item.EndDate),
										StartDateDisplay: item.StartDate,
										EndDateDisplay: item.EndDate,
										Link: item.Link,
										Description: item.Description,
										bExternal: item.bExternal
									}]
								};
								if (area.children.length === 0) {
									area.children.push(entry);
									rowCount++;
								} else {
									var bRowAdded = false;
									area.children.forEach(function (child) {
										//now check all rows where we can add the case. 
										var bSameTime = child.shapes.some(function (r) {
											return this.dateRangeOverlaps(entry.shapes[0].StartDate, entry.shapes[0].EndDate, r.StartDate, r.EndDate);
										}.bind(this));

										if (!bSameTime && !bRowAdded) {
											bRowAdded = true;
											child.shapes.push(entry.shapes[0]);
											return;
										}
									}.bind(this))
									if (!bRowAdded) {
										area.children.push(entry);
										rowCount++;
									}
								}
							}
						}.bind(this));
					}.bind(this));
					//this.getView().byId("treeFA").setVisibleRowCount(rowCount);
					if (rowCount > 0) {
						this.getView().byId("supportPlanGCContainer").setHeight(((rowCount + 3) * this.getView().byId("treeFA")._getDefaultRowHeight().toString()) + "px");
					}
					this.getView().getModel("FAHierarchy").setData(hierarchy);
					this.getView().byId("subGanttChart").setBusy(false);
				}.bind(this));
			}.bind(this));
		},
		dateRangeOverlaps: function (a_start, a_end, b_start, b_end) {
			if (a_start < b_start && b_start < a_end) return true; // b starts in a
			if (a_start < b_end && b_end < a_end) return true; // b ends in a
			if (b_start < a_start && a_end < b_end) return true; // a in b
			return false;
		},

		onTimelineDateChange: function (oEvent) {
			//set gantt start / end time
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMddhhMMss"
			});
			var input = oEvent.getSource();
			var date = oFormat.format(input.getDateValue());
			if (input.getBinding("value").getPath().includes("Start")) this.getView().getModel("FAHierarchy").setProperty("/StartDate", date);
			if (input.getBinding("value").getPath().includes("End")) this.getView().getModel("FAHierarchy").setProperty("/EndDate", date);
		},

		_getGanttStartDate: function (date) {
			return new Date(new Date(new Date().setMonth(date.getMonth() - 1)).setDate(1));
		},

		_getGanttEndDate: function (i) {
			return new Date(new Date().getFullYear(), new Date().getMonth() + i, 0);
		},

		shapeSelected: function (oEvent) {
			// open detail popover
			if (oEvent.getParameter("shape")) {
				var path = oEvent.getParameter("shape").getBindingContext("FAHierarchy").getPath();
				var oData = this.getView().getModel("FAHierarchy").getProperty(path);
				var source = oEvent.getParameter("shape");
				if (!this.oPopover) {
					this.oPopover = sap.ui.xmlfragment(this.getView().getId(),
						"com.sap.mcconedashboard.view.fragment.Case.FocusAreaPopover", this);
					this.getView().addDependent(this.oPopover);
					this.oPopover.setModel(new JSONModel(oData), "focusArea");
				} else this.oPopover.getModel("focusArea").setData(oData);
				this.oPopover.openBy(source);
			}
		},
		_getCaseURL: function (CaseID) {
			var currentUrl = window.location.href;
			var Url = "https://fiorilaunchpad.sap.com/sites#mcconedashboard-Display&/Case/" + CaseID;
			if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) { //we are in test environment
				Url = "https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites#mcconedashboard-Display&/Case/" + CaseID;
			} else if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard")) { //we are in dev environment
				Url = "https://flpsandbox-br339jmc4c.dispatcher.int.sap.eu2.hana.ondemand.com/sites#mcconedashboard-Display&/Case/" + CaseID;
			}
			return Url;
		},

		_bindFocusAreas: function (CaseID) {
			var oModel = this.getView().getModel("subModel");
			oModel.read("/MCCProject", {
				filters: [new Filter("CaseID", "EQ", CaseID)],
				success: function (oData) {
					this.oView.getModel("focusAreas").setData(oData.results);
				}.bind(this),
				error: function () { }
			});
		},

		_bindImpactedCustomers: function (CaseID) {
			var oModel = this.getView().getModel("subModel");
			oModel.read("/MCCProject", {
				filters: [new Filter("CaseID", "EQ", CaseID)],
				success: function (oData) {
					this.oView.getModel("impactedCustomers").setData(oData.results);
				}.bind(this),
				error: function () { }
			});
		},

		_bindInitiatedCrossIssues: function (caseId) {
			var oAppDepModel = this.getOwnerComponent().getModel("appDepModel");

			var linkedObjectsTemp = this.getView().getModel("linkedObjects").getData();
			if (linkedObjectsTemp.length === 0) {
				// Nothing to do ...
				return;
			}
			// Make table empty when loading data
			for (var i = 0; i < linkedObjectsTemp.length; i++) {
				linkedObjectsTemp[i].Description = "";
				linkedObjectsTemp[i].HasEngReasonOrExecSummary = false;
			}
			this.getView().getModel("linkedObjects").setData(linkedObjectsTemp);
			this.getView().byId("tableLinksTF").setBusy(true);
			var aFilterID = [];
			linkedObjectsTemp.forEach(function (item) {
				aFilterID.push(new Filter("TopIssueID", FilterOperator.EQ, item.ObjectID));
			});
			var filterID = new Filter({
				filters: aFilterID,
				and: false
			});
			var filterType = new Filter("TopIssueType", FilterOperator.EQ, "ZS38");
			oAppDepModel.read("/TopIssueSet", {
				filters: [filterID, filterType],
				urlParameters: {
					"$expand": "toAffectedProduct,toPartiesInvolved,toNote",
				},
				success: function (oData) {
					if (oData.results.length > 0) {
						for (var j = 0; j < oData.results.length; j++) {
							for (var i = 0; i < linkedObjectsTemp.length; i++) {
								if (linkedObjectsTemp[i].ObjectID === oData.results[j].TopIssueID) {
									linkedObjectsTemp[i].Description = oData.results[j].Description;
									linkedObjectsTemp[i].Rating = oData.results[j].RatingText;
									linkedObjectsTemp[i].Priority = oData.results[j].PriorityText;
									linkedObjectsTemp[i].Status = oData.results[j].StatusText;
									linkedObjectsTemp[i].MCCResponsible = oData.results[j].RespPersonName;
									linkedObjectsTemp[i].MCCResponsibleID = oData.results[j].RespPersonNo;
									linkedObjectsTemp[i].CreatedOn = oData.results[j].CreatedAt;
									linkedObjectsTemp[i].StartDate = oData.results[j].RequestedStartDate;
									linkedObjectsTemp[i].ETA = oData.results[j].RequestedEndDate;
									var affProd = "";
									for (var ii = 0; ii < oData.results[j].toAffectedProduct.results.length; ii++) {
										affProd = affProd + " " + oData.results[j].toAffectedProduct.results[ii].AffectedProductText;
										if (ii < oData.results[j].toAffectedProduct.results.length - 1) {
											affProd = affProd + ",";
										}
									}
									linkedObjectsTemp[i].ProductVersions = affProd;
									var impCust = "";
									var impCustNo = 0;
									var impCustLength = 0;
									// Check, how many impacted customers we have at all
									for (var iii = 0; iii < oData.results[j].toPartiesInvolved.results.length; iii++) {
										if (oData.results[j].toPartiesInvolved.results[iii].PartnerFct === "ZSAFFCUS") { // Affected Customer
											impCustLength = impCustLength + 1;
										}
									}
									linkedObjectsTemp[i].ImpactedCustomerNumber = impCustLength;
									for (var iii = 0; iii < oData.results[j].toPartiesInvolved.results.length; iii++) {
										if (oData.results[j].toPartiesInvolved.results[iii].PartnerFct === "ZSAFFCUS") { // Affected Customer
											impCust = impCust + " " + oData.results[j].toPartiesInvolved.results[iii].Name;
											impCustNo = impCustNo + 1;
										}
										if (oData.results[j].toPartiesInvolved.results[iii].PartnerFct === "ZSAFFCUS" && impCustNo < impCustLength) {
											impCust = impCust + ",";
										}

									}
									if (impCust === "") {
										linkedObjectsTemp[i].ImpactedCustomers = oData.results[j].SoldToPartyText;
									} else {
										linkedObjectsTemp[i].ImpactedCustomers = impCust;
									}
									linkedObjectsTemp[i].ImpactedCustomersList = oData.results[j].toPartiesInvolved.results;
									var bHasEngReasonOrExecSummary = false;
									linkedObjectsTemp[i].HasEngReasonOrExecSummary = false;
									if (oData.results[0].toNote.results.length > 0) {
										linkedObjectsTemp[i].Notes = oData.results[j].toNote.results;
										for (var iiii = 0; iiii < linkedObjectsTemp[i].Notes.length; iiii++) {
											if (linkedObjectsTemp[i].Notes[iiii].NoteType === "ZSCA" || // Engagement Reason
												linkedObjectsTemp[i].Notes[iiii].NoteType === "Z03V") { // Executive Summary
												bHasEngReasonOrExecSummary = true;
												break;
											}
										}
										if (bHasEngReasonOrExecSummary === true) {
											linkedObjectsTemp[i].HasEngReasonOrExecSummary = true;
										} else {
											linkedObjectsTemp[i].HasEngReasonOrExecSummary = false;
										}
									}
									this.getView().getModel("linkedObjects").setData(linkedObjectsTemp);
									break;
								}
							}
						}
					}
					this.getView().byId("tableLinksTF").setBusy(false);
				}.bind(this),
				error: function (error) {
					this.getView().byId("tableLinksTF").setBusy(false);
				}.bind(this),
			});
		},

		handleQuickInfoPressed: function (oEvent) {
			var oData = oEvent.getSource().getBindingContext("linkedObjects").getObject();
			var sText1 = "-";
			var sType1 = "Engagement Reason";
			var sText2 = "-";
			var sType2 = "Executive Summary";
			for (var i = 0; i < oData.Notes.length; i++) {
				if (oData.Notes[i].NoteType === "ZSCA") { // Engagement Reason
					sText1 = this.formatter.formatNoteToHTML(oData.Notes[i].Text);
				}
				if (oData.Notes[i].NoteType === "Z03V") { // Executive Summary
					sText2 = this.formatter.formatNoteToHTML(oData.Notes[i].Text);
				}
			}
			new sap.m.Popover({
				title: "Quick Info",
				placement: "PreferredRightOrFlip",
				contentWidth: "45rem",
				content: [
					new sap.m.VBox({
						width: "auto"
					}).addItem(new sap.m.Label({
						design: "Bold",
						text: sType1
					}).addStyleClass("sapUiTinyMarginBeginEnd sapUiTinyMarginTop"))
						.addItem(new sap.m.FormattedText({
							htmlText: sText1
						}).addStyleClass("sapUiTinyMarginBeginEnd sapUiSmallMarginBottom"))
						.addItem(new sap.m.Label({
							design: "Bold",
							text: sType2
						}).addStyleClass("sapUiTinyMarginBeginEnd sapUiTinyMarginTop"))
						.addItem(new sap.m.FormattedText({
							htmlText: sText2
						}).addStyleClass("sapUiTinyMarginBeginEnd sapUiSmallMarginBottom"))
						.addStyleClass("sapUiTinyMargin")
				]
			}).openBy(oEvent.getSource());
		},

		onImpactedCustomerNumber: function (oEvent) {
			var linkedObjects = this.getView().getModel("linkedObjects").getData();
			var crossIssueID = oEvent.getSource().getParent().getParent().getAggregation("cells")[0].getItems()[0].getProperty("text");
			for (var i = 0; i < linkedObjects.length; i++) {
				if (parseInt(linkedObjects[i].ObjectID) === parseInt(crossIssueID)) {
					var initiatedCrossIssue = linkedObjects[i];
				}
			}
			var oInitiatedCrossIssueModel = new JSONModel();
			oInitiatedCrossIssueModel.setData(initiatedCrossIssue);

			if (!this.ImpacedCustomersDialog) {
				this.ImpacedCustomersDialog = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.LinkedObjectsImpactedCustomers", this);
				this.getView().addDependent(this.ImpacedCustomersDialog);
			}

			this.ImpacedCustomersDialog.setModel(oInitiatedCrossIssueModel, "initiatedCrossIssue");
			this.ImpacedCustomersDialog.open();
		},

		onNavToCustomer: function (oEvent) {
			this.ImpacedCustomersDialog.setBusy(true);
			var oModel = this.getOwnerComponent().getModel();
			var sValue = oEvent.getSource().getBindingContext("initiatedCrossIssue").getObject().PartnerId;
			var custName = oEvent.getSource().getBindingContext("initiatedCrossIssue").getObject().Name;
			var currentUrl = window.location.href;
			var aFilter = new Array(
				new Filter([
					new Filter("CustomerName", sap.ui.model.FilterOperator.Contains, sValue),
					new Filter("ErpCustNo", sap.ui.model.FilterOperator.EQ, sValue),
					new Filter("Partner", sap.ui.model.FilterOperator.EQ, sValue)
				],
					false
				)
			);
			oModel.read("/CustomerSet", {
				urlParameters: {
					"$select": "CustomerName,ErpCustNo"
				},
				filters: aFilter,
				success: function (data, response) {
					this.ImpacedCustomersDialog.setBusy(false);
					if (data.results.length > 0) {
						var ErpCustNo = data.results[0].ErpCustNo;
						var oRouter = this.getRouter();
						oRouter.navTo("Customer", {
							ErpCustNo: ErpCustNo,
							"?query": this._getQueryParameter()
						});
					}
				}.bind(this)
			});
		},

		impactedCustomerNumberExitPress: function (oEvent) {
			this.ImpacedCustomersDialog.close();
		},

		navToObject: function (oEvent) {
			var index = oEvent.getSource().getParent().getParent().getBindingContext("linkedObjects").getPath().substring(1);
			var URL = this.getView().getModel("linkedObjects").getProperty("/" + index + "/URL");
			var type = this.getView().getModel("linkedObjects").getProperty("/" + index + "/ObjectType");
			var ID = this.getView().getModel("linkedObjects").getProperty("/" + index + "/ObjectID");
			/*if (window.location.href.includes("dev-mallard") || window.location.href.includes("ssn8r5sjsj")) {
				URL = "https://sapit-customersupport-dev-mallard.launchpad.cfapps.eu10.hana.ondemand.com/sites#mccworkbench-Display&/" + ID;
			} else if (window.location.href.includes("test-kinkajou") || window.location.href.includes("a44f228ad") || window.location.href.includes(
					"sapitcloudt")) {
				URL = "https://sapit-home-test-004.launchpad.cfapps.eu10.hana.ondemand.com/sites#mccworkbench-Display&/" + ID;
			} else {
				URL = "https://sapit-home-prod-004.launchpad.cfapps.eu10.hana.ondemand.com/sites#mccworkbench-Display&/" + ID;
			}
			var win = window.open(URL, "_blank");
			win.opener = null;
			win.focus();*/

			var oRouter = this.getRouter();
			oRouter.navTo("CrossIssueDetails", {
				objectId: ID,
				"?query": this._getQueryParameter()
			});
		}
	});
});