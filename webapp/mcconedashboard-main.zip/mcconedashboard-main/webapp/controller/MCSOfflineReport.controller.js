sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"sap/m/FacetFilterList",
	"com/sap/mcconedashboard/model/models",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/model/json/JSONModel",
	"com/sap/mcconedashboard/model/formatter",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"com/sap/mcconedashboard/controller/mcs/ReportDownloadHandler",
	"sap/ui/core/routing/History"
], function (BaseController, FacetFilterList, models, Filter, Sorter, JSONModel, formatter, MessageBox, MessageToast,
	ReportDownloadHandler, History) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.MCSOfflineReport", {

		facetFilter: null,
		models: models,
		sTitle: null,
		sSetToBind: null,
		oInputField: null,
		aTokens: null,
		reportDownloadHandler: ReportDownloadHandler,
		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the controller is instantiated.
		 * @public
		 */
		onInit: function () {
			// Get default model from component
			this.setModel(this.getOwnerComponent().getModel("mcsModel"));
			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

			//set Control Names
			this._setControls();

			//Set initial token selection to empty
			this.aKeys = ["value_key", "value_text"];

			var oModel = new JSONModel();
			this._initializeDates(oModel);
			this.getView().setModel(oModel, "dateFilterModel");
			var that = this;

			this.getView().byId("multiInputCreationTimeFilter").setTokens([new sap.m.Token({
				key: oModel.getProperty("/creationDateSelectedOption"),
				text: this.formatter.concatenateDateAndOption(oModel.getProperty("/creationDateSelectedOption"), oModel.getProperty(
					"/creationDateValue1"), oModel.getProperty("/creationDateValue2")),
				'delete': function (oEvent) {
					that._synchModelOnTokenDelete(oEvent, "creation", oModel);
				}
			})]);

			this.getView().byId("multiInputClosingTimeFilter").setTokens([new sap.m.Token({
				key: "empty",
				text: this.formatter.formatClosingDateEmpty(oModel.getProperty("/closingDateEmptySelected")),
				'delete': function (oEvent) {
					that._synchModelOnTokenDelete(oEvent, "empty", oModel);
				}
			}), new sap.m.Token({
				key: "{path:'dateFilterModel>/closingDateSelectedOption'}",
				text: this.formatter.concatenateDateAndOption(oModel.getProperty("/closingDateSelectedOption"), oModel.getProperty(
					"/closingDateValue1"), oModel.getProperty("/closingDateValue2")),
				'delete': function (oEvent) {
					that._synchModelOnTokenDelete(oEvent, "closing", oModel);
				}
			})]);
		},
		onAfterRendering: function () {
			//preset process type filter to Global Escalation
			//this.getView().byId("processTypeMultiComboxId").clearSelection();
			this.getView().byId("processTypeMultiComboxId").addSelectedKeys(["ZSPRCTYP01"]);
			//this.getView().byId("processTypeMultiComboxId").setValueState("None");

			//preset region filter to WORLD
			//	this.getView().byId("regionMultiComboxId").clearSelection();
			this.getView().byId("regionMultiComboxId").addSelectedKeys(["WORLD"]);
			//this.getView().byId("regionMultiComboxId").setValueState("None");

		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function () {
			var sPreviousHash = History.getInstance().getPreviousHash();
			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("mcsdashboard", {
					"?query": this._getQueryParameter(),
				}, true);
			}
		},

		_setControls: function () {
			this.oInputCaseId = this.getView().byId("multiInputCaseId");
			this.oRadioButtonMIMETypeCaseId = this.getView().byId("radioBtnMimeTypeCaseId");
			this.oProcessTypeMultiCombox = this.getView().byId("processTypeMultiComboxId");
			this.oRegionMultiCombox = this.getView().byId("regionMultiComboxId");
			this.oRatingMultiCombox = this.getView().byId("ratingMultiComboxId");
			this.oStatusMultiCombox = this.getView().byId("statusMultiComboxId");
			this.oMultiInputCreationTime = this.getView().byId("multiInputCreationTimeFilter");
			this.oMultiInputClosingTime = this.getView().byId("multiInputClosingTimeFilter");
			this.oMultiInputMainCust = this.getView().byId("multiInputMainCust");
			this.oMultiInputCustSeg = this.getView().byId("multiInputCustSeg");
			this.oMultiInputDelivUnit = this.getView().byId("multiInputDelivUnit");
			this.oMultiInputProdCat = this.getView().byId("multiInputProdCat");
			this.oMultiInputProdLine = this.getView().byId("multiInputProdLine");
			this.oMultiInputProd = this.getView().byId("multiInputProd");
			this.oCheckBoxMainProd = this.getView().byId("checkBoxMainProd");
			this.oMultiInputSalesOrg = this.getView().byId("multiInputSalesOrg");
			this.oMultiInputServiceOrg = this.getView().byId("multiInputServiceOrg");
			this.oMultiInputServiceTeam = this.getView().byId("multiInputServiceTeam");
			this.oRadioButtonMIMEType = this.getView().byId("radioBtnMimeType");
		},

		_getTokenSaveStructure: function (aToken) {
			var aTokenSaveStructures = [];

			aToken.forEach(function (oToken) {
				var oTokenSaveStructure = {
					key: oToken.getKey(),
					text: oToken.getText()
				};
				aTokenSaveStructures.push(oTokenSaveStructure);
			});

			return aTokenSaveStructures;
		},

		handleValueHelp: function (oEvent) {
			var that = this;
			//check from which MultiInputField the event has been thrown
			var oEventSourceId = oEvent.getSource().getId();
			that.oInputField = oEvent.getSource();

			if (oEventSourceId.indexOf("CustSeg") > -1) {
				that.sTitle = this._oResourceBundle.getText("reportCustomerSegmentFilter");
				that.sSetToBind = "/MasterCodeSet";
			} else if (oEventSourceId.indexOf("CaseId") > -1) {
				that.sTitle = this._oResourceBundle.getText("caseIdFilter");
				that.sSetToBind = "/MCSDetailsSet";
			} else if (oEventSourceId.indexOf("DelivUnit") > -1) {
				that.sTitle = this._oResourceBundle.getText("reportDeliveryUnitFilter");
				that.sSetToBind = "/DeliveryUnitSet";
			} else if (oEventSourceId.indexOf("ProdCat") > -1) {
				that.sTitle = this._oResourceBundle.getText("reportProductCategoryFilter");
				that.sSetToBind = "/ProdCategorySet";
			} else if (oEventSourceId.indexOf("ProdLine") > -1) {
				that.sTitle = this._oResourceBundle.getText("reportProductLineFilter");
				that.sSetToBind = "/ProdLineSet";
			} else if (oEventSourceId.indexOf("Prod") > -1) {
				that.sTitle = this._oResourceBundle.getText("reportProductFilter");
				that.sSetToBind = "/RefObjectSet";
			} else if (oEventSourceId.indexOf("SalesOrg") > -1) {
				that.sTitle = this._oResourceBundle.getText("reportSalesOrgFilter");
				that.sSetToBind = "/SalesOrganizationSet";
			} else if (oEventSourceId.indexOf("ServiceOrg") > -1) {
				that.sTitle = this._oResourceBundle.getText("reportServiceOrgFilter");
				that.sSetToBind = "/ServiceOrganizationSet";
			} else if (oEventSourceId.indexOf("ServiceTeam") > -1) {
				that.sTitle = this._oResourceBundle.getText("reportServiceTeamFilter");
				that.sSetToBind = "/ServiceTeamSet";
			} else if (oEventSourceId.indexOf("MainCust") > -1) {
				that.sTitle = this._oResourceBundle.getText("mainCustomerFilter");
				that.sSetToBind = "/MainCustomerSet";
			}

			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: that.oInputField.getValue(),
				title: that.sTitle,
				supportMultiselect: true,
				supportRanges: false,
				supportRangesOnly: false,
				key: this.aKeys[0],
				descriptionKey: this.aKeys[1],
				stretch: sap.ui.Device.system.phone,
				tokenDisplayBehaviour: "descriptionOnly",
				ok: function (oControlEvent) {
					that.aTokens = oControlEvent.getParameter("tokens");
					that.oInputField.setTokens(that.aTokens);
					oValueHelpDialog.close();
				},
				cancel: function (oControlEvent) {
					oValueHelpDialog.close();
				},
				afterClose: function () {
					oValueHelpDialog.destroy();
					that.oInputField.closeMultiLine();
				}
			});

			var oColModel = new sap.ui.model.json.JSONModel();

			if (oEventSourceId.indexOf("MainCust") > -1) {
				oColModel.setData({
					cols: [{
						label: "Description",
						template: "value_text"
					}, {
						label: "Id",
						template: "value_key"
					}]
				});
			} else {
				oColModel.setData({
					cols: [{
						label: "Description",
						template: "value_text"
					}]
				});
			}

			oValueHelpDialog.getTableAsync().then(function (oTable) {
				oTable.setModel(oColModel, "columns");
				oTable.setModel(this.getModel("mcsModel"));
				if (oTable.bindRows) {
					oTable.bindRows(that.sSetToBind);
					// update list binding
					var binding = oTable.getBinding("rows");
					//sort ascending
					var aSorters = [];
					aSorters.push(new Sorter("value_text", false));
					binding.sort(aSorters);
				}
				oValueHelpDialog.update();
			}.bind(this));

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: false,
				showGoOnFB: false, //!sap.ui.Device.system.phone,
				showFilterConfiguration: false,
				useToolbar: false
			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					showSearchButton: true, //sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function (event) {
						var aFilters = [];
						var sQuery = event.getSource().getValue();
						if (sQuery && sQuery.length > 0) {
							var filter = new Filter("value_text", sap.ui.model.FilterOperator.Contains, sQuery);
							aFilters.push(filter);
						}
						// update list binding
						oValueHelpDialog.getTableAsync().then(function (oTable) {
							var binding = oTable.getBinding("rows");
							binding.filter(aFilters, "Application");
							//sort ascending
							var aSorters = [];
							aSorters.push(new Sorter("value_text", false));
							binding.sort(aSorters);
							oValueHelpDialog.update();
						}.bind(this));
					}
				}));
			}

			oValueHelpDialog.setFilterBar(oFilterBar);

			if (that.oInputField.$().closest(".sapUiSizeCompact").length > 0) { // check if the Token field runs in Compact mode
				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			} else {
				oValueHelpDialog.addStyleClass("sapUiSizeCozy");
			}

			//wait till data has been loaded
			var fnOpenValueHelp = function (params) {
				this.getModel("mcsModel").detachRequestCompleted(fnOpenValueHelp, this);
				oValueHelpDialog.setTokens(that.oInputField.getTokens());
				oValueHelpDialog.open();
				//hide showAdvancesFilter button - otherwise it is shown as an inactive btn
				var oToolbarButton = sap.ui.getCore().byId(oFilterBar.getId() + "-btnShowHide");
				if (oToolbarButton) {
					oToolbarButton.setVisible(false);
				}
			};
			this.getModel("mcsModel").attachRequestCompleted(fnOpenValueHelp, this);

		},
		/**
		 *Value Help for dates with different selection possibilities
		 **/
		handleValueHelpDate: function (oEvent) {
			var that = this,
				oInputField, sTitle, sType;
			//check from which MultiInputField the event has been thrown
			var oEventSourceId = oEvent.getSource().getId();
			if (oEventSourceId.indexOf("ClosingTime") > -1) {
				oInputField = this.getView().byId("multiInputClosingTimeFilter");
				sTitle = this._oResourceBundle.getText("closingTimeFilter");
				sType = "closing";
			} else if (oEventSourceId.indexOf("CreationTime") > -1) {
				oInputField = this.getView().byId("multiInputCreationTimeFilter");
				sTitle = this._oResourceBundle.getText("creationTimeFilter");
				sType = "creation";
			}

			var dialogDate = new sap.m.Dialog({
				title: sTitle,
				type: "Standard",
				state: "None",
				content: new sap.ui.layout.VerticalLayout({
					content: [new sap.m.Label({
							text: sTitle
						}),
						new sap.m.Select({
							items: [new sap.ui.core.Item({
								key: "BT",
								text: "Between"
							}), new sap.ui.core.Item({
								key: "GE",
								text: ">="
							}), new sap.ui.core.Item({
								key: "LE",
								text: "<="
							})],
							change: function (selectedItem) {
								that._setVisibilityOfClosingDateEmptySwitch(sType);
								if (selectedItem.getSource().getProperty("selectedKey") !== "BT") {
									this.getModel("dateFilterModel").setProperty("/" + sType + "DateRangeVisible", false);
								} else {
									this.getModel("dateFilterModel").setProperty("/" + sType + "DateRangeVisible", true);
								}
								this.getModel("dateFilterModel").setProperty("/" + sType + "DateSelectedOption", selectedItem.getSource().getProperty(
									"selectedKey"));
								that.switchDateDisplay(this.getModel("dateFilterModel"), sType, selectedItem.getSource().getProperty("selectedKey"));

							},
							selectedKey: "{dateFilterModel>/" + sType + "DateSelectedOption}"
						}),
						new sap.m.DateRangeSelection({
							visible: "{=${dateFilterModel>/" + sType + "DateRangeVisible} ? true : false}", //"{dateFilterModel>/rangeVisible}",
							dateValue: "{dateFilterModel>/" + sType + "DateValue1}",
							secondDateValue: "{dateFilterModel>/" + sType + "DateValue2}",
							maxDate: "{dateFilterModel>/dateMax}",
							change: that.handleChange,
							width: "15rem"
						}),
						new sap.m.DatePicker({
							visible: "{=${dateFilterModel>/" + sType + "DateRangeVisible} ? false : true}",
							value: "{path:'dateFilterModel>/" + sType +
								"DateValue1', type:'sap.ui.model.type.Date', formatOptions: { style: 'medium'}}",
							valueFormat: "yyyy-MM-dd",
							change: that.handleChange
						}),
						new sap.m.CheckBox({
							visible: "{dateFilterModel>/closingDateEmptyVisibility}",
							text: "incl. empty",
							selected: "{dateFilterModel>/closingDateEmptySelected}"
						})
					]

				}),
				beginButton: new sap.m.Button({
					text: "Cancel",
					press: function () {
						dialogDate.close();
					}
				}),
				endButton: new sap.m.Button({
					text: "OK",
					press: function (oEvt) {
						that.aTokens = [];

						if (that.getModel("dateFilterModel").getProperty("/closingDateEmptyVisibility")) {
							if (that.getModel("dateFilterModel").getProperty("/closingDateEmptySelected")) {

								var emptyToken = new sap.m.Token({
									key: "empty",
									text: that.formatter.formatClosingDateEmpty(that.getModel("dateFilterModel").getProperty("/closingDateEmptySelected")),
									'delete': function (oEvent) {
										that._synchModelOnTokenDelete(oEvent, "empty", that.getModel("dateFilterModel"));
									}
								});
								that.aTokens.push(emptyToken);
							}
						}
						if (that.getModel("dateFilterModel").getProperty("/" + sType + "DateValue1")) {
							var rangeToken = new sap.m.Token({
								key: that.getModel("dateFilterModel").getProperty("/" + sType + "DateSelectedOption"),
								text: that.formatter.concatenateDateAndOption(that.getModel("dateFilterModel").getProperty("/" + sType +
									"DateSelectedOption"), that.getModel("dateFilterModel").getProperty("/" + sType + "DateValue1"), that.getModel(
									"dateFilterModel").getProperty("/" + sType + "DateValue2")),
								'delete': function (oEvent) {
									that._synchModelOnTokenDelete(oEvent, sType, that.getModel("dateFilterModel"));
								}
							});
							that.aTokens.push(rangeToken);
						}

						oInputField.setTokens(that.aTokens);
						dialogDate.close();

					}
				}),
				afterClose: function () {
					dialogDate.destroy();
				}
			});
			dialogDate.addStyleClass("sapUiContentPadding");
			dialogDate.setModel(this.getModel("dateFilterModel"), "dateFilterModel");
			this._setVisibilityOfClosingDateEmptySwitch(sType);
			dialogDate.open();

		},
		_setVisibilityOfClosingDateEmptySwitch: function (sType) {
			if (this.getModel("dateFilterModel").getProperty("/closingDateSelectedOption") !== "BT") {
				if (sType === "closing") {
					this.getModel("dateFilterModel").setProperty("/closingDateEmptyVisibility", true);
				} else {
					this.getModel("dateFilterModel").setProperty("/closingDateEmptyVisibility", false);
				}
			} else {
				this.getModel("dateFilterModel").setProperty("/closingDateEmptyVisibility", false);
			}
		},

		handleChange: function (oEvent) {
			var bValid = oEvent.getParameter("valid");
			this._iEvent++;

			var oDRS = oEvent.getSource();
			if (bValid) {
				oDRS.setValueState(sap.ui.core.ValueState.None);
			} else {
				oDRS.setValueState(sap.ui.core.ValueState.Error);
			}
		},
		onReset: function (oEvent) {
			var selectedFilters;
			if (oEvent) {
				var params = oEvent.getParameters();
				selectedFilters = params.selectionSet;
			} else {
				selectedFilters = this.byId("offlineReportFilterBar")._retrieveCurrentSelectionSet();
			}

			var that = this;

			var selectedFilterPresetKey = this.byId("filterPresetSelectId").getSelectedKey();
			if (selectedFilterPresetKey === "FP01") {
				//Cases Ongoing this year
				//Case Type: ZS01 Global Customer Escalation
				//Region: World
				//Creation Date: <= today
				//Closing Date: empty #  or >=01.01 of this year
				selectedFilters.forEach(function (item) {
					var filterId = item.getId();
					var tokens = [];
					if (filterId.indexOf("processType") > -1) {
						item.removeAllSelectedItems();
						item.addSelectedKeys(["ZSPRCTYP01"]);
						item.setValueState("None");
					} else if (filterId.indexOf("region") > -1) {
						item.removeAllSelectedItems();
						item.addSelectedKeys(["WORLD"]);
						item.setValueState("None");
					} else if (filterId.indexOf("status") > -1) {
						item.removeAllSelectedItems();
					} else if (filterId.indexOf("rating") > -1) {
						item.removeAllSelectedItems();
					} else if (filterId.indexOf("CustSeg") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("ServiceOrg") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("ServiceTeam") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("DelivUnit") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("MainProd") > -1) {
						item.setSelected(false);
					} else if (filterId.indexOf("ProdCat") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("ProdLine") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("Prod") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("SalesOrg") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("MainCust") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("CreationTime") > -1) {
						that._initializeDates(that.getView().getModel("dateFilterModel"));
						item.setValueState("None");
						item.setTokens([new sap.m.Token({
							key: that.getView().getModel("dateFilterModel").getProperty("/creationDateSelectedOption"),
							text: that.formatter.concatenateDateAndOption(that.getView().getModel("dateFilterModel").getProperty(
								"/creationDateSelectedOption"), that.getView().getModel("dateFilterModel").getProperty(
								"/creationDateValue1"), that.getView().getModel("dateFilterModel").getProperty("/creationDateValue2"))
						})]);
					} else if (filterId.indexOf("ClosingTime") > -1) {
						that._initializeDates(that.getView().getModel("dateFilterModel"));
						item.setValueState("None");
						item.setTokens([new sap.m.Token({
							key: "empty",
							text: that.formatter.formatClosingDateEmpty(that.getView().getModel("dateFilterModel").getProperty(
								"/closingDateEmptySelected"))
						}), new sap.m.Token({
							key: "{path:'dateFilterModel>/closingDateSelectedOption'}",
							text: that.formatter.concatenateDateAndOption(that.getView().getModel("dateFilterModel").getProperty(
								"/closingDateSelectedOption"), that.getView().getModel("dateFilterModel").getProperty(
								"/closingDateValue1"), that.getView().getModel("dateFilterModel").getProperty("/closingDateValue2"))
						})]);
					}
				});

			} else if (selectedFilterPresetKey === "FP02") { //FP03
				//SAP Business Technology Platform PL https://i7p.wdf.sap.corp/ppmslight/#/details/pl/73555000100700000172/overview
				//Case Type: ZS01
				//Status: 20, 30
				//Product Line  73555000100700000172
				selectedFilters.forEach(function (item) {
					var filterId = item.getId();
					var tokens = [];
					if (filterId.indexOf("processType") > -1) {
						item.removeAllSelectedItems();
						item.addSelectedKeys(["ZSPRCTYP01"]);
						item.addSelectedKeys(["ZSPRCTYP06"]);
						item.setValueState("None");
					} else if (filterId.indexOf("region") > -1) {
						item.removeAllSelectedItems();
						item.addSelectedKeys(["WORLD"]);
						item.setValueState("None");
					} else if (filterId.indexOf("status") > -1) {
						item.removeAllSelectedItems();
						item.addSelectedKeys(["20", "30"]);
						item.setValueState("None");
					} else if (filterId.indexOf("rating") > -1) {
						item.removeAllSelectedItems();
					} else if (filterId.indexOf("CustSeg") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("ServiceOrg") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("ServiceTeam") > -1) {
						item.setValueState("None");
						item.setTokens(tokens);
					} else if (filterId.indexOf("DelivUnit") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("MainProd") > -1) {
						item.setSelected(false);
					} else if (filterId.indexOf("ProdCat") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("ProdLine") > -1) {
						item.setTokens([new sap.m.Token({
							key: "73555000100700000172",
							text: "SAP Business Technology Platform"
						})]);
					} else if (filterId.indexOf("Prod") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("SalesOrg") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("MainCust") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("CreationTime") > -1) {
						that._initializeDates(that.getView().getModel("dateFilterModel"));
						item.setValueState("None");
						item.setTokens([new sap.m.Token({
							key: that.getView().getModel("dateFilterModel").getProperty("/creationDateSelectedOption"),
							text: that.formatter.concatenateDateAndOption(that.getView().getModel("dateFilterModel").getProperty(
								"/creationDateSelectedOption"), that.getView().getModel("dateFilterModel").getProperty(
								"/creationDateValue1"), that.getView().getModel("dateFilterModel").getProperty("/creationDateValue2"))
						})]);
					} else if (filterId.indexOf("ClosingTime") > -1) {
						that._initializeDates(that.getView().getModel("dateFilterModel"));
						item.setValueState("None");
						item.setTokens([new sap.m.Token({
							key: "empty",
							text: that.formatter.formatClosingDateEmpty(that.getView().getModel("dateFilterModel").getProperty(
								"/closingDateEmptySelected"))
						}), new sap.m.Token({
							key: "{path:'dateFilterModel>/closingDateSelectedOption'}",
							text: that.formatter.concatenateDateAndOption(that.getView().getModel("dateFilterModel").getProperty(
								"/closingDateSelectedOption"), that.getView().getModel("dateFilterModel").getProperty(
								"/closingDateValue1"), that.getView().getModel("dateFilterModel").getProperty("/closingDateValue2"))
						})]);
					}
				});

			} else { //FP03
				//HANA Report
				//Case Type: ZS01
				//Status: 20, 30
				//Service Teams: 0014235363, 0014235364, 0014235365, 0014217791, 0013732949, 0025970641, 0025970644, 0025970643, 0016673868
				//ICD 0001040360
				selectedFilters.forEach(function (item) {
					var filterId = item.getId();
					var tokens = [];
					if (filterId.indexOf("processType") > -1) {
						item.removeAllSelectedItems();
						item.addSelectedKeys(["ZSPRCTYP01"]);
						item.addSelectedKeys(["ZSPRCTYP06"]);
						item.setValueState("None");
					} else if (filterId.indexOf("region") > -1) {
						item.removeAllSelectedItems();
						item.addSelectedKeys(["WORLD"]);
						item.setValueState("None");
					} else if (filterId.indexOf("status") > -1) {
						item.removeAllSelectedItems();
						item.addSelectedKeys(["20", "30"]);
						item.setValueState("None");
					} else if (filterId.indexOf("rating") > -1) {
						item.removeAllSelectedItems();
					} else if (filterId.indexOf("CustSeg") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("ServiceOrg") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("ServiceTeam") > -1) {
						item.setValueState("None");
						item.setTokens([new sap.m.Token({
							key: "0014235363",
							text: "14235363"
						}), new sap.m.Token({
							key: "0014235364",
							text: "14235364"
						}), new sap.m.Token({
							key: "0014235365",
							text: "14235365"
						}), new sap.m.Token({
							key: "0014217791",
							text: "14217791"
						}), new sap.m.Token({
							key: "0013732949",
							text: "13732949"
						}), new sap.m.Token({
							key: "0025970641",
							text: "25970641"
						}), new sap.m.Token({
							key: "0025970644",
							text: "25970644"
						}), new sap.m.Token({
							key: "0025970643",
							text: "25970643"
						}), new sap.m.Token({
							key: "0016673868",
							text: "16673868"
						})]);
					} else if (filterId.indexOf("DelivUnit") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("MainProd") > -1) {
						item.setSelected(false);
					} else if (filterId.indexOf("ProdCat") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("ProdLine") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("Prod") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("SalesOrg") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("MainCust") > -1) {
						item.setTokens(tokens);
					} else if (filterId.indexOf("CreationTime") > -1) {
						that._initializeDates(that.getView().getModel("dateFilterModel"));
						item.setValueState("None");
						item.setTokens([new sap.m.Token({
							key: that.getView().getModel("dateFilterModel").getProperty("/creationDateSelectedOption"),
							text: that.formatter.concatenateDateAndOption(that.getView().getModel("dateFilterModel").getProperty(
								"/creationDateSelectedOption"), that.getView().getModel("dateFilterModel").getProperty(
								"/creationDateValue1"), that.getView().getModel("dateFilterModel").getProperty("/creationDateValue2"))
						})]);
					} else if (filterId.indexOf("ClosingTime") > -1) {
						that._initializeDates(that.getView().getModel("dateFilterModel"));
						item.setValueState("None");
						item.setTokens([new sap.m.Token({
							key: "empty",
							text: that.formatter.formatClosingDateEmpty(that.getView().getModel("dateFilterModel").getProperty(
								"/closingDateEmptySelected"))
						}), new sap.m.Token({
							key: "{path:'dateFilterModel>/closingDateSelectedOption'}",
							text: that.formatter.concatenateDateAndOption(that.getView().getModel("dateFilterModel").getProperty(
								"/closingDateSelectedOption"), that.getView().getModel("dateFilterModel").getProperty(
								"/closingDateValue1"), that.getView().getModel("dateFilterModel").getProperty("/closingDateValue2"))
						})]);
					}
				});

			}

			this.reportDownloadHandler.resetMimeFilterModel(this);
		},
		_getPresetFilters: function (oParam) {
			this.onReset();
		},

		onSearchCaseId: function (oEvent) {

			var oMultiInputCaseId = oEvent.getParameters().selectionSet[0];

			// return if validation for the inputfield fails!
			if (oMultiInputCaseId.getValueState() !== sap.ui.core.ValueState.None) {
				MessageToast.show(this._oResourceBundle.getText("pdfCaseIdMultiInputWrongFormat"));
				return;
			}

			this.reportDownloadHandler.resetMimeFilterModel(this);
			var oFiltersModel = this.getModel("extReportFilters");
			var sMimeType = null;

			var sValue = oMultiInputCaseId.getValue();
			var aCaseIds = sValue.split(",");

			oFiltersModel.setProperty("/" + "case_id", aCaseIds);

			if (this.getView().byId("radioBtnMimeTypeCaseId").getSelectedIndex() <= 0) {
				sMimeType = this._oResourceBundle.getText("typePDF");
			} else {
				sMimeType = this._oResourceBundle.getText("typeXLS");
			}

			this._caseIdMultiInputCount = aCaseIds.length;
			this._startReportGeneration(sMimeType, oFiltersModel, this);
		},

		onClearCaseId: function (oEvent) {
			var oMultiInputCaseId = oEvent.getParameters().selectionSet[0];
			oMultiInputCaseId.setValue("");

		},

		onLiveChangeCaseIdInput: function (oEvent) {

			// validate the input for a format that is equal to: 10001000,10001000,1000000
			// format explanation: 1 (8digitnumbers) followed by 0 or more (seperating comma with a 8digitnumber)
			var oInputField = oEvent.getSource();
			var sInput = oEvent.getParameter("value");
			var sCaseIdMultiInputValidation = "^([0-9]{8})(\,[0-9]{8})*$";

			// remove any whitespace
			sInput = sInput.replace(/\s/g, '');

			if (sInput.length === 0) {
				oInputField.setValueState(sap.ui.core.ValueState.None);
				return;
			}

			if (!sInput.match(sCaseIdMultiInputValidation)) {
				oInputField.setValueStateText(this._oResourceBundle.getText("pdfCaseIdMultiInputWrongFormat"));
				oInputField.setValueState(sap.ui.core.ValueState.Error);
				return;
			}

			oInputField.setValueState(sap.ui.core.ValueState.None);

		},

		onSearch: function (oEvent) {

			this.reportDownloadHandler.resetMimeFilterModel(this);
			var filtersModel = this.getModel("extReportFilters");
			var params = oEvent.getParameters();
			var selectedFilters = params.selectionSet;
			var bMandatoryFiltersFilled = true;
			var dDateValue1, dDateValue2, sOption;
			var that = this;
			var sMimeType = null;

			filtersModel.setProperty("/" + "case_id", null);

			selectedFilters.forEach(function (item) {
				var filterId = item.getId();
				var property, selectedKeys;
				if (filterId.indexOf("processType") > -1) {
					if (item.getProperty("selectedKeys") && item.getProperty("selectedKeys").length > 0) {
						selectedKeys = item.getProperty("selectedKeys"); //Object.keys(
						item.setValueState("None");
					} else {
						selectedKeys = null;
						bMandatoryFiltersFilled = false;
						item.setValueState("Error");
					}
					property = "process_type";
				} else if (filterId.indexOf("region") > -1) {
					if (item.getProperty("selectedKeys") && item.getProperty("selectedKeys").length > 0) {
						selectedKeys = item.getProperty("selectedKeys"); //Object.keys(
						item.setValueState("None");
					} else {
						selectedKeys = null;
						bMandatoryFiltersFilled = false;
						item.setValueState("Error");
					}
					property = "region";
				} else if (filterId.indexOf("status") > -1) {
					if (item.getProperty("selectedKeys") && item.getProperty("selectedKeys").length > 0) {
						selectedKeys = item.getProperty("selectedKeys"); //Object.keys(	
					} else {
						selectedKeys = null;
					}
					property = "status";
				} else if (filterId.indexOf("rating") > -1) {
					if (item.getProperty("selectedKeys") && item.getProperty("selectedKeys").length > 0) {
						selectedKeys = item.getProperty("selectedKeys"); //Object.keys(	
					} else {
						selectedKeys = null;
					}
					property = "rating";
				} else if (filterId.indexOf("CustSeg") > -1) {
					if (item.getTokens() && item.getTokens().length > 0) {
						selectedKeys = [];
						item.getTokens().forEach(function (itemInner) {
							selectedKeys.push(itemInner.getKey());
						});
					} else {
						selectedKeys = null;
					}
					property = "master_code";
				} else if (filterId.indexOf("ServiceOrg") > -1) {
					if (item.getTokens() && item.getTokens().length > 0) {
						selectedKeys = [];
						item.getTokens().forEach(function (itemInner) {
							selectedKeys.push(itemInner.getKey());
						});
					} else {
						selectedKeys = null;
					}
					property = "service_org";
				} else if (filterId.indexOf("ServiceTeam") > -1) {
					if (item.getTokens() && item.getTokens().length > 0) {
						selectedKeys = [];
						item.getTokens().forEach(function (itemInner) {
							selectedKeys.push(itemInner.getKey());
						});
					} else {
						selectedKeys = null;
					}
					property = "service_team";
				} else if (filterId.indexOf("DelivUnit") > -1) {
					if (item.getTokens() && item.getTokens().length > 0) {
						selectedKeys = [];
						item.getTokens().forEach(function (itemInner) {
							selectedKeys.push(itemInner.getKey());
						});
					} else {
						selectedKeys = null;
					}
					property = "delivery_unit";
				} else if (filterId.indexOf("MainProd") > -1) {
					if (item.getSelected()) {
						selectedKeys = "ZSCASEPROM";
					} else {
						selectedKeys = null;
					}
					property = "mainProductSearch";
				} else if (filterId.indexOf("ProdCat") > -1) {
					if (item.getTokens() && item.getTokens().length > 0) {
						selectedKeys = [];
						item.getTokens().forEach(function (itemInner) {
							selectedKeys.push(itemInner.getKey());
						});
					} else {
						selectedKeys = null;
					}
					property = "ref_objectprodCat";
				} else if (filterId.indexOf("ProdLine") > -1) {
					if (item.getTokens() && item.getTokens().length > 0) {
						selectedKeys = [];
						item.getTokens().forEach(function (itemInner) {
							selectedKeys.push(itemInner.getKey());
						});
					} else {
						selectedKeys = null;
					}
					property = "ref_objectprodLine";
				} else if (filterId.indexOf("Prod") > -1) {
					if (item.getTokens() && item.getTokens().length > 0) {
						selectedKeys = [];
						item.getTokens().forEach(function (itemInner) {
							selectedKeys.push(itemInner.getKey());
						});
					} else {
						selectedKeys = null;
					}
					property = "ref_object";
				} else if (filterId.indexOf("SalesOrg") > -1) {
					if (item.getTokens() && item.getTokens().length > 0) {
						selectedKeys = [];
						item.getTokens().forEach(function (itemInner) {
							selectedKeys.push(itemInner.getKey());
						});
					} else {
						selectedKeys = null;
					}
					property = "sales_org";
				} else if (filterId.indexOf("MainCust") > -1) {
					if (item.getTokens() && item.getTokens().length > 0) {
						selectedKeys = [];
						item.getTokens().forEach(function (itemInner) {
							selectedKeys.push(itemInner.getKey());
						});
					} else {
						selectedKeys = null;
					}
					property = "customer_bp_id";
				} else if (filterId.indexOf("CreationTime") > -1) {
					dDateValue1 = that.getView().getModel("dateFilterModel").getProperty("/creationDateValue1");
					dDateValue2 = that.getView().getModel("dateFilterModel").getProperty("/creationDateValue2");
					sOption = that.getView().getModel("dateFilterModel").getProperty("/creationDateSelectedOption");

					if (dDateValue1 != null) {
						item.setValueState("None");
						selectedKeys = [];
						selectedKeys.push(sOption);
						selectedKeys.push("" + dDateValue1.getFullYear() + ("0" + (dDateValue1.getMonth() + 1)).slice(-2) + ("0" + dDateValue1.getDate())
							.slice(-
								2) + that._getFinalTimestampValue(sOption));
						if (sOption === "BT") {
							selectedKeys.push("" + dDateValue2.getFullYear() + ("0" + (dDateValue2.getMonth() + 1)).slice(-2) + ("0" + dDateValue2.getDate())
								.slice(-
									2) + that._getFinalTimestampValue(sOption, "DateValue2"));
						}
					} else {
						bMandatoryFiltersFilled = false;
						selectedKeys = null;
						item.setValueState("Error");
					}
					property = "creation_date";
				} else if (filterId.indexOf("ClosingTime") > -1) {
					var tmpBMandatoryFiltersFilled = true;
					dDateValue1 = that.getView().getModel("dateFilterModel").getProperty("/closingDateValue1");
					dDateValue2 = that.getView().getModel("dateFilterModel").getProperty("/closingDateValue2");
					sOption = that.getView().getModel("dateFilterModel").getProperty("/closingDateSelectedOption");
					var bClosingDateEmptySelected = that.getView().getModel("dateFilterModel").getProperty("/closingDateEmptySelected");

					if (dDateValue1 != null) {
						item.setValueState("None");
						selectedKeys = [];
						selectedKeys.push(sOption);
						//in case if empty closing dates should also be included
						selectedKeys.push("" + dDateValue1.getFullYear() + ("0" + (dDateValue1.getMonth() + 1)).slice(-2) + ("0" + dDateValue1.getDate())
							.slice(-
								2) + that._getFinalTimestampValue(sOption));
						if (sOption === "BT") {
							selectedKeys.push("" + dDateValue2.getFullYear() + ("0" + (dDateValue2.getMonth() + 1)).slice(-2) + ("0" + dDateValue2.getDate())
								.slice(-
									2) + that._getFinalTimestampValue(sOption, "DateValue2"));
						}

					} else {
						tmpBMandatoryFiltersFilled = false;
						selectedKeys = null;
						item.setValueState("Error");
					}
					if (!selectedKeys) {
						selectedKeys = [];
					}
					if (bClosingDateEmptySelected) {
						selectedKeys.push(bClosingDateEmptySelected);
						tmpBMandatoryFiltersFilled = true;
						item.setValueState("None");
					} else {
						selectedKeys.push(false);
					}
					property = "closing_date";
					if (tmpBMandatoryFiltersFilled === false) {
						bMandatoryFiltersFilled = false;
					}
				} else if (filterId.indexOf("MimeType") > -1) {
					if (item.getSelectedIndex() === 0) {
						sMimeType = that._oResourceBundle.getText("typePDF");
					} else {
						sMimeType = that._oResourceBundle.getText("typeXLS");
					}
				}

				// : true,
				// closingDateEmptyVisibility: true

				filtersModel.setProperty("/" + property, selectedKeys);
				//	}
			});

			if (bMandatoryFiltersFilled) {

				this._startReportGeneration(sMimeType, filtersModel, that);

			} else {
				MessageToast.show(this._oResourceBundle.getText("pdfRequiredFilters"));
			}
		},

		_startReportGeneration: function (sMimeType, oFiltersModel, oThat) {
			var sfinalPOSTFilter = oFiltersModel.buildPOSTFilterString();
			//console.log("POST Filter: " + sfinalPOSTFilter);
			var result = null;
			//wait till data has been loaded
			var fnShowDecisionDialog = function (params) {
				this.getModel("mcsModel").detachRequestCompleted(fnShowDecisionDialog, this);
				if (result.getProperty("/oDataCallStatus") === "OK") {
					if (result.getProperty("/mimeFilteredCount") === 0) {
						MessageToast.show(oThat._oResourceBundle.getText("pdfNoMatches"));
					} else if (result.getProperty("/mimeFilteredCount") > 1000) {
						MessageToast.show(oThat._oResourceBundle.getText("pdfTooManyMatches", result.getProperty("/mimeFilteredCount")));
					} else {

						var sDecisionText = "";
						var sState = "None";
						if (oThat._caseIdMultiInputCount && oThat._caseIdMultiInputCount > result.getProperty("/mimeFilteredCount")) {
							sDecisionText = oThat._oResourceBundle.getText("mimeDecisionTextUnequalCaseIdReturn", [oThat._caseIdMultiInputCount, result.getProperty(
								"/mimeFilteredCount")]);
							sState = "Warning";
						} else {
							sDecisionText = oThat._oResourceBundle.getText("mimeDecisionText", result.getProperty("/mimeFilteredCount"));
						}
						//in case of no authorization show specific error message and do not enable the retry button

						//sap.m.Dialog needed because we want to provide the possibility to show link to Ticket create Launchpad
						/* eslint-disable  sap-no-hardcoded-url  */
						var dialog = new sap.m.Dialog({
							title: oThat._oResourceBundle.getText("busyDialogTitle"),
							type: "Standard",
							state: sState,
							content: new sap.ui.layout.VerticalLayout({
								content: [new sap.m.Text({
									text: sDecisionText
								})]

							}),
							beginButton: new sap.m.Button({
								text: "Generate",
								press: function () {
									oThat.onDownload("onPressGenerateMIME", sMimeType); //show Confidential Popup and proceed based on Action selection in that popup
									//	oThat.reportDownloadHandler.onPressGenerateMIME(oThat, sMimeType);
									oThat.trackEvent("Export/ReportDownload:" + sMimeType);
									dialog.close();
								}
							}),
							endButton: new sap.m.Button({
								text: "Cancel",
								press: function () {
									dialog.close();
								}
							}),
							afterClose: function () {
								dialog.destroy();
							}
						});
						dialog.addStyleClass("sapUiContentPadding");
						dialog.open();
						/* eslint-enable  sap-no-hardcoded-url  */
					}
				}
			};
			this.getModel("mcsModel").attachRequestCompleted(fnShowDecisionDialog, this);
			result = this.models.handleCasesForMIME(this.getModel("mcsModel"), sfinalPOSTFilter, null, false, sMimeType);
			this.setModel(result, "resultModel");
		},

		_getFinalTimestampValue: function (sOption, sBTValueTwo) {
			var timeStampStartOfDay = "000000";
			var timeStampEndOfDay = "235959";
			var finalTimeStamp = "";
			switch (sOption) {
			case "BT":
				if (sBTValueTwo) {
					finalTimeStamp = timeStampEndOfDay;
				} else {
					finalTimeStamp = timeStampStartOfDay;
				}
				break;
			case "LE":
				finalTimeStamp = timeStampEndOfDay;
				break;
			case "GE":
				finalTimeStamp = timeStampStartOfDay;
				break;
			default:
				finalTimeStamp = timeStampStartOfDay;
			}
			return finalTimeStamp;
		},
		_synchModelOnTokenDelete: function (oEvent, sType, oModel) {
			switch (sType) {
			case "creation":
				oModel.setProperty("/creationDateValue1", null);
				oModel.setProperty("/creationDateValue2", null);
				break;
			case "closing":
				oModel.setProperty("/closingDateValue1", null);
				oModel.setProperty("/closingDateValue2", null);
				break;
			case "empty":
				oModel.setProperty("/closingDateEmptySelected", false);
				break;
			default:
				//might be needed for further use, but currently shold not reach the default
			}
		},
		_initializeDates: function (oModel) {
			//init date range selection
			var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();
			//default selection should show 1st of month to today
			var dateToday = new Date(); //today
			//start with current month
			var dateFirstOfYear = new Date();
			dateFirstOfYear.setUTCDate(1);
			dateFirstOfYear.setUTCMonth(0);
			dateFirstOfYear.setUTCFullYear(dateToday.getUTCFullYear());
			oModel.setData({
				creationDateValue1: dateToday,
				creationDateValue2: null,
				closingDateValue1: dateFirstOfYear,
				closingDateValue2: null,
				//dateMin: dateMin,
				dateMax: new Date(dateToday.getUTCFullYear(), dateToday.getUTCMonth(), dateToday.getUTCDate(), 23, 59, 59, 999),
				creationDateRangeVisible: false,
				closingDateRangeVisible: false,
				creationDateSelectedOption: "LE",
				closingDateSelectedOption: "GE",
				closingDateEmptySelected: true,
				closingDateEmptyVisibility: true
			});
		},
		/*if the user changes the option in the drop down, the dates have to be reassigned
		e.g. initially it showed <= 27.06.2017 for Creation Date
		if the user switches to BT it should show e.g.
		01.06.2017 - 27.06.2017
		Therefore DateValue1 has to be copied to DateValue2
		DateValue1 has to be set to the first of current month*/
		switchDateDisplay: function (oModel, sType, option) {
			var dateValue1, dateValue2;
			if (option === "BT") {
				dateValue2 = new Date();
				dateValue1 = new Date(dateValue2.getUTCFullYear(), 0, 1, 0, 0, 0, 0);
				oModel.setProperty("/" + sType + "DateValue1", dateValue1);
				oModel.setProperty("/" + sType + "DateValue2", dateValue2);
			} else {
				oModel.setProperty("/" + sType + "DateValue2", null); //in case of all other options we only need DateValue2
			}
		}
	});

});