sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel"
], function (BaseController, formatter, Filter, FilterOperator, MessageToast, JSONModel) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.CriticalEventCoverageDetailsMobile", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				bLoadingState: false,
				iTabFiltered: 0,
				bLoadingStatePA: false,
				showObjectType: false
			}), "viewModel");
			this.getRouter().getRoute("CriticalEventCoverageDetailsMobile").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function (oEvent) {
			var oArgs = oEvent.getParameter("arguments");
			if (oArgs["?query"] && oArgs["?query"].showInternal === "true") {
				this.showInternal = true;
			} else {
				this.showInternal = false;
			}
			this.sObjectID = oEvent.getParameter("arguments").ObjectID;
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
			this._loadData();
		},

		onSectionChange: function (oEv) {
			if (oEv.getParameter("key") === "Links") {
				this._loadLinkedObjects();
			} else if (oEv.getParameter("key") === "Issue Tracker") {
				this._loadMCCIssues();
			} else if (oEv.getParameter("key") === "Updates") {
				this._loadNotes();
			} else if (oEv.getParameter("key") === "Focus Customers") {
				this._loadFocusCustomers();
			} else if (oEv.getParameter("key") === "Related Critical Period Coverage") {
				this._loadRelatedCPC();
			} else if (oEv.getParameter("key") === "General Information") {
				this._loadNotes();
			}
		},

		_loadData: function() {
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			oModel.read("/MCCObject('" + this.sObjectID + "')", {
				success: function (data) {
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getView().setModel(oModel,"detailData");
					this._loadLinkedObjects();
					this._loadMCCIssues();
					this._loadNotes();
					this._loadFocusCustomers();
					this._loadRelatedCPC();
				}.bind(this),
				error: function (data) {
					MessageToast.show("Can't receive API response for this ObjectID ");

				}
			});

			//also load Value Helpers for Focus customers
			this.getOwnerComponent().getModel("mccIssueTracking").read("/DropdownValues", {
				filters: [new Filter("DropdownName", "EQ", "CEC-Status-Dropdown")],
				success: function(oData) {
					this.getView().setModel(new JSONModel(oData.results),"valueHelps");
				}.bind(this)
			})
		},

		_loadFocusCustomers: function() {
			var oModel = this.getOwnerComponent().getModel("subModel");
			this.getView().setModel(new JSONModel([]), "cecCustomers");
			this.getView().setModel(new JSONModel([]), "customers");
			this.getView().setModel(new JSONModel({}), "newSH");
			oModel.read("/Stakeholder", {
				filters: [new Filter("ObjectID", "EQ", this.sObjectID)],
				success: function (oData) {
					var customers = [],
					tree = {
						contacts: []
					};
					oData.results.forEach(function (item) {
						//item.bEdit = false;
						item.CustomerNameFull = item.CustomerName + " (" + item.CustomerID + ")";
						customers.push(item.CustomerID);

						var bCustomer = tree.contacts.filter(element => element.UserName === item.CustomerNameFull);
						if (bCustomer.length === 0) {
							tree.contacts.push({
								UserName: item.CustomerNameFull,
								CustomerName: item.CustomerName,
								CustomerID: item.CustomerID,
								Region: item.Region,
								CaseID: item.CaseID,
								bCustomer: true,
								contacts: [item]
							});
						} else {
							tree.contacts.forEach(function (customer) {
								if (customer.UserName === item.CustomerNameFull) customer.contacts.push(item);
							});
						}
					});
					var uniqueCount = new Set(customers).size;
					this.getView().getModel("viewModel").setProperty("/numberOfCustomers",uniqueCount);
					this.getView().getModel("cecCustomers").setData(tree);
					this.getView().getModel("cecCustomers").setProperty("/count", uniqueCount);
				}.bind(this),
				error: function (data) {
					//this.getView().byId("cecIssueTable").setBusy(false);
					MessageToast.show("Can't receive API response for this ObjectID ");

				}
			});
		},

		_loadNotes: function() {
			var oModel = this.getOwnerComponent().getModel("subModel");
			oModel.read("/Notes", {
				filters: [new Filter("ObjectID", "EQ", this.sObjectID)],
				success: function(oData) {
					var aSorted = [];
					var aGeneral = [];
					for (var i = 0; i <= 6; i++) {
						for (var j = 0; j < oData.results.length; j++) {
							if (oData.results[j].Type === this._getType(i)) {
								oData.results[j].Text = this.formatter.formatNoteToHTML(oData.results[j].Text);
								if (this._getType(i) === "General") {
									aGeneral.push(oData.results[j]);
								} else {
									aSorted.push(oData.results[j]);
								}
							}
						}
					}
					this.getView().setModel(new JSONModel(aSorted), "Notes");
					this.getView().setModel(new JSONModel(aGeneral), "GeneralNotes");
				}.bind(this),				
				error: function (data) {
					MessageToast.show("Can't receive API response for this ObjectID ");

				}
			});
		},

		_loadMCCIssues: function() {
			this.getView().byId("IssueTrackerListId").setBusy(true)
			var oModel = this.getOwnerComponent().getModel("subModel");
			var that = this;
			
			oModel.read("/MCCIssues", {
				filters: [new Filter("ObjectID", "EQ", this.sObjectID)],
				urlParameters: {
					"$expand": "toAffectedProducts"
				},
				success: function (oData) {
					this.getView().byId("IssueTrackerListId").setBusy(false);
					oData.results.sort(function (a, b) {
						return (a.createdAt < b.createdAt) ? -1 : 1;
					});
					oData.results.forEach(function (issue, i) {
						issue.No = i + 1; //temporary issue number 
						issue.StatusT =  that.formatter.formatCECStatus(issue.Status);
					});
					var oModel = new sap.ui.model.json.JSONModel(oData);
					this.getView().setModel(oModel,"mccissues");
				}.bind(this),
				error: function (data) {
					this.getView().byId("IssueTrackerListId").setBusy(false);
					MessageToast.show("Can't receive API response for this ObjectID ");

				}
			});
			
		},

		_loadLinkedObjects: function () {
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			var oFilter = new Filter("TopIssueID", FilterOperator.EQ, this.sObjectID);
			oModel.read("/LinkedObjects", {
				filters: [oFilter],
				success: function (data) {
					data.results.forEach(function (item) {
						if (item.ObjectType !== "5") {
							item.URL = item.ObjectID;
						}
					});
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "linkedObjects");
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this),
				error: function (data) {
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "linkedObjects");
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this)
			});
		},

		_loadRelatedCPC: function() {
			var aFilters = [];
			var oTable = this.getView().byId("CPCListId");
			
			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04"));
			aFilters.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, this.getView().getModel("detailData").getProperty("/MCCTag")));

			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				// urlParameters: {
				// 	"$select": "CaseId,CaseTitle,CustomerText,Region,StatusT,Rating,CreateDate,CustomerErpNo,ServiceOrgT,HasNotes"
				// },
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);
					data.results.forEach(function (oCase) {
						if (oCase.Rating === "") {
							oCase.Rating = "unrated";
						}
						if (oCase.DbsMaintenanceRanking === "0") {
							oCase.DbsMaintenanceRanking = "";
						}
						oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);

					}.bind(this));
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "tableData");
					this.readImplementationPartner(oModel).then(function () {
						setTimeout(function () {
							oTable.rerender();
						}, 200);
					}.bind(this));
					//MISSIONRADAR 2211	
					this.readMissionRadarValues(oModel, "results");
					this.loadProducts();
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		loadProducts: function () {
			var aFilters = [];
			var oTable = this.getView().byId("table");
			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04"));
			aFilters.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, this.getView().getModel("detailData").getProperty("/MCCTag")));

			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$expand": "toProducts",
					"$select": "CaseId,toProducts"
				},
				success: function (data) {

					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					var oModel = this.getOwnerComponent().getModel("tableData");
					var aAlreadyAdded = oModel.getData().results;

					data.results.forEach(function (oCase) {
						oCase.ProductVersions = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.Product = this.formatter.concatProducts(oCase.toProducts.results, "ProductT");
						oCase.ProductCategory = this.formatter.concatProducts(oCase.toProducts.results, "ProductCatT");
						oCase.ProductLine = this.formatter.concatProducts(oCase.toProducts.results, "ProductLineT");
						oCase.ProductVer = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.ProductLineKeys = this.formatter.concatProducts(oCase.toProducts.results, "ProductLine");
						oCase.ProductKeys = this.formatter.concatProducts(oCase.toProducts.results, "Product");

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.CaseId === oCase.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = oCase.toProducts;
								aTmp[i].toLastNotes = oCase.toLastNotes;
								aTmp[i].ProductVersions = oCase.ProductVersions;
								aTmp[i].Product = oCase.Product;
								aTmp[i].ProductCategory = oCase.ProductCategory;
								aTmp[i].ProductLine = oCase.ProductLine;
								aTmp[i].ProductVer = oCase.ProductVer;
								aTmp[i].ProductLineKeys = oCase.ProductLineKeys;
								aTmp[i].ProductKeys = oCase.ProductKeys;
							});
						}
					}.bind(this));
					oModel.refresh();
				}.bind(this),

				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		readNotes: function (oControl, id, sObjectType) {
			var oICModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oICModel.read("/CustomerEngagementSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results, sObjectType);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("tableData").getObject();
			var sObjectType = "";
			if (oData.CustomerType != "") {
				sObjectType = oData.CustomerType;
			}
			var sId = oData.CaseId;
			this.readNotes(oEv.getSource(), sId, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},

		_openServiceNow: function(oEv) {
			var sId = oEv.getSource().getText();
			this._openServiceNowTicketURL(sId);
		},

		_getType: function (i) {
			if (i === 0) return "General";
			if (i === 1) return "Summary";
			if (i === 2) return "MCC";
			if (i === 3) return "Support";
			if (i === 4) return "Engineering";
			if (i === 5) return "Focus Customer";
			if (i === 6) return "Additional";
		},

		onFocusCustomerCollapseAll: function() {
			var oTreeTable = this.getView().byId("cecCustomerTable");
			oTreeTable.collapseAll();
		},

		onFocusCustomerExpandAll: function() {
			var oTreeTable = this.getView().byId("cecCustomerTable");
			oTreeTable.expandToLevel(1);
		},

		onOpenUser: function (oEv) {
			this.formatter.openUser(oEv, oEv.getSource().getBindingContext("cecCustomers").getObject().UserID);
		},

		navToCase: function(oEv) {
			var sCaseId = oEv.getSource().getBindingContext("cecCustomers").getObject().CaseID;
			this.getOwnerComponent().getModel("case").setProperty("/reload",true);

			var oRouter = this.getRouter();
			oRouter.navTo("CaseDetails", {
				CaseId: sCaseId,
				"?query": this._getQueryParameter()
			});
		},

		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("tableData").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		},

		onCase: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("tableData").getObject().CaseId;
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);

			this.getRouter().navTo("CaseDetailsMobile", {
				"?query": this._getQueryParameter(),
				"CaseId": sCaseId
			});
		},

		onCaseNewTab: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("tableData").getObject().CaseId;
			this._openCaseInNewTab(sCaseId);
		},

		onCustomer: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("tableData").getObject().CustomerErpNo;
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("Customer", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		handleURLPress: function (oEv) {
			if (oEv.getSource().getBindingContext("linkedObjects")) {
				var oBindingContext = oEv.getSource().getBindingContext("linkedObjects");
				var sObjectType = oBindingContext.getObject().ObjectType;
				var sUrl = oBindingContext.getObject().URL;
				var sObjectID = oBindingContext.getObject().ObjectID;
				var currentUrl = window.location.href;

				switch (sObjectType) {
					case "5": // Others
						if (!sUrl.startsWith("http")) {
							sUrl = "https://" + oBindingContext.getObject().URL + "/"
						}
						this._openWindow(sUrl);
						break;
					case "4": // ServiceNow ID
						if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") || currentUrl.includes("applicationstudio")) {
							//we are in dev envrionment
							sUrl = "https://bcdmain.wdf.sap.corp/sap/support/message/" + sObjectID;
							this._openWindow(sUrl);
						} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
							//we are in test envrionment
							sUrl = "https://qa-support.wdf.sap.corp/sap/support/message/" + sObjectID;
							this._openWindow(sUrl);
						} else {
							sUrl = "https://support.wdf.sap.corp/sap/support/message/" + sObjectID;
							this._openWindow(sUrl);
						}
						break;

					case "13": // Escalation Record ID
					case "12": // ServiceNow Incident ID
						if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") || currentUrl.includes("applicationstudio")) {
							//we are in dev envrionment
							sUrl = "https://dev.itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + sObjectID;
							this._openWindow(sUrl);
						} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
							//we are in test envrionment
							sUrl = "https://test.itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + sObjectID;
							this._openWindow(sUrl);
						} else {
							sUrl = "https://itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + sObjectID;
							this._openWindow(sUrl);
						}
						break;

					case "1": // ICP Case
						this.getOwnerComponent().getModel("case").setProperty("/reload", true);
						this.getRouter().navTo("CaseDetails", {
							"?query": this._getQueryParameter(),
							"CaseId": sUrl
						});
						break;
					default:
						if (sUrl !== "") {
							this.getOwnerComponent().getModel("case").setProperty("/reload", true);
							this.getRouter().navTo("CaseDetails", {
								"?query": this._getQueryParameter(),
								"CaseId": sUrl
							});
						}
						break;
				}
			}
		},

		onLiveSearchLinksChange: function(event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("LinksListId");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("ObjectTypeValue", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("URL", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter("Description", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter3);
		
			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		},

		onLiveSearchIssueTrackerChange: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("IssueTrackerListId");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("Title", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("AffectedCustText", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);
		
			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		},

		onLiveSearchChange: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("CPCListId");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("CustomerText", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("CountryT", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter("RegionT", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter3);

			var oFilter4 = new sap.ui.model.Filter("CaseTitle", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter4);

			var oFilter5 = new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter5);

			var oRatingFilter;
			if (searchValue === "red") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C");
			} else if (searchValue === "yellow" || searchValue === "orange") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "B");
			} else if (searchValue === "green") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "A");
			} else {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.Contains, searchValue);
			}
			aFilters.push(oRatingFilter);

			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		}
	
	});
});