sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"sap/ui/model/json/JSONModel",
	"sap/base/util/deepExtend",
	"sap/m/ColumnListItem",
	"sap/m/MultiInput",
	"sap/m/Select",
	"sap/m/MessageBox",
	"sap/m/MultiComboBox",
	"sap/m/Token",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/model/FilterOperator",
	"com/sap/mcconedashboard/control/CustomMultiInput"
], function (BaseController, JSONModel, deepExtend, ColumnListItem, MultiInput, Select, MessageBox, MultiComboBox, Token, Filter, Sorter,
	FilterOperator, CustomMultiInput) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.controllerMobile.EventCalendarMobile", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.mcconedashboard.view.EventCalendar
		 */
		onInit: function () {
			this.oViewModel = new JSONModel({
				eventTypeDropdownValues: [
					/*{
										"Key": "All",
										"Name": "All Events",
										"filter": true,
										"Legend": ""
									}, */
					{
						"Key": "SAP Production Release",
						"Name": "SAP Production Release",
						"Type": "Type12",
						"filter": false,
						"Legend": "Appointments"
					}, {
						"Key": "SAP Preview Release",
						"Name": "SAP Preview Release",
						"Type": "Type06",
						"filter": false,
						"Legend": "Appointments"
					}, {
						"Key": "Migration",
						"Name": "Migration",
						"Type": "Type05",
						"filter": false,
						"Legend": "Appointments"
					}, {
						"Key": "Business Event",
						"Name": "Business Event",
						"Type": "Type01",
						"filter": false,
						"Legend": "Appointments"
					}, {
						"Key": "Critical Event Coverage",
						"Name": "Critical Event Coverage",
						"Type": "Type18",
						"filter": false,
						"Legend": "Solution Hub"
					}, {
						"Key": "Solution Specific Event",
						"Name": "Solution Specific Event",
						"Type": "Type10",
						"filter": false,
						"Legend": "Appointments"
					}
				],
				solutionAreaValues: [{
					"Key": "HXM",
					"Name": "Human Capital Management",
					"filter": false
				}, {
					"Key": "CX",
					"Name": "Customer Experience",
					"filter": false
				}, {
					"Key": "DSC",
					"Name": "Digital Supply Chain",
					"filter": false
				}, {
					"Key": "ISBN",
					"Name": "Intelligent Spend & Business Network",
					"filter": false
				}, {
					"Key": "S/4HANA",
					"Name": "S/4HANA",
					"filter": false

				}, {
					"Key": "BTP HANA & Analytics",
					"Name": "Business Technology Platform (HANA & Analytics)",
					"filter": false

				}, {
					"Key": "BTP Core",
					"Name": "Business Technology Platfrom (Core)",
					"filter": false

				}],
				products: [],
				filteredProducts: [],
				startDate: new Date(),
				popoverContactNames: "",
				popoverProductName: "",
				bEC2: true //Event Calendar 2 not visible
			});

			this.getView().setModel(this.oViewModel, "viewModel");
			this.getView().setModel(new JSONModel({
				path: sap.ui.require.toUrl("com/sap/mcconedashboard/image/solution_hub_logo_name_horizontal_onwhite.png")
			}), "solHubLogo");
			this.getModel("solutionHub").setSizeLimit(5000);
			var views = this.getView().byId("eventCalendarIdMobile").getViews();
			this.getView().byId("eventCalendarIdMobile").setSelectedView(views[1]); //month

			//load data manually
			this.getModel("solutionHub").read("/Events", {
				success: function (oData) {
					this._setEventCalendar2(oData.results);
					this._onFilter();
				}.bind(this)
			});

		},

		onAfterRendering: function () {
			/*	var data = this.getView().getModel("solutionHub").oData;
				this._setEventCalendar2(data);*/
			this._setEventCalendar1();
		},

		viewChange: function (oEvent) {
			if (oEvent.getSource().getId().includes("eventCalendarIdMobile") && oEvent.getSource().getSelectedView().includes("YearMobile")) {
				this.openYearView();
			}
		},

		handleMoreLinkPress: function (oEvent) {
			var oDate = oEvent.getParameter("date"),
				oSinglePlanningCalendar = this.getView().byId("eventCalendarIdMobile");

			oSinglePlanningCalendar.setSelectedView(oSinglePlanningCalendar.getViews()[0]); // DayView
			oSinglePlanningCalendar.setStartDate(oDate);
		},

		handleAppointmentSelect: function (oEvent) {
			var oAppointment = oEvent.getParameter("appointment"),
				model = this.getView().getModel("viewModel").getProperty("/bEC2") ? "solutionAreas" : "solutionHub",
				path,
				sUser,
				aUserId,
				productId,
				aPromises = [],
				sContactNames = "";
			if (oAppointment) {
				path = oAppointment.getBindingContext(model).getPath();
				sUser = this.getView().getModel(model).getProperty(path).Contacts;
				aUserId = sUser.split(",");
				productId = this.getView().getModel(model).getProperty(path).MainProduct;

				//load user data
				if (aUserId.length > 0) {
					aUserId.forEach(function (userID) {
						if (userID) {
							aPromises.push(new Promise(function (resolve, reject) {
								jQuery.ajax({
									url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/sapit-employee-data/Employees('" + userID + "')",
									async: false,
									method: "GET",
									dataType: "json",
									success: function (oUserData) {
										sContactNames += oUserData.firstName + " " + oUserData.lastName + " (" + oUserData.id + "), ";
										resolve();
									},
									error: function (err) {
										resolve();
									}
								});
							}));
						}
					});
				}

				//load product
				aPromises.push(new Promise(function (resolve, reject) {
					var oModel = this.getView().getModel("appDepModelNoBatch");
					if (!productId) {
						this.oViewModel.setProperty("/popoverProductName", "");
						resolve();
						return;
					}
					oModel.read("/ProductSet", {
						filters: [new Filter("ProductNR", "EQ", productId)],
						success: function (data) {
							if (data.results.length > 0) this.oViewModel.setProperty("/popoverProductName", data.results[0].ProductName);
							else this.oViewModel.setProperty("/popoverProductName", "");
							resolve();
						}.bind(this),
						error: function (err) {
							this.oViewModel.setProperty("/popoverProductName", "");
							resolve();
						}.bind(this)
					});
				}.bind(this)));

				Promise.all(aPromises).then(function () {
					if (sUser && sContactNames === "") sContactNames = sUser;
					else if (sContactNames) sContactNames = sContactNames.substring(0, sContactNames.length - 2);
					this.oViewModel.setProperty("/popoverContactNames", sContactNames);
					if (model === "solutionHub") {
						this._pDetailsPopover = sap.ui.xmlfragment(this.getView().getId(),
							"com.sap.mcconedashboard.view.viewMobile.fragmentMobile.Global.EventCalendarDetailsMobile", this);
					} else {
						this._pDetailsPopover = sap.ui.xmlfragment(this.getView().getId(),
							"com.sap.mcconedashboard.view.viewMobile.fragmentMobile.Global.EventCalendar2DetailsMobile", this);
					}
					this._pDetailsPopover.bindElement({
						path: path,
						model: model,
						openBy: oAppointment
					});
					this.getView().addDependent(this._pDetailsPopover);
					this._pDetailsPopover.openBy(oAppointment);
				}.bind(this));
			}
		},

		onDownloadEvent: function (oEvent) {
			var viewModel = this.getView().getModel("viewModel"),
				model = this.getView().getModel("viewModel").getProperty("/bEC2") ? "solutionAreas" : "solutionHub",
				binding = oEvent.getSource().getParent().getParent().getBindingContext(model),
				path = binding.getPath(),
				object = binding.getModel().getProperty(path),
				startDate = this.formatDateDownload(object.StartDateTime),
				endDate = this.formatDateDownload(object.EndDateTime),
				timeStamp = this.formatDateDownload(new Date());
			//markdown->html text & remove surrounding div tags + line breaks
			var oMarkdownText = new sapit.controls.MarkdownText({
				text: object.AdditionalInfo
			});
			var sHTML = oMarkdownText.getAggregation("_html").getContent();
			sHTML = sHTML.replace(/\n/g, "").replace("<div>", "").replace("</div>", "");
			// var sHTML = "";
			var calendarBody = "\nX-ALT-DESC;FMTTYPE=text/html:<html><body>" +
				"<p><strong>Key Contacts:</strong> " + viewModel.getProperty("/popoverContactNames") + "</p>" +
				"<p><strong>Event Duration (UTC):</strong> " + this.formatEventDuration(object.StartDateTime, object.EndDateTime) + "</p>" +
				"<p><strong>Description:</strong><br/>" + object.EventDetails.replace(/\n/g, "<br/>") + "</p>" +
				"<p><strong>Main Product:</strong> " + viewModel.getProperty("/popoverProductName") + "</p>" +
				"<p><strong>URL:</strong> <a href:'" + object.URL + "' target:'_blank'>" + object.URL + "</a></p>" +
				"<p><strong>URL Description:</strong> " + object.URLDesc + "</p>" +
				"<p><strong>Additional Event Information:</strong><br/>" + sHTML + "</p>" +
				"</body><html>";
			calendarBody = calendarBody.replace(/null/g, "");
			var icsMSG =
				"BEGIN:VCALENDAR\nVERSION: 2.0\nCALSCALE:GREGORIAN\nBEGIN:VEVENT\nSUMMARY:" + object.EventName +
				"\nUID:c7614cff-3549-4a00-9152-d25cc1fe077d\nDTSTART;TZID=UTC:" + startDate + "\nDTEND;TZID=UTC:" + endDate + "\nDTSTAMP:" +
				timeStamp + "\nDESCRIPTION:" + calendarBody + "\nEND:VEVENT\nEND:VCALENDAR";
			var link = document.createElement("a");
			link.href = "data:text/calendar;charset=utf8," + encodeURIComponent(icsMSG);
			link.download = object.EventName + ".ics";
			link.click();
			//	window.open("data:text/calendar;charset=utf8," + escape(icsMSG));
		},

		onCloseEvent: function (oEvent) {
			var bPhone = this.getView().getModel("device").getProperty("/system/phone");
			if (bPhone) oEvent.getSource().getParent().close();
			else oEvent.getSource().getParent().getParent().close();
		},

		deselectItem: function (oEvent) {
			this._pDetailsPopover.mObjectBindingInfos.solutionHub.openBy.setSelected(false);
			// oEvent.getParameter("openBy").setSelected(false);
			oEvent.getSource().destroy();
		},

		onOpenFilterbar: function (oEvent) {
			if (this.getView().byId("DynamicSideContentMobile").getShowMainContent() === true) {
			this.getView().byId("DynamicSideContentMobile").setShowMainContent(false);
			this.getView().byId("DynamicSideContentMobile").setShowSideContent(true);
			} else {
			this.getView().byId("DynamicSideContentMobile").setShowMainContent(true);
			this.getView().byId("DynamicSideContentMobile").setShowSideContent(false);	
			}
			//this.getView().byId("DynamicSideContentMobile").toggle();
		},

		openYearView: function () {
			this.oView.setBusy(true);
			this._oYearDialog = sap.ui.xmlfragment(this.oView.getId(),
				"com.sap.mcconedashboard.view.viewMobile.fragmentMobile.Global.EventCalendarYearViewDialogMobile", this);
			this.oView.addDependent(this._oYearDialog);

			var eventModel = new JSONModel(this.getView().getModel("solutionHub").oData);
			this._oYearDialog.setModel(eventModel, "eventsDialog");
			//apply same filter as in event calendar
			this.getView().byId("deliveryCalendarIdMobile").getBindingInfo("appointments").binding.filter(this.getView().byId("eventCalendarIdMobile").getBindingInfo(
				"appointments").binding.aFilters);
			this._oYearDialog.open();
		},
		onAfterOpen: function () {
			this.oView.setBusy(false);
		},
		onMonthSelected: function (oEvent) {
			this.getView().byId("eventCalendarIdMobile").setSelectedView(this.getView().byId("eventCalendarIdMobile").getViewByKey("MonthView"));
			this.getView().byId("eventCalendarIdMobile").setStartDate(oEvent.getParameter("value"));
			this._oYearDialog.close();
			this._oYearDialog.destroy();
		},

		onClose: function (oEvent) {
			this.getView().byId("eventCalendarIdMobile").setSelectedView(this.getView().byId("eventCalendarIdMobile").getViewByKey("MonthView"));
			this._oYearDialog.close();
			this._oYearDialog.destroy();
		},

		onChangeCalendarView: function (oEvent) {
			if (oEvent.getParameter("item").getKey().includes("eventCalendar2IdMobile")) {
				var data = this.getView().getModel("solutionHub").oData;
				this._setEventCalendar2(data);
				oEvent.getSource().setSelectedKey("eventCalendarIdMobile");
			} else {
				this._setEventCalendar1();
				oEvent.getSource().setSelectedKey("eventCalendar2IdMobile");
			}
			this._onFilter();
		},

		_setEventCalendar1: function () {
			this.getView().byId("eventCalendarIdMobile").setVisible(true);
			this.getView().byId("eventCalendar2IdMobile").setVisible(false);
			this.getView().getModel("viewModel").setProperty("/bEC2", false);
		},

		_setEventCalendar2: function (data) {
			var solAreas = this.getView().getModel("viewModel").getProperty("/solutionAreaValues");
			var sortedData = [];
			solAreas.forEach(function (area, i) {
				sortedData.push({
					Name: area.Name,
					Key: area.Key,
					Events: []
				});
				for (var k in data) {
					if (data[k].SolutionArea === area.Key) sortedData[i].Events.push(data[k]);
				}
			});
			var eventModel = new JSONModel(sortedData);
			this.getView().setModel(eventModel, "solutionAreas");
			this.getView().byId("eventCalendarIdMobile").setVisible(false);
			this.getView().byId("eventCalendar2IdMobile").setVisible(true);
			this.getView().getModel("viewModel").setProperty("/bEC2", true);
		},

		onFilterSolutionArea: function (oEvent) {
			var bSelected = oEvent.getParameter("selected");
			var path = oEvent.getSource().getBindingContext("viewModel").getPath();
			this.getView().getModel("viewModel").setProperty(path + "/filter", bSelected);
			this._onFilter();
		},

		onFilterType: function (oEvent) {
			/*	var path = oEvent.getParameter("selectedItem").getBindingContext("viewModel").getPath();
				var oldPath = oEvent.getParameter("previousSelectedItem").getBindingContext("viewModel").getPath();
				this.getView().getModel("viewModel").setProperty(path + "/filter", true);
				this.getView().getModel("viewModel").setProperty(oldPath + "/filter", false);
				this._onFilter();*/
			var bSelected = oEvent.getParameter("selected");
			var path = oEvent.getSource().getBindingContext("viewModel").getPath();
			this.getView().getModel("viewModel").setProperty(path + "/filter", bSelected);
			this._onFilter();
		},

		openProductFilter: function (oEvent) {
			if (!this.productDialog) {
				this.productDialog = new sap.m.SelectDialog({
					title: "Filter Products",
					search: this._handleValueHelpSearch.bind(this),
					confirm: this._handleValueHelpClose.bind(this),
					cancel: this._handleValueHelpClose.bind(this),
					multiSelect: true,
					rememberSelections: true,
					contentHeight: "500px"
				});
				//	this.productDialog.setModel(new JSONModel(this.oView.getModel("viewModel").getProperty("/products")));
				this.productDialog.bindAggregation("items", {
					path: "viewModel>/products",
					template: new sap.m.StandardListItem({
						title: "{viewModel>ProductName}",
						description: "{viewModel>ProductNR}"
					}),
					templateShareable: false
				});
				this.oView.addDependent(this.productDialog);
			}
			this.productDialog.setBusy(true);
			//load products
			var oModel = this.getView().getModel("appDepModelNoBatch"),
				aEvents = Object.entries(this.getView().getModel("solutionHub").oData),
				aFilter = [];
			aEvents.forEach(function (event) {
				if (event[1].MainProduct) aFilter.push(new Filter("ProductNR", "EQ", event[1].MainProduct));
			});
			if (aFilter.length > 0) {
				oModel.read("/ProductSet", {
					filters: aFilter,
					success: function (data) {
						this.getView().getModel("viewModel").setProperty("/products", data.results);
						this.productDialog.setBusy(false);
					}.bind(this),
					error: function (err) {
						this.getView().getModel("viewModel").setProperty("/products", []);
						this.productDialog.setBusy(false);
					}.bind(this)
				});
			} else {
				this.getView().getModel("viewModel").setProperty("/products", []);
				this.productDialog.setBusy(false);
			}

			this.productDialog.open();
		},

		_handleValueHelpSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter({
				filters: [new Filter("ProductNR", FilterOperator.Contains, sValue),
					new Filter("ProductName", FilterOperator.Contains, sValue)
				],
				and: false
			});
			oEvent.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClose: function (oEvent) {
			var aSelectedItems = oEvent.getParameter("selectedItems"),
				oInput = this.getView().byId("productFilterMobile"),
				filteredProducts = this.getView().getModel("viewModel").getProperty("/filteredProducts");
			if (oEvent.getId() === "confirm") {
				if (aSelectedItems && aSelectedItems.length > 0) {
					aSelectedItems.forEach(function (oItem) {
						oInput.addToken(new sap.m.Token({
							text: oItem.getTitle(),
							key: oItem.getDescription()
						}));
						filteredProducts.push(oItem.getDescription());
					});
				} else if (aSelectedItems && aSelectedItems.length === 0) {
					this.getView().getModel("viewModel").setProperty("/filteredProducts", []);
				}
				this._onFilter();
			}
		},
		deleteToken: function (oEvent) {
			var filteredProducts = this.getView().getModel("viewModel").getProperty("/filteredProducts");
			if (oEvent.getParameter("type") === "removed") {
				var key = oEvent.getParameter("removedTokens")[0].getKey();
				if (this.productDialog) {
					var items = this.productDialog.getItems();
					items.forEach(function (item) {
						if (item.getDescription() === key) {
							item.setSelected(false);
						}
					});
				}
				filteredProducts.forEach(function (item, i) {
					if (item === key) {
						filteredProducts.splice(i, 1);
					}
				});
				this._onFilter();
			}
		},

		_onFilter: function () {
			var oFilter = [],
				aAllFilters = [];
			//filter for solution area
			var aFilterSettings = this.getView().getModel("viewModel").getProperty("/solutionAreaValues");
			var aFilters = [];
			aFilterSettings.forEach(function (value) {
				if (value.filter === true) aFilters.push(new Filter("SolutionArea", "EQ", value.Key));
			});
			if (aFilters.length > 0) {
				aAllFilters.push(new Filter({
					filters: aFilters,
					and: false
				}));
			}

			//filter for event type
			aFilterSettings = this.getView().getModel("viewModel").getProperty("/eventTypeDropdownValues");
			/*	aFilterSettings.forEach(function (value) {
					if (value.filter === true && value.Key !== "All") aAllFilters.push(new Filter("EventType", "EQ", value.Key));
				});*/
			aFilters = [];
			aFilterSettings.forEach(function (value) {
				if (value.filter === true) aFilters.push(new Filter("EventType", "EQ", value.Key));
			});
			if (aFilters.length > 0) {
				aAllFilters.push(new Filter({
					filters: aFilters,
					and: false
				}));
			}

			//filter for products
			aFilterSettings = this.getView().getModel("viewModel").getProperty("/filteredProducts");
			aFilters = [];
			aFilterSettings.forEach(function (value) {
				aFilters.push(new Filter("MainProduct", "EQ", value));
			});
			if (aFilters.length > 0) {
				aAllFilters.push(new Filter({
					filters: aFilters,
					and: false
				}));
			}

			//set filter
			if (aAllFilters.length > 0) {
				oFilter = new Filter({
					filters: aAllFilters,
					and: true
				});
			}
			if (this.getView().getModel("viewModel").getProperty("/bEC2")) {
				var rows = this.getView().byId("eventCalendar2IdMobile").getRows();
				rows.forEach(function (row) {
					row.getBinding("appointments").filter(oFilter);
				});
			} else this.getView().byId("eventCalendarIdMobile").getBinding("appointments").filter(oFilter);
		},

		formatEventType: function (type, status) {
			if (status === "Draft") return "Type09";
			switch (type) {
			case "SAP Production Release":
				return "Type12";
			case "SAP Preview Release":
				return "Type06";
			case "Migration":
				return "Type05";
			case "Business Event":
				return "Type01";
			case "Critical Event Coverage":
				return "Type18";
			case "Solution Specific Event":
				return "Type10";
			default:
				return "Type09";
			}
		},

		formatEventTypeDetails: function (type) {
			switch (type) {
			case "SAP Production Release":
				return 2;
			case "SAP Preview Release":
				return 6;
			case "Migration":
				return 3;
			case "Business Event":
				return 1;
			case "Critical Event Coverage":
				return 7;
			case "Solution Specific Event":
				return 4;
			default:
				return 9;
			}
		},

		/**
			* Formatter function used in the Event Calendar Dialogs to customize the display of the tag 
			* in the header of the detail dialog. This function maps certain technical tags to more user-friendly 
			* names. For example, the tag "HXM" is renamed to "HCM" due to a rebranding, although the technical key 
			* has not been updated.
			*
			* @param {string} tag - The technical tag that needs to be formatted.
			* @returns {string} The formatted tag for display in the dialog header.
		*/
		formatSolutionAreaTagDetails: function (tag) {
			switch (tag) {
				case "HXM":
					return "HCM";
				default:
					return tag;
			}
		},

		formatEventName: function (status, name) {
			if (status === "Draft") return "(DRAFT) " + name;
			else return name;
		},

		formatEventDuration: function (start, end) {
			var oDate = "";
			if (start !== null && start !== "" && start !== undefined) {
				start = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MMM dd, yyyy HH:mm z",
					style: "full",
					UTC: true
				}).format(start);
			}
			if (end !== null && end !== "" && end !== undefined) {
				end = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MMM dd, yyyy HH:mm z",
					style: "full",
					UTC: true
				}).format(end);
			}
			if (start !== null && start !== "" && start !== undefined &&
				end !== null && end !== "" && end !== undefined) {
				oDate = start + " - " + end;
			}
			return oDate;
		},

		formatDateDownload: function (date) {
			var oDate = "";
			if (date !== null && date !== "" && date !== undefined) {
				oDate = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "YYYYMMddTHHmmss",
					style: "full",
					UTC: true
				}).format(date);
			}
			return oDate;
		},

		formatImageWidth: function (system) {
			if (system.phone) return "150px";
			return "250px";
		}
	});
});