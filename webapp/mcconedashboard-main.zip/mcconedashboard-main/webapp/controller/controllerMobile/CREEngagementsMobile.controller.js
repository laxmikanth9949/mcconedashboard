sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast"
], function (BaseController, formatter, Filter, FilterOperator, MessageToast) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.CREEngagementsMobile", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				bLoadingState: false,
				// iTabAllPA: 0,
				// iTabGreenPA: 0,
				// iTabYellowPA: 0,
				// iTabRedPA: 0,
				// iTabUnratedPA: 0,
				iTabFiltered: 0,
				bLoadingStatePA: false,
				showObjectType: false
			}), "viewModel");
			//this.getRouter().getRoute("ProjectsOnWatchMobile").attachPatternMatched(this._onObjectMatched, this);
		},

		onAfterRendering: function () {

			if (this.getRouter().getRoute("CREEngagementsMobile")) {
				if (!this._isListInitialized) {
					var oList = this.getView().byId("listMobile");
					if (oList) {
						this._isListInitialized = true;
						this.getRouter().getRoute("CREEngagementsMobile").attachPatternMatched(this._onObjectMatched, this);
					}
				}
			}
		},

		_onObjectMatched: function (oEvent) {
			this.showInternal = false;
			this.showMCCInternal = false;
			var oArgs = oEvent.getParameter("arguments");
			if (oArgs["?query"] && oArgs["?query"].showInternal === "true") {
				this.showInternal = true;
			} else if (oArgs["?query"] && oArgs["?query"].showMCCInternal === "true"){
				this.showMCCInternal = true;
			}
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
			
			//Check if data was already loaded. If yes, use this data
			this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "tableData");
			this.getOwnerComponent().getModel("data").setProperty("/reloadCreEngagements", false);
			this._updateTable();
		},

		_updateTable: function () {
			var aFilters = [];
			var oList = this.getView().byId("listMobile");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = oFilterModel.getProperty("/regionText");

			var oFilterForICP = oFilterModel.getProperty("/oFilterForProjectsOnWatch");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			/* Only apply Region Filter if there is no Country Filter set
			if (typeof sRegion !== "undefined" && sRegion !== "" && !oFilterForICP.aFilters.some(filterGroup => {
				return filterGroup.aFilters.some(subFilter => subFilter.sPath.includes("Country"));
			})) { */

			/*
			if (typeof sRegion !== "undefined" && sRegion !== "") {

				var aRegionHelp = this.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.country;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var eqFilters = regionCountryValues.map(function (country) {
					return new sap.ui.model.Filter("CustomerCountry", sap.ui.model.FilterOperator.EQ, country);
				});

				var regionFilter = new sap.ui.model.Filter({
					filters: eqFilters,
					and: false //OR
				});


				// Combine the regionFilter with filterCondition using AND conjunction
				aFilters.push(regionFilter);

			} */

			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "SWATSTAT01"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "SWATSTAT05"),
                    new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "SWATSTAT06")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "SWAT")
				], false)
			],
				true
			);


			aFilters.push(tileSpecificFilters);
			



			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			oList.setBusy(true);

			oModel.read("/MCCObject", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
		
					oList.setBusy(false);
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "tableData");
				}.bind(this),
				error: function (data) {
					oList.setBusy(false);
				}.bind(this)
			});
		},

		handleProjectsOnWatchState: function (oEv) {
			var oList = this.getView().byId("listMobile");

			// Reset all table filters
			oList.getColumns().forEach(function (oColumn) {
				oColumn.filter(null);
				oColumn.setFilterValue("");
			});
			this.clearSearchField(oList);

			this._updateTable();
		},

		onLiveSearchChange: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("listMobile");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("ObjectID", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("Title", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter("Description", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter3);

			var oFilter4 = new sap.ui.model.Filter("ServiceStatus", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter4);

			var oFilter5 = new sap.ui.model.Filter("StatusText", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter5);

			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		},

		onCase: function (oEv) {
			var sObjectID = oEv.getSource().getBindingContext("tableData").getObject().ObjectID;
			this.getOwnerComponent().getModel("data").setProperty("/reload", true);
			/*this.getRouter().navTo("CriticalEventCoverageDetailsMobile", {
				"?query": this._getQueryParameter(),
				"ObjectID": sObjectID
			});*/
		}
	});
});