sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast"
], function (BaseController, formatter, Filter, FilterOperator, MessageToast) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.ProjectsOnWatchMobile", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				bLoadingState: false,
				// iTabAllPA: 0,
				// iTabGreenPA: 0,
				// iTabYellowPA: 0,
				// iTabRedPA: 0,
				// iTabUnratedPA: 0,
				iTabFiltered: 0,
				bLoadingStatePA: false,
				showObjectType: false
			}), "viewModel");
			//this.getRouter().getRoute("ProjectsOnWatchMobile").attachPatternMatched(this._onObjectMatched, this);
		},

		onAfterRendering: function () {

			if (this.getRouter().getRoute("ProjectsOnWatchMobile")) {
				if (!this._isListInitialized) {
					var oList = this.getView().byId("powListMobile");
					if (oList) {
						this._isListInitialized = true;
						this.getRouter().getRoute("ProjectsOnWatchMobile").attachPatternMatched(this._onObjectMatched, this);
					}
				}
			}

			if (this.getRouter().getRoute("ProjectsOnWatchDetailsMobile")) {
				if (!this._fragmentInitialized) {
					var oList = this.getView().byId("powActionPlanList");
					if (oList) {
						this.getRouter().getRoute("ProjectsOnWatchDetailsMobile").attachPatternMatched(this._onObjectMatchedDetails, this);
					}
				}
			}

		},

		_onObjectMatched: function (oEvent) {
			this.showInternal = false;
			this.showMCCInternal = false;
			var oArgs = oEvent.getParameter("arguments");
			if (oArgs["?query"] && oArgs["?query"].showInternal === "true") {
				this.showInternal = true;
			} else if (oArgs["?query"] && oArgs["?query"].showMCCInternal === "true"){
				this.showMCCInternal = true;
			}
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
			
			//Check if data was already loaded. If yes, use this data
			if (this.getOwnerComponent().getModel("data").getProperty("/reloadProjectsOnWatch")) {
				this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "tableData");
				this.getOwnerComponent().getModel("data").setProperty("/reloadProjectsOnWatch", false);
				this._updateTable();
			}

		},

		_updateTable: function () {
			var aFilters = [];
			var oList = this.getView().byId("powListMobile");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = oFilterModel.getProperty("/regionText");

			var oFilterForICP = oFilterModel.getProperty("/oFilterForProjectsOnWatch");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			/* Only apply Region Filter if there is no Country Filter set
			if (typeof sRegion !== "undefined" && sRegion !== "" && !oFilterForICP.aFilters.some(filterGroup => {
				return filterGroup.aFilters.some(subFilter => subFilter.sPath.includes("Country"));
			})) { */

			if (typeof sRegion !== "undefined" && sRegion !== "") {

				var aRegionHelp = this.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.country;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var eqFilters = regionCountryValues.map(function (country) {
					return new sap.ui.model.Filter("CustomerCountry", sap.ui.model.FilterOperator.EQ, country);
				});

				var regionFilter = new sap.ui.model.Filter({
					filters: eqFilters,
					and: false //OR
				});


				// Combine the regionFilter with filterCondition using AND conjunction
				aFilters.push(regionFilter);

			}

			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "POWSTAT01"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "POWSTAT02")
				], false)
			],
				true
			);


			aFilters.push(tileSpecificFilters);
			aFilters.push(new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "POW"));

			if (this.showInternal === true) {
				aFilters.push(new sap.ui.model.Filter("TriggeredBy", sap.ui.model.FilterOperator.EQ, "INTERNAL"));
			} else if (this.showMCCInternal === true) {
				aFilters.push(new sap.ui.model.Filter("TriggeredBy", sap.ui.model.FilterOperator.EQ, "MCCINTERNAL"));
			} else {
				aFilters.push(new sap.ui.model.Filter("TriggeredBy", sap.ui.model.FilterOperator.EQ, "EXTERNAL"));
			}


			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			oList.setBusy(true);

			oModel.read("/MCCObject", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$expand": "toNotes"
				},
				success: function (data) {
					data.results.forEach(function (item) {
						item.RatingT = formatter.formatRatingToColor(item.Rating);

						if (item.toNotes.results.length > 0) {
							item.bHasNotes = true;
						} else {
							item.bHasNotes = false;
						}
					});
					oList.setBusy(false);
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "tableData");
				}.bind(this),
				error: function (data) {
					oList.setBusy(false);
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this)
			});
		},

		handleProjectsOnWatchState: function (oEv) {
			var oList = this.getView().byId("powListMobile");

			// Reset all table filters
			oList.getColumns().forEach(function (oColumn) {
				oColumn.filter(null);
				oColumn.setFilterValue("");
			});
			this.clearSearchField(oList);

			this._updateTable();
		},

		onLiveSearchChange: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("powListMobile");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("ObjectID", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("Title", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter("Description", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter3);

			var oFilter4 = new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter4);

			var oFilter5 = new sap.ui.model.Filter("CustomerName", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter5);

			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		},

		onCase: function (oEv) {
			var sProjectId = oEv.getSource().getBindingContext("tableData").getObject().ObjectID;
			this.getOwnerComponent().getModel("data").setProperty("/reload", true);
			this.getRouter().navTo("ProjectsOnWatchDetailsMobile", {
				"?query": this._getQueryParameter(),
				"ProjectId": sProjectId
			});
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("tableData").getObject();
			var sLatestStatus = oData.LatestStatusText;
			var sDescription = oData.Description;

			if (!this.statusReportDialog) {
				this.statusReportDialog = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.StatusReportPOW", this);
				this.getView().addDependent(this.statusReportDialog);
			}
			this.statusReportDialog.setModel(new sap.ui.model.json.JSONModel({
				sLatestStatus: sLatestStatus,
				sDescription: sDescription
			}), "data");

			this.statusReportDialog.openBy(oEv.getSource());

			//this.readNotes(oEv.getSource(), sId, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},

		onOpenUser: function (oEv) {
			if (oEv.getSource().data("userid")) {
				this.formatter.openUser(oEv, oEv.getSource().data("userid"));
			}
		},

		onCustomer: function (oEv) {
			if (oEv.getSource().getBindingContext("tableData")) {
				var sCustomerErpNo = oEv.getSource().getBindingContext("tableData").getObject().CustomerID;
			} else {

				var sCustomerErpNo = this.getOwnerComponent().getModel("detailData").getData().CustomerID;
			}
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		// Begin of Details Functions

		_onObjectMatchedDetails: function (oEvent) {
			var sProjectId = oEvent.getParameter("arguments").ProjectId;
			this.projectId = sProjectId;
			this._checkIfPoW(sProjectId);
			this.getView().byId("ObjectPageLayoutPoWMobile").setSelectedSection(this.getView().byId("ObjectPageLayoutPoWMobile").getSections()[0].getId());

		},

		_checkIfPoW: function (sProjectId) {
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			var that = this;
			oModel.read("/MCCObject('" + sProjectId + "')", {
				success: function (data) {
					if (data.Type == "POW") {
						that._updateDetails(sProjectId);
						that._updateWatchItems(sProjectId);
						that._updateLinkedObjects(sProjectId);
					} else {
						MessageToast.show("Cannot find a Project on Watch under the specified ID");
					}
				},
				error: function (data) {
					MessageToast.show("Can't receive API response for this ProjectID ");

				}
			});
		},

		_updateDetails: function (sProjectId) {
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");

			oModel.read("/MCCObject('" + sProjectId + "')", {
				urlParameters: {
					"$expand": "toActionPlan, toAffectedProducts, toNotes"
				},
				success: function (data) {
					data.RatingT = this.formatter.formatRatingToColor(data.Rating);
					if (data.TriggeredBy == "MCCINTERNAL") {
						data.isMCCInternal = true;
					} else {
						data.isMCCInternal = false;
					}
					data.Notes = this.addCharterAndUpdates(data.toNotes.results);
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "detailData");
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this),
				error: function (data) {
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this)
			});
		},
		
		addCharterAndUpdates: function (aNotes) {
			var fixedHeadings = ["As-Is/Problem Statement", "To-Be/Target State/Objectives & expected Business Benefits", "Related Process(es) & targeted Improvements", "In Scope/Out of Scope", "Reason for Overall Rating", "Updates", "Decision Needs"];
			var addedHeadings = {};
			var updatedNotes = [];

			for (var i = 0; i < aNotes.length; i++) {
				var note = aNotes[i];
				// Check if Heading matches the fixedHeadings
				if (fixedHeadings.includes(note.Type) && !addedHeadings[note.Type]) {
					updatedNotes.push({
						Type: note.Type,
						Text: note.Text
					});
					addedHeadings[note.Type] = true;
				}
			}
		
			// Check if all fixed Headings are added
			var remainingHeadings = fixedHeadings.filter(function (heading) {
				return !addedHeadings[heading];
			});
		
			// Add Empty Entries for missing headings
			for (var j = 0; j < remainingHeadings.length; j++) {
				updatedNotes.push({
					Type: remainingHeadings[j],
					Text: ""
				});
			}
		
			// Sort based on fixed Headings
			updatedNotes.sort(function (a, b) {
				return fixedHeadings.indexOf(a.Type) - fixedHeadings.indexOf(b.Type);
			});
		
			return updatedNotes;
		},

		_updateWatchItems: function (sProjectId) {
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			var oFilter = new Filter("Type", FilterOperator.NE, "POWWORK");

			oModel.read("/MCCObject('" + sProjectId + "')/toIssues", {
				/*urlParameters: {
					"$expand": "toAffectedProducts"
				}, */
				filters: [oFilter],
				success: function (data) {
				/*	data.results.forEach(function (issue) {
						if (issue.toAffectedProducts.results.length > 0) {
							issue.affectedProducts = issue.toAffectedProducts.results[0];
							issue.ProductText = issue.toAffectedProducts.results.map(function (product) {
								return product.ProductText;
							}).join('\n');
						}
					}); */

					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "watchItemData");
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this),
				error: function (data) {
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this)
			});
		},

		_updateLinkedObjects: function (sProjectId) {
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			var oFilter = new Filter("TopIssueID", FilterOperator.EQ, sProjectId);
			oModel.read("/LinkedObjects", {
				filters: [oFilter],
				success: function (data) {
					data.results.forEach(function (item) {
						if (item.ObjectType !== "5") {
							item.URL = item.ObjectID;
						}
					});
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "linkedObjects");
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this),
				error: function (data) {
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "linkedObjects");
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this)
			});
		},

		onSectionChange: function (oEv) {
			if (oEv.getParameter("section").getTitle().includes("Action Plan")) {
				//this._updateDetails(this.projectId); Not needed since all data is initially loaded
			}
			if (oEv.getParameter("section").getTitle().includes("Watch Items")) {
				//this._updateWatchItems(this.projectId); Not needed since all data is initially loaded
			}
			if (oEv.getParameter("section").getTitle().includes("Project Details")) {

			}
		},

		onLiveSearchChangeAffectedProducts: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("powAffProdList");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("ProductText", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("ProductID", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		},

		onLiveSearchChangeWatchItems: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("powWatchItemsList");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("Priority", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("ProductText", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter("ResponsibleName", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter3);

			var oFilter4 = new sap.ui.model.Filter("ResponsibleID", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter4);

			var oFilter5 = new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter5);

			var oFilter6 = new sap.ui.model.Filter("Title", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter6);

			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		},

		onLiveSearchChangeActionPlan: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("powActionPlanList");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("ActionTitle", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("ResponsibleOrg", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter("ResponsibleUserName", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter3);

			var oFilter4 = new sap.ui.model.Filter("ResponsibleUser", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter4);

			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		},

		onLiveSearchChangeLinkedObjects: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("powLinkedObjectsList");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("ObjectTypeValue", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("Description", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		},



		handleURLPress: function (oEv) {
			if (oEv.getSource().getBindingContext("linkedObjects")) {
				var oBindingContext = oEv.getSource().getBindingContext("linkedObjects");
				var sObjectType = oBindingContext.getObject().ObjectType;
				var sUrl = oBindingContext.getObject().URL;
				var sObjectID = oBindingContext.getObject().ObjectID;
				var currentUrl = window.location.href;

				switch (sObjectType) {
					case "5": // Others
						if (!sUrl.startsWith("http")) {
							sUrl = "https://" + oBindingContext.getObject().URL + "/"
						}
						this._openWindow(sUrl);
						break;
					case "4": // ServiceNow ID
						if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") || currentUrl.includes("applicationstudio")) {
							//we are in dev envrionment
							sUrl = "https://bcdmain.wdf.sap.corp/sap/support/message/" + sObjectID;
							this._openWindow(sUrl);
						} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
							//we are in test envrionment
							sUrl = "https://qa-support.wdf.sap.corp/sap/support/message/" + sObjectID;
							this._openWindow(sUrl);
						} else {
							sUrl = "https://support.wdf.sap.corp/sap/support/message/" + sObjectID;
							this._openWindow(sUrl);
						}
						break;

					case "13": // Escalation Record ID
					case "12": // ServiceNow Incident ID
						if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") || currentUrl.includes("applicationstudio")) {
							//we are in dev envrionment
							sUrl = "https://dev.itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + sObjectID;
							this._openWindow(sUrl);
						} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
							//we are in test envrionment
							sUrl = "https://test.itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + sObjectID;
							this._openWindow(sUrl);
						} else {
							sUrl = "https://itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + sObjectID;
							this._openWindow(sUrl);
						}
						break;

					case "1": // ICP Case
						this.getOwnerComponent().getModel("case").setProperty("/reload", true);
						this.getRouter().navTo("CaseDetailsMobile", {
							"?query": this._getQueryParameter(),
							"CaseId": sUrl
						});
						break;
					default:
						if (sUrl !== "") {
							this.getOwnerComponent().getModel("case").setProperty("/reload", true);
							this.getRouter().navTo("CaseDetailsMobile", {
								"?query": this._getQueryParameter(),
								"CaseId": sUrl
							});
						}
						break;
				}
			}
		},




	});
});