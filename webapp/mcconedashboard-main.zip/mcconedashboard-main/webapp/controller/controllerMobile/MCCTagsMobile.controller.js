sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/model/Constants"
], function (BaseController, formatter, Constants) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.controllerMobile.MCCTagsMobile", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				iTabFiltered: 0,
				bLoadingState: false,
				title: "",
				showObjectType: true
			}), "viewModel");

			this._oGlobalFilter = null;
			this._oPriceFilter = null;
			this._tblRendered = false;
			this.getRouter().getRoute("MCCTagsMobile").attachPatternMatched(this._onObjectMatched, this);
			this.getRouter().getRoute("TagMobile").attachPatternMatched(this._onObjectMatched, this);

		},

		onAfterRendering: function () { },

		_onObjectMatched: function (oEvent) {
			//Check if data was already loaded. If yes, use this data
			var sKey = oEvent.getParameter("arguments").Description;
			this.getView().getModel("viewModel").setProperty("/intent", oEvent.getParameter("name")); //either TAG or Task Forces; in case of Tags the filters or HANA odata call are reduced to only name
			this.getView().getModel("viewModel").setProperty("/title", sKey);
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "tableData");

			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);

			if (!this.getOwnerComponent().getModel("data").getProperty("/serviceTeams")) {
				this.getOwnerComponent().getModel("data").setProperty("/serviceTeams", []);
			}
			//in case of intent "Tag", we need to overwrite the initially set /tagName 
			if (this.getView().getModel("viewModel").getProperty("/intent") === "Tag") {
				this.getOwnerComponent().getModel("data").setProperty("/tagName", "");
				this.getOwnerComponent().getModel("data").setProperty("/serviceTeams", []);
				this.getOwnerComponent().getModel("data").setProperty("/serviceTeamsDescr", "");
			} else if (this.getView().getModel("viewModel").getProperty("/intent") === "TaskForces" && sKey !== this.getOwnerComponent().getModel(
				"data").getProperty("/tagName")) { // in case end user refreshes the page or enters a different value for the intent
				this.getOwnerComponent().getModel("data").setProperty("/tagName", "");
				this.getOwnerComponent().getModel("data").setProperty("/serviceTeams", []);
				this.getOwnerComponent().getModel("data").setProperty("/serviceTeamsDescr", "");
			}
			var sTagName = this.getOwnerComponent().getModel("data").getProperty("/tagName");

			if (this.getOwnerComponent().getModel("data").getProperty("/serviceTeams") && this.getOwnerComponent().getModel("data").getProperty(
				"/serviceTeams").length > 0) {
				this._updateTable(this.getOwnerComponent().getModel("data").getProperty("/serviceTeams"), this.getOwnerComponent().getModel("data")
					.getProperty(
						"/serviceTeamsDescr"));
				this.getView().getModel("viewModel").setProperty("/title", this.getOwnerComponent().getModel("data").getProperty(
					"/serviceTeamsDescr"));
			} else if (sTagName !== "") {
				this._updateTable(this.getOwnerComponent().getModel("data").getProperty("/serviceTeams"), this.getOwnerComponent().getModel("data")
					.getProperty(
						"/serviceTeamsDescr"));
				this.getView().getModel("viewModel").setProperty("/title", this.getOwnerComponent().getModel("data").getProperty(
					"/serviceTeamsDescr"));
			} else {
				//check if servie teams or tag is available --> in case of direct call of URL intent
				var aPromises = [];
				aPromises.push(this._loadServiceTeams(sKey));
				aPromises.push(this._loadTags(sKey));
				Promise.all(aPromises).then(function (aResults) {
					var aServiceTeams = this.getOwnerComponent().getModel("data").getProperty("/serviceTeams");
					var sDescription = this.getOwnerComponent().getModel("data").getProperty("/serviceTeamsDescr");

					if (aResults[0] > 0 || aResults[1] > 0) {
						this._updateTable(aServiceTeams, sDescription);
					} else {
						//show error
					}
				}.bind(this));
			}
		},

		_loadTags: function (sKey) {
			return new Promise(function (resolve) {
				var oSubModel = this.getOwnerComponent().getModel("subModel");
				var dToday = new Date();
				var aFilters = [];
				//only with intent "TaskForces" the following filters should be applied
				if (this.getView().getModel("viewModel").getProperty("/intent") !== "Tag") {
					aFilters.push(new sap.ui.model.Filter("ShowInOneDashboard", sap.ui.model.FilterOperator.EQ, true));

					aFilters.push(new sap.ui.model.Filter([
						new sap.ui.model.Filter("DateFrom", sap.ui.model.FilterOperator.LE, dToday),
						new sap.ui.model.Filter("DateTo", sap.ui.model.FilterOperator.GE, dToday),
						new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "MCC")
					], true));
				}

				aFilters.push(new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.EQ, sKey));

				oSubModel.read("/MCCTags", {
					filters: aFilters,
					success: function (data) {

						if (data.results.length === 1) {
							this.getOwnerComponent().getModel("data").setProperty("/tagName", sKey);
							this.getView().getModel("viewModel").setProperty("/title", data.results[0].Title);
						}

						resolve(data.results.length);
					}.bind(this)
				});
			}.bind(this));

		},

		_loadServiceTeams: function (sKey) {
			return new Promise(function (resolve) {
				var oAppDepModel = this.getOwnerComponent().getModel("appDepModelNoBatch");
				oAppDepModel.read("/BusinessUnitSet('" + sKey + "')", {
					urlParameters: {
						"$expand": "toServiceTeam"
					},
					success: function (data) {
						if (data.toServiceTeam.results.length > 0) {
							var sDescription = this.getTaskForcesDescription(data.Description);
							this.getView().getModel("viewModel").setProperty("/title", sDescription);
						}

						var aServiceTeams = [];
						data.toServiceTeam.results.forEach(function (serviceTeam) {
							aServiceTeams.push(this.pad(
								serviceTeam.Key,
								10));
						}.bind(this));
						this.getOwnerComponent().getModel("data").setProperty("/serviceTeams", aServiceTeams);
						this.getOwnerComponent().getModel("data").setProperty("/serviceTeamsDescr", sDescription);
						resolve(data.toServiceTeam.results.length);
					}.bind(this)
				});
			}.bind(this));
		},

		_updateTable: function (serviceTeams, sDescription) {
			var aPromises = [];
			var oFilterModel = this.getModel("filterModel");
			var oICModel = this.getModel();
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var oFacetFilterFilters = oFilterModel.getProperty("/oFilterModelICP");
			var oSettings = this.getOwnerComponent().getModel("settings").getData();
			var bCaseFilter = this.getOwnerComponent().getModel("data").getProperty("/taskForcesFilter");
			var sTagName = this.getOwnerComponent().getModel("data").getProperty("/tagName");

			var aServiceTeamFilter = [];
			serviceTeams.forEach(function (serviceTeam) {
				aServiceTeamFilter.push(new sap.ui.model.Filter("ServiceTeam", sap.ui.model.FilterOperator.EQ, this.pad(
					serviceTeam,
					10)));
			}.bind(this));
			var oServiceTeamFilter = new sap.ui.model.Filter(aServiceTeamFilter, false);

			var oCriticalSituationsPromise = new Promise(function (resolve) {
				var aFiltersCriticalSituations = [];

				var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
				if (!bCaseState) {
					bCaseState = "open";
				}
				if (bCaseState === "open" || bCaseState === "all") {
					var aTileFilterSpec1 = [
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false)
					];

					if (sTagName === "") {
						aTileFilterSpec1.push(oServiceTeamFilter);
					}

					var tileSpecificFilters1 = new sap.ui.model.Filter(aTileFilterSpec1,
						true
					);
				}
				if (bCaseState === "closed" || bCaseState === "all") {
					var aTileFilterSpec2 = [
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90")
						], false),
						this.getClosedDateFilter("ClosingDate")
					];

					if (sTagName === "") {
						aTileFilterSpec2.push(oServiceTeamFilter);
					}

					var tileSpecificFilters2 = new sap.ui.model.Filter(aTileFilterSpec2,
						true
					);

				}

				if (bCaseState === "open") {
					aFiltersCriticalSituations.push(tileSpecificFilters1);
				} else if (bCaseState === "closed") {
					aFiltersCriticalSituations.push(tileSpecificFilters2);
				} else if (bCaseState === "all") {
					aFiltersCriticalSituations.push(new sap.ui.model.Filter([
						tileSpecificFilters1,
						tileSpecificFilters2
					],
						false
					));
				}

				if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
					aFiltersCriticalSituations.push(oFacetFilterFilters);
				}

				if (sRegion) {
					var aRegionFilter = [];
					sRegion.split(",").forEach(function (region) {
						aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
					});
					aFiltersCriticalSituations.push(new sap.ui.model.Filter(aRegionFilter, false));
				}

				aFiltersCriticalSituations.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

				if (sTagName !== "") {
					aFiltersCriticalSituations.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, sTagName));
				}

				var sEntity = sTagName === "" ? "/CriticalSituationsSet" : "/CustomerEngagementSet";

				oICModel.read(sEntity, {
					urlParameters: {
						"$top": "9999"
					},
					filters: [new sap.ui.model.Filter(aFiltersCriticalSituations, true)],
					success: function (data) {
						//sort client at side
						data = this._sortByRanking(data);
						data.results.forEach(function (value) {
							value.EntitySet = "CriticalSituationsSet";
							value.objectType = sDescription;
							switch (value.CustomerType) {
								case "ZSCUSTYP05":
									value.objectType = "Critical Customer Management";
									break;
								case "ZSCUSTYP04":
									value.objectType = "Critical Period Coverage";
									break;
								case "ZSCUSTYP07":
									value.objectType = "Task Force";
									break;
								case "ZSCUSTYP06":
									value.objectType = "Top Critical Customer";
									break;
							}
							if (value.DbsMaintenanceRanking === "0") {
								value.DbsMaintenanceRanking = "";
							}

						});
						resolve(data);
					}.bind(this),
					error: function (data) {
						this.getModel("data").setProperty("/TopCriticalCustomersBusy", false);
					}.bind(this)
				});
			}.bind(this));
			aPromises.push(oCriticalSituationsPromise);
			if (oSettings.ShowGlobalAggregation || oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations) {
				//in case of anonymized mode, no GEM should be retunrned
				if (oSettings.isAnonymizedMode === false) {
					var oGlobalEscalationsPromise = new Promise(function (resolve) {
						var aFiltersGlobalEscalations = [];
						if (sRegion) {
							var aRegionFilter = [];
							sRegion.split(",").forEach(function (region) {
								aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
							});
							aFiltersGlobalEscalations.push(new sap.ui.model.Filter(aRegionFilter, false));
						}

						//all ongoing Critical MCC Customer Sit
						//User Status: New, In Process, In Escalation, In Management Review
						var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
						if (!bCaseState) {
							bCaseState = "open";
						}
						if (bCaseState === "open" || bCaseState === "all") {

							var aTileSpecFilter1 = [
								new sap.ui.model.Filter([
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20"),
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30")
								], false)
							];

							if (sTagName === "") {
								aTileSpecFilter1.push(oServiceTeamFilter);
							}

							var tileSpecificFilters1 = new sap.ui.model.Filter(aTileSpecFilter1,
								true
							);
						}
						if (bCaseState === "closed" || bCaseState === "all") {
							var aTileSpecFilter2 = [
								new sap.ui.model.Filter([
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "40")
								], false),
								this.getClosedDateFilter("ClosingDate")
							];
							var tileSpecificFilters2 = new sap.ui.model.Filter(aTileSpecFilter2,
								true
							);

							if (sTagName === "") {
								aTileSpecFilter2.push(oServiceTeamFilter);
							}

						}

						if (bCaseState === "open") {
							aFiltersGlobalEscalations.push(tileSpecificFilters1);
						} else if (bCaseState === "closed") {
							aFiltersGlobalEscalations.push(tileSpecificFilters2);
						} else if (bCaseState === "all") {
							aFiltersGlobalEscalations.push(new sap.ui.model.Filter([
								tileSpecificFilters1,
								tileSpecificFilters2
							],
								false
							));
						}

						if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
							aFiltersGlobalEscalations.push(oFacetFilterFilters);
						}

						if (sTagName !== "") {
							aFiltersGlobalEscalations.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, sTagName));
						}

						//CriticalSituations Promise	
						oICModel.read("/GlobalEscalationsSet", {
							urlParameters: {
								"$top": "9999"
							},
							filters: [new sap.ui.model.Filter(aFiltersGlobalEscalations, true)],
							success: function (data) {
								//sort client at side
								data = this._sortByRanking(data);
								data.results.forEach(function (value) {
									value.EntitySet = "GlobalEscalationsSet";
									value.objectType = "Global Escalation";
									if (value.DbsMaintenanceRanking === "0") {
										value.DbsMaintenanceRanking = "";
									}

									//in case the user has only AGGR AUTH we need to assure, that the action-Icon for showing the notes, is not visible in the UI
									//RD05.22 this is not valid anymore, because the HasNotes is now covered by AUTH checks in the Backend
									// if (oSettings.ShowGlobalAggregation) {
									// 	if (!oSettings.ShowGlobalEscalations && !oSettings.ShowRegionalGlobalEscalations) {
									// 		value.HasNotes = "";
									// 	}
									// }

								});
								resolve(data);
							}.bind(this),
							error: function () {
								this.getModel("data").setProperty("/TopCriticalCustomersBusy", false);
							}
						});
					}.bind(this));
					aPromises.push(oGlobalEscalationsPromise);
				}
			}

			var oCCMCPCPromise = new Promise(function (resolve, reject) {
				var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
				if (!bCaseState) {
					bCaseState = "open";
				}


				//read Entries in Service Now for the given Tag in the URL
				var escalationIDsString;

				//This Filter is only used for DEV since the Global Variable is not working as intended yet
				//var sFilterString = "sysparm_query=id_type=Escalation%5elabel.name=" + sTagName + "&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";

				//Use this one for TEST + PROD
				var sFilterString = "sysparm_query=id_type=Escalation%5elabel.global=true%5elabel.name=" + sTagName + "&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";

				var oServiceNowTagPromise = new Promise(function (resolve, reject) {
					$.ajax({
						method: "GET",
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						contentType: "application/json",
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
						success: function (data) {

							if (data.result.length > 0) {
								var escalationIDs = data.result.map(function (obj) {
									return obj.id_display;
								});

								// Filter out empty or null values
								var validEscalationIDs = escalationIDs.filter(function (id) {
									return id !== null && id !== '';
								});

								// Combine all valid Escalation IDs into a string for the filter
								escalationIDsString = validEscalationIDs.join(',');
								resolve(escalationIDsString);
							} else {
								resolve(escalationIDsString);
							}
						}.bind(this),
						error: function (err) {
							resolve();
						}.bind(this)
					});
				}.bind(this));

				oServiceNowTagPromise.then(function (escalationIDsString) {
					if (escalationIDsString) {
						var oFilterModel = this.getModel("filterModel");
						oFilterModel.refresh(true);
						var sRegion = this.getRegionFilterModel();
						var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");
						var sFilterString;

						if (bCaseState === "open") {
							sFilterString = "sysparm_query=ORDERBYu_task_record.priority%5estate=101^ORstate=100^numberIN" + escalationIDsString;
						} else if (bCaseState === "closed") {
							sFilterString = "sysparm_query=ORDERBYu_task_record.priority%5estate=103^numberIN" + escalationIDsString;
						} else if (bCaseState === "all") {
							sFilterString = "sysparm_query=ORDERBYu_task_record.priority%5estate=103^ORstate=101^ORstate=100^numberIN" + escalationIDsString;
						}


						if (typeof sRegion !== "undefined" && sRegion !== "") {

							var aRegionHelp = this.getModel("countryRegionModel").getData();
							var selectedRegions = sRegion.split(","); // Split the selected regions into an array

							// Create an object to map selected regions to filterBasis (given in countryRegionModel)
							var regionFilterBasisMap = {
								"EMEA North": "subsubregion",
								"EMEA South": "subsubregion",
								"NA": "region",
								"APJ": "region",
								"MEE": "subregion",
								"GTC": "subregion",
								"LAC": "subregion"
							};

							var regionCountryValues = [];

							// Iterate through selectedRegions and create filters based on filterBasis
							selectedRegions.forEach(function (region) {
								var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

								// Filter regionCountries based on the chosen filter basis
								var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
									return item[filterBasis] === region;
								});

								// Add regionCountryValues for the current region to the array
								regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
									return regionCountry.countryCode;
								}));
							});

							// Extend sFilterString based on regionCountryValues
							if (regionCountryValues.length > 0) {
								var regionFilters = regionCountryValues.map(function (country) {
									return "u_customer_3.country=" + encodeURIComponent(country);
								}).join("%5eOR");

								// Append the new regionFilters to the existing sFilterString
								sFilterString += "^" + regionFilters;
							}

						}

						if (aFilter && aFilter.length > 0) {
							aFilter.forEach(function (filter) {
								sFilterString += "^" + filter;
							});
						}

						sFilterString = sFilterString.replaceAll("^", "%5e");
						//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
						if (sFilterString.startsWith("%5esysparm_query")) {
							sFilterString.replace("%5esysparm_query", "sysparm_query");
						}
						sFilterString += Constants.fieldsForCPCTable;

						$.ajax({
							method: "GET",
							contentType: "application/json",
							headers: {
								"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
							},
							url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/sn_customerservice_escalation?" + sFilterString,
							success: function (oData) {
								oData.result.forEach(function (item) {
									//Adjustments for CPC View
									item["state"] = this.formatter.getCimEscalationStatus(item["state"], this);
									item["objectType"] = this.formatter.formatLinkedServiceNowObjectType(item["u_escalation_type"], item["state"], item["u_request_reason"]);
									item["CaseTitle"] = item["short_description"];
									item["EscalationID"] = item["number"];
									item["CountryT"] = this.formatter.getCountryName(item["u_customer_3.country"], this);
									item["RegionT"] = this.getRegionByCountryOrCountryCode(item["u_customer_3.country"], this);
									item["CaseTag"] = sTagName; //Do we need other Tags too?
									item["Responsible"] = item["assigned_to.first_name"] + " " + item["assigned_to.last_name"];
									item["ResponsibleId"] = item["assigned_to.employee_number"];
									item["Rating"] = this.formatter.adaptSNRatingToGeneralRating(item["u_rating"]);
									item["AssignmentGroup"] = item["assignment_group.name"];
									item["CreateDate"] = item["sys_created_on"];
									item["ChangeDate"] = item["sys_updated_on"];
									item["GoLiveDateSNOW"] = item["u_go_live_date"];
									item["PriorityT"] = this.formatter.getCimPriority(item["u_task_record.priority"], this);
									item["priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"], this);
									item["u_request_reason"] = this.formatter.formatSNOWRequestReason(item["u_request_reason"], this);
									item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"], this);
									item["approval_set_formatted"] = this.formatter.getDaysHoursMinSince(item["approval_set"], this);
									item["StatusT"] = item["state"];
									item["CustomerText"] = item["u_customer_3.name"];
									item["CustomerErpNo"] = item["u_customer_3.number"];
									item["CustomerBpNo"] = item["u_customer_3.u_sap_crm_bp_number"];
								}.bind(this));
								this._addHANADataToSNOWData(oData)
									.then(function (updatedData) {
										loadAllMCCTags(updatedData);
									})
									.catch(function (error) {
										loadAllMCCTags(oData);
									});


								function loadAllMCCTags(data) {
									//read Service NOW Tags; get tags, which have been created in the last half year (maybe this needs to be changed later?)
									var dateOffset = (24 * 60 * 60 * 1000) * Constants.serviceNowTagsCreatedSinceDays;
									var dateInPast = new Date();
									dateInPast.setTime(dateInPast.getTime() - dateOffset);
									var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
										pattern: "yyyy-MM-dd" // we need a format like 2022-12-24
									});
									dateInPast = oFormat.format(dateInPast);
									var sFilterString = "sysparm_query=id_type=Escalation%5esys_created_on%3Ejavascript:gs.dateGenerate(%27" + dateInPast +
										"%27,%2700:00:00%27)%5elabel.global=true%5elabel.nameSTARTSWITHMCC&sysparm_fields=id_type,label.sys_id,label.name,sys_created_on,label.sys_created_on,id_display,label.global";

									$.ajax({
										method: "GET",
										headers: {
											"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
										},
										contentType: "application/json",
										url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
										success: function (oData) {
											data.result.forEach(function (item) {
												var oTagElement = oData.result.filter(function (val) {
													return val["id_display"] === item.number; //"ESC0140066"; //
												});
												if (oTagElement) {
													item.CaseTag = "";
													oTagElement.forEach(function (tagElementItem, index) {
														item.CaseTag += tagElementItem['label.name'];
														if (oTagElement.length > (index + 1)) {
															item.CaseTag += ", ";
														}
													});
												}
											}.bind(this));
											resolve(data);
										}.bind(this),
										error: function (err) {
											resolve(data);
										}.bind(this)
									});
								}
							}.bind(this),
							error: function (err) {
								reject(oData);
							}.bind(this)
						});

					} else {
						resolve();
					}
				}.bind(this));
			}.bind(this));
			aPromises.push(oCCMCPCPromise);

			Promise.all(aPromises).then(function (aResults) {
				var aData = {
					results: []
				};
				aResults.forEach(function (val) {
					if (val && (val.results || val.result)) {
						(val.results || val.result).forEach(function (res) {
							aData.results.push(res);
						});
					}
				});

				this._calculateRating(aData);
				aData.results.forEach(function (oCase) {
					if (oCase.Rating === "") {
						oCase.Rating = "unrated";
					}
				}.bind(this));

				var oModel = new sap.ui.model.json.JSONModel(aData);
				this.getOwnerComponent().setModel(oModel, "tableData");
				this.loadProductsCriticalSituation(oServiceTeamFilter);
				if (oSettings.ShowGlobalAggregation || oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations) {
					//in case of anonymized mode, no GEM should be retunrned
					if (oSettings.isAnonymizedMode === false) {
						this.loadProductsGlobalEscalation(oServiceTeamFilter);
					}
				}
				this.readImplementationPartner(oModel).then(function () {
					var oTable = this.getView().byId("TPCListId");
					setTimeout(function () {
						oTable.rerender();
					}, 200);
				}.bind(this));
				//MISSIONRADAR 2211	
				this.readMissionRadarValues(oModel, "results");
			}.bind(this));
		},

		_addHANADataToSNOWData: function (aSNOWData) {
			var aFilters = [];
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "open";
			}
			var oFilterForICP = oFilterModel.getProperty("/oFilterForCriticalPeriodCoverage");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			//Show only for ExpectedAction and Type
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "EXEC")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "AccER")
				], false)
			],
				false
			);
			aFilters.push(tileSpecificFilters);

			// EscalationID Filters (OR)
			if (aSNOWData && aSNOWData.result && Array.isArray(aSNOWData.result)) {
				var aEscalationIDFilters = aSNOWData.result.map(function (item) {
					return new sap.ui.model.Filter("EscalationID", sap.ui.model.FilterOperator.EQ, item.EscalationID);
				});

				if (aEscalationIDFilters.length > 0) {
					var oEscalationIDFilter = new sap.ui.model.Filter({
						filters: aEscalationIDFilters,
						and: false
					});
					aFilters.push(oEscalationIDFilter);
				}
			}

			var oModel = this.getOwnerComponent().getModel("subModel");

			return new Promise(function (resolve, reject) {
				oModel.read("/MCCObject", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					urlParameters: {
						// "$select": "ExpectedAction, GoLiveDate, StartDate, EndDate, EscalationID, ProductLineID, ProductLineName, Type, ExpectedAction"
					},
					success: function (data) {
						if (data?.results?.length) {
							data.results.forEach(resultItem => {
								const matchingSNOWData = aSNOWData.result.find(snowItem => snowItem.EscalationID === resultItem.EscalationID);

								if (matchingSNOWData) {
									const isCPCRequest = matchingSNOWData.objectType === "CPC Requests";
									const isValidCPCRequest = isCPCRequest && resultItem.ExpectedAction === "accept_engagement";

									if (!isCPCRequest || isValidCPCRequest) {
										Object.assign(matchingSNOWData, {
											ExpectedAction: resultItem.ExpectedAction,
											GoLiveDate: resultItem.GoLiveDate,
											StartDate: resultItem.StartDate,
											PlanEndDate: resultItem.EndDate,
											ProductID: resultItem.ProductID,
											Product: resultItem.ProductText,
											ProductLineID: resultItem.ProductLineID,
											ProductLine: resultItem.ProductLineName,
											Type: resultItem.Type
										});
									}
								}
							});
						}

						// Resolve the Promise with the updated aSNOWData
						resolve(aSNOWData);

					}.bind(this),
					error: function (error) {
						// Reject the Promise in case of an error
						reject(error);
					}.bind(this)
				});
			});

		},

		loadProductsGlobalEscalation: function (oServiceTeamFilter) {
			var aFilters = [];
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var sTagName = this.getOwnerComponent().getModel("data").getProperty("/tagName");

			var oFacetFilterFilters = oFilterModel.getProperty("/oFilterModelICP");

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var aTileSpecFilter = [
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30")
				], false)
			];
			if (sTagName === "") {
				aTileSpecFilter.push(oServiceTeamFilter);
			}

			var tileSpecificFilters = new sap.ui.model.Filter(aTileSpecFilter,
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			if (sTagName !== "") {
				aFilters.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, sTagName));
			}

			var oICModel = this.getModel();
			oICModel.read("/GlobalEscalationsSet", {
				urlParameters: {
					"$top": "9999",
					"$expand": "toProducts",
					"$select": "CaseId,toProducts"
				},
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					var oModel = this.getOwnerComponent().getModel("tableData");
					var aAlreadyAdded = oModel.getData().results;
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					data.results.forEach(function (oCase) {
						oCase.ProductVersions = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.Product = this.formatter.concatProducts(oCase.toProducts.results, "ProductT");
						oCase.ProductCategory = this.formatter.concatProducts(oCase.toProducts.results, "ProductCatT");
						oCase.ProductLine = this.formatter.concatProducts(oCase.toProducts.results, "ProductLineT");
						oCase.ProductVer = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.ProductLineKeys = this.formatter.concatProducts(oCase.toProducts.results, "ProductLine");
						oCase.ProductKeys = this.formatter.concatProducts(oCase.toProducts.results, "Product");

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.CaseId === oCase.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = oCase.toProducts;
								aTmp[i].toLastNotes = oCase.toLastNotes;
								aTmp[i].ProductVersions = oCase.ProductVersions;
								aTmp[i].Product = oCase.Product;
								aTmp[i].ProductCategory = oCase.ProductCategory;
								aTmp[i].ProductLine = oCase.ProductLine;
								aTmp[i].ProductVer = oCase.ProductVer;
								aTmp[i].ProductLineKeys = oCase.ProductLineKeys;
								aTmp[i].ProductKeys = oCase.ProductKeys;
							});
						}
					}.bind(this));
					oModel.refresh();
				}.bind(this),
				error: function (data) {
					this.getModel("data").setProperty("/TopCriticalCustomersBusy", false);
				}.bind(this)
			});
		},

		loadProductsCriticalSituation: function (oServiceTeamFilter) {
			var aFilters = [];
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var sTagName = this.getOwnerComponent().getModel("data").getProperty("/tagName");

			var oFacetFilterFilters = oFilterModel.getProperty("/oFilterModelICP");

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var aTileSpecFilter = [
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
				], false)
			];

			if (sTagName === "") {
				aTileSpecFilter.push(oServiceTeamFilter);
			}

			var tileSpecificFilters = new sap.ui.model.Filter(aTileSpecFilter,
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			if (sTagName !== "") {
				aFilters.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, sTagName));
			}

			var sEntity = sTagName === "" ? "/CriticalSituationsSet" : "/CustomerEngagementSet";

			var oICModel = this.getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			oICModel.read(sEntity, {
				urlParameters: {
					"$top": "9999",
					"$expand": "toProducts",
					"$select": "CaseId,toProducts"
				},
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					var oModel = this.getOwnerComponent().getModel("tableData");
					var aAlreadyAdded = oModel.getData().results;
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					data.results.forEach(function (oCase) {
						oCase.ProductVersions = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.Product = this.formatter.concatProducts(oCase.toProducts.results, "ProductT");
						oCase.ProductCategory = this.formatter.concatProducts(oCase.toProducts.results, "ProductCatT");
						oCase.ProductLine = this.formatter.concatProducts(oCase.toProducts.results, "ProductLineT");
						oCase.ProductVer = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.ProductLineKeys = this.formatter.concatProducts(oCase.toProducts.results, "ProductLine");
						oCase.ProductKeys = this.formatter.concatProducts(oCase.toProducts.results, "Product");

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.CaseId === oCase.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = oCase.toProducts;
								aTmp[i].toLastNotes = oCase.toLastNotes;
								aTmp[i].ProductVersions = oCase.ProductVersions;
								aTmp[i].Product = oCase.Product;
								aTmp[i].ProductCategory = oCase.ProductCategory;
								aTmp[i].ProductLine = oCase.ProductLine;
								aTmp[i].ProductVer = oCase.ProductVer;
								aTmp[i].ProductLineKeys = oCase.ProductLineKeys;
								aTmp[i].ProductKeys = oCase.ProductKeys;
							});
						}
					}.bind(this));
					oModel.refresh();
				}.bind(this),
				error: function (data) {
					this.getModel("data").setProperty("/TopCriticalCustomersBusy", false);
				}.bind(this)
			});
		},

		readNotes: function (oControl, id, entitySet, sObjectType) {
			var oICModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			var sEntity = entitySet || "CriticalSituationsSet";
			oICModel.read("/" + sEntity + "('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results, sObjectType);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		_calculateRating: function (data) {
			var oViewModel = this.getView().getModel("viewModel");
			var iGreen = 0;
			var iYellow = 0;
			var iRed = 0;
			var iUnrated = 0;
			data.results.forEach(function (oCase) {
				switch (oCase.Rating) {
					case "A":
						iGreen++;
						break;
					case "B":
						iYellow++;
						break;
					case "C":
						iRed++;
						break;
					default:
						iUnrated++;
				}
			});
			oViewModel.setProperty("/iTabAll", data.results.length);
			oViewModel.setProperty("/iTabGreen", iGreen);
			oViewModel.setProperty("/iTabYellow", iYellow);
			oViewModel.setProperty("/iTabRed", iRed);
			oViewModel.setProperty("/iTabUnrated", iUnrated);
		},

		onCustomer: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("tableData").getObject().CustomerErpNo;
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		onCase: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("tableData").getObject().CaseId;
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);
			this.getRouter().navTo("CaseDetailsMobile", {
				"?query": this._getQueryParameter(),
				"CaseId": sCaseId
			});
		},

		onCaseNewTab: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("tableData").getObject().CaseId;
			this._openCaseInNewTab(sCaseId);
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("tableData").getObject();
			var sObjectType = "";
			if (oData.CustomerType != "") {
				sObjectType = oData.CustomerType;
			}
			var sId = oData.CaseId;
			var sEntitySet = oData.EntitySet;
			this.readNotes(oEv.getSource(), sId, sEntitySet, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},

		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("tableData").getPath();
			var oProperty = this.getModel("tableData").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("tableData").getObject();
			var sCaseId = oProperty.CaseId;
			this._shopTopIssuesCountPopover(sCaseId, oEv.getSource());
		},

		changeCaseState: function () {
			var sKey = this.getView().getModel("viewModel").getProperty("/title");
			var sTagName = this.getOwnerComponent().getModel("data").getProperty("/tagName");
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);

			if (this.getOwnerComponent().getModel("data").getProperty("/serviceTeams")) {
				this._updateTable(this.getOwnerComponent().getModel("data").getProperty("/serviceTeams"), this.getOwnerComponent().getModel("data")
					.getProperty(
						"/serviceTeamsDescr"));
				this.getView().getModel("viewModel").setProperty("/title", this.getOwnerComponent().getModel("data").getProperty(
					"/serviceTeamsDescr"));

			} else if (sTagName !== "") {
				this._updateTable(this.getOwnerComponent().getModel("data").getProperty("/serviceTeams"), this.getOwnerComponent().getModel("data")
					.getProperty(
						"/serviceTeamsDescr"));
				this.getView().getModel("viewModel").setProperty("/title", this.getOwnerComponent().getModel("data").getProperty(
					"/serviceTeamsDescr"));
			} else {
				//check if servie teams or tag is available
				var aPromises = [];

				aPromises.push(this._loadServiceTeams(sKey));
				aPromises.push(this._loadTags(sKey));
				Promise.all(aPromises).then(function (aResults) {
					var aServiceTeams = this.getOwnerComponent().getModel("data").getProperty("/serviceTeams");
					var sDescription = this.getOwnerComponent().getModel("data").getProperty("/serviceTeamsDescr");

					if (aResults[0] > 0 || aResults[1] > 0) {
						this._updateTable(aServiceTeams, sDescription);
					}

				}.bind(this));
			}
		},

		onObjectTypePress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("tableData").getObject().objectType;
			var sMsg = this._getObjectTypeInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		},
		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("tableData").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		},

		onLiveSearchChange: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("TPCListId");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("CustomerText", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("CountryT", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter("RegionT", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter3);

			var oFilter4 = new sap.ui.model.Filter("CaseTitle", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter4);

			var oFilter5 = new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter5);

			var oRatingFilter;
			if (searchValue === "red") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C");
			} else if (searchValue === "yellow" || searchValue === "orange") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "B");
			} else if (searchValue === "green") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "A");
			} else {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.Contains, searchValue);
			}
			aFilters.push(oRatingFilter);

			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		}
	});
});