sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/model/Constants",
	"sap/m/Popover",
	"sap/ui/core/Fragment"
], function (BaseController, formatter, Constants, Popover, Fragment) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.controllerMobile.OutagesMobile", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				bLoadingState: false
			}), "viewModel");

			this.getRouter().getRoute("OutagesMobile").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function (oEvent) {
			//Check if data was already loaded. If yes, use this data
			if (!this.getOwnerComponent().getModel("data") || (this.getOwnerComponent().getModel("data").getData() && this.getOwnerComponent().getModel(
					"data").getData().reloadOutages)) {

				var oOutagesModel = this.getOwnerComponent().getModel("outageMainModel");
				oOutagesModel.metadataLoaded(true).then(
					function () {
						this._updateTable(oOutagesModel);
					}.bind(this)
				);
			}
			this.onNavToOutagesList();

			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
		},

		_updateTable: function (oOutagesModel) {
			var aFilters = [];
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bState = this.getOwnerComponent().getModel("data").getProperty("/outagesState");
			var oUrlParameters = {
				"$select": "MasterEventID,CecEventID,CecEventStartDateTime,CecEventEndDateTime,MasterEventCustomerCount,MasterEventLobCount,MasterEventServiceStatusCode,SwatModeIsActive,CecEventStatusText,MasterEventCustomerCount,MasterEventLobCount,CecEventDescription"
			};
			if (!bState) {
				bState = "open";
			}

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					//map filter region
					if (region === "EMEA") {
						aRegionFilter.push(new sap.ui.model.Filter("CustomerGlobalRegionCode", sap.ui.model.FilterOperator.EQ, "EMN"));
						aRegionFilter.push(new sap.ui.model.Filter("CustomerGlobalRegionCode", sap.ui.model.FilterOperator.EQ, "EMS"));
					} else if (region === "EMEA_NORTH") {
						aRegionFilter.push(new sap.ui.model.Filter("CustomerGlobalRegionCode", sap.ui.model.FilterOperator.EQ, "EMN"));
					} else if (region === "EMEA_SOUTH") {
						aRegionFilter.push(new sap.ui.model.Filter("CustomerGlobalRegionCode", sap.ui.model.FilterOperator.EQ, "EMS"));
					} else if (region === "GTC") {
						aRegionFilter.push(new sap.ui.model.Filter("CustomerGlobalRegionCode", sap.ui.model.FilterOperator.EQ, "GCH"));
					} else if (region === "LAC") {
						aRegionFilter.push(new sap.ui.model.Filter("CustomerGlobalRegionCode", sap.ui.model.FilterOperator.EQ, "LA"));
					} else {
						aRegionFilter.push(new sap.ui.model.Filter("CustomerGlobalRegionCode", sap.ui.model.FilterOperator.EQ, region));
					}
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFacetFilters = oFilterModel.getProperty("/oFilterForOutages");

			if (oFacetFilters && oFacetFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilters);
			}

			if (bState === "closed" || bState === "all") {
				/*var dateOffset = (24 * 60 * 60 * 1000) * Constants.closedCasesPastDays;
				var dateInPast = new Date();
				dateInPast.setTime(dateInPast.getTime() - dateOffset);*/
				var dateOffset = (24 * 60 * 60 * 1000) * Constants.closedCasesPastDays;
				var dateInPast = new Date();
				dateInPast.setTime(dateInPast.getTime() - dateOffset);
				var oFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyyMMddHHmmss"
				});
				dateInPast = oFormat.format(dateInPast);
				var dateToday = oFormat.format(new Date());

				var timeFilter = new sap.ui.model.Filter([
					new sap.ui.model.Filter("CecEventEndDateTime", sap.ui.model.FilterOperator.BT, dateInPast, dateToday)
				]);

				var tileSpecificFilters1 = new sap.ui.model.Filter([
						new sap.ui.model.Filter("SwatModeIsActive", sap.ui.model.FilterOperator.EQ, 0),
						timeFilter
					],
					true
				);

			}
			if (bState === "open" || bState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter("SwatModeIsActive", sap.ui.model.FilterOperator.EQ, 1)
					],
					true
				);
			}

			if (bState === "open") {
				aFilters.push(tileSpecificFilters2);
			} else if (bState === "closed") {
				aFilters.push(tileSpecificFilters1);
			} else if (bState === "all") {
				aFilters.push(new sap.ui.model.Filter([
						tileSpecificFilters1,
						tileSpecificFilters2
					],
					false
				));
			}

			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);

			//sorter
			var aSorter = [];
			aSorter.push(new sap.ui.model.Sorter("SwatModeIsActive", true));
			aSorter.push(new sap.ui.model.Sorter("CecEventStartDateTime", true));

			oOutagesModel.read("/GetSwatOutages", {
				urlParameters: oUrlParameters,
				sorters: aSorter,
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);

					//calculate duration
					data.results.forEach(function (value) {
						value.duration = this._calculateDurationBetweenDates(value.CecEventStartDateTime, value.CecEventEndDateTime);
						value.durationCombined = this._calculateDurationBetweenDatesCombined(value.CecEventStartDateTime, value.CecEventEndDateTime);
						value.SwatModeIsActiveFormatted = this.formatter.formatOutageStatus(value.SwatModeIsActive, this);
						value.MasterEventServiceStatusCodeFormatted = this.formatter.formatOutageType(value.MasterEventServiceStatusCode, this);
					}.bind(this));
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "data");
				}.bind(this),
				error: function (data) {
					//oTable.setBusy(false);
				}.bind(this)
			});
		},

		_calculateDurationBetweenDates: function (start, end) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyyMMddHHmmss"
			});
			if (start && start !== "0") {
				var dStart = dateFormat.parse(start);
				var dEnd = end && end !== "0" ? dateFormat.parse(end) : new Date();
				var sResult = "";

				var diffInSeconds = Math.abs(dEnd - dStart) / 1000;
				var days = Math.floor(diffInSeconds / 60 / 60 / 24);
				var hours = Math.floor(diffInSeconds / 60 / 60 % 24);
				var minutes = Math.floor(diffInSeconds / 60 % 60);
				var seconds = Math.floor(diffInSeconds % 60);

				sResult += days > 0 ? days + "d" + " " : "";
				sResult += hours > 0 ? hours + "h" + " " : "";
				sResult += minutes > 0 ? minutes + "m" + " " : "";
				sResult += seconds > 0 ? seconds + "s" : "";

				return sResult;
			}
			return "";
		},

		//Function to calculate the duration between dates in seconds for proper sorting
		_calculateDurationBetweenDatesCombined: function (start, end) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyyMMddHHmmss"
			});
			if (start && start !== "0") {
				var dStart = dateFormat.parse(start);
				var dEnd = end && end !== "0" ? dateFormat.parse(end) : new Date();
				var sResult = "";

				sResult = Math.abs(dEnd - dStart) / 1000;

				return sResult;
			}
			return "";
		},

		onNavToOutagesList: function () {
			var oSplitContainer = this.getView().byId("splitContainerOutage");
			oSplitContainer.toDetail(this.createId("outagesPage"));
		},

		onOutagePress: function (oEvent) {
			var oDetailPage = this.getView().byId("outageDetailPage");
			this.byId("splitContainerOutage").toDetail(oDetailPage);
			var oIconTabBar = this.byId("outageDetailTabBar");
			oIconTabBar.setSelectedKey("Info");

			var oIncidentDescriptionText = this.getView().byId("incidentDescriptionText");
			var oCustomerImpactText = this.getView().byId("customerImpactText");

			var oInput = oEvent.getSource();
			var sId = oInput.getBindingContext("data").getObject().CecEventID;

			var oOutagesModel = this.getOwnerComponent().getModel("outageMainModel");
			if (oOutagesModel.isMetadataLoadingFailed()) {
				this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				return null;
			}

			var oOutageDetailModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oOutageDetailModel, "outageDetailModel");

			oInput.setBusy(true);
			oIncidentDescriptionText.setBusy(true);
			oCustomerImpactText.setBusy(true);

			oOutagesModel.read("/GetSwatOutageFieldParams('" + sId + "')", {
				success: function (data) {
					if (!data.IncidentDescription || data.IncidentDescription === "") {
						data.IncidentDescription = "Currently no details available";
					}
					if (!data.CustomerImpact || data.CustomerImpact === "") {
						data.CustomerImpact = "Currently no details available";
					}

					data.IncidentDescription = unescape(data.IncidentDescription.replace(/(<([^>]+)>)/ig, '')).replace(/&nbsp;/g, ' ');
					data.CustomerImpact = unescape(data.CustomerImpact.replace(/(<([^>]+)>)/ig, '')).replace(/&nbsp;/g, ' ');

					var oOutage = oInput.getBindingContext("data").getObject();
					oOutage.CecEventID = sId;
					oOutage.IncidentDescription = data.IncidentDescription;
					oOutage.CustomerImpact = data.CustomerImpact;

					oOutageDetailModel.setData(oOutage);

					oDetailPage.bindElement({
						model: "outageDetailModel",
						path: "/"
					});
					this.getView().updateBindings(true);

					this.loadImpactedCustomers();
					this.loadImpactedLob();

					oInput.setBusy(false);
					oIncidentDescriptionText.setBusy(false);
					oCustomerImpactText.setBusy(false);
				}.bind(this),
				error: function (data) {

					data.IncidentDescription = "Currently no details available";
					data.CustomerImpact = "Currently no details available";

					// hinzufügen der Beschreibungen an das bestehende Objekt
					var oOutage = oInput.getBindingContext("data").getObject();
					oOutage.IncidentDescription = data.IncidentDescription;
					oOutage.CustomerImpact = data.CustomerImpact;
					oOutage.CecEventID = sId;

					oOutageDetailModel.setData(oOutage);
					oDetailPage.bindElement({
						model: "outageDetailModel",
						path: "/"
					});
					this.getView().updateBindings(true);
					this.loadImpactedCustomers();
					this.loadImpactedLob();

					oInput.setBusy(false);
					oIncidentDescriptionText.setBusy(false);
					oCustomerImpactText.setBusy(false);
				}.bind(this)
			});
		},

		onPressEventId: function (oEv) {
			var sUrl = "https://go.sap.corp/downtime-dashboard#/swatactivationdetails/" + oEv.getSource().getTitle();
			this._openWindow(sUrl);
		},

		onPressFurterInformation: function (oEv) {
			var sUrl = "https://go.sap.corp/downtime-dashboard#/swatactivationdetails/";
			var oOutageDetailModel = this.getView().getModel("outageDetailModel");
			var sCecEventID = oOutageDetailModel.getProperty("/CecEventID");
			sUrl = sUrl + sCecEventID;

			this._openWindow(sUrl);
		},

		onPressSituationDetails: function (oEv) {
			var oInput = oEv.getSource();
			var sId = oEv.getSource().getBindingContext("data").getObject().CecEventID;
			var oOutagesModel = this.getOwnerComponent().getModel("outageMainModel");
			if (oOutagesModel.isMetadataLoadingFailed()) {
				this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				return null;
			}
			oInput.setBusy(true);
			oOutagesModel.read("/GetSwatOutageFieldParams('" + sId + "')", {
				success: function (data) {
					oInput.setBusy(false);

					if (data.IncidentDescription === "") {
						data.IncidentDescription = "Currently no details available";
					}
					if (data.CustomerImpact === "") {
						data.CustomerImpact = "Currently no details available";
					}

					data.IncidentDescription = unescape(data.IncidentDescription.replace(/(<([^>]+)>)/ig, '')).replace(/&nbsp;/g, ' ');
					data.CustomerImpact = unescape(data.CustomerImpact.replace(/(<([^>]+)>)/ig, '')).replace(/&nbsp;/g, ' ');

					var oModel = new sap.ui.model.json.JSONModel(data);
					Fragment.load({
						name: "com.sap.mcconedashboard.view.viewMobile.fragmentMobile.OutagesDetailsMobile",
						controller: this
					}).then(function (oDialog) {
						oDialog.setModel(oModel, "data");
						this.getView().addDependent(oDialog);
						oDialog.openBy(oInput);
					}.bind(this));
				}.bind(this),
				error: function (data) {
					oInput.setBusy(false);
					//show popover, but with info, that no data is available
					data.CecEventID = sId;
					data.IncidentDescription = "Currently no details available";
					data.CustomerImpact = "Currently no details available";
					var oModel = new sap.ui.model.json.JSONModel(data);
					Fragment.load({
						name: "com.sap.mcconedashboard.view.viewMobile.fragmentMobile.OutagesDetailsMobile",
						controller: this
					}).then(function (oDialog) {
						oDialog.setModel(oModel, "data");
						this.getView().addDependent(oDialog);
						oDialog.openBy(oInput);
					}.bind(this));
				}.bind(this)
			});
		},

		onPressImpactedLob: function (oEv) {
			var oUrlParameters = {
				"$select": "MasterEventID,LoBID,LoBName"
			};
			var oInput = oEv.getSource();
			var sId = oEv.getSource().getBindingContext("outageDetailModel").getObject().MasterEventID;
			var aFilter = [new sap.ui.model.Filter("MasterEventID", sap.ui.model.FilterOperator.EQ, sId)];
			var oOutagesModel = this.getOwnerComponent().getModel("outageMainModel");
			if (oOutagesModel.isMetadataLoadingFailed()) {
				this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				return null;
			}
			var aSorter = [];
			aSorter.push(new sap.ui.model.Sorter("LoBName", false));

			oInput.setBusy(true);
			oOutagesModel.read("/GetSwatOutageAffectedLoBs", {
				urlParameters: oUrlParameters,
				filters: [new sap.ui.model.Filter(aFilter, true)],
				sorters: aSorter,
				success: function (data) {
					oInput.setBusy(false);
					if (data.results.length > 0) {
						//var s = this.joinObj(data.results, "LoBName");
						this._openPopover("Impacted LoBs", data.results);
					}
				}.bind(this),
				error: function (data) {
					oInput.setBusy(false);
				}.bind(this)
			});
		},

		loadImpactedLob: function () {
			var oUrlParameters = {
				"$select": "MasterEventID,LoBID,LoBName"
			};

			var oList = this.getView().byId("outageImpLoBsList");
			var oOutageDetailModel = this.getView().getModel("outageDetailModel");
			var sId = oOutageDetailModel.getProperty("/MasterEventID");
			var aFilter = [new sap.ui.model.Filter("MasterEventID", sap.ui.model.FilterOperator.EQ, sId)];
			var oOutagesModel = this.getOwnerComponent().getModel("outageMainModel");
			if (oOutagesModel.isMetadataLoadingFailed()) {
				this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				return null;
			}
			var aSorter = [];
			aSorter.push(new sap.ui.model.Sorter("LoBName", false));

			oOutagesModel.read("/GetSwatOutageAffectedLoBs", {
				urlParameters: oUrlParameters,
				filters: [new sap.ui.model.Filter(aFilter, true)],
				sorters: aSorter,
				success: function (data) {

					if (data.results.length > 0) {
						//this._openPopover("Impacted LoBs", data.results);
						var oModel = new sap.ui.model.json.JSONModel();
						var oData = {
							"title": "Impacted LoBs",
							"items": []
						};
						var aItems = data.results;
						aItems.forEach(function (val) {
							var sCustCrm = "";
							var sCustErp = "";

							oData.items.push({
								"type": "lob",
								"title": val.LoBName || val.CustomerName + " - " + val.CustomerCountryNames,
								"custCrm": sCustCrm,
								"custErp": sCustErp
							});
						});

						oModel.setData(oData);
						oList.setModel(oModel, "AffImpModel");

					}
				}.bind(this),
				error: function (data) {

				}.bind(this)
			});
		},

		//For Dialog (OLD)
		onPressImpactedCustomers: function (oEv) {
			var oUrlParameters = {
				"$select": "MasterEventID,CustomerCRMID,CustomerERPID,CustomerName,CustomerGlobalRegionCode,CustomerGlobalRegionName,CustomerIndustryCode,CustomerIndustryName,CustomerCountryNames,CustomerCountryCodes"
			};
			var oInput = oEv.getSource();
			var sId = oEv.getSource().getBindingContext("outageDetailModel").getObject().MasterEventID;
			var aFilter = [new sap.ui.model.Filter("MasterEventID", sap.ui.model.FilterOperator.EQ, sId)];
			var oOutagesModel = this.getOwnerComponent().getModel("outageMainModel");
			if (oOutagesModel.isMetadataLoadingFailed()) {
				this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				return null;
			}
			var aSorter = [];
			aSorter.push(new sap.ui.model.Sorter("CustomerName", false));

			oInput.setBusy(true);
			oOutagesModel.read("/GetSwatOutageAffectedCustomers", {
				urlParameters: oUrlParameters,
				filters: [new sap.ui.model.Filter(aFilter, true)],
				sorters: aSorter,
				success: function (data) {
					oInput.setBusy(false);
					if (data.results.length > 0) {
						//var s = this.joinObj(data.results, "CustomerName");
						this._openPopover("Impacted Customers", data.results);

					}
				}.bind(this),
				error: function (data) {
					oInput.setBusy(false);
				}.bind(this)
			});
		},

		loadImpactedCustomers: function () {
			var oUrlParameters = {
				"$select": "MasterEventID,CustomerCRMID,CustomerERPID,CustomerName,CustomerGlobalRegionCode,CustomerGlobalRegionName,CustomerIndustryCode,CustomerIndustryName,CustomerCountryNames,CustomerCountryCodes"
			};
			var oList = this.getView().byId("outageImpCustList");
			var oOutageDetailModel = this.getView().getModel("outageDetailModel");
			var sId = oOutageDetailModel.getProperty("/MasterEventID");
			var aFilter = [new sap.ui.model.Filter("MasterEventID", sap.ui.model.FilterOperator.EQ, sId)];
			var oOutagesModel = this.getOwnerComponent().getModel("outageMainModel");
			if (oOutagesModel.isMetadataLoadingFailed()) {
				this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				return null;
			}
			var aSorter = [];
			aSorter.push(new sap.ui.model.Sorter("CustomerName", false));

			oOutagesModel.read("/GetSwatOutageAffectedCustomers", {
				urlParameters: oUrlParameters,
				filters: [new sap.ui.model.Filter(aFilter, true)],
				sorters: aSorter,
				success: function (data) {
					if (data.results.length > 0) {
						var oModel = new sap.ui.model.json.JSONModel();
						var oData = {
							"title": "Impacted Customers",
							"items": []
						};
						var aItems = data.results;
						aItems.forEach(function (val) {
							var sCustCrm = "";
							var sCustErp = "";
							if (val.CustomerCRMID !== "") {
								sCustCrm = "BP ID: " + val.CustomerCRMID;
							}
							if (val.CustomerERPID !== "") {
								sCustErp = "ERP ID: " + val.CustomerERPID;
							}
							oData.items.push({
								"type": "cust",
								"title": val.LoBName || val.CustomerName + " - " + val.CustomerCountryNames,
								"custCrm": sCustCrm,
								"custErp": sCustErp
							});
						});
	
						oModel.setData(oData);
						oList.setModel(oModel, "AffCustModel");

					}
				}.bind(this),
				error: function (data) {

				}.bind(this)
			});
		},

		_openPopover: function (title, aItems) {
			var oModel = new sap.ui.model.json.JSONModel();
			var oData = {
				"title": title,
				"items": []
			};
			//map values for model
			aItems.forEach(function (val) {
				var sCustCrm = "";
				var sCustErp = "";
				if (title === "Impacted Customers") {
					if (val.CustomerCRMID !== "") {
						sCustCrm = "BP ID: " + val.CustomerCRMID;
					}
					if (val.CustomerERPID !== "") {
						sCustErp = "ERP ID: " + val.CustomerERPID;
					}
				}

				oData.items.push({
					"type": title === "Impacted Customers" ? "cust" : "lob",
					"title": val.LoBName || val.CustomerName + " - " + val.CustomerCountryNames,
					"custCrm": sCustCrm,
					"custErp": sCustErp
				});
			});
			oModel.setData(oData);
			Fragment.load({
				name: "com.sap.mcconedashboard.view.fragment.OutagesDialogList",
				controller: this
			}).then(function (oDialog) {
				oDialog.setModel(oModel, "data");
				this.getView().addDependent(oDialog);
				oDialog.open();
			}.bind(this));
		},

		onCustSearch: function (oEv) {
			var sQuery = oEv.getParameter("newValue");
			var oList = this.getView().byId("outageImpCustList");
			var aFilters = [];
			if (sQuery && sQuery.length > 0) {
				aFilters.push(new sap.ui.model.Filter([
					new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("custCrm", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("custErp", sap.ui.model.FilterOperator.Contains, sQuery)
				]));
			}
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		onLoBSearch: function (oEv) {
			var sQuery = oEv.getParameter("newValue");
			var oList = this.getView().byId("outageImpLoBsList");
			var aFilters = [];
			if (sQuery && sQuery.length > 0) {
				aFilters.push(new sap.ui.model.Filter([
					new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("custCrm", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("custErp", sap.ui.model.FilterOperator.Contains, sQuery)
				]));
			}
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		onListClose: function (oEv) {
			oEv.getSource().getParent().close();
			oEv.getSource().getParent().destroy();
		},

		onNavToCustomerView: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("AffCustModel").getObject().custErp.substring(8);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		onTabSelect: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("item");
			var sKey = oSelectedItem.getKey();

			if (sKey === "ImpCust") {
				//	this.onImpactedCustomersTab();
			}
		},

		onOutageLiveSearch: function (event) {
				var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("outagesList");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("CecEventID", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);
			
			var oFilter2 = new sap.ui.model.Filter("duration", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);
			
			var oFilter3 = new sap.ui.model.Filter("CecEventDescription", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter3);
			
			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		}

	});

});