sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/model/Constants"
], function (BaseController, formatter, Constants) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.controllerMobile.GlobalEscalationMobile", {

		formatter: formatter,

		onInit: function () {

			//create local model to read customer related data, should be this name, cause fragment reused
			var oCustomerData = {
				reload: true
			};
			var oCustomerModel = new sap.ui.model.json.JSONModel(oCustomerData);
			this.getOwnerComponent().setModel(oCustomerModel, "globalEscalations");

			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				iTabFiltered: 0,
				bLoadingState: false
			}), "viewModel");

			this._oGlobalFilter = null;
			this._oPriceFilter = null;
			this._tblRendered = false;
			this.getRouter().getRoute("GlobalEscalationMobile").attachPatternMatched(this._onObjectMatched, this);

		},

		onAfterRendering: function () {},

		_onObjectMatched: function (oEvent) {
			if (this.getModel("globalEscalations") && this.getModel("globalEscalations").getData() && this.getModel("globalEscalations").getProperty(
					"/reload")) {
				this.getModel("globalEscalations").setProperty("/reload", false);
				this._updateTable();
			}
			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
		},

		_updateTable: function () {
			var aFilters = [];
			var oFilterModel = this.getModel("filterModel");
			var aCaseIdsRequestingUnitFromHana = null;
			var oSettings = this.getOwnerComponent().getModel("settings").getData();
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/globalEscalationsCaseState");
			var bCaseFilter = this.getOwnerComponent().getModel("data").getProperty("/globalEscalationsCaseFilter");
			if (!bCaseState) {
				bCaseState = "open";
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			if (bCaseState === "open" || bCaseState === "all") {
				//ALL ongoing 
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20"), new sap.ui.model.Filter(
							"Status", sap.ui.model.FilterOperator.EQ, "30")], false)
					],
					true
				);
			}

			//read all Requestîng Units from the HANA DB for GEM
			this.getModel("subModel").read("/Cases", {
				filters: [new sap.ui.model.Filter(
					[new sap.ui.model.Filter("UseCaseType", sap.ui.model.FilterOperator.EQ, "mcs-gem")].filter(Boolean),
					true
				)],
				urlParameters: {
					"$select": "CaseID,RequestingUnit,RequestingUnitName"
				},
				success: function (oData) {
					if (oData.results) {
						aCaseIdsRequestingUnitFromHana = oData.results;
					}
				},
				error: function () {}
			});

			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
						tileSpecificFilters1,
						tileSpecificFilters2
					],
					false
				));
			}

			this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", true);

			var oICModel = this.getModel();

			oICModel.read("/GlobalEscalationsSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);

					this._calculateRating(data);
					data.results.forEach(function (oCase) {
						if (oCase.Rating === "") {
							oCase.Rating = "unrated";
						}
						if (oCase.DbsMaintenanceRanking === "0") {
							oCase.DbsMaintenanceRanking = "";
						}
						oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);
						//add data for requesting unit to result list
						if (aCaseIdsRequestingUnitFromHana) {
							var index = aCaseIdsRequestingUnitFromHana.findIndex(item => item.CaseID.toString() === oCase.CaseId);
							if (index > -1) {
								oCase.ReqestingUnit = aCaseIdsRequestingUnitFromHana[index].RequestingUnit;
								oCase.RequestingUnitT = aCaseIdsRequestingUnitFromHana[index].RequestingUnitName; //this.formatter.getRequestingUnitText(oCase.ReqestingUnit, this._oResourceBundle);
							}
						}

					}.bind(this));
					this.getModel("globalEscalations").setProperty("/GlobalEscalationsSet", data.results);
					this.loadProducts(aFilters);
					//MISSIONRADAR 2211	
					this.readMissionRadarValues(this.getModel("globalEscalations"), "GlobalEscalationsSet");

				}.bind(this),
				error: function (data) {
					this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
				}.bind(this)
			});

		},

		loadProducts: function (aFilters) {
			this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", true);

			var oICModel = this.getModel();
			oICModel.read("/GlobalEscalationsSet", {
				urlParameters: {
					"$expand": "toProducts"
				},
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					var oModel = this.getModel("globalEscalations");
					var aAlreadyAdded = oModel.getProperty("/GlobalEscalationsSet");
					//concat toProducts properties
					data.results.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVersion = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.CaseId === result.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVersion = result.ProductVersion;
							});
						}

					}, this);
					this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
				}.bind(this),
				error: function (data) {
					this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
				}.bind(this)
			});
		},

		loadNotes: function (oControl, id) {
			var oICModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oICModel.read("/GlobalEscalationsSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		handleCustomerPress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("globalEscalations").getPath();
			var oProperty = this.getModel("globalEscalations").getProperty(sPath);
			var sErpCustNo = oProperty.CustomerErpNo || oProperty.ErpCustNo || oProperty.CustomerNo;
			var oRouter = this.getRouter();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("globalEscalations").getPath();
			var oProperty = this.getModel("globalEscalations").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("globalEscalations").getObject();
			var sObjectType = "";
			var sId = oData.CaseId;
			this.loadNotes(oEv.getSource(), sId, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},

		handleCasePress: function (evt) {
			this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", true);
			var oList = this.getView().byId("globalEscalationsList");
			var sPath = evt.getSource().getBindingContextPath();
			var oProperty = this.getModel("globalEscalations").getProperty(sPath);
			var sCaseId = oProperty.CaseId;
			var oRouter = this.getRouter();
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);
			this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
			oRouter.navTo("CaseDetailsMobile", {
				"?query": this._getQueryParameter(),
				CaseId: sCaseId
			});
		},

		onCaseNewTab: function (oEv) {
			var sPath = oEv.getSource().getParent().getBindingContext("globalEscalations").getPath();
			var oProperty = this.getModel("globalEscalations").getProperty(sPath);
			var sCaseId = oProperty.CaseId;
			this._openCaseInNewTab(sCaseId);
		},

		changeCaseState: function () {
			this._updateTable();
		},

		_calculateRating: function (data) {
			var oViewModel = this.getView().getModel("viewModel");
			var iGreen = 0;
			var iYellow = 0;
			var iRed = 0;
			var iUnrated = 0;
			data.results.forEach(function (oCase) {
				switch (oCase.Rating) {
				case "A":
					iGreen++;
					break;
				case "B":
					iYellow++;
					break;
				case "C":
					iRed++;
					break;
				default:
					iUnrated++;
				}
			});
			oViewModel.setProperty("/iTabAll", data.results.length);
			oViewModel.setProperty("/iTabGreen", iGreen);
			oViewModel.setProperty("/iTabYellow", iYellow);
			oViewModel.setProperty("/iTabRed", iRed);
			oViewModel.setProperty("/iTabUnrated", iUnrated);
		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("globalEscalations").getObject();
			var sCaseId = oProperty.CaseId;
			this._shopTopIssuesCountPopover(sCaseId, oEv.getSource());
		},

		onLiveSearchChange: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("globalEscalationsList");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("CustomerText", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("CountryT", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter("RegionT", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter3);

			var oFilter4 = new sap.ui.model.Filter("CaseTitle", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter4);

			var oFilter5 = new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter5);

			var oRatingFilter;
			if (searchValue === "red") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C");
			} else if (searchValue === "yellow" || searchValue === "orange") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "B");
			} else if (searchValue === "green") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "A");
			} else {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.Contains, searchValue);
			}
			aFilters.push(oRatingFilter);

			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		}

	});
});