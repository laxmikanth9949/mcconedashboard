sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/model/Constants"
], function (BaseController, formatter, Constants) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.controllerMobile.ProductEscalationMobile", {

		formatter: formatter,
		//we can use the same oData model and filters as for DB(Business Down), because it uses the same oData Service and calls
		onInit: function () {
			//create local model to read customer related data, should be this name, cause fragment reused
			var oCustomerData = {
				reload: true
			};
			var oCustomerModel = new sap.ui.model.json.JSONModel(oCustomerData);
			this.getOwnerComponent().setModel(oCustomerModel, "productEscalations");

			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				iTabFiltered: 0,
				bLoadingState: false
			}), "viewModel");

			this._oGlobalFilter = null;
			this._oPriceFilter = null;
			this._tblRendered = false;

			//reset caseIds for PDF or XLS Export
			this.getModel("settings").setProperty("/caseIdsForExport", null);
			this.getRouter().getRoute("ProductEscalationMobile").attachPatternMatched(this._onObjectMatched, this);
		},

		onAfterRendering: function () {
		},

		_onObjectMatched: function (oEvent) {
			if (this.getModel("productEscalations") && this.getModel("productEscalations").getData() && this.getModel(
					"productEscalations").getProperty(
					"/reload")) {
				this.getModel("productEscalations").setProperty("/reload", false);
				this._updateTable();
			}
			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
		},

		_updateTable: function () {
			var aFilters = [];
			var oFilterModel = this.oView.getModel("filterModel");
			var sRegion = oFilterModel.getProperty("/region");
			var oFilterForMCS = oFilterModel.getProperty("/oFilterModelMCS");

			var bCaseFilter = this.getOwnerComponent().getModel("data").getProperty("/productEscalationsCaseFilter");

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			if (oFilterForMCS && oFilterForMCS.aFilters.length > 0) {
				//oFilterForMCS = this._mapFacetFiltersForBusinessDowns(oFilterForMCS);
				if (oFilterForMCS.aFilters.length > 0) {
					aFilters.push(oFilterForMCS);
				}
			}

			//Escalation Status Flag:  15 - Business Down

			var tileSpecificFilters = new sap.ui.model.Filter([
					new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "20"),
					new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "30")
				],
				false
			);
			aFilters.push(tileSpecificFilters);

			aFilters.push(new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP06"));

			this.getModel("productEscalations").setProperty("/ProductEscalationsSetBusy", true);

			var oMCSModel = this.oView.getModel("mcsModel");
			oMCSModel.metadataLoaded(true).then(
				function () {
					oMCSModel.read("/MCSDashboardSet", {
						filters: [new sap.ui.model.Filter(aFilters, true)],
						success: function (data) {
							//sort client at side
							data = this._sortByRanking(data);

							this._calculateRating(data);
							data.results.forEach(function (oCase) {
								if (oCase.rating === "") {
									oCase.rating = "unrated";
								}
								oCase.country_text = this.formatter.getCountryName(oCase.country, this);
								if (oCase.dbs_maintenance_rank === "0") {
									oCase.dbs_maintenance_rank = "";
								}
								
								oCase.priorityMatched =  this.formatter.sortPriorities(oCase.priority_text);
								
								//for PDF/XLS Generation we need to store the case IDs
								if (this.getModel("settings").getProperty("/caseIdsForExport") === null) {
									this.getModel("settings").setProperty("/caseIdsForExport", [oCase.case_id]);
								} else {
									this.getModel("settings").getProperty("/caseIdsForExport").push(oCase.case_id);
								}

							}.bind(this));
							this.getModel("productEscalations").setProperty("/ProductEscalationsSet", data.results); //this._convertDataToStandardStructure(data.results)
							this.loadProducts(aFilters);

						}.bind(this),
						error: function (data) {
							this.getModel("productEscalations").setProperty("/ProductEscalationsSetBusy", false);
						}.bind(this)
					});
				}.bind(this));
		},

		loadProducts: function (aFilters) {
			this.getModel("productEscalations").setProperty("/ProductEscalationsSetBusy", true);

			var oBDModel = this.getModel("mcsModel");
			var aFilters = [];

			var tileSpecificFilters = new sap.ui.model.Filter([
					new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "20"),
					new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "30")
				],
				false
			);

			aFilters.push(tileSpecificFilters);

			aFilters.push(new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP06"));

			oBDModel.read("/MCSDashboardSet", {
				filters: aFilters,
				urlParameters: {
					"$expand": "toProducts",
					"$select": "case_id,toProducts"
				},
				success: function (data) {
					var oModel = this.getModel("productEscalations");
					var aAlreadyAdded = oModel.getProperty("/ProductEscalationsSet");
					//concat toProducts properties
					data.results.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVersion = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.case_id === result.case_id;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].Product = result.Product;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVersion = result.ProductVersion;
							});
						}

					}, this);
					oModel.refresh();
					this.getModel("productEscalations").setProperty("/ProductEscalationsSetBusy", false);
				}.bind(this),
				error: function (data) {
					this.getModel("productEscalations").setProperty("/ProductEscalationsSetBusy", false);
				}.bind(this)
			});

		},

		loadNotes: function (oControl, id) {
			var oBDModel = this.getModel("mcsModel");
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oBDModel.read("/MCSDashboardSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		handleCustomerPress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("productEscalations").getPath();
			var oProperty = this.getModel("productEscalations").getProperty(sPath);
			var sErpCustNo = oProperty.customer_erp_no || oProperty.CustomerNo;
			var oRouter = this.getRouter();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("productEscalations").getPath();
			var oProperty = this.getModel("productEscalations").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("productEscalations").getObject();
			var sObjectType = "";
			var sId = oData.case_id;
			this.loadNotes(oEv.getSource(), sId, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},
		
		handleCasePress: function (evt) {
			this.getModel("productEscalations").setProperty("/ProductEscalationsSetBusy", true);
			var sPath = evt.getSource().getBindingContextPath();
			var oProperty = this.getModel("productEscalations").getProperty(sPath);
			var sCaseId = oProperty.case_id;
			var oRouter = this.getRouter();
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);
			this.getModel("productEscalations").setProperty("/ProductEscalationsSetBusy", false);
			oRouter.navTo("CaseDetailsMobile", {
				"?query": this._getQueryParameter(),
				CaseId: sCaseId
			});
		},
		
		
		
		onCaseNewTab: function (oEv) {
			var sPath = oEv.getSource().getParent().getBindingContext("productEscalations").getPath();
			var oProperty = this.getModel("productEscalations").getProperty(sPath);
			var sCaseId = oProperty.case_id;
			this._openCaseInNewTab(sCaseId);
		},

		changeCaseState: function () {
			this._updateTable();
		},

		_calculateRating: function (data) {
			var oViewModel = this.getView().getModel("viewModel");
			var iGreen = 0;
			var iYellow = 0;
			var iRed = 0;
			var iUnrated = 0;
			data.results.forEach(function (oCase) {
				switch (oCase.rating) {
				case "A":
					iGreen++;
					break;
				case "B":
					iYellow++;
					break;
				case "C":
					iRed++;
					break;
				default:
					iUnrated++;
				}
			});
			oViewModel.setProperty("/iTabAll", data.results.length);
			oViewModel.setProperty("/iTabGreen", iGreen);
			oViewModel.setProperty("/iTabYellow", iYellow);
			oViewModel.setProperty("/iTabRed", iRed);
			oViewModel.setProperty("/iTabUnrated", iUnrated);
		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("productEscalations").getObject();
			var sCaseId = oProperty.case_id;
			this._shopTopIssuesCountPopover(sCaseId, oEv.getSource());
		},
	
		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("productEscalations").getObject().rating_text;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		},
		
		onLiveSearchProdEsc: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("tabIncList");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("objectType", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("country_text", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter("region_text", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter3);

			var oFilter4 = new sap.ui.model.Filter("case_title", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter4);

			var oFilter5 = new sap.ui.model.Filter("case_id", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter5);
			
			var oFilter6 = new sap.ui.model.Filter("customer_name", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter6);
			
			var oFilter7 = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter7);

			var oRatingFilter;
			if (searchValue === "red") {
				oRatingFilter = new sap.ui.model.Filter("rating", sap.ui.model.FilterOperator.EQ, "C");
			} else if (searchValue === "yellow" || searchValue === "orange") {
				oRatingFilter = new sap.ui.model.Filter("rating", sap.ui.model.FilterOperator.EQ, "B");
			} else if (searchValue === "green") {
				oRatingFilter = new sap.ui.model.Filter("rating", sap.ui.model.FilterOperator.EQ, "A");
			} else {
				oRatingFilter = new sap.ui.model.Filter("rating", sap.ui.model.FilterOperator.Contains, searchValue);
			}
			aFilters.push(oRatingFilter);

			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		},
		
	});

});