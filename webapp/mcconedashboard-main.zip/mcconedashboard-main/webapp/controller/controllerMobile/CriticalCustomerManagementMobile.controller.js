sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/model/Constants"
], function (BaseController, formatter, Constants) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.CriticalCustomerManagementMobile", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				iTabFiltered: 0,
				bLoadingState: false
			}), "viewModel");
			this.getRouter().getRoute("CriticalCustomerManagementMobile").attachPatternMatched(this._onObjectMatched, this);
		},

		onAfterRendering: function () {

		},

		_onObjectMatched: function (oEvent) {
			//Check if data was already loaded. If yes, use this data
			if (!this.getOwnerComponent().getModel("data") || (this.getOwnerComponent().getModel("data").getData() && this.getOwnerComponent().getModel(
					"data").getData().reloadCriticalCustomerManagement)) {
				this._updateTable();
			}
			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
		},

		_updateTable: function () {
			var aFilters = [];
			var oList = this.getView().byId("CCMListId");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/criticalCustomerManagementCaseState");
			//var bCaseFilter = this.getOwnerComponent().getModel("data").getProperty("/criticalCustomerManagementFilter");
			if (!bCaseState) {
				bCaseState = "open";
			}

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			if (bCaseState === "closed" || bCaseState === "all") {
				var dateOffset = (24 * 60 * 60 * 1000) * Constants.closedCasesPastDays;
				var dateInPast = new Date();
				dateInPast.setTime(dateInPast.getTime() - dateOffset);

				var tileSpecificFilters1 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90")
						], false),
						new sap.ui.model.Filter({
							path: "ClosingDate",
							operator: sap.ui.model.FilterOperator.GE,
							value1: dateInPast
						})
					],
					true
				);

			}
			if (bCaseState === "open" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false)
					],
					true
				);
			}
			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
						tileSpecificFilters1,
						tileSpecificFilters2
					],
					false
				));
			}
			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP05"));

			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);

			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				// urlParameters: {
				// 	"$select": "CaseId,CaseTitle,CustomerText,Region,StatusT,Rating,CreateDate,CustomerErpNo,ServiceOrgT,HasNotes,ChangeDate,ClosingDate,PlanEndDate,GoLiveDate,TopIssuesCount,MasterCodeT,ServiceTeamT"
				// },
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);

					data.results.forEach(function (oCase) {
						oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);
						if (oCase.Rating === "") {
							oCase.Rating = "unrated";
						}
						if (oCase.DbsMaintenanceRanking === "0") {
							oCase.DbsMaintenanceRanking = "";
						}
					}.bind(this));

					//also load from hana to get ccm light cases
					this._loadCCMLightCases(data.results).then(function (aCases) {
						var data = {
							results: aCases
						};

						this._calculateRating(data);
						var oModel = new sap.ui.model.json.JSONModel(data);
						this.getOwnerComponent().setModel(oModel, "data");
						this.readProducts(oModel, aFilters);
						this.readImplementationPartner(oModel).then(function () {
							setTimeout(function () {
								oList.rerender();
							}, 200);
						}.bind(this));
						//MISSIONRADAR 2211	
						this.readMissionRadarValues(oModel, "results");
						/*if (bCaseFilter !== "none") {
							var oIconTabBar = this.getView().byId("dataIconTabBar");
							oIconTabBar.setSelectedKey(bCaseFilter);
							oIconTabBar.fireSelect();
						}*/
					}.bind(this));

				}.bind(this),
				error: function (data) {
					oList.setBusy(false);
				}.bind(this)
			});
		},

		_loadCCMLightCases: function (aData) {
			return new Promise(function (resolve) {
				resolve(aData);
			});
			/*return new Promise(function (resolve) {
				var aFilteresData = [];
				var aFilters = [new sap.ui.model.Filter([
					new sap.ui.model.Filter("bCCML1", sap.ui.model.FilterOperator.EQ, true),
					new sap.ui.model.Filter("bCCML2", sap.ui.model.FilterOperator.NE, true)
				], true)];

				this.getModel("subModel").read("/Cases", {
					filters: aFilters,
					urlParameters: {
						"$select": "CaseID,bCCML1,bCCML2"
					},
					success: function (oData) {
						//check if not a light case
						aData.forEach(function (c) {
							var oCase = oData.results.find(function (hanaCase) {
								return c.CaseId === hanaCase.CaseID.toString();
							});
							if (!oCase) {
								aFilteresData.push(c);
							}
						});
						resolve(aFilteresData);
					}
				});
			}.bind(this));*/

		},

		readProducts: function (oModel, aFilters) {
			var oList = this.getView().byId("CCMListId");
			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$expand": "toProducts",
					"$select": "CaseId,toProducts"
				},
				success: function (data) {
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					var aAlreadyAdded = oModel.getData().results;
					this._updateFilteredCount();
					data.results.forEach(function (oCase) {
						oCase.ProductVersions = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.Product = this.formatter.concatProducts(oCase.toProducts.results, "ProductT");
						oCase.ProductCategory = this.formatter.concatProducts(oCase.toProducts.results, "ProductCatT");
						oCase.ProductLine = this.formatter.concatProducts(oCase.toProducts.results, "ProductLineT");
						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.CaseId === oCase.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = oCase.toProducts;
								aTmp[i].toLastNotes = oCase.toLastNotes;
								aTmp[i].ProductVersions = oCase.ProductVersions;
								aTmp[i].Product = oCase.Product;
								aTmp[i].ProductCategory = oCase.ProductCategory;
								aTmp[i].ProductLine = oCase.ProductLine;
							});
						}

					}.bind(this));
					oModel.refresh();

				}.bind(this),
				error: function (data) {
					oList.setBusy(false);
				}.bind(this)
			});
		},

		readNotes: function (oControl, id, sObjectType) {
			//Just take the same filters from the base callvar aFilters = [];
			var oICModel = this.getOwnerComponent().getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oICModel.read("/CustomerEngagementSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results, sObjectType);
				}.bind(this),
				error: function () {
					//show busy indicator in Popoversap.ui.core.BusyIndicator.hide();();
					oControl.setBusy(false);
				}
			});
		},

		handleRatingIconTabBarSelect: function (oEv) {
			var oList = this.getView().byId("CCMListId");
			var sRatingKey = oEv.getSource().getSelectedKey();
			var aFilter = [];

			// Reset all table filters
			oList.getColumns().forEach(function (oColumn) {
				oColumn.filter(null);
				oColumn.setFilterValue("");
			});
			this.clearSearchField(oList);

			if (sRatingKey !== "All") {
				aFilter.push(new sap.ui.model.Filter("Rating", "EQ", sRatingKey));
			}
			oList.getBinding("items").filter(aFilter);
			this._updateFilteredCount();
		},

		onCase: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("data").getObject().CaseId;
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);
			this.getRouter().navTo("CaseDetailsMobile", {
				"?query": this._getQueryParameter(),
				"CaseId": sCaseId
			});
		},

		onCaseNewTab: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("data").getObject().CaseId;
			this._openCaseInNewTab(sCaseId);
		},

		onCustomer: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("data").getObject().CustomerErpNo;
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		_calculateRating: function (data) {
			var oViewModel = this.getView().getModel("viewModel");
			var iGreen = 0;
			var iYellow = 0;
			var iRed = 0;
			var iUnrated = 0;
			data.results.forEach(function (oCase) {
				switch (oCase.Rating) {
				case "A":
					iGreen++;
					break;
				case "B":
					iYellow++;
					break;
				case "C":
					iRed++;
					break;
				default:
					iUnrated++;
				}
			});
			oViewModel.setProperty("/iTabAll", data.results.length);
			oViewModel.setProperty("/iTabGreen", iGreen);
			oViewModel.setProperty("/iTabYellow", iYellow);
			oViewModel.setProperty("/iTabRed", iRed);
			oViewModel.setProperty("/iTabUnrated", iUnrated);
			this._updateFilteredCount();
		},

		_updateFilteredCount: function () {
			var oList = this.getView().byId("CCMListId");
			var iFilteredCount = oList.getBinding("items").getLength();
			var aFilters = oList.getBinding("items").aFilters;
			if (aFilters && aFilters.length > 0) {
				var iLengths = oList.getBinding("items").iLengths;
				if (iLengths) {
					iFilteredCount = oList.getBinding("items").iLength - iLengths.sum();
				} else {
					iFilteredCount = oList.getBinding("items").iLength;
				}
			}
			this.getView().getModel("viewModel").setProperty("/iTabFiltered", iFilteredCount);
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("data").getObject();
			var sObjectType = "";
			if (oData.CustomerType != "") {
				sObjectType = oData.CustomerType;
			}
			var sId = oData.CaseId;
			this.readNotes(oEv.getSource(), sId, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},

		changeCaseState: function () {
			this._updateTable();
		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("data").getObject();
			var sCaseId = oProperty.CaseId;
			this._shopTopIssuesCountPopover(sCaseId, oEv.getSource());
		},
		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("data").getPath();
			var oProperty = this.getModel("data").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		/*customSorting: function (oEvent) {
			var oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingColumn");
			var oMCCiColumn = this.byId("mcci");
			var oPreventionScoreColumn = this.byId("preventionScore");
			var oCurrentColumn = oEvent.getParameter("column");
			if (oCurrentColumn !== oGUMaintenanceRankingColumn && oCurrentColumn !== oMCCiColumn && oCurrentColumn !== oPreventionScoreColumn) {
				//oGUMaintenanceRankingColumn.setSorted(false); //No multi-column sorting
				return;
			}
			oEvent.preventDefault();
			var sOrder = oEvent.getParameter("sortOrder");
			if (oCurrentColumn == oMCCiColumn || oCurrentColumn == oPreventionScoreColumn) {
				this.customSortingBaseFloat(oCurrentColumn, sOrder, "CCMListId");
			} else {
				this.customSortingBase(oCurrentColumn, sOrder, oGUMaintenanceRankingColumn, "CCMListId");
			}
		},*/

		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("data").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		},

		onLiveSearchChange: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("CCMListId");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("CustomerText", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("CountryT", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter("RegionT", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter3);

			var oFilter4 = new sap.ui.model.Filter("CaseTitle", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter4);

			var oFilter5 = new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter5);

			var oRatingFilter;
			if (searchValue === "red") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C");
			} else if (searchValue === "yellow" || searchValue === "orange") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "B");
			} else if (searchValue === "green") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "A");
			} else {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.Contains, searchValue);
			}
			aFilters.push(oRatingFilter);

			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		}
		
	});
});