sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter"
], function (BaseController, formatter) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.controllerMobile.CriticalPeriodCoverageMobile", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				bLoadingState: false,
				// iTabAllPA: 0,
				// iTabGreenPA: 0,
				// iTabYellowPA: 0,
				// iTabRedPA: 0,
				// iTabUnratedPA: 0,
				iTabFiltered: 0,
				bLoadingStatePA: false,
				showObjectType: false
			}), "viewModel");
			this.getRouter().getRoute("CriticalPeriodCoverageMobile").attachPatternMatched(this._onObjectMatched, this);

		},

		onAfterRendering: function () {

		},

		onTabSelect: function (oEvent) {
			var oDataModel = this.getView().getModel("data");
			var oIconTabBar = this.getView().byId("idIconTabBarFiori2");
			var sSelectedKey = oIconTabBar.getSelectedKey();

			if (sSelectedKey === "ongoing") {
				oDataModel.setProperty("/taskForcesState", "open");
				this._updateTable();
			} else if (sSelectedKey === "planned") {
				oDataModel.setProperty("/taskForcesState", "open");
				this._updateTablePlannedActivities();
			} else if (sSelectedKey === "closed") {
				oDataModel.setProperty("/taskForcesState", "closed");
				this._updateTableClosed();
			}
		},

		_onObjectMatched: function (oEvent) {
			//Check if data was already loaded. If yes, use this data
			if (this.getOwnerComponent().getModel("data").getProperty("/reloadCriticalPeriodCoverage")) {
				this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "tableData");
				this.getOwnerComponent().getModel("data").setProperty("/reloadCriticalPeriodCoverage", false);
				this._updateTable();
				//this._updateTablePlannedActivities();
				//this._updateTableClosed();
			}

			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
		},

		_updateTable: function () {
			var aFilters = [];
			var oList = this.getView().byId("CPCListId");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			//var bCaseFilter = this.getOwnerComponent().getModel("data").getProperty("/taskForcesFilter");

			if (!bCaseState) {
				bCaseState = "open";
			}

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			if (bCaseState === "open" || bCaseState === "all") {
				var tileSpecificFilters1 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"), //New
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"), //In Progress
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"), //In Escalation
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99") //In Management Review
						], false)
					],
					true
				);
			}
			if (bCaseState === "closed" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
						], false),
						this.getClosedDateFilter("ClosingDate")
					],
					true
				);

			}

			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
						tileSpecificFilters1,
						tileSpecificFilters2
					],
					false
				));
			}

			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04"));

			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				// urlParameters: {
				// 	"$select": "CaseId,CaseTitle,CustomerText,Region,StatusT,Rating,CreateDate,CustomerErpNo,ServiceOrgT,HasNotes"
				// },
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);

					this._calculateRating(data);
					data.results.forEach(function (oCase) {
						if (oCase.Rating === "") {
							oCase.Rating = "unrated";
						}
						if (oCase.DbsMaintenanceRanking === "0") {
							oCase.DbsMaintenanceRanking = "";
						}
						oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);

						switch (oCase.CustomerType) {
						case "ZSCUSTYP05":
							oCase.objectType = "Critical Customer Management";
							break;
						case "ZSCUSTYP04":
							oCase.objectType = "Critical Period Coverage";
							break;
						}

					}.bind(this));
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "tableData");
					this.readImplementationPartner(oModel).then(function () {
						setTimeout(function () {
							oList.rerender();
						}, 200);
					}.bind(this));
					//MISSIONRADAR 2211	
					this.readMissionRadarValues(oModel, "results");
					this.loadProducts();

				}.bind(this),
				error: function (data) {
					oList.setBusy(false);
				}.bind(this)
			});
		},

		loadProducts: function () {
			var aFilters = [];
			var oList = this.getView().byId("CPCListId");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "open";
			}

			// if (sRegion) {
			// 	aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, sRegion));
			// }
			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			if (bCaseState === "open" || bCaseState === "all") {
				var tileSpecificFilters1 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"), //New
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"), //In Progress
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"), //In Escalation
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99") //In Management Review
						], false)
					],
					true
				);
			}
			if (bCaseState === "closed" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
						], false),
						this.getClosedDateFilter("ClosingDate")
					],
					true
				);

			}

			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
						tileSpecificFilters1,
						tileSpecificFilters2
					],
					false
				));
			}

			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04"));

			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$expand": "toProducts",
					"$select": "CaseId,toProducts"
				},
				success: function (data) {

					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					var oModel = this.getOwnerComponent().getModel("tableData");
					var aAlreadyAdded = oModel.getData().results;

					data.results.forEach(function (oCase) {
						oCase.ProductVersions = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.Product = this.formatter.concatProducts(oCase.toProducts.results, "ProductT");
						oCase.ProductCategory = this.formatter.concatProducts(oCase.toProducts.results, "ProductCatT");
						oCase.ProductLine = this.formatter.concatProducts(oCase.toProducts.results, "ProductLineT");
						oCase.ProductVer = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.ProductLineKeys = this.formatter.concatProducts(oCase.toProducts.results, "ProductLine");
						oCase.ProductKeys = this.formatter.concatProducts(oCase.toProducts.results, "Product");

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.CaseId === oCase.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = oCase.toProducts;
								aTmp[i].toLastNotes = oCase.toLastNotes;
								aTmp[i].ProductVersions = oCase.ProductVersions;
								aTmp[i].Product = oCase.Product;
								aTmp[i].ProductCategory = oCase.ProductCategory;
								aTmp[i].ProductLine = oCase.ProductLine;
								aTmp[i].ProductVer = oCase.ProductVer;
								aTmp[i].ProductLineKeys = oCase.ProductLineKeys;
								aTmp[i].ProductKeys = oCase.ProductKeys;
							});
						}
					}.bind(this));
					this._updateFilteredCount();
					oModel.refresh();
				}.bind(this),

				error: function (data) {
					oList.setBusy(false);
				}.bind(this)
			});
		},

		readNotes: function (oControl, id, sObjectType) {
			var oICModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oICModel.read("/CustomerEngagementSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results, sObjectType);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		handleRatingIconTabBarSelect: function (oEv) {
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			var oList = this.getView().byId("CPCListId");

			if (bCaseState === "closed") {
				oList = this.getView().byId("tableClosed");
			}

			var sRatingKey = oEv.getSource().getSelectedKey();
			var aFilter = [];

			// Reset all table filters
			oList.getColumns().forEach(function (oColumn) {
				oColumn.filter(null);
				oColumn.setFilterValue("");
			});
			this.clearSearchField(oList);

			if (sRatingKey !== "All") {
				aFilter.push(new sap.ui.model.Filter("Rating", "EQ", sRatingKey));
			}
			oList.getBinding("rows").filter(aFilter);
			this._updateFilteredCount();
		},

		onCase: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("tableData").getObject().CaseId;
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);
			this.getRouter().navTo("CaseDetailsMobile", {
				"?query": this._getQueryParameter(),
				"CaseId": sCaseId
			});
		},

		onCaseNewTab: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("tableData").getObject().CaseId;
			this._openCaseInNewTab(sCaseId);
		},

		onCustomer: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("tableData").getObject().CustomerErpNo;
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		_calculateRating: function (data) {
			var oViewModel = this.getView().getModel("viewModel");
			var iGreen = 0;
			var iYellow = 0;
			var iRed = 0;
			var iUnrated = 0;
			data.results.forEach(function (oCase) {
				switch (oCase.Rating) {
				case "A":
					iGreen++;
					break;
				case "B":
					iYellow++;
					break;
				case "C":
					iRed++;
					break;
				default:
					iUnrated++;
				}
			});
			oViewModel.setProperty("/iTabAll", data.results.length);
			oViewModel.setProperty("/iTabGreen", iGreen);
			oViewModel.setProperty("/iTabYellow", iYellow);
			oViewModel.setProperty("/iTabRed", iRed);
			oViewModel.setProperty("/iTabUnrated", iUnrated);
			this._updateFilteredCount();
		},

		_updateFilteredCount: function () {
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (bCaseState === "closed") {
				var oList = this.getView().byId("CPCListClosedId");
			} else {
				oList = this.getView().byId("CPCListId");
			}
			var iFilteredCount = oList.getBinding("items").getLength();
			var aFilters = oList.getBinding("items").aFilters;
			if (aFilters && aFilters.length > 0) {
				var iLengths = oList.getBinding("items").iLengths;
				if (iLengths) {
					iFilteredCount = oList.getBinding("items").iLength - iLengths.sum();
				} else {
					iFilteredCount = oList.getBinding("items").iLength;
				}
			}
			this.getView().getModel("viewModel").setProperty("/iTabFiltered", iFilteredCount);
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("tableData").getObject();
			var sObjectType = "";
			if (oData.CustomerType != "") {
				sObjectType = oData.CustomerType;
			}
			var sId = oData.CaseId;
			this.readNotes(oEv.getSource(), sId, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("tableData").getObject();
			var sCaseId = oProperty.CaseId;
			this._shopTopIssuesCountPopover(sCaseId, oEv.getSource());
		},

		_updateTablePlannedActivities: function () {
			var oICModel = this.getOwnerComponent().getModel();
			var aFilters = [];
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "open";
			}

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				oFilterForICP.aFilters = oFilterForICP.aFilters.filter(function (filter) {
					if (filter.aFilters && filter.aFilters.length > 0) {
						return filter.aFilters[0].sPath !== "SalesOrg" && filter.aFilters[0].sPath !== "ServiceOrg";
					}
					return true;
				});
				if (oFilterForICP.aFilters.length !== 0) {
					aFilters.push(oFilterForICP);
				}
			}

			if (bCaseState === "open" || bCaseState === "all") {
				var tileSpecificFilters1 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0011"), //In Process Backoffice
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0012"), //Responsible's Action
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0019"), //In MCC Focus Teams | E0020 = OBSOLETE
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0027") //?? | E0026 = Restricted
						], false)
					],
					true
				);
			}
			if (bCaseState === "closed" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0012"), //Responsible's Action
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0013"), //Confirmed
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0014"), //Completed
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0017"), //??
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0018") //??
						], false),
						this.getClosedDateFilter("ClosingDate")
					],
					true
				);

			}

			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
						tileSpecificFilters1,
						tileSpecificFilters2
					],
					false
				));
			}

			aFilters.push(new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "ZZM"));
			aFilters.push(new sap.ui.model.Filter("ActResult", sap.ui.model.FilterOperator.EQ, "Z2ZS460006"));

			this.getView().getModel("viewModel").setProperty("/bLoadingStatePA", true);

			var oPrioritySorter = new sap.ui.model.Sorter("Priority", false);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);
			return new Promise(function (resolve, reject) {
				oICModel.read("/MCCActivitiesSet", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					sorters: [oPrioritySorter, oChangeDateSorter],
					urlParameters: {
						"$expand": "toProducts"
					},
					success: function (data) {
						this.getView().getModel("viewModel").setProperty("/bLoadingStatePA", false);
						//	this._calculateRatingPA(data);
						data.results.forEach(function (result) {
							if (result.Rating === "") {
								result.Rating = "unrated";
							}
							if (result.Category === "ZZM") {
								result.objectType = "Planned CPC Engagment";
							}
							result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
							result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
							result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
							result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
							result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
							result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
							result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);
						}, this);
						var oModel = new sap.ui.model.json.JSONModel(data);
						this.getOwnerComponent().setModel(oModel, "dataPA");
					}.bind(this),
					error: function (data) {
						this.getView().getModel("viewModel").setProperty("/bLoadingStatePA", false);
					}.bind(this)
				});
			}.bind(this));

		},

		_updateTableClosed: function () {
			var aFilters = [];
			var oTable = this.getView().byId("tableClosed");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			var bCaseFilter = this.getOwnerComponent().getModel("data").getProperty("/taskForcesFilter");
			this.getView().byId("dataIconTabBarClosed").setSelectedKey("All");

			if (!bCaseState) {
				bCaseState = "closed";
			}

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			if (bCaseState === "closed" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
						], false),
						this.getClosedDateFilter("ClosingDate")
					],
					true
				);

			}

			if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
					tileSpecificFilters2
				], false));
			}

			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04"));

			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				// urlParameters: {
				// 	"$select": "CaseId,CaseTitle,CustomerText,Region,StatusT,Rating,CreateDate,CustomerErpNo,ServiceOrgT,HasNotes"
				// },
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);

					this._calculateRating(data);
					data.results.forEach(function (oCase) {
						if (oCase.Rating === "") {
							oCase.Rating = "unrated";
						}
						if (oCase.DbsMaintenanceRanking === "0") {
							oCase.DbsMaintenanceRanking = "";
						}
						oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);

						switch (oCase.CustomerType) {
						case "ZSCUSTYP05":
							oCase.objectType = "Critical Customer Management";
							break;
						case "ZSCUSTYP04":
							oCase.objectType = "Critical Period Coverage";
							break;
						}

					}.bind(this));
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "tableData");
					this.readImplementationPartner(oModel).then(function () {
						setTimeout(function () {
							oTable.rerender();
						}, 200);
					}.bind(this));
					//MISSIONRADAR 2211	
					this.readMissionRadarValues(oModel, "results");
					this.loadClosedProducts();

					if (bCaseFilter !== "none") {
						var oIconTabBar = this.getView().byId("dataIconTabBarClosed");
						oIconTabBar.setSelectedKey(bCaseFilter);
						oIconTabBar.fireSelect();
					}
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		loadClosedProducts: function () {
			var aFilters = [];
			var oTable = this.getView().byId("tableClosed");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "closed";
			}

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			if (bCaseState === "closed" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
						], false),
						this.getClosedDateFilter("ClosingDate")
					],
					true
				);

			}

			if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
					tileSpecificFilters2
				], false));
			}

			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04"));

			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$expand": "toProducts",
					"$select": "CaseId,toProducts"
				},
				success: function (data) {
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					var oModel = this.getOwnerComponent().getModel("tableData");
					var aAlreadyAdded = oModel.getData().results;

					data.results.forEach(function (oCase) {
						oCase.ProductVersions = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.Product = this.formatter.concatProducts(oCase.toProducts.results, "ProductT");
						oCase.ProductCategory = this.formatter.concatProducts(oCase.toProducts.results, "ProductCatT");
						oCase.ProductLine = this.formatter.concatProducts(oCase.toProducts.results, "ProductLineT");
						oCase.ProductVer = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.ProductLineKeys = this.formatter.concatProducts(oCase.toProducts.results, "ProductLine");
						oCase.ProductKeys = this.formatter.concatProducts(oCase.toProducts.results, "Product");

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.CaseId === oCase.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = oCase.toProducts;
								aTmp[i].toLastNotes = oCase.toLastNotes;
								aTmp[i].ProductVersions = oCase.ProductVersions;
								aTmp[i].Product = oCase.Product;
								aTmp[i].ProductCategory = oCase.ProductCategory;
								aTmp[i].ProductLine = oCase.ProductLine;
								aTmp[i].ProductVer = oCase.ProductVer;
								aTmp[i].ProductLineKeys = oCase.ProductLineKeys;
								aTmp[i].ProductKeys = oCase.ProductKeys;
							});
						}
					}.bind(this));
					this._updateFilteredCount();
					oModel.refresh();
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		handleOpenIssuesCasePress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("dataPA").getPath();
			var oProperty = this.getModel("dataPA").getProperty(sPath);

			if (oProperty.objectType === "Planned CPC Engagment") {
				this._openSosApp(oProperty["sys_id"], "&transType=sn_customerservice_escalation");
			}
			// else {
			// 	this._openSosApp(oProperty["active_escalation.sys_id"]);
			// }
		},

		handleCustomerPress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("dataPA").getPath();
			var oProperty = this.getModel("dataPA").getProperty(sPath);
			var sErpCustNo = oProperty.CustomerErpNo || oProperty.ErpCustNo || oProperty.CustomerNo;
			var oRouter = this.getRouter();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},
		onOpenUser: function (oEv) {
			// if (oEv.getSource().data("EmplRespUser")) {
			// 	this.formatter.openUser(oEv, oEv.getSource().data("EmplRespUser"));
			// } 
			// else
			if (oEv.getSource().data("userid")) {
				this.formatter.openUser(oEv, oEv.getSource().data("userid"));
			}
			//else {
			// 	this.formatter.openUser(oEv, oEv.getSource().data("useridBDM"));
			// }
		},
		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("tableData").getPath();
			var oProperty = this.getModel("tableData").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},
		handleGlobalUltimatePressPA: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("dataPA").getPath();
			var oProperty = this.getModel("dataPA").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		changeCaseState: function () {
			this._updateTable();
			this._updateTablePlannedActivities();
			this._updateTableClosed();
		},
		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("tableData").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		},

		onLiveSearchChange: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("CPCListId");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("CustomerText", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("CountryT", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter("RegionT", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter3);

			var oFilter4 = new sap.ui.model.Filter("CaseTitle", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter4);

			var oFilter5 = new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter5);

			var oRatingFilter;
			if (searchValue === "red") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C");
			} else if (searchValue === "yellow" || searchValue === "orange") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "B");
			} else if (searchValue === "green") {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "A");
			} else {
				oRatingFilter = new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.Contains, searchValue);
			}
			aFilters.push(oRatingFilter);

			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		}

	});
});