sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"com/sap/mcconedashboard/control/CustomFacetFilterList",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/utils/FilterComponent",
	"sap/ui/Device"
], function (BaseController, JSONModel, MessageToast, CustomFacetFilterList, formatter, FilterComponent, Device) {
	"use strict";
	return BaseController.extend("com.sap.mcconedashboard.controller.controllerMobile.GlobalMobile", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.mcconedashboard.view.Global
		 */
		// Check yearly IAC (Internal Account Classification) https://sap.sharepoint.com/teams/IDM/SitePages/GTM.aspx
		//values from 2020 iacValues: ["1", "8", "3", "T", "U", "O", "P"],
		//values for 2021 		iacValues: ["1", "8", "9", "G", "V", "I"],
		//values for 2022
		iacValues: ["X", "Y", "9", "V", "I", "Z"],
		formatter: formatter,

		_iGlobalLiveSearchRequestId: 0,

		onInit: function () {

			// define default structure of searchModel
			var oSearchModel = new JSONModel({
				data: []
			});
			this.getView().setModel(oSearchModel, "searchModel");

			//attachPatternMatched
			this.getRouter().getRoute("GlobalMobile").attachPatternMatched(this.onObjectMatched, this);

			//initialize filter component
			this.oFilterComponent = new FilterComponent(this);

			this._loadSolutions();
			//	this._loadServiceTeams();
			if (!this.getOwnerComponent().getModel("variantManagement")) {
				this._loadVariants("GLOBAL");
			}

			//In Case the Browser sends beforeInstallPrompt, save the event in a variable to handle the installation 
			this._deferredPrompt = null;
			window.addEventListener('beforeinstallprompt', function (event) {
				// Prevent the mini-infobar from appearing on mobile
				//event.preventDefault();
				// Stash the event so it can be triggered later.
				this._deferredPrompt = event;
				// Optionally, send analytics event that PWA install promo was shown.
				console.log("beforeinstallprompt triggered.");
			});

		},

		onAfterRendering: function () {
			var oTabBar = this.getView().byId("globalIconTabBarMobile");
			this.onNavToEngagementList();

			var oFavModel = this.getModel("userProfile");
			//set local favorite model to empty array to avoid duplicates on favorite

			this.getView().byId("favoriteList").getBinding("items").attachChange(function (oEv) {
				var aContent = this.getView().byId("favoriteList").getItems();
				//check always all tiles if background image is set. otherwise load it
				aContent.forEach(function (listItem) {
					var oData = listItem.getBindingContext("favoriteModel").getObject();
					if (!listItem.getProperty("icon") || listItem.getProperty("icon") == "sap-icon://building") {
						this._loadCustomerLogo(oData.Partner, listItem);
					}
				}.bind(this));
			}.bind(this));

			if (!this.getModel("favoriteModel").getProperty("/userFavorites") || this.getModel("favoriteModel").getProperty("/reload")) {
				this.getModel("favoriteModel").setProperty("/reload", false);
				this.getView().getModel("favoriteModel").setProperty("/listEntries", []);
				this.getView().byId("favoriteList").setBusyIndicatorDelay(0);
				this.getView().byId("favoriteList").setBusy(true);
				oFavModel.read("/Entries", {
					filters: [new sap.ui.model.Filter("Attribute", sap.ui.model.FilterOperator.EQ, "FAVORITE_CUSTOMERS")],
					success: function (data) {
						this.getView().byId("favoriteList").setBusy(false);
						this.getModel("favoriteModel").setProperty("/userFavorites", data.results);
						this._getFavoriteCustomerData(data.results);
					}.bind(this),
					error: function (data) { }
				});
			}

			//nav to event calendar
			if (this.getOwnerComponent().getModel("settings").getProperty("/initialTabSelection") !== "") {
				oTabBar.setSelectedKey(this.getOwnerComponent().getModel("settings").getProperty("/initialTabSelection"));
			}
			if (this.getOwnerComponent().getModel("settings").getProperty("/initialTabSelection") === "eventCalendar") {
				this.getOwnerComponent().getModel("settings").setProperty("/showHeaderOnStartPage", false);
			} else {
				this.getOwnerComponent().getModel("settings").setProperty("/showHeaderOnStartPage", true);
			}

			//Check if Footer should be shown when loading page
			this.checkFooterStatus();

			//Show Fiori Image as App Icon Preview
			this.getView().byId("appImage").setSrc(sap.ui.require.toUrl("com/sap/mcconedashboard/image/SAP_Fiori_Launchpad.png"));

		},

		onObjectMatched: function (oEv) {
			this.getOwnerComponent().getModel("settings").setProperty("/isInChartsTile", false);
			this.getOwnerComponent().getModel("settings").setProperty("/isInOperationalKPITile", false);

			var oTabBar = this.getView().byId("globalIconTabBarMobile");
			var oArgs = oEv.getParameter("arguments");

			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);

			var oFaceFilterSelection = this.getOwnerComponent().getModel("filterModel").getProperty("/facetFilterSelection");
			if (!this.getOwnerComponent().getModel("settings").getProperty("/initialReadOfVariantManagement")) {
				this.oFilterComponent.syncFacetFilters(oFaceFilterSelection, false);
			} else {
				this.oFilterComponent.syncFacetFilters(oFaceFilterSelection, true);
			}
			var sTab = "";
			if (oArgs["?query"] && oArgs["?query"].tab) {
				sTab = oArgs["?query"].tab;
			} else if (jQuery.sap.getUriParameters()._get("tab") && jQuery.sap.getUriParameters()._get("tab") !== "") {
				sTab = jQuery.sap.getUriParameters()._get("tab");
			}
			if (sTab === "eventCalendar") {
				oTabBar.setSelectedKey("eventCalendar");
				this.getOwnerComponent().getModel("settings").setProperty("/showHeaderOnStartPage", false);
			}
		},

		_loadCustomerLogo: function (sErpCustNo, listItem) {
			var oSettings = this.getOwnerComponent().getModel("settings");
			sErpCustNo = oSettings.getProperty("/isAnonymizedMode") ? "" : sErpCustNo;
			if (sErpCustNo && sErpCustNo !== "" && sErpCustNo !== null) {
				var sPath = sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/ic/sap/opu/odata/sap/";
				var sUrl = sPath + "ZS_APP_DEP_SRV/CustomerSet('" + sErpCustNo + "')/$value";

				this._getImageStream(sUrl).then(function (sBase64) {
					listItem.setIcon(sBase64);
				}.bind(this));
			}
		},

		checkFooterStatus: function () {
			var oDynamicPage = this.getView().byId("dynamicPageId");
			var oPersonalizationService;
			var oComponent;

			// Verify that the app was opened from the Fiori Launchpad
			if (sap.ushell && sap.ushell.Container) {
				oPersonalizationService = sap.ushell.Container.getServiceAsync("Personalization");
				oComponent = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			} else {
				// app not opened from the Fiori Launchpad
				if (!this.isBannerClosedCookieSet()) {
					oDynamicPage.setShowFooter(true);
				}
				return;
			}

			var oScope = {
				keyCategory: oPersonalizationService.constants.keyCategory.FIXED_KEY,
				writeFrequency: oPersonalizationService.constants.writeFrequency.LOW,
				clientStorageAllowed: true
			};

			var oPersId = {
				container: "MCCOneDashboardFooterContainer",
				item: "footerClosed"
			};

			var oPersonalizer = oPersonalizationService.getPersonalizer(oPersId, oScope, oComponent);

			var that = this;
			var oReadPromise = oPersonalizer.getPersData()
				.done(function (oPersData) {
					// Handle old oPersData without entries property
					if (!oPersData || !oPersData.entries) {
						// Delete old oPersData without entries
						var oDeletePromise = oPersonalizer.delPersData()
							.done(function () {
								that.setBannerClosedCookie();
								oDynamicPage.setShowFooter(true);
							})
							.fail(function () {
								jQuery.sap.log.error("Failed to delete old personalization data.");
								that.setBannerClosedCookie();
								oDynamicPage.setShowFooter(true);
							});
						return;
					}

					var currentScreenSize = {
						height: sap.ui.Device.resize.height,
						width: sap.ui.Device.resize.width
					};

					var shouldShowFooter = true;

					oPersData.entries.forEach(function (entry) {
						if (entry.device === navigator.userAgent &&
							entry.devSize.height === currentScreenSize.height &&
							entry.devSize.width === currentScreenSize.width) {
							var currentDate = new Date();
							var closedDate = new Date(entry.footerClosedTimestamp);
							var timeDiff = currentDate.getTime() - closedDate.getTime();
							var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));

							if (daysDiff <= 3) {
								shouldShowFooter = false;
							}
						}
					});

					if (shouldShowFooter) {
						oDynamicPage.setShowFooter(true);
					} else {
						oDynamicPage.setShowFooter(false);
					}
				})
				.fail(function () {
					jQuery.sap.log.error("Failed to read personalization data.");
					// Service is unavailable, fall back to cookie checking
					if (!this.isBannerClosedCookieSet()) {
						// No cookie available, show the footer
						oDynamicPage.setShowFooter(true);
					}
				});
		},

		onCloseFooter: function () {
			var oDynamicPage = this.getView().byId("dynamicPageId");
			var oPersonalizationService;
			var oComponent;

			// Verify that the app was opened from the Fiori Launchpad
			if (sap.ushell && sap.ushell.Container) {
				oPersonalizationService = sap.ushell.Container.getServiceAsync("Personalization");
				oComponent = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			} else {
				// The app was not opened from the Fiori Launchpad, use Cookies instead
				this.setBannerClosedCookie();
				oDynamicPage.setShowFooter(false);
				return;
			}

			var oScope = {
				keyCategory: oPersonalizationService.constants.keyCategory.FIXED_KEY,
				writeFrequency: oPersonalizationService.constants.writeFrequency.LOW,
				clientStorageAllowed: true
			};

			var oPersId = {
				container: "MCCOneDashboardFooterContainer",
				item: "footerClosed"
			};

			var oPersonalizer = oPersonalizationService.getPersonalizer(oPersId, oScope, oComponent);

			var that = this;
			var oReadPromise = oPersonalizer.getPersData()
				.done(function (oPersData) {
					// Check if the personalization data is present, otherwise initialize
					if (!oPersData) {
						oPersData = {
							entries: []
						};
					}

					var currentScreenSize = {
						height: sap.ui.Device.resize.height,
						width: sap.ui.Device.resize.width
					};

					// Check if an entry for this device and size already exists
					var existingEntry = oPersData.entries.find(function (entry) {
						return entry.device === navigator.userAgent &&
							entry.devSize.height === currentScreenSize.height &&
							entry.devSize.width === currentScreenSize.width;
					});

					if (!existingEntry) {
						// Add a new entry for this device and size
						oPersData.entries.push({
							footerClosed: true,
							footerClosedTimestamp: new Date(),
							device: navigator.userAgent,
							devSize: {
								height: sap.ui.Device.resize.height,
								width: sap.ui.Device.resize.width
							}
						});

						// Save changes
						var oSavePromise = oPersonalizer.setPersData(oPersData)
							.done(function () {
								oDynamicPage.setShowFooter(false);
							})
							.fail(function () {
								jQuery.sap.log.error("Failed to save personalization data.");
								that.setBannerClosedCookie();
								oDynamicPage.setShowFooter(false);
							});
					}
				})
				.fail(function () {
					jQuery.sap.log.error("Failed to read personalization data.");
					that.setBannerClosedCookie();
					oDynamicPage.setShowFooter(false);
				});
		},

		// Set Cookie for not showing the banner again
		setBannerClosedCookie: function () {
			var sCookieName = "bannerClosed";
			var sCookieValue = "true";

			// Cookie unavailable tomorrow 0:00
			var oExpirationDate = new Date();
			oExpirationDate.setDate(oExpirationDate.getDate() + 1);
			oExpirationDate.setHours(0, 0, 0, 0);

			// Set Cookie
			document.cookie = sCookieName + "=" + sCookieValue + "; expires=" + oExpirationDate.toUTCString() + "; path=/";
		},

		// Check for Cookie
		isBannerClosedCookieSet: function () {
			var sCookieName = "bannerClosed";
			var cookies = document.cookie.split(';');

			for (var i = 0; i < cookies.length; i++) {
				var cookie = cookies[i].trim();
				if (cookie.indexOf(sCookieName + "=") === 0) {
					return true;
				}
			}

			return false;
		},

		//Used to toggle the banner
		onToggleFooter: function () {
			this.getView().byId("dynamicPageId").setShowFooter(!this.getView().byId("dynamicPageId").getShowFooter());
		},

		onInstallButtonPress: function () {

			// IOS
			if (sap.ui.Device.os.ios) {
				sap.m.MessageToast.show("Just tap 'Share' then 'Add to Home Screen'");

				// Desktop
			} else if (sap.ui.Device.system.desktop) {
				sap.m.MessageToast.show("Just tap the '\u2606' to add this page to your bookmarks");

				// Android (trying to automatically add Home Screen Icon)
			} else if (sap.ui.Device.os.android) {
				sap.m.MessageToast.show("Just tap ' \u22EE ' then 'Add to Home screen'");
				//this.addToHomeScreen();
			}
		},

		addToHomeScreen: function () {
			this._deferredPrompt.prompt();
		},

		onCustomerPress: function (oEvent) {
			//navigate to customer fact sheet with ErpCustNo
			var sPath = oEvent.getSource().getBindingContext("favoriteModel").getPath();
			var sErpCustNo = this.getModel("favoriteModel").getProperty(sPath).ErpCustNo;
			this._navToCustomerFactSheet(sErpCustNo);
			this.trackEvent("Customer: display - favorite tile");
		},

		_navToCustomerFactSheet: function (sErpCustNo) {
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			var oRouter = this.getRouter();
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
			this.trackEvent("Customer: display - search result");
		},

		_updateFavriteCustomerModel: function (oObject) {
			var oFavModel = this.getModel("favoriteModel");
			var aFavCustomer = oFavModel.getProperty("/listEntries");
			aFavCustomer.push(oObject);
			oFavModel.setProperty("/listEntries", aFavCustomer);
		},

		onLiveSearchChangeFavorites: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("favoriteList");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter("TrendRounded", sap.ui.model.FilterOperator.EQ, searchValue);
			aFilters.push(oFilter3);

			var oFilter4 = new sap.ui.model.Filter("preventionScoreDesc", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter4);

			var oFilter5 = new sap.ui.model.Filter("MasterCodeT", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter5);

			var oFilter6 = new sap.ui.model.Filter("Partner", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter6);

			var oFilter7 = new sap.ui.model.Filter("ErpCustNo", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter7);

			var oFilter8 = new sap.ui.model.Filter("GEM_CASES/value", sap.ui.model.FilterOperator.EQ, searchValue);
			aFilters.push(oFilter8);

			var oFilter9 = new sap.ui.model.Filter("TC2_CASES/value", sap.ui.model.FilterOperator.EQ, searchValue);
			aFilters.push(oFilter9);

			var oFilter10 = new sap.ui.model.Filter("OtherCases", sap.ui.model.FilterOperator.EQ, searchValue);
			aFilters.push(oFilter10);

			var oFilter11 = new sap.ui.model.Filter("MCCiRounded", sap.ui.model.FilterOperator.EQ, searchValue);
			aFilters.push(oFilter11);



			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		},

		onFavoritePress: function (oEvent) {
			var oFavoriteButton = oEvent.getSource();
			var sCustomerKey = oFavoriteButton.getParent().getBindingContext("searchModel").getObject().key;
			var sIcon = oEvent.getSource().getIcon();
			var oFavModel = this.getModel("userProfile");
			var aPromises = [];

			var oPromise = new Promise(function (resolve) {
				if (sIcon === "sap-icon://unfavorite") {
					var aFavorites = this.getModel("favoriteModel").getProperty("/userFavorites");
					for (var i = 0; i < aFavorites.length; i++) {
						if (aFavorites[i].Value === this._addLeadingZeros(sCustomerKey)) {
							var sField = aFavorites[i].Field;
							this.getView().getModel("favoriteModel").setProperty("/loadingFavorites", false);
							oFavModel.remove("/Entries(Username='',Attribute='FAVORITE_CUSTOMERS',Field='" + sField + "')", {
								success: function () {
									MessageToast.show("Favorite customer successfully removed.");
									oFavoriteButton.setIcon("sap-icon://add-favorite");
									oFavoriteButton.setTooltip(this.getResourceBundle().getText("addToFav"));
									resolve();
								}.bind(this),
								error: function () {
									MessageToast.show("Error when removing favorite customer.");
									//favoriteBtn.setEnabled(true);
								}.bind(this)
							});
							/*favoriteBtn.setIcon("sap-icon://add-favorite");
							favoriteBtn.setTooltip("Add to favorite");*/
						}
					}
				} else {
					this.getView().getModel("favoriteModel").setProperty("/loadingFavorites", false);
					oFavModel.create("/Entries", {
						"Attribute": "FAVORITE_CUSTOMERS",
						"Value": this._addLeadingZeros(sCustomerKey)
					}, {
						success: function (e) {
							MessageToast.show("Favorite customer successfully added.");
							oFavoriteButton.setIcon("sap-icon://unfavorite");
							oFavoriteButton.setTooltip(this.getResourceBundle().getText("removeFromFav"));
							resolve();
						}.bind(this),
						error: function (e) {
							MessageToast.show("Error when adding favorite customer");
							// favoriteBtn.setEnabled(true);
						}.bind(this)
					});
					this.trackEvent("Favorite: added - favorite search");
				}
			}.bind(this));
			aPromises.push(oPromise);

			Promise.all(aPromises).then(function () {
				oFavModel.read("/Entries", {
					filters: [new sap.ui.model.Filter("Attribute", sap.ui.model.FilterOperator.EQ, "FAVORITE_CUSTOMERS")],
					success: function (data) {
						this.getView().getModel("favoriteModel").setProperty("/listEntries", []);
						this.getModel("favoriteModel").setProperty("/userFavorites", data.results);
						this._getFavoriteCustomerData(data.results);
					}.bind(this),
					error: function (data) {
						this.getView().getModel("favoriteModel").setProperty("/loadingFavorites", true);
					}.bind(this)
				});
			}.bind(this));

		},

		navToSolution: function (oEv, oTitle) {
			var sSolutionKey = oEv.getSource().getBindingContext("solutions").getObject().SolKey;

			//var oTitle = oEv.getSource().getParent().getItems()[0].getText();
			var sKey = "";
			switch (oTitle) {
				case "All":
					sKey = "All";
					break;
				case "GEM":
					sKey = "GlobalEscalations";
					break;
				case "BDS":
					sKey = "BusinessDownSituations";
					break;
				case "CCM":
					sKey = "CriticalCustomerManagement";
					break;
			}

			if (this.getOwnerComponent().getModel("solutionModel")) {
				this.getOwnerComponent().getModel("solutionModel").setProperty("/reload", true);
				this.getOwnerComponent().getModel("solutionModel").setProperty("/preSelectKey", sKey);
			} else {
				this.getOwnerComponent().setModel(new JSONModel({
					preSelectKey: sKey,
					reload: true
				}), "solutionModel");
			}

			var oRouter = this.getRouter();
			oRouter.navTo("SolutionMobile", {
				"?query": this._getQueryParameter(),
				Solution: sSolutionKey
			});
			this.trackEvent("Solution: display - main tile");
		},

		/*_getFavoriteCustomerData: function (aFavorites) {
		   var oModel = this.getModel();
		   aFavorites.forEach(function (oEntry) {
			   var sEntity = "/CustomerSet('" + oEntry.Value + "')";
			   oModel.read(sEntity, {
				   success: function (data) {
					   this._updateFavriteCustomerModel(data);
					   this.getView().getModel("favoriteModel").setProperty("/loadingFavorites", true);
				   }.bind(this),
				   error: function (data) {}
			   });
		   }, this);
	   }, */

		_getFavoriteCustomerData: function (aFavorites) {
			const oModel = this.getModel();
			const oView = this.getView();
			const oFavoriteModel = oView.getModel("favoriteModel");
			const oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			this.getModel("favoriteModel").setProperty("/userFavorites", aFavorites);

			const aPromises = aFavorites.map((oEntry) => {
				if (!oEntry.Value) {
					return Promise.reject();
				}
				const sEntity = `/CustomerSet('${oEntry.Value}')`;

				return new Promise((resolve, reject) => {
					oModel.read(sEntity, {
						success: (data) => {
							this._updateFavoriteCustomerModel(data);
							oFavoriteModel.setProperty("/loadingFavorites", true);
							resolve();
						},
						error: () => {
							reject();
						}
					});
				});
			});

			Promise.all(aPromises)
				.then(() => this._loadCustomerLogosForFavoriteList())
				.finally(() => this.addMCCiValues(aFavorites))
				.catch((error) => {
					var dialog = new sap.m.Dialog({
						title: oResourceBundle.getText("errorHeader"),
						type: "Message",
						state: "Error",
						content: new sap.ui.layout.VerticalLayout({
							content: [new sap.m.Text({
								text: "Error loading favorite customer data"
							})]
						}),
						beginButton: new sap.m.Button({
							text: "Close",
							press: function () {
								dialog.close();
							}
						}),
						afterClose: function () {
							dialog.destroy();
						}
					});
					dialog.addStyleClass("sapUiContentPadding");
					dialog.open();
				});
		},

		_updateFavoriteCustomerModel: function (oObject) {
			var oFavModel = this.getModel("favoriteModel");
			var aFavCustomer = oFavModel.getProperty("/listEntries");
			aFavCustomer.push(oObject);
			oFavModel.setProperty("/listEntries", aFavCustomer);
		},

		_loadCustomerLogosForFavoriteList: function () {
			return new Promise((resolve) => {
				const oSettings = this.getOwnerComponent().getModel("settings");

				if (oSettings.getProperty("/isAnonymizedMode")) {
					resolve();
					return;
				}

				const oFavoriteModel = this.getModel("favoriteModel");
				const aFavorites = oFavoriteModel.getProperty("/listEntries");

				if (!aFavorites || aFavorites.length === 0) {
					resolve();
					return;
				}

				const sPath = sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/ic/sap/opu/odata/sap/";
				const aPromises = aFavorites.map((oEntry) => {
					if (!oEntry.Partner) {
						return Promise.resolve(oEntry);
					}
					const sUrl = `${sPath}ZS_APP_DEP_SRV/CustomerSet('${oEntry.Partner}')/$value`;

					return this._getImageStream(sUrl)
						.then((sBase64) => {
							oEntry.customerAvatar = sBase64;
							return oEntry;
						})
						.catch((error) => {
							console.error(`Can't load Avatar for Customer ${oEntry.Partner}`, error);
							return oEntry;
						});
				});

				Promise.all(aPromises)
					.then((aResults) => {
						oFavoriteModel.setProperty("/listEntries", aResults);
						resolve();
					})
					.catch((error) => {
						console.error("Error while loading Avatars:", error);
						resolve();  // We call resolve even if there's an error to avoid blocking the chain
					});
			});
		},

		addMCCiValues: function (aFavorites) {
			var oTrendModel = new sap.ui.model.json.JSONModel();
			var that = this;

			//Create an Array of all Customer IDs in the FavoriteModel to search for specific CustomerIDs in the TrendData 
			var aERPAccounts = [];
			var readERPAccountsPromise = new Promise((resolve) => {
				if (aFavorites && aFavorites && Array.isArray(aFavorites)) {
					aFavorites.forEach(function (item) {
						if (item.Value) {
							aERPAccounts = aERPAccounts.concat(item.Value);
						}
					});
				}
				resolve();
			});

			readERPAccountsPromise.then(() => {
				var readMissionRadarGoLiveTrendDataPromise = new Promise((resolve) => {
					if (aERPAccounts.length > 0) {
						this.readMissionRadarGoLiveTrendData(oTrendModel, aERPAccounts, function () {
							var oData = oTrendModel.getData();
							if (oData && oData.items && Array.isArray(oData.items)) {
								oData.items.forEach(function (item) {
									item.MCCiRounded = Math.round(item.MCCI.value);
									item.TrendRounded = Math.round(item.TREND_28_DAYS.value);
									item.TrendRoundedThreeDays = Math.round(item.TREND_3_DAYS.value);
									item.OtherCases = item.CPC_CASES.value + item.CCM_CASES.value + item.TF_CASES.value;
									that.addTrendCalculations(item, that);
								});
								oTrendModel.setData(oData);
							}
							resolve();
						});
					} else {
						reject();
					}
				});

				readMissionRadarGoLiveTrendDataPromise.then(() => {
					that.mergeTrendDataIntoFavoriteModel(oTrendModel);
				});
			});
		},

		addTrendCalculations: function (item, that) {
			item.preventionScoreDesc = that.formatter._formatTrendDesc(Math.round(item.TREND_28_DAYS.value));
			item.preventionScoreColor = that.formatter._formatTrendColor(Math.round(item.TREND_28_DAYS.value));
			item.preventionScoreIcon = that.formatter._formatTrendIcon(Math.round(item.TREND_28_DAYS.value));
			item.preventionScoreThreeDaysDesc = that.formatter._formatTrendDesc(Math.round(item.TREND_3_DAYS.value));
			item.preventionScoreThreeDaysColor = that.formatter._formatTrendColor(Math.round(item.TREND_3_DAYS.value));
			item.preventionScoreThreeDaysIcon = that.formatter._formatTrendIcon(Math.round(item.TREND_3_DAYS.value));
		},

		mergeTrendDataIntoFavoriteModel: function (oTrendModel) {
			var that = this;
			var oFavoriteModel = this.getModel("favoriteModel");
			if (!oFavoriteModel || !oTrendModel) {
				// No Models - abort
				return;
			}

			var oFavoritesData = oFavoriteModel.getProperty("/listEntries");
			var oTrendData = oTrendModel.getData();

			if (!oFavoritesData || !oTrendData) {
				// No data - abort
				return;
			}

			// Create a Map-Object for fast usage of trend data
			var trendDataMap = new Map();
			if (oTrendData.items) {
				oTrendData.items.forEach(function (trendItem) {
					trendDataMap.set(trendItem.ERP_Account.key, trendItem);
				});
			}

			// Go threw Favorites-Data and merge
			oFavoritesData.forEach(function (favItem) {
				var key = that._addLeadingZeros(favItem.ErpCustNo);
				if (trendDataMap.has(key)) {
					var trendItem = trendDataMap.get(key);
					favItem.preventionScoreDesc = trendItem.preventionScoreDesc;
					favItem.preventionScoreColor = trendItem.preventionScoreColor;
					favItem.preventionScoreIcon = trendItem.preventionScoreIcon;
					favItem.Trend = trendItem.Trend;
					favItem.MCCI = trendItem.MCCI;
					favItem.TrendRounded = trendItem.TrendRounded;
					favItem.MCCiRounded = trendItem.MCCiRounded;
					favItem.TrendRoundedThreeDays = trendItem.TrendRoundedThreeDays;
					favItem.TREND_3_DAYS = trendItem.TREND_3_DAYS;
					favItem.TREND_28_DAYS = trendItem.TREND_28_DAYS;
					favItem.OPEN_NOW_P1 = trendItem.OPEN_NOW_P1;
					favItem.OPEN_NOW_P2 = trendItem.OPEN_NOW_P2;
					favItem.GEM_CASES = trendItem.GEM_CASES;
					favItem.CPC_CASES = trendItem.CPC_CASES;
					favItem.TC2_CASES = trendItem.TC2_CASES;
					favItem.TF_CASES = trendItem.TF_CASES;
					favItem.CCM_CASES = trendItem.CCM_CASES;
					favItem.Internal_Sales_Segment = trendItem.Internal_Sales_Segment;
					favItem.OtherCases = trendItem.OtherCases;
				}
			});

			// Check and set MCCiRounded to -1 if still no value to sort them at the bottom for desc ordering
			oFavoritesData.forEach(function (favItem) {
				if (favItem.MCCiRounded === undefined || favItem.MCCiRounded === null) {
					favItem.MCCiRounded = -1;
				}
			});

			// Set new data to Fav Model
			oFavoriteModel.setProperty("/listEntries", oFavoritesData);
			this.getView().byId("favoriteList").getModel().refresh(true);
			this.getView().byId("favoriteList").getBinding("items").refresh();
		},

		growingFavsFinished: function (oEvent) {
			// Handle the update finished event to check if the growing has happened
			this._loadCustomerLogosForFavoriteList();

		},

		_loadSolutions: function () {
			this.getModel("appDepModelNoBatch").read("/SolutionSet", {
				urlParameters: {
					"$expand": "toSolutionProdLin",
					"$orderby": "Description"
				},
				success: function (oData) {
					oData.results.unshift({
						toSolutionProdLin: {
							results: []
						},
						SolKey: "All",
						Description: "All"
					});
					this.getView().setModel(new sap.ui.model.json.JSONModel(oData.results), "solutions");
				}.bind(this)
			});
		},

		onNavToExecutiveAssistance: function () {
			if (this.getOwnerComponent().getModel("data")) {
				this.getOwnerComponent().getModel("data").setProperty("/reload", true);
				this.getOwnerComponent().getModel("data").setProperty("/executiveAssistanceState", "open");
			}

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.navTo("ExecutiveAssistanceMobile", {
				"?query": this._getQueryParameter()
			});
			this.trackEvent("Executive Assistance: display - main tile");
		},

		onNavToTopCriticalCustomers: function (oEvent) {
			if (this.getOwnerComponent().getModel("data")) {
				this.getOwnerComponent().getModel("data").setProperty("/reloadTopCriticalCustomers", true);
				this.getOwnerComponent().getModel("data").setProperty("/taskForcesState", "open");
				this.getOwnerComponent().getModel("data").setProperty("/taskForcesFilter", "none");
			}

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("TopCriticalCustomersMobile", {
				"?query": this._getQueryParameter(),
			}); //Guided Solution Support
			this.trackEvent("Top Critical Customers display - main tile");
		},

		onNavToEngagementsTaskForces: function (oEvent) {
			if (this.getOwnerComponent().getModel("data")) {
				this.getOwnerComponent().getModel("data").setProperty("/reloadEngagementTaskForces", true);
			}
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("EngagementTaskForcesMobile", {
				"?query": this._getQueryParameter(),
			});
			this.trackEvent("Task Forces: display - main tile");
		},

		onNavToCustomerVisits: function (oEvent) {
			if (this.getOwnerComponent().getModel("data")) {
				this.getOwnerComponent().getModel("data").setProperty("/reloadCustomerVisits", true);
				this.getOwnerComponent().getModel("data").setProperty("/customerVisitsState", "open");
			}

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CustomerVisitsMobile", {
				"?query": this._getQueryParameter(),
			}); //Guided Solution Support
			this.trackEvent("Customer Visits display - main tile");
		},

		onNavToCriticalEventCoverage: function (oEvent) {
			if (this.getOwnerComponent().getModel("data")) {
				this.getOwnerComponent().getModel("data").setProperty("/reloadCriticalEventCoverage", true);
			}

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CriticalEventCoverageMobile", {
				"?query": this._getQueryParameter(),
			});
			this.trackEvent("Critical Event Coverage display - main tile");
		},

		onNavToCreEngagements: function (oEvent) {
			if (this.getOwnerComponent().getModel("data")) {
				this.getOwnerComponent().getModel("data").setProperty("/reloadCreEngagements", true);
			}

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CREEngagementsMobile", {
				"?query": this._getQueryParameter(),
			});
			this.trackEvent("CR&E Engagements display - main tile");
		},


		onNavToProjectsOnWatch: function (oEvent) {
			if (this.getOwnerComponent().getModel("data")) {
				this.getOwnerComponent().getModel("data").setProperty("/reloadProjectsOnWatch", true);
			}

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ProjectsOnWatchMobile", {
				"?query": this._getQueryParameter(),
			}); //Guided Solution Support
			this.trackEvent("Projects on Watch display - main tile");
		},

		onNavToInitiativesTaskForces: function (oEvent) {
			var oSplitContainer = this.byId("splitContainerEng");
			oSplitContainer.toDetail(this.createId("taskForcesPage"));
		},

		onNavToEngagementList: function () {
			var oSplitContainer = this.getView().byId("splitContainerEng");
			oSplitContainer.toDetail(this.createId("engagementPage"));
		},

		onNavToCriticalPeriodCoverage: function (oEvent) {
			if (this.getOwnerComponent().getModel("data")) {
				this.getOwnerComponent().getModel("data").setProperty("/reloadCriticalPeriodCoverage", true);
				this.getOwnerComponent().getModel("data").setProperty("/taskForcesState", "open");
				this.getOwnerComponent().getModel("data").setProperty("/taskForcesFilter", "none");
			}
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CriticalPeriodCoverageMobile", {
				"?query": this._getQueryParameter(),
			});
			this.trackEvent("Critical Period Coverage: display - main tile");
		},

		onNavToMCCCases: function (oEvent) {
			if (this.getOwnerComponent().getModel("data")) {
				this.getOwnerComponent().getModel("data").setProperty("/reloadCriticalCustomerManagement", true);
				this.getOwnerComponent().getModel("data").setProperty("/criticalCustomerManagementCaseState", "open");
				this.getOwnerComponent().getModel("data").setProperty("/criticalCustomerManagementFilter", "none");
			}
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CriticalCustomerManagementMobile", {
				"?query": this._getQueryParameter(),
			});
			this.trackEvent("Critical Customer Management: display - main tile");
		},

		onNavToBusinessDown: function (oEvent) {
			if (this.getOwnerComponent().getModel("businessDownSituations")) {
				this.getOwnerComponent().getModel("businessDownSituations").setProperty("/reload", true);
			}
			this.getOwnerComponent().getModel("data").setProperty("/businessDownSituationsCaseState", "open");
			this.getOwnerComponent().getModel("data").setProperty("/businessDownSituationsCaseFilter", "none");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("BusinessDownSituationMobile", {
				"?query": this._getQueryParameter(),
			});
			this.trackEvent("Business Down: display - main tile");
		},

		onNavToPECriticalSituations: function () {

			if (this.getOwnerComponent().getModel("peCriticalSituations")) {
				this.getOwnerComponent().getModel("peCriticalSituations").setProperty("/reload", true);
			}
			this.getOwnerComponent().getModel("data").setProperty("/peCriticalSituationsCaseState", "open");
			this.getOwnerComponent().getModel("data").setProperty("/peCriticalSituationsCaseFilter", "none");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.navTo("PECriticalSituationMobile", {
				"?query": this._getQueryParameter()
			});
			this.trackEvent("PE Critical Situations: display - main tile");
		},

		navToMcsDashboard: function (oEvent) {
			//in case if Anonymization Mode/Customer Visit: we should show the tile and the counter, yet prevent further navigation to the details
			if (this.getOwnerComponent().getModel("settings").getProperty("/isAnonymizedMode") === true) {
				return null;
			}

			if (this.getOwnerComponent().getModel("globalEscalations")) {
				this.getOwnerComponent().getModel("globalEscalations").setProperty("/reload", true);
			}
			this.getOwnerComponent().getModel("data").setProperty("/globalEscalationsCaseState", "open");
			this.getOwnerComponent().getModel("data").setProperty("/globalEscalationsCaseFilter", "none");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("GlobalEscalationMobile", {
				"?query": this._getQueryParameter(),
			});
			this.trackEvent("Global Escalation: display - main tile listview");
			//	}
		},

		navToOutages: function (oEvent) {
			if (this.getOwnerComponent().getModel("data")) {
				this.getOwnerComponent().getModel("data").setProperty("/reloadOutages", true);
				this.getOwnerComponent().getModel("data").setProperty("/outagesState", "open");
			}
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("OutagesMobile", {
				"?query": this._getQueryParameter(),
			});
			this.trackEvent("Major SAP Cloud Outages: display - main tile");
		},

		_navToCaseNumberSearchResult: function (item) {
			var oBindingContext = item.getBindingContext("searchModeloCaseNumber");
			var oData = oBindingContext.getObject();

			if (oData.sysId && oData.sysId !== "") {
				this._openSosApp(oData.sysId, "&transType=sn_customerservice_case");
				return null;
			} else if (oData.isActivity) {
				this._openSosApp(oData.id, "", true);
				return null;
			}

			switch (oData.type) {
				case "Escalation Record":
				case "Active Escalation":
					this._openSosApp(oData.sysId, "&transType=sn_customerservice_case");
					break;
				case "Global Escalation":
				case "Customer Engagement":
				case "Critical Customer Management":
				case "Critical Period Coverage":
				case "Guided Solution Support":
				case "Business Down Situation":
				case "Top Critical Customers":
				case "Task Forces":
					this.getOwnerComponent().getModel("case").setProperty("/reload", true);
					this.getRouter().navTo("CaseDetailsMobile", {
						"?query": this._getQueryParameter(),
						CaseId: oData.id
					});
					break;
			}

		},

		_readCaseNumberSearch: function (oEvent) {
			var oInput = oEvent.getSource();
			var aPromises = [];

			// get value from search filter control
			var sValue = "";
			try {
				sValue = oEvent.getParameter("query");
			} catch (error) {
				sValue = oEvent.searchValue;
			}

			if (sValue.length === 0) {
				return 0;
			} else if (sValue.length < 8) {
				sap.m.MessageBox.error("Please enter at least 8 character");
				return null;
			}

			sValue = sValue.replaceAll("/", "");
			sValue = sValue.replaceAll(" ", "");

			//show busy indicator
			oInput.setBusyIndicatorDelay(0);
			oInput.setBusy(true);

			var oEscalationRecordPromise = this._readCaseNumberSearchEscalationRecords(sValue);
			aPromises.push(oEscalationRecordPromise);

			// in case of anonymized mode, no GEM should be retunrned
			if (this.getOwnerComponent().getModel("settings").getProperty("/isAnonymizedMode") === false) {
				var oGlobalEscalationsPromise = this._readCaseNumberSearchGlobalEscalations(sValue);
				aPromises.push(oGlobalEscalationsPromise);
			}
			var oCustomerEngagementPromise = this._readCaseNumberSearchCustomerEngagements(sValue);
			aPromises.push(oCustomerEngagementPromise);

			var oActiveEscalationPromise = this._readCaseNumberSearchActiveEscalations(sValue);
			aPromises.push(oActiveEscalationPromise);

			var oICPPromise = this._readCaseNumberSearchICP(sValue);
			aPromises.push(oICPPromise);

			Promise.all(aPromises).then(function (result) {
				var oModel = new JSONModel();
				var aData = [];
				result.forEach(function (arr) {
					aData = aData.concat(arr);
				});

				if (aData.length === 0) {
					sap.m.MessageToast.show("Case not found", {
						of: oInput
						//at: "center center"
					});
				}

				oModel.setData(aData);
				this.getView().setModel(oModel, "searchModeloCaseNumber");
				oInput.setBusy(false);

				if (oInput.getBinding("suggestionItems")) {
					oInput.suggest();
				}
			}.bind(this));
		},

		_readCaseNumberSearchCustomerEngagements: function (value) {
			return new Promise(function (resolve, reject) {
				var oModel = this.getOwnerComponent().getModel();
				var aFilter = [new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.Contains, value)];
				oModel.read("/CustomerEngagementSet", {
					filters: aFilter,
					success: function (oData) {
						var aData = [];
						oData.results.forEach(function (data) {
							var sType = "Customer Engagement";
							switch (data.CustomerType) {
								case "ZSCUSTYP05":
									sType = "Critical Customer Management";
									break;
								case "ZSCUSTYP04":
									sType = "Critical Period Coverage";
									break;
								case "ZSCUSTYP06":
									sType = "Top Critical Customers";
									break;
								case "ZSCUSTYP07":
									sType = "Task Forces";
									break;
							}
							aData.push({
								id: data.CaseId,
								title: data.CaseTitle || "title hidden",
								type: sType,
								status: data.StatusT
							});
						});
						resolve(aData);
					},
					error: function () {
						resolve([]);
					}
				});
			}.bind(this));
		},

		_readCaseNumberSearchICP: function (value) {
			return new Promise(function (resolve, reject) {
				var oModel = this.getOwnerComponent().getModel("appDepModel");
				var oSettingsModel = this.getOwnerComponent().getModel("settings");
				var aFilter = [];
				//aFilter.push(new sap.ui.model.Filter("RefDocID", sap.ui.model.FilterOperator.NE, "0000"));
				aFilter.push(new sap.ui.model.Filter("CustomerTicketID", sap.ui.model.FilterOperator.Contains, value));
				oModel.read("/ActivitySet", {
					urlParameters: {
						"$select": "RefDocID,RefDocType,StatusDesc,Description,ActivityID,CategoryID,PriorityID,StatusID,ReasonID,ResultID"
					},
					filters: aFilter,
					success: function (oData) {
						var aPromises = [];
						var aData = [];
						oData.results.forEach(function (data) {
							if (data.RefDocID === "" || data.RefDocID === "0" || data.RefDocID === "0000") {
								var sType = "CRM Activity";
								var oObject = {
									id: data.ActivityID,
									title: data.Description || "title hidden",
									status: data.StatusDesc,
									isActivity: true
								};

								//nav to sos app
								switch (data.CategoryID) {
									case "ZYP":
										sType = "MCC Issue";
										break;
									case "ZYT":
										sType = "TC2 Evaluation Request";
										break;
									case "ZYO":
										sType = "CCM Request";
										break;
									case "ZZM":
										sType = "CPC Request";
										break;
									case "ZZD":
										sType = "MCC Support Requests";
										break;
									case "ZZR":
										sType = "MCC SOS Request";
										break;
								}

								if ((data.CategoryID === "Z91" || data.CategoryID === "Z93" || data.CategoryID === "ZB9") &&
									data.PriorityID === "1" &&
									data.StatusID === "E0011" &&
									(data.ReasonID === "A1ZS0000010010" || data.ReasonID === "A1ZS0000010050" || data.ReasonID === "A1ZS0000010060" ||
										data.ReasonID ===
										"A1ZS0000010100")) {
									sType = "Business Down Situation";
								} else if (data.CategoryID === "Z90" &&
									data.PriorityID === "1" &&
									data.StatusID === "E0011" &&
									(data.ReasonID === "A1ZS0000010010" || data.ReasonID === "A1ZS0000010050" || data.ReasonID === "A1ZS0000010060" ||
										data.ReasonID ===
										"A1ZS0000010100")) {
									sType = "Go-Live Endangered";
								} else if ((data.CategoryID === "Z90" || data.CategoryID === "ZB2") &&
									data.PriorityID === "5" &&
									data.ResultID === "Z2ZS460050" &&
									(data.ReasonID === "A1ZS0000010040" || data.ReasonID === "A1ZS0000010050" || data.ReasonID === "A1ZS0000010060" ||
										data.ReasonID ===
										"A1ZS0000010100")) {
									sType = "Go-Live Announcement";
								} else if ((data.CategoryID === "Z91" || data.CategoryID === "Z90" || data.CategoryID === "Z93" || data.CategoryID ===
									"ZB9" ||
									data.CategoryID === "Z88") && (data.PriorityID === "1" || data.PriorityID === "3") && (data.ReasonID ===
										"A1ZS0000010020" ||
										data.ReasonID === "A1ZS0000010070" || data.ReasonID === "A1ZS0000010080" || data.ReasonID ===
										"A1ZS0000010090")) {
									sType = "MCS Backoffice Activity";
								}

								oObject.type = sType;
								aData.push(oObject);
							} else if (data.RefDocID !== "" && data.RefDocID !== "0000" && data.RefDocType === "ZS01") {
								// in case of anonymized mode, no GEM should be retunrned
								if (oSettingsModel.getProperty("/isAnonymizedMode") === false) {
									var oGlobalEscalationsPromise = this._readCaseNumberSearchGlobalEscalations(data.RefDocID);
									aPromises.push(oGlobalEscalationsPromise);
								}
							} else if (data.RefDocID !== "" && data.RefDocID !== "0000" && data.RefDocType === "ZS02") {
								var oCustomerEngagementPromise = this._readCaseNumberSearchCustomerEngagements(data.RefDocID);
								aPromises.push(oCustomerEngagementPromise);
							}
						}.bind(this));

						if (aData.length > 0) {
							aPromises.push(new Promise(function (res) {
								res(aData);
							}));
						}

						Promise.all(aPromises).then(function (result) {
							var aData = [];
							result.forEach(function (arr) {
								aData = aData.concat(arr);
							});
							resolve(aData);
						}.bind(this));
					}.bind(this),
					error: function (err) {
						resolve([]);
					}
				});
			}.bind(this));
		},

		_readCaseNumberSearchGlobalEscalations: function (value) {
			return new Promise(function (resolve, reject) {
				var oModel = this.getOwnerComponent().getModel();
				var aFilter = [new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.Contains, value)];
				oModel.read("/GlobalEscalationsSet", {
					filters: aFilter,
					success: function (oData) {
						var aData = [];
						oData.results.forEach(function (data) {
							aData.push({
								id: data.CaseId,
								title: data.CaseTitle || "title hidden",
								type: "Global Escalation",
								status: data.StatusT
							});
						});
						resolve(aData);
					},
					error: function () {
						resolve([]);
					}
				});
			}.bind(this));
		},

		_readCaseNumberSearchActiveEscalations: function (value) {
			var that = this;
			return new Promise(function (resolve, reject) {
				var sFilterString =
					"&sysparm_fields=u_task_record.account.u_region,u_task_record.number,u_request_reason,u_escalation_type,u_task_record.short_description,u_task_record.account.name,u_task_record.account.number,u_task_record.state,u_task_record.correlation_id,u_task_record.u_bcp_link,u_task_record.priority,number,state,sys_id";
				sFilterString += "&sysparm_query=u_task_record.numberLIKE" + value + "%5eORu_task_record.correlation_idLIKE" + value +
					"%5esys_id!==''%5eactive=true";

				$.ajax({
					method: "GET",
					contentType: "application/json",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/sn_customerservice_escalation?" + sFilterString,
					success: function (oData) {
						//parse data
						var aData = [];
						oData.result.forEach(function (data) {
							var sType = "Escalation Record";
							switch (data["u_escalation_type"]) {
								case "3":
									sType = "Critical Incident Management";
									break;
								case "4":
									sType = "Critical Customer Management";
									break;
								case "0":
									sType = "Business Down Management";
									switch (data["u_request_reason"]) {
										case "8":
										case "9":
											sType = "Business Down Situations";
											break;
										case "7":
											sType = "PE Critical Engagements";
											break;
										case "10":
											sType = "xTec Engagements";
											break;
									}
									break;
							}
							aData.push({
								title: data["u_task_record.short_description"] || "title hidden",
								id: data["number"],
								type: sType,
								sysId: data["sys_id"],
								status: that.formatter.getCimEscalationStatus(data["state"])
							});
						});
						resolve(aData);
					}.bind(this),
					error: function (err) {
						resolve([]);
					}.bind(this)
				});
			}.bind(this));
		},

		_readCaseNumberSearchEscalationRecords: function (value) {
			var that = this;
			return new Promise(function (resolve, reject) {
				var sFilterString =
					"sysparm_fields=u_task_record.account.u_region,u_task_record.number,u_escalation_type,u_task_record.short_description,u_task_record.account.name,u_task_record.account.number,u_task_record.state,u_task_record.correlation_id,u_task_record.u_bcp_link,u_task_record.priority,number,state,sys_id";
				sFilterString += "&sysparm_query=number=" + value;
				$.ajax({
					method: "GET",
					contentType: "application/json",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/sn_customerservice_escalation?" + sFilterString,
					success: function (oData) {
						//parse data
						var aData = [];
						oData.result.forEach(function (data) {
							var sType = "Escalation Record";
							switch (data["u_escalation_type"]) {
								case "3":
									sType = "Critical Incident Management";
									break;
								case "4":
									sType = "Critical Customer Management";
									break;
								case "0":
									sType = "Business Down Management";
									break;
							}
							aData.push({
								title: data["u_task_record.short_description"] || data.short_description || "title hidden",
								id: data["number"],
								type: sType,
								sysId: data["sys_id"],
								status: that.formatter.getCimEscalationStatus(data["state"])
							});
						});
						resolve(aData);
					}.bind(this),
					error: function (err) {
						resolve([]);
					}.bind(this)
				});
			}.bind(this));
		},

		onSearch: function (event) {
			var oSearchField = event.getSource();
			var item = event.getParameter("suggestionItem");
			if (item) {
				var sPath = item.getBindingContext("searchModel").getPath();
				var oCustomer = this.getModel("searchModel").getProperty(sPath);
				var sErpCustNo = oCustomer.key;
				//remove leading zeros
				sErpCustNo = parseInt(sErpCustNo, 10).toString();
				this._navToCustomerFactSheet(sErpCustNo);
				oSearchField.setEnableSuggestions(false);

			} else {
				oSearchField.setEnableSuggestions(true);
				this.onLiveChange(event);
			}
		},

		onSearchCaseNumber: function (event) {
			//mindestens 8 zeichen
			var oSearchField = event.getSource();
			var item = event.getParameter("suggestionItem");
			var oModel = new JSONModel();
			this.getView().setModel(oModel, "searchModeloCaseNumber");

			if (item) {
				this._navToCaseNumberSearchResult(item);
				oSearchField.setEnableSuggestions(false);
			} else {
				//load backend data
				oSearchField.setEnableSuggestions(true);
				this._readCaseNumberSearch(event);
			}
		},

		onSuggest: function (oEvent) {
			var oSearchField = oEvent.getSource();
			oSearchField.setEnableSuggestions(false);
		},

		_showSuggestions: function (sSuggestValue) {
			var aFilters = [];
			var oSearchField = this.getView().byId("searchFieldMobile");
			if (oSearchField.getBinding("suggestionItems")) {
				//oSearchField.getBinding("suggestionItems").filter(aFilters);
				oSearchField.suggest();
			} else
				oSearchField.setEnableSuggestions(false);
		},

		onLiveChange: function (oEvent) {

			this.trackEvent("Customer: search");
			var oInput = oEvent.getSource();

			// get value from search filter control
			var sValue;
			try {
				sValue = oEvent.getParameter("query");
			} catch (error) {
				sValue = oEvent.searchValue;
			}

			var oCustomerFilter = new Array(
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("CustomerName", sap.ui.model.FilterOperator.Contains, sValue),
					new sap.ui.model.Filter("ErpCustNo", sap.ui.model.FilterOperator.EQ, sValue),
					new sap.ui.model.Filter("Partner", sap.ui.model.FilterOperator.EQ, sValue)
				],
					false
				)
			);

			// reset suggestionItems list
			if (this.getView().getModel("searchModel")) {
				this.getView().getModel("searchModel").setProperty("/data", []);
			}

			if (sValue === "") {
				return null;
			}

			//show busy indicator
			oInput.setBusyIndicatorDelay(0);
			oInput.setBusy(true);

			// read customer model
			var oModel = this.getOwnerComponent().getModel();

			oModel.read("/CustomerSet", {
				urlParameters: {
					"$top": 999,
					"$select": "CustomerName,ErpCustNo,Iac,CountryT,GuErpNo,IsGlobalUltimate,Partner"
				},
				filters: oCustomerFilter,
				success: function (data, response) {
					oInput.setBusy(false);

					if (data.results.length === 0) {
						sap.m.MessageToast.show("Customer not found", {
							of: oInput
						});
					}

					var aCustomerData = [];
					//push data to array
					data.results.forEach(function (customer) {
						aCustomerData.push({
							text: customer.CustomerName,
							key: customer.ErpCustNo,
							filterProp: customer.IsGlobalUltimate === "X" ? "Global Ultimate" : "Customer",
							iac: this.iacValues.indexOf(customer.Iac) > -1 ? customer.Iac : "ZZZZZ",
							//description: " - " + customer.CountryT //"(" + customer.CountryT + ")"
							description: "(BP: " + customer.Partner + ", ERP: " + customer.ErpCustNo + ") - " + customer.CountryT
						});
					}.bind(this));

					this.iacValues.push("ZZZZZ");

					//sort array by filterProp and iac
					aCustomerData = aCustomerData.sort(function (a, b) {
						if (this.iacValues.indexOf(a.iac) < this.iacValues.indexOf(b.iac)) {
							return -1;
						} else if (this.iacValues.indexOf(a.iac) > this.iacValues.indexOf(b.iac)) {
							return 1;
						} else if (b.filterProp < a.filterProp) {
							return -1;
						} else if (b.filterProp > a.filterProp) {
							return 1;
						} else if (b.text > a.text) {
							return -1;
						} else if (b.text < a.text) {
							return 1;
						} else if (b.description > a.description) {
							return -1;
						} else if (b.description < a.description) {
							return 1;
						}
						return 0;
					}.bind(this));

					for (var i = 0; i < aCustomerData.length; i++) {
						if (i === 0) {
							aCustomerData[i].isTopMatch = true;
						} else if ((i === 1 || i === 2) && aCustomerData[i].iac !== "ZZZZZ") {
							aCustomerData[i].isTopMatch = true;
						} else if (i > 2 && i < 5 && aCustomerData[i].iac !== "ZZZZZ" && aCustomerData[i].iac === aCustomerData[(i - 1)].iac) {
							aCustomerData[i].isTopMatch = true;
						} else {
							aCustomerData[i].isTopMatch = false;
						}
					}

					this.getView().getModel("searchModel").setProperty("/data", aCustomerData);

					// invoke suggestions
					this._showSuggestions(sValue);
				}.bind(this)
			});
		},

		handleFacetFilterReset: function (oEvent) {
			//moved to BaseController because of MCS Dashboard integration and use in Charts and Operational View
			this.handleFacetFilterResetBase(oEvent);
			this.oFilterComponent._updateTileNumbers();
			this.getView().byId("filterVariantManagement").currentVariantSetModified(true);
		},

		onGlobalIconTabBarMobileSelect: function (oEvent) {
			//var oTabBar = this.getView().byId("globalIconTabBarMobile");
			var sSelectedIconTabKey = oEvent.getParameter("key");
			if (sSelectedIconTabKey === "EngagementsTab") {
				this.onNavToEngagementList();
			}
		},

		onNavToAllGEM: function (event) {
			if (this.getOwnerComponent().getModel("globalEscalations")) {
				this.getOwnerComponent().getModel("globalEscalations").setProperty("/reload", true);
			}
			this.getOwnerComponent().getModel("data").setProperty("/executiveGEMCaseState", "open");
			this.getOwnerComponent().getModel("data").setProperty("/executiveGEMCaseSelectedTabBarKey", "All");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.navTo("ExecutiveGEMMobile", {
				query: {
					selectedTab: "All",
					caseState: "open"
				}
			});
			this.trackEvent("Executive GEM: display - main tile");
		},

		onNavToProdEsca: function (oEvent) {
			if (this.oController.getOwnerComponent().getModel("productEscalations")) {
				this.oController.getOwnerComponent().getModel("productEscalations").setProperty("/reload", true);
			}
			this.oController.getOwnerComponent().getModel("data").setProperty("/productEscalationsCaseState", "open");
			this.oController.getOwnerComponent().getModel("data").setProperty("/productEscalationsCaseFilter", "none");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this.oController);
			oRouter.navTo("ProductEscalationMobile", {
				"?query": this.oController._getQueryParameter(),
			});
			this.oController.trackEvent("Product Escalation: display - main tile");
		},

		onNavToTaskForces: function (sKey, sDescription, aServiceTeams, sTagName) {
			if (sKey instanceof Object) {
				sDescription = sKey.getSource().data("description");
				aServiceTeams = sKey.getSource().data("serviceTeams");
				sTagName = sKey.getSource().data("tagName");
				sKey = sKey.getSource().data("key");
			}
			if (this.oController.getOwnerComponent().getModel("data")) {
				this.oController.getOwnerComponent().getModel("data").setProperty("/serviceTeams", aServiceTeams);
				this.oController.getOwnerComponent().getModel("data").setProperty("/serviceTeamsDescr", sDescription);
				this.oController.getOwnerComponent().getModel("data").setProperty("/taskForcesFilter", "none");
				this.oController.getOwnerComponent().getModel("data").setProperty("/taskForcesState", "open");
				this.oController.getOwnerComponent().getModel("data").setProperty("/tagName", sTagName);
			}
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this.oController);
			oRouter.navTo("MCCTagsMobile", {
				"?query": this.oController._getQueryParameter(),
				Description: sKey
			});
			this.oController.trackEvent(sDescription + ": display - main tile");
		},

	});
});