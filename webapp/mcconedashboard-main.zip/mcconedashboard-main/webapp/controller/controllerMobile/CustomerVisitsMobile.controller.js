sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter"
], function (BaseController, formatter) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.CustomerVisitsMobile", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				bLoadingState: false,
				// iTabAllPA: 0,
				// iTabGreenPA: 0,
				// iTabYellowPA: 0,
				// iTabRedPA: 0,
				// iTabUnratedPA: 0,
				iTabFiltered: 0,
				bLoadingStatePA: false,
				showObjectType: false
			}), "viewModel");
			this.getRouter().getRoute("CustomerVisitsMobile").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function (oEvent) {
			var oTabBar = this.getView().byId("customerVisitsTabBar");
			//Check if data was already loaded. If yes, use this data
			if (this.getOwnerComponent().getModel("data").getProperty("/reloadCustomerVisits")) {
				this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "tableData");
				this.getOwnerComponent().getModel("data").setProperty("/reloadCustomerVisits", false);
				this._updateTable();
			}
			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
		},

		_updateTable: function () {
			var aFilters = [];
			var oTable = this.getView().byId("table");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			var tileSpecificFilters = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("StatusT", sap.ui.model.FilterOperator.EQ, "New"),
						new sap.ui.model.Filter("StatusT", sap.ui.model.FilterOperator.EQ, "In Process Backoffice"),
						new sap.ui.model.Filter("StatusT", sap.ui.model.FilterOperator.EQ, "In MCC Focus Teams")
					], false)
				],
				true
			);

			aFilters.push(tileSpecificFilters);
			aFilters.push(new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "ZVM"));
			aFilters.push(new sap.ui.model.Filter("ProcessType", sap.ui.model.FilterOperator.EQ, "ZS46"));

			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oICModel = this.getOwnerComponent().getModel();
			oTable.setBusy(true);

			oICModel.read("/MCCActivitiesSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					oTable.setBusy(false);
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "tableData");
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		onCustomer: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("tableData").getObject().CustomerErpNo;
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("CustomerMobile", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("tableData").getObject();
			var sObjectType = "";
			if (oData.CustomerType != "") {
				sObjectType = oData.CustomerType;
			}
			var sId = oData.CaseId;
			this.readNotes(oEv.getSource(), sId, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("tableData").getObject();
			var sCaseId = oProperty.CaseId;
			this._shopTopIssuesCountPopover(sCaseId, oEv.getSource());
		},

		handleOpenIssuesCasePress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("tableData").getPath();
			var oProperty = this.getModel("tableData").getProperty(sPath);
			this._openWindow(oProperty.LinkToActivity);
		},

		handleCustomerPress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("tableData").getPath();
			var oProperty = this.getModel("tableData").getProperty(sPath);
			var sErpCustNo = oProperty.CustomerErpNo || oProperty.ErpCustNo || oProperty.CustomerNo;
			var oRouter = this.getRouter();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},
		onOpenUser: function (oEv) {
			// if (oEv.getSource().data("EmplRespUser")) {
			// 	this.formatter.openUser(oEv, oEv.getSource().data("EmplRespUser"));
			// } 
			// else
			if (oEv.getSource().data("userid")) {
				this.formatter.openUser(oEv, oEv.getSource().data("userid"));
			}
			//else {
			// 	this.formatter.openUser(oEv, oEv.getSource().data("useridBDM"));
			// }
		},
		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("tableData").getPath();
			var oProperty = this.getModel("tableData").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},
		handleGlobalUltimatePressPA: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("tableData").getPath();
			var oProperty = this.getModel("tableData").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		customSorting: function (oEvent) {
			var oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingColumn");
			var oMCCiColumn = this.byId("mcci");
			var oPreventionScoreColumn = this.byId("preventionScore");
			var oTable = this.getView().byId("table");
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");

			if (bCaseState === "closed") {
				oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingColumnClosed");
				oMCCiColumn = this.byId("mcciClosed");
				oPreventionScoreColumn = this.byId("preventionScoreClosed");
				oTable = this.getView().byId("tableClosed");
			}

			var oCurrentColumn = oEvent.getParameter("column");
			if (oCurrentColumn !== oGUMaintenanceRankingColumn && oCurrentColumn !== oMCCiColumn && oCurrentColumn !== oPreventionScoreColumn) {
				//oGUMaintenanceRankingColumn.setSorted(false); //No multi-column sorting
				return;
			}
			oEvent.preventDefault();
			var sOrder = oEvent.getParameter("sortOrder");

			if (oCurrentColumn == oMCCiColumn || oCurrentColumn == oPreventionScoreColumn) {
				this.customSortingBaseFloat(oCurrentColumn, sOrder, oTable);
			} else {
				this.customSortingBase(oCurrentColumn, sOrder, oGUMaintenanceRankingColumn, oTable);
			}
		},

		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("tableData").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		},

		handleCustomerVisitState: function (oEv) {
			var sState = oEv.getParameter("selectedKey");
			var oTable = this.getView().byId("table");

			this.getOwnerComponent().getModel("data").setProperty("/customerVisitsState", sState);

			// Reset all table filters
			oTable.getColumns().forEach(function (oColumn) {
				oColumn.filter(null);
				oColumn.setFilterValue("");
			});
			this.clearSearchField(oTable);

			this._updateTable(sState);
		},

		onLiveSearchChange: function (event) {
			var searchValue = event.getParameter("newValue").toLowerCase();
			var oList = this.getView().byId("table");
			var oBinding = oList.getBinding("items");
			var aFilters = [];

			var oFilter1 = new sap.ui.model.Filter("CustomerText", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter("CountryT", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter("RegionT", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter3);

			var oFilter4 = new sap.ui.model.Filter("Description", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter4);

			var oFilter5 = new sap.ui.model.Filter("ObjectId", sap.ui.model.FilterOperator.Contains, searchValue);
			aFilters.push(oFilter5);

			var oCombinedFilter = new sap.ui.model.Filter(aFilters, false);
			oBinding.filter(oCombinedFilter);
		}
	});
});