sap.ui.define([
	"com/sap/mcconedashboard/model/models",
	"sap/m/MessageBox",
	"sap/m/Dialog",
	"sap/ui/layout/VerticalLayout",
	"sap/m/Button",
	"sap/m/Text"
], function (models, MessageBox) {
	"use strict";

	return { //UI5Object.extend("com.sap.mcconedashboard.controller.ReportDownloadHandler", {
		models: models,
		resetMimeFilterModel: function (controller) {
			var filtersModel = controller.getModel("extReportFilters");
			filtersModel.setProperty("/case_id", null);
			filtersModel.setProperty("/id", null);
			filtersModel.setProperty("/process_type", null);
			filtersModel.setProperty("/region", null);
			filtersModel.setProperty("/status", null);
			filtersModel.setProperty("/rating", null);
			filtersModel.setProperty("/master_code", null);
			filtersModel.setProperty("/service_org", null);
			filtersModel.setProperty("/delivery_unit", null);
			filtersModel.setProperty("/ref_objectprodCat", null);
			filtersModel.setProperty("/ref_objectprodLine", null);
			filtersModel.setProperty("/ref_object", null);
			filtersModel.setProperty("/sales_org", null);
			filtersModel.setProperty("/customer_bp_id", null);
			filtersModel.setProperty("/creation_date", null);
			filtersModel.setProperty("/closing_date", null);
			filtersModel.setProperty("/mainProductSearch", null);
		},

		onPressGenerateMIME: function (controller, sMimeType) {
			//controller.getView().byId(sBusyId).setBusy(true);
			var oBusyDialog = null,
				iTimeout = 1000;

			var filtersModel = controller.getModel("extReportFilters");
			var sfinalPOSTFilter = filtersModel.buildPOSTFilterString();
			var oResultModel = controller.getModel("resultModel");

			if (!oBusyDialog) {
				oBusyDialog = new sap.m.BusyDialog({
					title: controller.getResourceBundle().getText("busyDialogTitle"),
					text: controller.getResourceBundle().getText("busyDialogText")
				});
				controller.getView().addDependent(oBusyDialog);
			}
			// open dialog
			jQuery.sap.syncStyleClass("sapUiSizeCompact", controller.getView(), oBusyDialog);
			oBusyDialog.open();
			var that = this;
			//check periodically, if the generation in the Background has been finished
			var fnCheckMIMEGenerationFinished = function (params) {
				controller.getModel("mcsModel").detachRequestCompleted(fnCheckMIMEGenerationFinished, controller);
				if (oResultModel.getProperty("/oDataCallStatus") === "OK") {
					if (oResultModel.getProperty("/mimeFilteredCount") > 15) {
						iTimeout = 3000;
					} else if (oResultModel.getProperty("/mimeFilteredCount") > 5) {
						iTimeout = 2000;
					}
					//var result = null;
					//call of the oData Service in order to check the status of the generation
					var fnCheckPeriodically = function () {
						models.checkMimeGenerationStatus(controller.getModel("mcsModel"), controller.getModel("resultModel"));
					};
					///check the return value of the oData Call
					//if it is already generate stop the execution and show the PDF or excel
					//if not recheck after 3 seconds
					var fnCheckReturnValue = function () {
						if (controller.getModel("resultModel").getProperty("/mimeGenerated") === "X") {
							controller.getModel("mcsModel").detachRequestCompleted(fnCheckReturnValue, controller);
							//controller.getView().byId(sBusyId).setBusy(false);
							oBusyDialog.close();
							that.displayMime(controller);
						} else {
							if (oResultModel.getProperty("/oDataCallStatus") === "OK") {
								setTimeout(fnCheckPeriodically, iTimeout);
							} else {
								controller.getModel("mcsModel").detachRequestCompleted(fnCheckReturnValue, controller);
								oBusyDialog.close();
							}
						}
					};
					//trigger the first check and attach the needed function to the model
					var fnStartCheck = function () {
						controller.getModel("mcsModel").attachRequestCompleted(fnCheckReturnValue, controller);
						models.checkMimeGenerationStatus(controller.getModel("mcsModel"), controller.getModel("resultModel"));
					};
					setTimeout(fnStartCheck, 1000);
				}
			};
			controller.getModel("mcsModel").attachRequestCompleted(fnCheckMIMEGenerationFinished, controller);
			var resultModel = models.handleCasesForMIME(controller.getModel("mcsModel"), sfinalPOSTFilter, controller.getModel("resultModel"),
				true, sMimeType);
			if (!oResultModel) {
				oResultModel = resultModel;
				controller.setModel(resultModel, "resultModel");
			}

		},
		displayMime: function (controller) {
			var view = controller.getView();
			//sBaseUrl = "https://flpsandbox-br339jmc4c.dispatcher.int.sap.eu2.hana.ondemand.com/sap/fiori/mcconedashboard";
			var sBaseUrl = window.location.protocol + '//' + window.location.host + "/sap/fiori/mcconedashboard";
			if (window.location.href.includes("webidetesting") || window.location.href.includes("index")) {
				sBaseUrl = "";
			}
			var sURL = sBaseUrl + controller.getModel("mcsModel").sServiceUrl + "/MIMERequestOutSet(mime_guid=&#39;" + controller.getModel(
					"resultModel").getProperty(
					"/mimeGUID") +
				"&#39;)/$value?AppIdentifier=vFkzmhgGIsokhbTq20b492pFxGMABxLU";
			var oDeviceModel = view.getModel("device");

			var sContent = "",
				newWindow;
			if (oDeviceModel.getData().browser.name === "cr") {
				var left = (screen.width / 2) - (500 / 2);
				var top = (screen.height / 2) - (100 / 2);
				newWindow = window.open("", "_blank", "top=" + top + ",left=" + left + ",width=500,height=100");
				newWindow.opener = null;
				sContent = "<h3>" + controller.getResourceBundle().getText("mimeDownload") + "</h3><iframe  src='" + sURL +
					"'  width='0' height='0'></iframe>";
				newWindow.document.write(sContent);
				newWindow.document.title = controller.getResourceBundle().getText("mimeTitle");

			} else if (oDeviceModel.getData().browser.mobile === true) {
				sURL = controller.getModel("mcsModel").sServiceUrl + "/MIMERequestOutSet(mime_guid='" + controller.getModel("resultModel").getProperty(
						"/mimeGUID") +
					"')/$value?AppIdentifier=vFkzmhgGIsokhbTq20b492pFxGMABxLU";
				var win = window.open(sURL, "_blank");
				win.opener = null;
			} else {
				newWindow = window.open("", "_blank");
				newWindow.opener = null;
				sContent = "<h3>" + controller.getResourceBundle().getText("mimeDisplay") + "</h3><iframe   src='" + sURL +
					"'  width='100%' height='100%' ></iframe>";
				newWindow.document.write(sContent);
				newWindow.document.title = controller.getResourceBundle().getText("mimeTitle");
			}
		}
	}; //);
});