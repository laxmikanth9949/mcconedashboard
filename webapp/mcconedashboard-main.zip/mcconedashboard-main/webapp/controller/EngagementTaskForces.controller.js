sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/model/Constants"
], function (BaseController, formatter, Constants) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.EngagementTaskForces", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				iTabFiltered: 0,
				bLoadingState: false
			}), "viewModel");
			this.getRouter().getRoute("EngagementTaskForces").attachPatternMatched(this._onObjectMatched, this);

			//Attach Listener in case a global Filter is applied
			var oTable = this.getView().byId("table");
			var oSearchField = this.getSearchField(oTable);
			oSearchField.attachSearch(function (oEvent) {
				this._updateFilteredCount();
			}, this);
		},

		onAfterRendering: function () {
			var oTable = this.getView().byId("table");
			oTable.attachFilter(function (oEvent) {
				setTimeout(function () {
					this._updateFilteredCount();
				}.bind(this), 200); //Wait for filter execution
			}, this);
		},

		_onObjectMatched: function (oEvent) {
			//Check if data was already loaded. If yes, use this data
			if (!this.getOwnerComponent().getModel("data") || (this.getOwnerComponent().getModel("data").getData() && this.getOwnerComponent().getModel(
					"data").getData().reloadEngagementTaskForces)) {
				this._updateTable();
			}

			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
		},

		_updateTable: function () {
			var aFilters = [];
			var oTable = this.getView().byId("table");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();

			this.getView().byId("dataIconTabBar").setSelectedKey("All");

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			var tileSpecificFilters2 = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
					], false)
				],
				true
			);

			aFilters.push(tileSpecificFilters2);

			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP07"));

			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);

			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			oICModel.read("/CustomerEngagementSet", {
				filters: aFilters,
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);

					data.results.forEach(function (oCase) {
						oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);
						if (oCase.Rating === "") {
							oCase.Rating = "unrated";
						}
						if (oCase.DbsMaintenanceRanking === "0") {
							oCase.DbsMaintenanceRanking = "";
						}
					}.bind(this));

					this._calculateRating(data);
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "data");
					this.readProducts(oModel, aFilters);
					this._getTCCFocusAreaCount();
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		readProducts: function (oModel, aFilters) {
			var oTable = this.getView().byId("table");
			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$expand": "toProducts",
					"$select": "CaseId,toProducts"
				},
				success: function (data) {
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					var aAlreadyAdded = oModel.getData().results;
					this._updateFilteredCount();
					data.results.forEach(function (oCase) {
						oCase.ProductVersions = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.Product = this.formatter.concatProducts(oCase.toProducts.results, "ProductT");
						oCase.ProductCategory = this.formatter.concatProducts(oCase.toProducts.results, "ProductCatT");
						oCase.ProductLine = this.formatter.concatProducts(oCase.toProducts.results, "ProductLineT");
						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.CaseId === oCase.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = oCase.toProducts;
								aTmp[i].toLastNotes = oCase.toLastNotes;
								aTmp[i].ProductVersions = oCase.ProductVersions;
								aTmp[i].Product = oCase.Product;
								aTmp[i].ProductCategory = oCase.ProductCategory;
								aTmp[i].ProductLine = oCase.ProductLine;
							});
						}

					}.bind(this));
					oModel.refresh();

				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		readNotes: function (oControl, id, sObjectType) {
			//Just take the same filters from the base callvar aFilters = [];
			var oICModel = this.getOwnerComponent().getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oICModel.read("/CustomerEngagementSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results, sObjectType);
				}.bind(this),
				error: function () {
					//show busy indicator in Popoversap.ui.core.BusyIndicator.hide();();
					oControl.setBusy(false);
				}
			});
		},

		_getTCCFocusAreaCount: function () {
			var oSubModel = this.getView().getModel("subModel");
			var oTableModel = this.getView().getModel("data");
			//Todo defensive programming
			var oTableData = oTableModel.getData().results;
			oTableData.forEach(function (row, index) {
				var sCaseId = row.CaseId;
				var aFilter = [new sap.ui.model.Filter("CaseID", "EQ", sCaseId)];
				oSubModel.read("/MCCProject", {
					filters: aFilter,
					success: function (oData) {
						//Get next upcoming go live date
						//First filter all in past
						var aData = oData.results.filter(function (v) {
							return v.GoLiveDate > new Date();
						});

						if (aData && aData.length > 0) {
							var aData = aData.sort(function (a, b) {
								return a.GoLiveDate - b.GoLiveDate;
							});
							oTableModel.setProperty(`/results/${index}/NextGoLiveDate`, aData[0].GoLiveDate);
						}
						oTableModel.setProperty(`/results/${index}/AffectedCustomersCount`, oData.results.length);
					}.bind(this),
					error: function (data) {}.bind(this)
				});
			});
		},

		handleRatingIconTabBarSelect: function (oEv) {
			var oTable = this.getView().byId("table");
			var sRatingKey = oEv.getSource().getSelectedKey();
			var aFilter = [];

			// Reset all table filters
			oTable.getColumns().forEach(function (oColumn) {
				oColumn.filter(null);
				oColumn.setFilterValue("");
			});
			this.clearSearchField(oTable);

			if (sRatingKey !== "All") {
				aFilter.push(new sap.ui.model.Filter("Rating", "EQ", sRatingKey));
			}
			oTable.getBinding("rows").filter(aFilter);
			this._updateFilteredCount();
		},

		onCase: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("data").getObject().CaseId;
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);
			this.getRouter().navTo("CaseDetails", {
				"?query": this._getQueryParameter(),
				"CaseId": sCaseId
			});
		},

		onCaseNewTab: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("data").getObject().CaseId;
			this._openCaseInNewTab(sCaseId);
		},

		onCustomer: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("data").getObject().CustomerErpNo;
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("Customer", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		_calculateRating: function (data) {
			var oViewModel = this.getView().getModel("viewModel");
			var iGreen = 0;
			var iYellow = 0;
			var iRed = 0;
			var iUnrated = 0;
			data.results.forEach(function (oCase) {
				switch (oCase.Rating) {
				case "A":
					iGreen++;
					break;
				case "B":
					iYellow++;
					break;
				case "C":
					iRed++;
					break;
				default:
					iUnrated++;
				}
			});
			oViewModel.setProperty("/iTabAll", data.results.length);
			oViewModel.setProperty("/iTabGreen", iGreen);
			oViewModel.setProperty("/iTabYellow", iYellow);
			oViewModel.setProperty("/iTabRed", iRed);
			oViewModel.setProperty("/iTabUnrated", iUnrated);
			this._updateFilteredCount();
		},

		_updateFilteredCount: function () {
			var oTable = this.getView().byId("table");
			var iFilteredCount = oTable.getBinding("rows").getLength();
			var aFilters = oTable.getBinding("rows").aFilters;
			if (aFilters && aFilters.length > 0) {
				var iLengths = oTable.getBinding("rows").iLengths;
				if (iLengths) {
					iFilteredCount = oTable.getBinding("rows").iLength - iLengths.sum();
				} else {
					iFilteredCount = oTable.getBinding("rows").iLength;
				}
			}
			this.getView().getModel("viewModel").setProperty("/iTabFiltered", iFilteredCount);
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("data").getObject();
			var sObjectType = "";
			if (oData.CustomerType != "") {
				sObjectType = oData.CustomerType;
			}
			var sId = oData.CaseId;
			this.readNotes(oEv.getSource(), sId, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},

		changeCaseState: function () {
			this._updateTable();
		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("data").getObject();
			var sCaseId = oProperty.CaseId;
			this._shopTopIssuesCountPopover(sCaseId, oEv.getSource());
		},

		onAffectedCustomers: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("data").getObject();
			var sCaseId = oProperty.CaseId;
			this._showFocusAffectedCustomersPopover(sCaseId, oEv.getSource());
		},

		_showFocusAffectedCustomersPopover: function (sCaseId, oControl) {
			var oModel = this.getModel("subModel");
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("CaseID", sap.ui.model.FilterOperator.EQ, sCaseId));
			var oPrioritySorter = new sap.ui.model.Sorter("Priority", false);
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oModel.read("/MCCProject", {
				filters: aFilters,
				sorters: [oPrioritySorter],
				/*urlParameters: {
					"$select": "Title,Description,StatusSummary,CaseID"
				},*/
				success: function (data) {
					oControl.setBusy(false);
					var oPopoverModel = new sap.ui.model.json.JSONModel();
					var aItems = [];
					data.results.forEach(function (focusarea) {
						var oData = {};
						oData.id = focusarea.CaseID;
						oData.customerName = focusarea.CustomerName;
						oData.customerId = focusarea.CustomerID;
						oData.iconSrc = "sap-icon://circle-task-2";
						//todo: check coloring and ratings
						oData.iconColor = focusarea.Rating === "Green" ? "#b00" : focusarea.Rating === "Yellow" ? "#e9730c" : focusarea.Rating ===
							"Red" ? "#107e3e" :
							"#6a6d70";
						aItems.push(oData);
					}.bind(this));
					if (!this.oAffectedCustomersPopover) {
						sap.ui.core.Fragment.load({
							name: "com.sap.mcconedashboard.view.fragment.OpenAffectedCustomersPopover",
							controller: this
						}).then(function (oPopover) {
							this.oAffectedCustomersPopover = oPopover;
							oPopoverModel.setData(aItems);
							this.oAffectedCustomersPopover.setModel(oPopoverModel, "data");
							this.getView().addDependent(this.oAffectedCustomersPopover);
							this.oAffectedCustomersPopover.openBy(oControl);
						}.bind(this));
					} else {
						oPopoverModel.setData(aItems);
						this.oAffectedCustomersPopover.setModel(oPopoverModel, "data");
						this.oAffectedCustomersPopover.openBy(oControl);
					}

				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
			this.trackEvent("Open Affected Customers: show Popover");
		},

		navToCaseFromFocusAreaPopover: function(oEv) {
			var oRouter = this.getRouter();
			var sErpCustNo = oEv.getSource().getBindingContext("data").getObject("customerId");
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		_showFocusAreaCountPopover: function (sCaseId, oControl) {
			var oModel = this.getModel("subModel");
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("CaseID", sap.ui.model.FilterOperator.EQ, sCaseId));
			var oPrioritySorter = new sap.ui.model.Sorter("Priority", false);
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oModel.read("/MCCProject", {
				filters: aFilters,
				sorters: [oPrioritySorter],
				urlParameters: {
					"$select": "Title,Description,StatusSummary,CaseID"
				},
				success: function (data) {
					oControl.setBusy(false);
					var oPopoverModel = new sap.ui.model.json.JSONModel();
					var aItems = [];
					data.results.forEach(function (focusarea) {
						var oData = {};
						oData.id = focusarea.CaseID;
						oData.description = focusarea.Description;
						oData.title = focusarea.Title;
						oData.statusSummary = focusarea.StatusSummary;
						oData.iconSrc = "sap-icon://circle-task-2";
						//todo: check coloring and ratings
						oData.iconColor = focusarea.Rating === "Green" ? "#b00" : focusarea.Rating === "Yellow" ? "#e9730c" : focusarea.Rating ===
							"Red" ? "#107e3e" :
							"#6a6d70";
						aItems.push(oData);
					}.bind(this));
					if (!this.oFocusAreaPopover) {
						sap.ui.core.Fragment.load({
							name: "com.sap.mcconedashboard.view.fragment.OpenFocusAreaPopover",
							controller: this
						}).then(function (oPopover) {
							this.oFocusAreaPopover = oPopover;
							oPopoverModel.setData(aItems);
							this.oFocusAreaPopover.setModel(oPopoverModel, "data");
							this.getView().addDependent(this.oFocusAreaPopover);
							this.oFocusAreaPopover.openBy(oControl);
						}.bind(this));
					} else {
						oPopoverModel.setData(aItems);
						this.oFocusAreaPopover.setModel(oPopoverModel, "data");
						this.oFocusAreaPopover.openBy(oControl);
					}

				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
			this.trackEvent("Open Focus Areas: show Popover");
		},

		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("data").getPath();
			var oProperty = this.getModel("data").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},
		customSorting: function (oEvent) {
			var oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingColumn");
			var oMCCiColumn = this.byId("mcci");
			var oPreventionScoreColumn = this.byId("preventionScore");
			var oCurrentColumn = oEvent.getParameter("column");
			if (oCurrentColumn !== oGUMaintenanceRankingColumn && oCurrentColumn !== oMCCiColumn && oCurrentColumn !== oPreventionScoreColumn) {
				//oGUMaintenanceRankingColumn.setSorted(false); //No multi-column sorting
				return;
			}
			oEvent.preventDefault();
			var sOrder = oEvent.getParameter("sortOrder");
			if (oCurrentColumn == oMCCiColumn || oCurrentColumn == oPreventionScoreColumn) {
				this.customSortingBaseFloat(oCurrentColumn, sOrder, "table");
			} else {
				this.customSortingBase(oCurrentColumn, sOrder, oGUMaintenanceRankingColumn, "table");
			}
		},
		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("data").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		}
	});
});