sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Icon"
], function (BaseController, JSONModel, Icon) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.Main", {
		//MCS Dashboard relevant coding
		onInit: function () {
			this._bMessageOpen = false;
			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

			//add custom stylesheet, which created during app startup containing the theme related colors based on standard SAP UI5 color names
			this.applyCustomStyleBasedOnSAPui5ColorNames();
		}
	});
});