sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"sap/ui/model/json/JSONModel",
	"com/sap/mcconedashboard/model/formatter"
], function (BaseController, JSONModel, formatter) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.Subscriptions", {
		// Check yearly IAC (Internal Account Classification) https://sap.sharepoint.com/teams/IDM/SitePages/GTM.aspx
		//values from 2020 iacValues: ["1", "8", "3", "T", "U", "O", "P"],
		//values for 2021 		iacValues: ["1", "8", "9", "G", "V", "I"],
		//values for 2022
		iacValues: ["X", "Y", "9", "V", "I", "Z"],
		formatter: formatter,

		onInit: function () {
			var dfdFiltersModelLoaded = this.getFiltersValueSet();
			this.oTable = this.byId("idSettingsTable");
			this.debounceTimer = null;
			this.oFilters = {
				"Customer": "Customer",
				"GlobalUltimate": "Global Ultimate",
				"country": "Country",
				"subregion": "Region",
				"ProductCategory": "Product Category",
				"ProductLine": "Product Line",
				"Product": "Product",
				"caseID": "MCC Engagement ID",
				// "SupportEngagement":"Support Engagement",
				"SolutionArea": "MCC Solution"
			};

			this.aToDelete = [];

			this.removedItems = [];

			// [{ValueKey:"GEM",ValueText:"Global Escalations"},{ValueKey:"CCM",ValueText:"Critical Customer Management"}];
			this.oRegions = [{
				ValueKey: "WORLD",
				ValueText: "World"
			}, {
				ValueKey: "APJ",
				ValueText: "APJ"
			}, {
				ValueKey: "EMEA North",
				ValueText: "EMEA North"
			}, {
				ValueKey: "EMEA South",
				ValueText: "EMEA South"
			}, {
				ValueKey: "GTC",
				ValueText: "GTC"
			}, {
				ValueKey: "LAC",
				ValueText: "LAC"
			}, {
				ValueKey: "MEE",
				ValueText: "MEE"
			}, {
				ValueKey: "NA",
				ValueText: "NA"
			}];
			this.aCustomers = [];
			this.aProductLines = [];
			this.aProducts = [];
			var aFilters = [];
			for (var key in this.oFilters) {
				aFilters.push({
					ValueKey: key,
					ValueText: this.oFilters[key],
					enabled: key !== 'caseID'
				});
			}
			// var aObjectTypes = [];
			// for(var key in this.oCustomerEngagement){
			// 	aObjectTypes.push({key:key, text:this.oCustomerEngagement[key]});
			// }
			this.oViewModel = new JSONModel({
				editing: false,
				valueHelpDialogTitle: "",
				filters: aFilters,
				regions: this.oRegions,
				country: [],
				productCategories: [],
				MCCSolution: [],
				MCCTag: [],
				productLines: [],
				products: [],
				customers: [],
				globalUltimates: []
			});
			this.oViewModel.setSizeLimit(99999999);
			this.getView().setModel(this.oViewModel, "viewModel");

			var suggestionModel = new JSONModel({
				"items": []
			});
			this.getView().setModel(suggestionModel, "suggestionModel");

			this.subModel = this.getModel("subModel");

			/*$.when(dfdFiltersModelLoaded).done(function () {
				this.loadRoles();
			}.bind(this));*/
		},

		onBeforeRendering: function () {
			var oSettings = this.getOwnerComponent().getModel("settings").getData();
			this.aCustomerEngagement = [];
			//the GEM selection should only be available if user has access via profile to global Escalations
			// sales org specific AUTH should be handled by the additional auth check in the workbench app
			if (oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations) {
				this.aCustomerEngagement.push({
					ValueKey: "GEM",
					ValueText: "Global Escalations"
				});
			}
			this.aCustomerEngagement.push({
				ValueKey: "CCM",
				ValueText: "Critical Customer Management"
			});

			this.aCustomerEngagement.push({
				ValueKey: "CPC",
				ValueText: "Critical Period Coverage"
			});
			this.aCustomerEngagement.push({
				ValueKey: "TC2",
				ValueText: "Top Critical Customer"
			});
			this.oViewModel.setProperty("/CustomerEngagement", this.aCustomerEngagement);
			this.loadRoles();
		},

		loadRoles: function () {
			sap.ui.core.BusyIndicator.show();
			this.subModel.read("/MailRoles", {
				filters: [new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, this.getModel("userapi").getProperty("/name"))],
				sorters: [new sap.ui.model.Sorter("createdAt")],
				success: function (oData) {
					var settings = [];
					for (var i = 0; i < oData.results.length; i++) {
						var item = oData.results[i];
						for (var filter in this.oFilters) {
							if (item[filter]) {
								var filterItem = {};
								filterItem.filterName = filter;
								if (filter === "caseID") {
									filterItem.filterValue = item[filter];
								} else {
									filterItem.filterValue = item[filter].split(",");
								}
								filterItem.RoleID = item.RoleID;
								settings.push(filterItem);
							}
						}
						if (item.CustomerEngagement) {
							var filterItem = {};
							filterItem.RoleID = item.RoleID;
							filterItem.CustomerEngagement = item.CustomerEngagement.split(",");
							settings.push(filterItem);
						}
					}
					//first read all descriptions to the keys
					this.getFilterTexts(settings).then(function () {

						//now map description to key
						oData.results.forEach(function (subscription) {
							if (subscription.Customer && subscription.Customer !== "") {
								subscription.Customer = subscription.Customer.split(",");
								for (var n = 0; n < subscription.Customer.length; n++) {
									var oCustomer = this.aCustomers.find(function (cus) {
										return cus.ValueKey === subscription.Customer[n];
									});
									if (oCustomer) {
										subscription.Customer[n] = oCustomer.ValueText;
									}
								}
							}
							if (subscription.GlobalUltimate && subscription.GlobalUltimate !== "") {
								subscription.GlobalUltimate = subscription.GlobalUltimate.split(",");
								for (var n = 0; n < subscription.GlobalUltimate.length; n++) {
									var oCustomer = this.aCustomers.find(function (cus) {
										return cus.ValueKey === subscription.GlobalUltimate[n];
									});
									if (oCustomer) {
										subscription.GlobalUltimate[n] = oCustomer.ValueText;
									}
								}
							}
							if (subscription.ProductLine && subscription.ProductLine !== "") {
								subscription.ProductLine = subscription.ProductLine.split(",");
								for (var n = 0; n < subscription.ProductLine.length; n++) {
									var oProductLine = this.aProductLines.find(function (cus) {
										return cus.ValueKey === subscription.ProductLine[n];
									});
									if (oProductLine) {
										subscription.ProductLine[n] = oProductLine.ValueText;
									}
								}
							}
							if (subscription.Product && subscription.Product !== "") {
								subscription.Product = subscription.Product.split(",");
								for (var n = 0; n < subscription.Product.length; n++) {
									var oProduct = this.aProducts.find(function (cus) {
										return cus.ValueKey === subscription.Product[n];
									});
									if (oProduct) {
										subscription.Product[n] = oProduct.ValueText;
									}
								}
							}

							if (subscription.country && subscription.country !== "") {
								subscription.country = subscription.country.split(",");
								var aCountries = this.getView().getModel("viewModel").getProperty("/country");
								for (var n = 0; n < subscription.country.length; n++) {
									var oCountry = aCountries.find(function (cus) {
										return cus.ValueKey === subscription.country[n];
									});
									if (oCountry) {
										subscription.country[n] = oCountry.ValueText;
									}
								}
							}

							if (subscription.subregion && subscription.subregion !== "") {
								subscription.subregion = subscription.subregion.split(",");
								var aRegions = this.getView().getModel("viewModel").getProperty("/regions");
								for (var n = 0; n < subscription.subregion.length; n++) {
									var oRegion = aRegions.find(function (cus) {
										return cus.ValueKey === subscription.subregion[n];
									});
									if (oRegion) {
										subscription.subregion[n] = oRegion.ValueText;
									}
								}
							}

							//we need to push subsubregion into subregion, because we have only 1 UI Element
							if (subscription.subsubregion && subscription.subsubregion !== "") {
								subscription.subsubregion = subscription.subsubregion.split(",");
								var aRegions = this.getView().getModel("viewModel").getProperty("/regions");
								for (var n = 0; n < subscription.subsubregion.length; n++) {
									var oRegion = aRegions.find(function (cus) {
										return cus.ValueKey === subscription.subsubregion[n];
									});

									if (subscription.subregion === null || subscription.subregion === "") {
										subscription.subregion = [];
									}

									if (oRegion) {
										subscription.subregion.push(oRegion.ValueText);
									}
								}
							}

							if (subscription.ProductCategory && subscription.ProductCategory !== "") {
								subscription.ProductCategory = subscription.ProductCategory.split(",");
								var aProductCategories = this.getView().getModel("viewModel").getProperty("/productCategories");
								for (var n = 0; n < subscription.ProductCategory.length; n++) {
									var oProductCategory = aProductCategories.find(function (cus) {
										return cus.ValueKey === subscription.ProductCategory[n];
									});
									if (oProductCategory) {
										subscription.ProductCategory[n] = oProductCategory.ValueText;
									}
								}
							}

							if (subscription.SolutionArea && subscription.SolutionArea !== "") {
								subscription.SolutionArea = subscription.SolutionArea.split(",");
								var aMCCSolutions = this.getView().getModel("viewModel").getProperty("/MCCSolution");
								for (var n = 0; n < subscription.SolutionArea.length; n++) {
									var oSolutionArea = aMCCSolutions.find(function (cus) {
										return cus.SolKey === subscription.SolutionArea[n];
									});
									if (oSolutionArea) {
										subscription.SolutionArea[n] = oSolutionArea.Description;
									}
								}
							}

							if (subscription.MCCTag && subscription.MCCTag !== "") {
								subscription.MCCTag = subscription.MCCTag.split(",");
								var aMCCTags = this.getView().getModel("viewModel").getProperty("/MCCTag");
								for (var n = 0; n < subscription.MCCTag.length; n++) {
									var oMCCTag = aMCCTags.find(function (tag) {
										return tag.Name === subscription.MCCTag[n];
									});
									if (oMCCTag) {
										subscription.MCCTag[n] = oMCCTag.Name;
									}
								}
							}

							if (subscription.CustomerEngagement && subscription.CustomerEngagement !== "") {
								subscription.CustomerEngagement = subscription.CustomerEngagement.split(",");
								var aCustomerEngagements = this.getView().getModel("viewModel").getProperty("/CustomerEngagement");
								for (var n = 0; n < subscription.CustomerEngagement.length; n++) {
									var oCustomerEngment = aCustomerEngagements.find(function (cus) {
										return cus.ValueKey === subscription.CustomerEngagement[n];
									});
									if (oCustomerEngment) {
										subscription.CustomerEngagement[n] = oCustomerEngment.ValueText;
									}
								}
							}

						}.bind(this));

						var oModel = new JSONModel(oData);
						this.getView().setModel(oModel, "data");
						sap.ui.core.BusyIndicator.hide();
					}.bind(this));

				}.bind(this),
				error: function (err) {
					//Busy indicator also must be hidden in case there is an error
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},

		getFiltersValueSet: function () {
			var oModel = this.getModel("mainModelNoBatch");
			var dfd = jQuery.Deferred();
			var dfd1 = jQuery.Deferred();
			var dfd2 = jQuery.Deferred();
			var dfd3 = jQuery.Deferred();
			var dfd4 = jQuery.Deferred();
			$.when(dfd1, dfd2, dfd3, dfd4).done(function () {
				dfd.resolve();
				sap.ui.core.BusyIndicator.hide();
				// this.oModel.updateBindings(true);
			}.bind(this));
			var oAppDepModel = this.getModel("appDepModelNoBatch");
			oModel.read("/GenericFilterSet", {
				urlParameters: {
					"$top": 999
				},
				filters: [new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, "PRODUCT_CATEGORY_FLT"), new sap.ui.model.Filter(
					"ValueText", sap.ui.model.FilterOperator.EQ, "")],
				success: function (data) {
					this.oViewModel.setProperty("/productCategories", data.results);
					dfd1.resolve();
				}.bind(this),
				error: function (data) {

				}.bind(this)
			});
			var oCountrySorter = new sap.ui.model.Sorter({
				path: "ValueText",
				descending: false
			});
			oModel.read("/GenericFilterSet", {
				urlParameters: {
					"$top": 300
				},
				filters: [new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, "COUNTRY_FLT")],
				sorters: [oCountrySorter],
				success: function (data) {
					this.oViewModel.setProperty("/country", data.results);
					dfd2.resolve();
				}.bind(this),
				error: function (data) {

				}.bind(this)
			});
			oAppDepModel.read("/SolutionSet", {
				success: function (data) {
					this.oViewModel.setProperty("/MCCSolution", data.results);
					dfd3.resolve();
				}.bind(this),
				error: function (data) {

				}.bind(this)
			});

			var oSubModel = this.getOwnerComponent().getModel("subModel");
			var dToday = new Date();
			var aMCCTagsFilters = [];

			// we decided to show for subscriptions and facet filters all active MCC Tags 	aMCCTagsFilters.push(new sap.ui.model.Filter("ShowInOneDashboard", sap.ui.model.FilterOperator.EQ, true));

			aMCCTagsFilters.push(new sap.ui.model.Filter([
				new sap.ui.model.Filter("DateFrom", sap.ui.model.FilterOperator.LE, dToday),
				new sap.ui.model.Filter("DateTo", sap.ui.model.FilterOperator.GE, dToday),
				new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "MCC")
			], true));

			oSubModel.read("/MCCTags", {
				filters: aMCCTagsFilters,
				success: function (data) {
					this.oViewModel.setProperty("/MCCTag", data.results);
					dfd4.resolve();
				}.bind(this)
			});
			return dfd;
		},

		onSave: function () {
			var oData = this.getView().getModel("data").getData();
			var oSubModel = this.getModel("subModel");
			var aPromises = [];
			var bInvalid = false;

			//check all data. double loop, but not no other possibility with this data model
			oData.results.forEach(function (data) {
				if ((!data.Customer || data.Customer.length === 0) &&
					(!data.caseID || data.caseID.length === 0) &&
					(!data.GlobalUltimate || data.GlobalUltimate.length === 0) &&
					(!data.ProductLine || data.ProductLine.length === 0) &&
					(!data.Product || data.Product.length === 0) &&
					(!data.country || data.country.length === 0) &&
					(!data.subregion || data.subregion.length === 0) &&
					(!data.subsubregion || data.subsubregion.length === 0) &&
					(!data.ProductCategory || data.ProductCategory.length === 0) &&
					(!data.MCCTag || data.MCCTag.length === 0) &&
					(!data.SolutionArea || data.SolutionArea.length === 0) ||
					(!data.CustomerEngagement || data.CustomerEngagement.length === 0)
				) {
					bInvalid = true;
				}
			}.bind(this));

			if (oData.results.length === 0) {
				bInvalid = false;
			}

			if (bInvalid) {
				sap.m.MessageBox.warning(
					"Please select at least one MCC Engagement as well as one other value.", {
					styleClass: "sapUiSizeCompact"
				}
				);
			} else {
				oData.results.forEach(function (data) {
					if (data.edited || data.newItem) {
						//prepare payload. replace texts with ids
						if (data.Customer && data.Customer.length >= 0) {
							var aKeyArray = [];
							if (typeof data.Customer === "object") {
								data.Customer.forEach(function (customer) {
									var oCustomer = this.aCustomers.find(function (cus) {
										return cus.ValueText === customer;
									});
									if (oCustomer.ValueKey) {
										aKeyArray.push(oCustomer.ValueKey);
									}
								}.bind(this));
								data.Customer = aKeyArray.toString();
							}

						}

						if (data.Customer === "") {
							data.Customer = null;
						}

						if (data.GlobalUltimate && data.GlobalUltimate.length >= 0) {
							var aKeyArray = [];
							if (typeof data.GlobalUltimate === "object") {
								data.GlobalUltimate.forEach(function (customer) {
									var oCustomer = this.aCustomers.find(function (cus) {
										return cus.ValueText === customer;
									});
									if (oCustomer) {
										aKeyArray.push(oCustomer.ValueKey);
									}
								}.bind(this));
								data.GlobalUltimate = aKeyArray.toString();
							}
						}

						if (data.GlobalUltimate === "") {
							data.GlobalUltimate = null;
						}

						if (data.ProductLine && data.ProductLine.length >= 0) {
							var aKeyArray = [];
							if (typeof data.ProductLine === "object") {
								data.ProductLine.forEach(function (productLine) {
									var oProductLine = this.aProductLines.find(function (pl) {
										return pl.ValueText === productLine;
									});
									if (oProductLine) {
										aKeyArray.push(oProductLine.ValueKey);
									}
								}.bind(this));
								data.ProductLine = aKeyArray.toString();
							}
						}

						if (data.ProductLine === "") {
							data.ProductLine = null;
						}

						if (data.Product && data.Product.length >= 0) {
							var aKeyArray = [];
							if (typeof data.Product === "object") {
								data.Product.forEach(function (product) {
									var oProduct = this.aProducts.find(function (p) {
										return p.ValueText === product;
									});
									if (oProduct) {
										aKeyArray.push(oProduct.ValueKey);
									}
								}.bind(this));
								data.Product = aKeyArray.toString();
							}
						}

						if (data.Product === "") {
							data.Product = null;
						}

						if (data.country && data.country.length >= 0) {
							var aKeyArray = [];
							if (typeof data.country === "object") {
								data.country.forEach(function (country) {
									var aCountries = this.getView().getModel("viewModel").getProperty("/country");
									var oCountry = aCountries.find(function (p) {
										return p.ValueText === country;
									});
									if (oCountry) {
										aKeyArray.push(oCountry.ValueKey);
									}
								}.bind(this));
								data.country = aKeyArray.toString();
							}
						}

						if (data.country === "") {
							data.country = null;
						}

						if (data.subregion && data.subregion.length >= 0) {
							var aKeyArray = [];
							var aKeySubSubRegion = [];
							if (typeof data.subregion === "object") {
								data.subregion.forEach(function (subregion) {
									var aRegions = this.getView().getModel("viewModel").getProperty("/regions");
									var oCountry = aRegions.find(function (p) {
										return p.ValueText === subregion;
									});
									if (oCountry && oCountry.ValueKey !== "EMEA North" && oCountry.ValueKey !== "EMEA South") {
										aKeyArray.push(oCountry.ValueKey);
									} else if (oCountry && oCountry.ValueKey && (oCountry.ValueKey === "EMEA North" || oCountry.ValueKey === "EMEA South")) {
										aKeySubSubRegion.push(oCountry.ValueKey);
									}
								}.bind(this));
								data.subregion = aKeyArray.toString();
								data.subsubregion = aKeySubSubRegion.toString();
							}
						}

						if (data.subregion === "") {
							data.subregion = null;
						}

						if (data.subsubregion === "") {
							data.subsubregion = null;
						}

						if (data.ProductCategory && data.ProductCategory.length >= 0) {
							var aKeyArray = [];
							if (typeof data.ProductCategory === "object") {
								data.ProductCategory.forEach(function (ProductCategory) {
									var aProductCategories = this.getView().getModel("viewModel").getProperty("/productCategories");
									var oCountry = aProductCategories.find(function (p) {
										return p.ValueText === ProductCategory;
									});
									if (oCountry) {
										aKeyArray.push(oCountry.ValueKey);
									}
								}.bind(this));
								data.ProductCategory = aKeyArray.toString();
							}
						}

						if (data.ProductCategory === "") {
							data.ProductCategory = null;
						}

						if (data.SolutionArea && data.SolutionArea.length >= 0) {
							var aKeyArray = [];
							if (typeof data.SolutionArea === "object") {
								data.SolutionArea.forEach(function (SolutionArea) {
									var aSolutionAreas = this.getView().getModel("viewModel").getProperty("/MCCSolution");
									var oSolutionArea = aSolutionAreas.find(function (p) {
										return p.Description === SolutionArea;
									});
									if (oSolutionArea) {
										aKeyArray.push(oSolutionArea.SolKey);
									}
								}.bind(this));
								data.SolutionArea = aKeyArray.toString();
							}
						}

						if (data.SolutionArea === "") {
							data.SolutionArea = null;
						}

						if (data.MCCTag && data.MCCTag.length >= 0) {
							var aKeyArray = [];
							if (typeof data.MCCTag === "object") {
								data.MCCTag.forEach(function (MCCTag) {
									var aMCCTags = this.getView().getModel("viewModel").getProperty("/MCCTag");
									var oMCCTag = aMCCTags.find(function (p) {
										return p.Name === MCCTag;
									});
									if (oMCCTag) {
										aKeyArray.push(oMCCTag.Name);
									}
								}.bind(this));
								data.MCCTag = aKeyArray.toString();
							}
						}

						if (data.MCCTag === "") {
							data.MCCTag = null;
						}

						if (data.CustomerEngagement && data.CustomerEngagement.length >= 0) {
							var aKeyArray = [];
							if (typeof data.CustomerEngagement === "object") {
								data.CustomerEngagement.forEach(function (CustomerEngagement) {
									var aCustomerEngagements = this.getView().getModel("viewModel").getProperty("/CustomerEngagement");
									var oCustomerEngagement = aCustomerEngagements.find(function (p) {
										return p.ValueText === CustomerEngagement;
									});
									if (oCustomerEngagement) {
										aKeyArray.push(oCustomerEngagement.ValueKey);
									}
								}.bind(this));
								data.CustomerEngagement = aKeyArray.toString();
							}
						}

						if (data.CustomerEngagement === "") {
							data.CustomerEngagement = null;
						}

						if (data.edited && !data.newItem) {
							if (data.subregion === "") {
								data.subregion = null;
							}
							aPromises.push(new Promise(function (resolve) {
								delete data.edited;
								delete data.newItem;
								oSubModel.update("/MailRoles(guid'" + data.RoleID + "')", data, {
									success: function (response) {
										resolve();
									}.bind(this)
								});
							}.bind(this)));
						} else if (data.newItem) {
							aPromises.push(new Promise(function (resolve) {
								delete data.edited;
								delete data.newItem;
								oSubModel.create("/MailRoles", data, {
									success: function (response) {
										resolve();
									}.bind(this)
								});
							}.bind(this)));
						}
					}
				}.bind(this));

				this.aToDelete.forEach(function (id) {
					if (id !== undefined) {
						aPromises.push(new Promise(function (resolve) {
							oSubModel.remove("/MailRoles(guid'" + id + "')", {
								success: function (response) {
									resolve();
								}.bind(this)
							});
						}.bind(this)));
						this.aToDelete = [];
					}
				}.bind(this));

				//only cancel if something happend
				Promise.all(aPromises).then(function () {
					sap.m.MessageBox.success(
						"Changes have been successfully saved.", {
						styleClass: "sapUiSizeCompact"
					}
					);
					this.oViewModel.setProperty("/editing", false);
					this.loadRoles();
				}.bind(this));
			}

		},

		onAdd: function () {
			var newItem = {
				newItem: true,
				RoleType: "SUB",
				Recipients: this.getModel("userapi").getProperty("/email"),
				UserID: this.getModel("userapi").getProperty("/name"),
				caseID: null //needed for editable setting of the filters to be selected, moreover caseID can only be added through Case Detail view
			};
			var aData = this.getView().getModel("data").getData().results;
			aData.unshift(newItem);
			this.getView().getModel("data").refresh();
			this.getView().byId("subscriptionsTable").setVisibleRowCount(aData.length);
		},

		onDelete: function (oEv) {
			var aData = this.getView().getModel("data").getData().results;
			var oData = oEv.getSource().getBindingContext("data").getObject();
			this.aToDelete.push(oData.RoleID);
			var index = aData.findIndex(function (data) {
				return data.RoleID === oData.RoleID;
			});
			aData.splice(index, 1);
			this.getView().getModel("data").refresh();

			this.getView().byId("subscriptionsTable").setVisibleRowCount(aData.length);
		},

		onComboBoxUpdate: function (oEv) {
			//just set edited flag, to know if we need to update on save
			var oData = oEv.getSource().getBindingContext("data").getObject();
			oData.edited = true;
		},

		onTokenUpdate: function (oEv) {
			var aAddedToken = oEv.getParameter("addedTokens");
			var aRemovedTokens = oEv.getParameter("removedTokens");
			var sType = oEv.getSource().data("type");
			var oData = oEv.getSource().getBindingContext("data").getObject();
			oData.edited = true;
			aRemovedTokens.forEach(function (token) {
				//get key by filters
				if (sType === "Customer") {
					var index = oData.Customer.findIndex(function (customer) {
						return token.getText() === customer;
					});
					oData.Customer.splice(index, 1);
				}
				if (sType === "GlobalUltimate") {
					var index = oData.GlobalUltimate.findIndex(function (gu) {
						return token.getText() === gu;
					});
					oData.GlobalUltimate.splice(index, 1);
				}
				if (sType === "ProductLine") {
					var index = oData.ProductLine.findIndex(function (productLine) {
						return token.getText() === productLine;
					});
					oData.ProductLine.splice(index, 1);
				}
				if (sType === "Product") {
					var index = oData.Product.findIndex(function (product) {
						return token.getText() === product;
					});
					oData.Product.splice(index, 1);
				}
			}.bind(this));
			aAddedToken.forEach(function (token) {
				if (sType === "Customer") {
					if (!oData.Customer) {
						oData.Customer = [];
					}
					oData.Customer.push(token.getText());
					this.aCustomers.push({
						ValueKey: token.getKey(),
						ValueText: token.getText()
					});
				}
				if (sType === "GlobalUltimate") {
					if (!oData.GlobalUltimate) {
						oData.GlobalUltimate = [];
					}
					oData.GlobalUltimate.push(token.getText());
					this.aCustomers.push({
						ValueKey: token.getKey(),
						ValueText: token.getText()
					});
				}
				if (sType === "ProductLine") {
					if (!oData.ProductLine) {
						oData.ProductLine = [];
					}
					oData.ProductLine.push(token.getText());
					this.aProductLines.push({
						ValueKey: token.getKey(),
						ValueText: token.getText()
					});
				}
				if (sType === "Product") {
					if (!oData.Product) {
						oData.Product = [];
					}
					oData.Product.push(token.getText());
					this.aProducts.push({
						ValueKey: token.getKey(),
						ValueText: token.getText()
					});
				}
			}.bind(this));
		},

		onSuggest: function (oEvent) {
			var oInput = oEvent.getSource();
			this._oMultiInput = oInput;
			var sValue = oEvent.getParameter("suggestValue");
			var sType = this._oMultiInput.data("type");
			var oModel = this.getOwnerComponent().getModel("mainModelNoBatch");
			// reset suggestionItems list
			if (this.getView().getModel("suggestionModel")) {
				this.getView().getModel("suggestionModel").setProperty("/items", []);
			}
			if (sValue === "") {
				return null;
			}
			//show busy indicator
			oInput.setBusyIndicatorDelay(0);
			oInput.setBusy(true);

			if (sType === "Customer" || sType === "GlobalUltimate") {
				var oFilter = new Array(
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("CustomerName", sap.ui.model.FilterOperator.Contains, sValue),
						new sap.ui.model.Filter("ErpCustNo", sap.ui.model.FilterOperator.EQ, sValue),
						new sap.ui.model.Filter("Partner", sap.ui.model.FilterOperator.EQ, sValue)
					],
						false
					)
				);
				oModel.read("/CustomerSet", {
					urlParameters: {
						"$top": 999,
						"$select": "CustomerName,ErpCustNo,Iac,CountryT,GuErpNo,IsGlobalUltimate"
					},
					filters: oFilter,
					success: function (data, response) {
						oInput.setBusy(false);
						var aCustomerData = [];
						//push data to array
						data.results.forEach(function (customer) {
							var visible = sType === "Customer" ? true : customer.IsGlobalUltimate === "X";
							if (visible) {
								aCustomerData.push({
									text: customer.CustomerName,
									key: customer.ErpCustNo,
									filterProp: customer.IsGlobalUltimate === "X" ? "Global Ultimate" : "Customer",
									iac: this.iacValues.indexOf(customer.Iac) > -1 ? customer.Iac : "ZZZZZ",
									description: " - " + customer.CountryT //"(" + customer.CountryT + ")"
								});
							}

						}.bind(this));

						this.iacValues.push("ZZZZZ");

						//sort array by filterProp and iac
						aCustomerData = aCustomerData.sort(function (a, b) {
							if (this.iacValues.indexOf(a.iac) < this.iacValues.indexOf(b.iac)) {
								return -1;
							} else if (this.iacValues.indexOf(a.iac) > this.iacValues.indexOf(b.iac)) {
								return 1;
							} else if (b.filterProp < a.filterProp) {
								return -1;
							} else if (b.filterProp > a.filterProp) {
								return 1;
							} else if (b.text > a.text) {
								return -1;
							} else if (b.text < a.text) {
								return 1;
							} else if (b.description > a.description) {
								return -1;
							} else if (b.description < a.description) {
								return 1;
							}
							return 0;
						}.bind(this));

						for (var i = 0; i < aCustomerData.length; i++) {
							if (i === 0) {
								aCustomerData[i].isTopMatch = true;
							} else if ((i === 1 || i === 2) && aCustomerData[i].iac !== "ZZZZZ") {
								aCustomerData[i].isTopMatch = true;
							} else if (i > 2 && i < 5 && aCustomerData[i].iac !== "ZZZZZ" && aCustomerData[i].iac === aCustomerData[(i - 1)].iac) {
								aCustomerData[i].isTopMatch = true;
							} else {
								aCustomerData[i].isTopMatch = false;
							}
						}

						this.getView().getModel("suggestionModel").setProperty("/items", aCustomerData);
						// oInput.suggest();
					}.bind(this)
				});
			} else if (sType === "Product") {
				oModel.read("/GenericFilterSet", {
					urlParameters: {
						"$top": 999
					},
					filters: [new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, "PRODUCT_FLT"), new sap.ui.model.Filter(
						"ValueText", sap.ui.model.FilterOperator.Contains, sValue)],
					success: function (data) {
						oInput.setBusy(false);
						var aProductData = [];
						//push data to array
						data.results.forEach(function (product) {
							aProductData.push({
								text: product.ValueText,
								key: product.ValueKey
							});
						}.bind(this));
						this.getView().getModel("suggestionModel").setProperty("/items", aProductData);
					}.bind(this),
					error: function (data) {

					}.bind(this)
				});
			} else if (sType === "ProductLine") {
				oModel.read("/GenericFilterSet", {
					urlParameters: {
						"$top": 999
					},
					filters: [new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, "PRODUCT_LINE_FLT"), new sap.ui.model.Filter(
						"ValueText", sap.ui.model.FilterOperator.Contains, sValue)],
					success: function (data) {
						oInput.setBusy(false);
						var aProductLineData = [];
						//push data to array
						data.results.forEach(function (productLine) {
							aProductLineData.push({
								text: productLine.ValueText,
								key: productLine.ValueKey
							});
						}.bind(this));
						this.getView().getModel("suggestionModel").setProperty("/items", aProductLineData);
					}.bind(this),
					error: function (data) {

					}.bind(this)
				});
			}
		},
		onSuggestionItemSelected: function (e) {
			this.getView().getModel("suggestionModel").setProperty("/items", []);
			var sFilterName = this._oMultiInput.getName();
			var sPath = this._oMultiInput.getBindingContext().getPath();
			var aTokens = this._oMultiInput.getTokens();
			var that = this;
			if (aTokens && aTokens.length) {
				var aFilterValue = aTokens.map(function (tk) {
					if (sFilterName === "Customer" || sFilterName === "GlobalUltimate") {
						var aCustomers = that.customerModel.getProperty("/customers");
						aCustomers.push({
							ValueKey: tk.getKey(),
							ValueText: tk.getText()
						});
						that.customerModel.setProperty("/customers", aCustomers);
					} else if (sFilterName === "ProductLine") {
						var aProductLines = that.oViewModel.getProperty("/productLines");
						aProductLines.push({
							ValueKey: tk.getKey(),
							ValueText: tk.getText()
						});
						that.oViewModel.setProperty("/productLines", aProductLines);
					} else if (sFilterName === "Product") {
						var aProducts = that.oViewModel.getProperty("/products");
						aProducts.push({
							ValueKey: tk.getKey(),
							ValueText: tk.getText()
						});
						that.oViewModel.setProperty("/products", aProducts);
					}

					return tk.getKey();
				});
				this.oModel.setProperty(sPath + "/filterValue", aFilterValue);
			}
		},

		onEdit: function () {
			this.oViewModel.setProperty("/editing", true);
		},
		onCancel: function () {
			this.oViewModel.setProperty("/editing", false);
			this.loadRoles();
		},

		getFilterTexts: function (settings) {
			return new Promise(function (resolve) {
				var selectedFilters = settings;
				var oModel = this.getOwnerComponent().getModel("mainModelNoBatch");
				var aCustomerIDs = [];
				var aCustomerFilters = [];
				var aProducts = [];
				var aProductLines = [];
				var aProductFilters = [];
				var aProductLineFilters = [];
				var aPromises = [];
				selectedFilters.forEach(function (item) {
					if ((item.filterName === "Customer" || item.filterName === "GlobalUltimate") && item.filterValue.length) {
						item.filterValue.forEach(function (customer) {
							if (aCustomerIDs.indexOf(customer) === -1) {
								aCustomerFilters.push(new sap.ui.model.Filter("ErpCustNo", sap.ui.model.FilterOperator.EQ, customer));
								aCustomerIDs.push(customer);
							}
						});
					}
					if (item.filterName === "Product" && item.filterValue.length) {
						item.filterValue.forEach(function (product) {
							if (aProducts.indexOf(product) === -1) {
								aProductFilters.push(new sap.ui.model.Filter("ValueText", sap.ui.model.FilterOperator.EQ, product));
								aProducts.push(product);
							}
						});
					}
					if (item.filterName === "ProductLine" && item.filterValue.length) {
						item.filterValue.forEach(function (productLine) {
							if (aProductLines.indexOf(productLine) === -1) {
								aProductLineFilters.push(new sap.ui.model.Filter("ValueText", sap.ui.model.FilterOperator.EQ, productLine));
								aProductLines.push(productLine);
							}
						});
					}
				});
				if (aCustomerFilters.length) {
					aPromises.push(new Promise(function (resolveCustomer) {
						var oCustomerFilter = new Array(
							new sap.ui.model.Filter(aCustomerFilters,
								false
							)
						);
						oModel.read("/CustomerSet", {
							urlParameters: {
								"$top": 999,
								"$select": "CustomerName,Name1,ErpCustNo,Iac,CountryT,GuErpNo"
							},
							filters: oCustomerFilter,
							success: function (data, response) {
								var that = this;
								this.aCustomers = [];
								data.results.forEach(function (customer) {
									that.aCustomers.push({
										ValueKey: customer.ErpCustNo,
										ValueText: customer.CustomerName + " - " + customer.CountryT
									});
									// this.aCustomers[customer.ErpCustNo] = customer;
								});
								resolveCustomer();
							}.bind(this)
						});
					}.bind(this)));

				}
				if (aProductFilters.length) {
					this.aProducts = [];
					for (var j = 0; j < aProductFilters.length; j++) {
						aPromises.push(new Promise(function (resolveProducts) {
							oModel.read("/GenericFilterSet", {
								urlParameters: {},
								filters: [new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, "PRODUCT_FLT"), aProductFilters[j]],
								success: function (data) {
									var that = this;
									data.results.forEach(function (product) {
										that.aProducts.push({
											ValueKey: product.ValueKey,
											ValueText: product.ValueText
										});
									});
									resolveProducts();
								}.bind(this)
							});
						}.bind(this)));
					}
				}
				if (aProductLineFilters.length) {
					this.aProductLines = [];
					for (var j = 0; j < aProductLineFilters.length; j++) {
						aPromises.push(new Promise(function (resolvePL) {
							oModel.read("/GenericFilterSet", {
								urlParameters: {},
								filters: [new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, "PRODUCT_LINE_FLT"),
								aProductLineFilters[j]
								],
								success: function (data) {
									var that = this;
									data.results.forEach(function (productLine) {
										that.aProductLines.push({
											ValueKey: productLine.ValueKey,
											ValueText: productLine.ValueText
										});
									});
									resolvePL();
								}.bind(this)
							});

						}.bind(this)));
					}
				}

				Promise.all(aPromises).then(function () {
					resolve();
				});

			}.bind(this));

		}

	});

});