sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment"
], function (BaseController, formatter, JSONModel, Fragment) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.TopCriticalCustomers", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				iTabFiltered: 0,
				bLoadingState: false,
				showObjectType: false,
				isTCCView: true
			}), "viewModel");
			this.getRouter().getRoute("TopCriticalCustomers").attachPatternMatched(this._onObjectMatched, this);

		},

		onAfterRendering: function () {
			var oTable = this.getView().byId("table");
			oTable.attachFilter(function (oEvent) {
				setTimeout(function () {
					this._updateFilteredCount();
				}.bind(this), 200); //Wait for filter execution
			}, this);

			//Attach Listener in case a global Filter is applied
			var oSearchField = this.getSearchField(oTable);
			oSearchField.attachSearch(function (oEvent) {
				this._updateFilteredCount();
			}, this);
		},

		_onObjectMatched: function (oEvent) {
			//Check if data was already loaded. If yes, use this data
			if (this.getOwnerComponent().getModel("data").getProperty("/reloadTopCriticalCustomers")) {
				this.getOwnerComponent().getModel("data").setProperty("/reloadTopCriticalCustomers", false);
				this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "tableData");
				this._updateTable();
			}
			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);

			//Need to hide the Column Manually since the MCCTags Fragment is reused for TC2
			var oAssignmentGroupColumn = this.getView().byId("assignmentGroupColumn");
			oAssignmentGroupColumn.setVisible(false);
		},

		_updateTable: function () {
			var aFilters = [];
			var oTable = this.getView().byId("table");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			var bCaseFilter = this.getOwnerComponent().getModel("data").getProperty("/taskForcesFilter");
			this.getView().byId("dataIconTabBar").setSelectedKey("All");
			if (!bCaseState) {
				bCaseState = "open";
			}
			if (bCaseState === "open" || bCaseState === "all") {
				var tileSpecificFilters1 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false)
					],
					true
				);
			}
			if (bCaseState === "closed" || bCaseState === "all") {
				var pastDateSixMonths = new Date();
				pastDateSixMonths.setMonth(pastDateSixMonths.getMonth() - 3);
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90")
						], false),

						this.getClosedDateFilter("ClosingDate", pastDateSixMonths)
					],
					true
				);

			}

			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
						tileSpecificFilters1,
						tileSpecificFilters2
					],
					false
				));
			}

			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP06"));

			var oICModel = this.getOwnerComponent().getModel();
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				// urlParameters: {
				// 	"$select": "CaseId,CaseTitle,CustomerText,Region,StatusT,Rating,CreateDate,CustomerErpNo,ServiceOrgT,HasNotes"
				// },
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);
					this._calculateRating(data);
					data.results.forEach(function (oCase) {
						if (oCase.Rating === "") {
							oCase.Rating = "unrated";
						}
						if (oCase.DbsMaintenanceRanking === "0") {
							oCase.DbsMaintenanceRanking = "";
						}

						oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);
						oCase.objectType = "Top Critical Customers";
						oCase.TopIssuesCountString = oCase.TopIssuesCount.toString();
						//			oCase.FocusAreasCountString = oCase.FocusAreasCount.toString();
					}.bind(this));
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "tableData");
					this.loadProducts();
					this._getTCCFocusAreaCount();
					this.readImplementationPartner(oModel).then(function () {
						setTimeout(function () {
							oTable.rerender();
						}, 200);
					});
					//MISSIONRADAR 2211	
					this.readMissionRadarValues(oModel, "results");

					if (bCaseFilter !== "none") {
						var oIconTabBar = this.getView().byId("dataIconTabBar");
						oIconTabBar.setSelectedKey(bCaseFilter);
						oIconTabBar.fireSelect();
					}
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		loadProducts: function () {
			var aFilters = [];
			var oTable = this.getView().byId("table");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "open";
			}
			if (bCaseState === "open" || bCaseState === "all") {
				var tileSpecificFilters1 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false)
					],
					true
				);
			}
			if (bCaseState === "closed" || bCaseState === "all") {
				var pastDateSixMonths = new Date();
				pastDateSixMonths.setMonth(pastDateSixMonths.getMonth() - 3);
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90")
						], false),
						this.getClosedDateFilter("ClosingDate", pastDateSixMonths)
					],
					true
				);

			}

			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
						tileSpecificFilters1,
						tileSpecificFilters2
					],
					false
				));
			}

			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP06"));

			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$expand": "toProducts",
					"$select": "CaseId,toProducts"
				},
				success: function (data) {
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					var oModel = this.getOwnerComponent().getModel("tableData");
					var aAlreadyAdded = oModel.getData().results;
					this._updateFilteredCount();
					data.results.forEach(function (oCase) {
						oCase.ProductVersions = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.Product = this.formatter.concatProducts(oCase.toProducts.results, "ProductT");
						oCase.ProductCategory = this.formatter.concatProducts(oCase.toProducts.results, "ProductCatT");
						oCase.ProductLine = this.formatter.concatProducts(oCase.toProducts.results, "ProductLineT");
						oCase.ProductVer = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.ProductLineKeys = this.formatter.concatProducts(oCase.toProducts.results, "ProductLine");
						oCase.ProductKeys = this.formatter.concatProducts(oCase.toProducts.results, "Product");

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.CaseId === oCase.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = oCase.toProducts;
								aTmp[i].toLastNotes = oCase.toLastNotes;
								aTmp[i].ProductVersions = oCase.ProductVersions;
								aTmp[i].Product = oCase.Product;
								aTmp[i].ProductCategory = oCase.ProductCategory;
								aTmp[i].ProductLine = oCase.ProductLine;
								aTmp[i].ProductVer = oCase.ProductVer;
								aTmp[i].ProductLineKeys = oCase.ProductLineKeys;
								aTmp[i].ProductKeys = oCase.ProductKeys;
							});
						}
					}.bind(this));
					oModel.refresh();
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		readNotes: function (oControl, id, sObjectType) {
			var oICModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oICModel.read("/CustomerEngagementSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this._updateFilteredCount();
					this.openQuickInfoPopover(oControl, data.results, sObjectType);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		handleRatingIconTabBarSelect: function (oEv) {
			var oTable = this.getView().byId("table");
			var sRatingKey = oEv.getSource().getSelectedKey();
			var aFilter = [];

			// Reset all table filters
			oTable.getColumns().forEach(function (oColumn) {
				oColumn.filter(null);
				oColumn.setFilterValue("");
			});
			this.clearSearchField(oTable);

			if (sRatingKey !== "All") {
				aFilter.push(new sap.ui.model.Filter("Rating", "EQ", sRatingKey));
			}
			oTable.getBinding("rows").filter(aFilter);
			this._updateFilteredCount();
		},

		onCase: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("tableData").getObject().CaseId;
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);
			this.getRouter().navTo("CaseDetails", {
				"?query": this._getQueryParameter(),
				"CaseId": sCaseId
			});
		},

		onCaseNewTab: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("tableData").getObject().CaseId;
			this._openCaseInNewTab(sCaseId);
		},

		onCustomer: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("tableData").getObject().CustomerErpNo;
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("Customer", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		_getTCCFocusAreaCount: function () {
			var oSubModel = this.getView().getModel("subModel");
			var oTableModel = this.getView().getModel("tableData");
			//Todo defensive programming
			var oTableData = oTableModel.getData().results;
			oTableData.forEach(function (row, index) {
				var sCaseId = row.CaseId;
				var aFilter = [new sap.ui.model.Filter("CaseID", "EQ", sCaseId)];

				//only new and in process
				aFilter.push(new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"), //New
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"), //In Progress
				], false));

				oSubModel.read("/MCCProject", {
					filters: aFilter,
					success: function (oData) {
						//Get next upcoming go live date
						//First filter all in past
						var aData = oData.results.filter(function (v) {
							return v.GoLiveDate > new Date();
						});

						if (aData && aData.length > 0) {
							var aData = aData.sort(function (a, b) {
								return a.GoLiveDate - b.GoLiveDate;
							});
							oTableModel.setProperty(`/results/${index}/NextGoLiveDate`, aData[0].GoLiveDate);
						}
						oTableModel.setProperty(`/results/${index}/FocusAreasCount`, oData.results.length);
					}.bind(this),
					error: function (data) {}.bind(this)
				});
			});
		},

		_calculateRating: function (data) {
			var oViewModel = this.getView().getModel("viewModel");
			var iGreen = 0;
			var iYellow = 0;
			var iRed = 0;
			var iUnrated = 0;
			data.results.forEach(function (oCase) {
				switch (oCase.Rating) {
				case "A":
					iGreen++;
					break;
				case "B":
					iYellow++;
					break;
				case "C":
					iRed++;
					break;
				default:
					iUnrated++;
				}
			});
			oViewModel.setProperty("/iTabAll", data.results.length);
			oViewModel.setProperty("/iTabGreen", iGreen);
			oViewModel.setProperty("/iTabYellow", iYellow);
			oViewModel.setProperty("/iTabRed", iRed);
			oViewModel.setProperty("/iTabUnrated", iUnrated);
			this._updateFilteredCount();
		},

		_updateFilteredCount: function () {
			var oTable = this.getView().byId("table");
			var iFilteredCount = oTable.getBinding("rows").getLength();
			var aFilters = oTable.getBinding("rows").aFilters;
			if (aFilters && aFilters.length > 0) {
				var iLengths = oTable.getBinding("rows").iLengths;
				if (iLengths) {
					iFilteredCount = oTable.getBinding("rows").iLength - iLengths.sum();
				} else {
					iFilteredCount = oTable.getBinding("rows").iLength;
				}
			}
			this.getView().getModel("viewModel").setProperty("/iTabFiltered", iFilteredCount);
		},

		_showFocusAreaCountPopover: function (sCaseId, oControl) {
			var oModel = this.getModel("subModel");
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("CaseID", sap.ui.model.FilterOperator.EQ, sCaseId));
			//only new and in process
			aFilters.push(new sap.ui.model.Filter([
				new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"), //New
				new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"), //In Progress
			], false));
			var oPrioritySorter = new sap.ui.model.Sorter("Priority", false);
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oModel.read("/MCCProject", {
				filters: aFilters,
				sorters: [oPrioritySorter],
				urlParameters: {
					"$select": "Title,Description,StatusSummary,CaseID"
				},
				success: function (data) {
					oControl.setBusy(false);
					var oPopoverModel = new JSONModel();
					var aItems = [];
					data.results.forEach(function (focusarea) {
						var oData = {};
						oData.id = focusarea.CaseID;
						oData.description = focusarea.Description;
						oData.title = focusarea.Title;
						oData.statusSummary = focusarea.StatusSummary;
						oData.iconSrc = "sap-icon://circle-task-2";
						//todo: check coloring and ratings
						oData.iconColor = focusarea.Rating === "Green" ? "#b00" : focusarea.Rating === "Yellow" ? "#e9730c" : focusarea.Rating ===
							"Red" ? "#107e3e" :
							"#6a6d70";
						aItems.push(oData);
					}.bind(this));
					if (!this.oFocusAreaPopover) {
						Fragment.load({
							name: "com.sap.mcconedashboard.view.fragment.OpenFocusAreaPopover",
							controller: this
						}).then(function (oPopover) {
							this.oFocusAreaPopover = oPopover;
							oPopoverModel.setData(aItems);
							this.oFocusAreaPopover.setModel(oPopoverModel, "data");
							this.getView().addDependent(this.oFocusAreaPopover);
							this.oFocusAreaPopover.openBy(oControl);
						}.bind(this));
					} else {
						oPopoverModel.setData(aItems);
						this.oFocusAreaPopover.setModel(oPopoverModel, "data");
						this.oFocusAreaPopover.openBy(oControl);
					}

				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
			this.trackEvent("Open Focus Areas: show Popover");
		},

		navToCaseFromFocusAreaPopover: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("data").getObject().id;
			var oParams = this._getQueryParameter();
			oParams["tab"] = "FocusAreaSection";

			this.getOwnerComponent().getModel("case").setProperty("/reload",true);

			this.getRouter().navTo("CaseDetails", {
				CaseId: sCaseId,
				"?query": oParams
			});
			
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("tableData").getObject();
			var sObjectType = "";
			if (oData.CustomerType != "") {
				sObjectType = oData.CustomerType;
			}
			var sId = oData.CaseId;
			this.readNotes(oEv.getSource(), sId, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("tableData").getObject();
			var sCaseId = oProperty.CaseId;
			this._shopTopIssuesCountPopover(sCaseId, oEv.getSource());
		},
		onFocusAreasCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("tableData").getObject();
			var sCaseId = oProperty.CaseId;
			this._showFocusAreaCountPopover(sCaseId, oEv.getSource());
		},

		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("tableData").getPath();
			var oProperty = this.getModel("tableData").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},
		customSorting: function (oEvent) {
			var oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingColumn");
			var oMCCiColumn = this.byId("mcci");
			var oPreventionScoreColumn = this.byId("preventionScore");
			var oCurrentColumn = oEvent.getParameter("column");
			if (oCurrentColumn !== oGUMaintenanceRankingColumn && oCurrentColumn !== oMCCiColumn && oCurrentColumn !== oPreventionScoreColumn) {
				//oGUMaintenanceRankingColumn.setSorted(false); //No multi-column sorting
				return;
			}
			oEvent.preventDefault();
			var sOrder = oEvent.getParameter("sortOrder");
			if (oCurrentColumn == oMCCiColumn || oCurrentColumn == oPreventionScoreColumn) {
				this.customSortingBaseFloat(oCurrentColumn, sOrder, "table");
			} else {
				this.customSortingBase(oCurrentColumn, sOrder, oGUMaintenanceRankingColumn, "table");
			}
		},
		changeCaseState: function () {
			this._updateTable();
		},
		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("tableData").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		}
	});
});