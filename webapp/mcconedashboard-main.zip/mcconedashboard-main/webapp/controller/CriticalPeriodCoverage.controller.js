sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/model/Constants"
], function (BaseController, formatter, Constants) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.CriticalPeriodCoverage", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				bLoadingState: false,
				// iTabAllPA: 0,
				// iTabGreenPA: 0,
				// iTabYellowPA: 0,
				// iTabRedPA: 0,
				// iTabUnratedPA: 0,
				iTabFiltered: 0,
				bLoadingStatePA: false,
				showObjectType: false
			}), "viewModel");
			this.getRouter().getRoute("CriticalPeriodCoverage").attachPatternMatched(this._onObjectMatched, this);

			var oIconTabBar = this.getView().byId("idIconTabBarFiori2");
			oIconTabBar.attachSelect(this.onTabSelect, this);

		},

		onAfterRendering: function () {
			var oTable = this.getView().byId("table");
			oTable.attachFilter(function (oEvent) {
				setTimeout(function () {
					this._updateFilteredCount();
				}.bind(this), 200); //Wait for filter execution
			}, this);

			var oTableClosed = this.getView().byId("tableClosed");
			oTableClosed.attachFilter(function (oEvent) {
				setTimeout(function () {
					this._updateFilteredCount();
				}.bind(this), 200); //Wait for filter execution
			}, this);

			//Attach Listener in case a global Filter is applied
			var oSearchField = this.getSearchField(oTable);
			oSearchField.attachSearch(function (oEvent) {
				this._updateFilteredCount();
			}, this);
		},

		onTabSelect: function (oEvent) {
			var oDataModel = this.getView().getModel("data");
			var oIconTabBar = this.getView().byId("idIconTabBarFiori2");
			var sSelectedKey = oIconTabBar.getSelectedKey();

			if (sSelectedKey === "ongoing") {
				oDataModel.setProperty("/taskForcesState", "open");
				this._updateTable();
			} else if (sSelectedKey === "planned") {
				oDataModel.setProperty("/taskForcesState", "open");
				this._updateTablePlannedActivities();
			} else if (sSelectedKey === "closed") {
				oDataModel.setProperty("/taskForcesState", "closed");
				this._updateTableClosed();
			}
		},

		_onObjectMatched: function (oEvent) {
			//Check if data was already loaded. If yes, use this data
			if (this.getOwnerComponent().getModel("data").getProperty("/reloadCriticalPeriodCoverage")) {
				this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "tableData");
				this.getOwnerComponent().getModel("data").setProperty("/reloadCriticalPeriodCoverage", false);
				this._updateTable();
				//this._updateTablePlannedActivities();
				//this._updateTableClosed();
			}

			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
		},

		_updateTable: function () {
			var aFilters = [];
			var oTable = this.getView().byId("table");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			var bCaseFilter = this.getOwnerComponent().getModel("data").getProperty("/taskForcesFilter");
			this.getView().byId("dataIconTabBar").setSelectedKey("All");

			if (!bCaseState) {
				bCaseState = "open";
			}

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			if (bCaseState === "open" || bCaseState === "all") {
				var tileSpecificFilters1 = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"), //New
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"), //In Progress
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"), //In Escalation
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99") //In Management Review
					], false)
				],
					true
				);
			}
			if (bCaseState === "closed" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
					], false),
					this.getClosedDateFilter("ClosingDate")
				],
					true
				);

			}

			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
					tileSpecificFilters1,
					tileSpecificFilters2
				],
					false
				));
			}

			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04"));

			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				// urlParameters: {
				// 	"$select": "CaseId,CaseTitle,CustomerText,Region,StatusT,Rating,CreateDate,CustomerErpNo,ServiceOrgT,HasNotes"
				// },
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);

					this._calculateRating(data);
					data.results.forEach(function (oCase) {
						if (oCase.Rating === "") {
							oCase.Rating = "unrated";
						}
						if (oCase.DbsMaintenanceRanking === "0") {
							oCase.DbsMaintenanceRanking = "";
						}
						oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);

						switch (oCase.CustomerType) {
							case "ZSCUSTYP05":
								oCase.objectType = "Critical Customer Management";
								break;
							case "ZSCUSTYP04":
								oCase.objectType = "Critical Period Coverage";
								break;
						}

					}.bind(this));
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "tableData");
					this.readImplementationPartner(oModel).then(function () {
						setTimeout(function () {
							oTable.rerender();
						}, 200);
					}.bind(this));
					//MISSIONRADAR 2211	
					this.readMissionRadarValues(oModel, "results");
					this.loadProducts();

					if (bCaseFilter !== "none") {
						var oIconTabBar = this.getView().byId("dataIconTabBar");
						oIconTabBar.setSelectedKey(bCaseFilter);
						oIconTabBar.fireSelect();
					}
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		loadProducts: function () {
			var aFilters = [];
			var oTable = this.getView().byId("table");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "open";
			}

			// if (sRegion) {
			// 	aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, sRegion));
			// }
			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			if (bCaseState === "open" || bCaseState === "all") {
				var tileSpecificFilters1 = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"), //New
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"), //In Progress
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"), //In Escalation
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99") //In Management Review
					], false)
				],
					true
				);
			}
			if (bCaseState === "closed" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
					], false),
					this.getClosedDateFilter("ClosingDate")
				],
					true
				);

			}

			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
					tileSpecificFilters1,
					tileSpecificFilters2
				],
					false
				));
			}

			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04"));

			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$expand": "toProducts",
					"$select": "CaseId,toProducts"
				},
				success: function (data) {

					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					var oModel = this.getOwnerComponent().getModel("tableData");
					var aAlreadyAdded = oModel.getData().results;

					data.results.forEach(function (oCase) {
						oCase.ProductVersions = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.Product = this.formatter.concatProducts(oCase.toProducts.results, "ProductT");
						oCase.ProductCategory = this.formatter.concatProducts(oCase.toProducts.results, "ProductCatT");
						oCase.ProductLine = this.formatter.concatProducts(oCase.toProducts.results, "ProductLineT");
						oCase.ProductVer = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.ProductLineKeys = this.formatter.concatProducts(oCase.toProducts.results, "ProductLine");
						oCase.ProductKeys = this.formatter.concatProducts(oCase.toProducts.results, "Product");

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.CaseId === oCase.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = oCase.toProducts;
								aTmp[i].toLastNotes = oCase.toLastNotes;
								aTmp[i].ProductVersions = oCase.ProductVersions;
								aTmp[i].Product = oCase.Product;
								aTmp[i].ProductCategory = oCase.ProductCategory;
								aTmp[i].ProductLine = oCase.ProductLine;
								aTmp[i].ProductVer = oCase.ProductVer;
								aTmp[i].ProductLineKeys = oCase.ProductLineKeys;
								aTmp[i].ProductKeys = oCase.ProductKeys;
							});
						}
					}.bind(this));
					this._updateFilteredCount();
					oModel.refresh();
				}.bind(this),

				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		readNotes: function (oControl, id, sObjectType) {
			var oICModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oICModel.read("/CustomerEngagementSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results, sObjectType);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		handleRatingIconTabBarSelect: function (oEv) {
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			var oTable = this.getView().byId("table");

			if (bCaseState === "closed") {
				oTable = this.getView().byId("tableClosed");
			}

			var sRatingKey = oEv.getSource().getSelectedKey();
			var aFilter = [];

			// Reset all table filters
			oTable.getColumns().forEach(function (oColumn) {
				oColumn.filter(null);
				oColumn.setFilterValue("");
			});
			this.clearSearchField(oTable);

			if (sRatingKey !== "All") {
				aFilter.push(new sap.ui.model.Filter("Rating", "EQ", sRatingKey));
			}
			oTable.getBinding("rows").filter(aFilter);
			this._updateFilteredCount();
		},

		onCase: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("tableData").getObject().CaseId;
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);

			this.getRouter().navTo("CaseDetails", {
				"?query": this._getQueryParameter(),
				"CaseId": sCaseId
			});
		},

		onCaseNewTab: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("tableData").getObject().CaseId;
			this._openCaseInNewTab(sCaseId);
		},

		onCustomer: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("tableData").getObject().CustomerErpNo;
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("Customer", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		_calculateRating: function (data) {
			var oViewModel = this.getView().getModel("viewModel");
			var iGreen = 0;
			var iYellow = 0;
			var iRed = 0;
			var iUnrated = 0;
			data.results.forEach(function (oCase) {
				switch (oCase.Rating) {
					case "A":
						iGreen++;
						break;
					case "B":
						iYellow++;
						break;
					case "C":
						iRed++;
						break;
					default:
						iUnrated++;
				}
			});
			oViewModel.setProperty("/iTabAll", data.results.length);
			oViewModel.setProperty("/iTabGreen", iGreen);
			oViewModel.setProperty("/iTabYellow", iYellow);
			oViewModel.setProperty("/iTabRed", iRed);
			oViewModel.setProperty("/iTabUnrated", iUnrated);
			this._updateFilteredCount();
		},

		_updateFilteredCount: function () {
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (bCaseState === "closed") {
				var oTable = this.getView().byId("tableClosed");
			} else {
				oTable = this.getView().byId("table");
			}
			var iFilteredCount = oTable.getBinding("rows").getLength();
			var aFilters = oTable.getBinding("rows").aFilters;
			if (aFilters && aFilters.length > 0) {
				var iLengths = oTable.getBinding("rows").iLengths;
				if (iLengths) {
					iFilteredCount = oTable.getBinding("rows").iLength - iLengths.sum();
				} else {
					iFilteredCount = oTable.getBinding("rows").iLength;
				}
			}
			this.getView().getModel("viewModel").setProperty("/iTabFiltered", iFilteredCount);
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("tableData").getObject();
			var sObjectType = "";
			if (oData.CustomerType != "") {
				sObjectType = oData.CustomerType;
			}
			var sId = oData.CaseId;
			this.readNotes(oEv.getSource(), sId, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("tableData").getObject();
			var sCaseId = oProperty.CaseId;
			this._shopTopIssuesCountPopover(sCaseId, oEv.getSource());
		},

		_updateTablePlannedActivities: function () {
			var aFilters = [];
			var oTable = this.getView().byId("tablePA");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);

			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "open";
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterForCriticalPeriodCoverage");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			//Show only for ExpectedAction and Type
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("ExpectedAction", sap.ui.model.FilterOperator.EQ, "accept_engagement")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "AccER")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			//Use only those entries that do not have a EndDate set or it is in the future
			var today = new Date();
			today.setDate(today.getDate());

			/*
			var closedDateFilter = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.GE, today),
					new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.EQ, null)
				], false)
			],
				true
			);
			aFilters.push(closedDateFilter);
			*/

			var startDateFilter = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.GE, today),
					new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, null)
				], false)
			],
				true
			);
			aFilters.push(startDateFilter);

			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			oTable.setBusy(true);
			var that = this;

			oModel.read("/MCCObject", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$select": "ExpectedAction, GoLiveDate, StartDate, EndDate, EscalationID, ProductLineID, ProductLineName, Type, CustomerCountry"
				},
				success: function (data) {
					that._updateTablePlannedWithServiceNow(data);
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this)
			});

		},

		_updateTablePlannedWithServiceNow: function (aMCCObjects) {
			var oTable = this.getView().byId("tablePA");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");



			if (aMCCObjects.results.length > 0) {
				var escalationIDs = aMCCObjects.results.map(function (obj) {
					return obj.EscalationID;
				});

				// Filter out empty or null values
				var validEscalationIDs = escalationIDs.filter(function (id) {
					return id !== null && id !== '';
				});

				// Combine all valid Escalation IDs into a string for the filter
				var escalationIDsString = validEscalationIDs.join(',');

				//var sFilterString = "sysparm_query=ORDERBYu_task_record.priority^u_escalation_type=6";
				var sFilterString = "ORDERBYu_task_record.priority^u_escalation_type=6";
				sFilterString += "^numberIN" + escalationIDsString;

				//sFilterString += "^numberINESC0489274,ESC0494268"

				if (typeof sRegion !== "undefined" && sRegion !== "") {

					var aRegionHelp = this.getModel("countryRegionModel").getData();
					var selectedRegions = sRegion.split(","); // Split the selected regions into an array

					// Create an object to map selected regions to filterBasis (given in countryRegionModel)
					var regionFilterBasisMap = {
						"EMEA North": "subsubregion",
						"EMEA South": "subsubregion",
						"NA": "region",
						"APJ": "region",
						"MEE": "subregion",
						"GTC": "subregion",
						"LAC": "subregion"
					};

					var regionCountryValues = [];

					// Iterate through selectedRegions and create filters based on filterBasis
					selectedRegions.forEach(function (region) {
						var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

						// Filter regionCountries based on the chosen filter basis
						var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
							return item[filterBasis] === region;
						});

						// Add regionCountryValues for the current region to the array
						regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
							return regionCountry.countryCode;
						}));
					});

					// Extend sFilterString based on regionCountryValues
					if (regionCountryValues.length > 0) {
						var regionFilters = regionCountryValues.map(function (country) {
							return "u_customer_3.country=" + encodeURIComponent(country);
						}).join("^OR");

						// Append the new regionFilters to the existing sFilterString
						sFilterString += "^" + regionFilters;
					}

				}

				if (aFilter && aFilter.length > 0) {
					aFilter.forEach(function (filter) {
						sFilterString += "^" + filter;
					});
				}

			//	sFilterString = sFilterString.replaceAll("^", "%5e");
				sFilterString = "sysparm_query=" + encodeURIComponent(sFilterString);
				//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
				if (sFilterString.startsWith("%5esysparm_query")) {
					sFilterString.replace("%5esysparm_query", "sysparm_query");
				}
				//sFilterString += Constants.fieldsForCPCTable;
				sFilterString += "&sysparm_fields=";
				sFilterString += encodeURIComponent(Constants.fieldsForCPCTableWithoutParameter);

				var oServiceNowPromise = new Promise(function (resolve, reject) {
					var body = {
						"batch_request_id":1, 
						"rest_requests":[{
							"headers": [
								{"name":"Content-Type", "value":"application/json"},
								{"name":"Accept","value":"application/json"}
							],
							"url": "/api/now/table/sn_customerservice_escalation?" + sFilterString,
							"method":"GET",
							"id":"0000014383DUMMY",
							"exclude_response_headers": "true"
						}]
					};
					body = JSON.stringify(body);
					$.ajax({
						method: "POST",
						contentType: "application/json",
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
						data: body,
						success: function (oData) {
							oData = JSON.parse(atob(oData.serviced_requests[0].body));
							oData.result.forEach(function (item) {
								//Adjustments for CPC View
								item["PriorityT"] = this.formatter.getCimPriority(item["u_task_record.priority"], this);
								item["priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"], this);
								item["CountryT"] = this.formatter.getCountryName(item["u_customer_3.country"], this);
								item["Region"] = this.getRegionByCountryOrCountryCode(item["u_customer_3.country"], this);
								item["u_request_reason"] = this.formatter.formatSNOWRequestReason(item["u_request_reason"], this);
								item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"], this);
								item["state"] = this.formatter.getCimEscalationStatus(item["state"], this);
								item["approval_set_formatted"] = this.formatter.getDaysHoursMinSince(item["approval_set"], this);
								item["ObjectId"] = item["number"];
								item["ShortDescription"] = item["short_description"];
								item["StatusT"] = item["state"];
								item["CustomerText"] = item["u_customer_3.name"];
								item["CustomerErpNo"] = item["u_customer_3.number"];
								item["CustomerBpNo"] = item["u_customer_3.u_sap_crm_bp_number"];
								item["EmplRespName"] = item["assigned_to.first_name"] + " " + item["assigned_to.last_name"];
								item["EmplRespUser"] = item["assigned_to.employee_number"];
								item["CreationDate"] = item["sys_created_on"];
								item["ChangeDate"] = item["sys_updated_on"];
								item["AssignmentGroup"] = item["assignment_group.name"];


								// Mapping with HANA Data
								var mappedObject = aMCCObjects.results.find(function (mccItem) {
									return mccItem.EscalationID === item.number;
								});

								if (mappedObject) {
									item["Product"] = mappedObject.ProductLineName;
									item["ProductLineID"] = mappedObject.ProductLineID;
									item["ActualsStartDate"] = mappedObject.StartDate;
									item["ActualsEndDate"] = mappedObject.EndDate;
									item["GoLiveDate"] = mappedObject.GoLiveDate;
								}

							}.bind(this));

							oTable.setBusy(false);
							this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
							var oModel = new sap.ui.model.json.JSONModel(oData);
							this.getView().setModel(oModel, "dataPA");
							resolve(oData);

						}.bind(this),
						error: function (err) {
							oTable.setBusy(false);
							this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
							resolve();
						}.bind(this)
					});
				}.bind(this));

				oServiceNowPromise.then(function (oServiceNowData) {
					this._updateTablePlannedActivitiesFromActivitiesSet().then(function (oActivitiesData) {
						// Retrieve existing data from dataPA model
						var oExistingModel = this.getView().getModel("dataPA");
						var aExistingData = oExistingModel ? oExistingModel.getData().result : [];

						// Combine ServiceNow data with existing data
						var aCombinedData = aExistingData.concat(oActivitiesData.results);
						var oCombinedModel = new sap.ui.model.json.JSONModel({ result: aCombinedData });
						this.getView().setModel(oCombinedModel, "dataPA");
					}.bind(this));
				}.bind(this)).catch(function (error) {
					console.error("Error updating data:", error);
				});

			} else {
				//No Call needed since no data anyway
				oTable.setBusy(false);
				this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
			}

		},

		_updateTablePlannedActivitiesFromActivitiesSet: function () {
			var oICModel = this.getOwnerComponent().getModel();
			var aFilters = [];
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "open";
			}

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				oFilterForICP.aFilters = oFilterForICP.aFilters.filter(function (filter) {
					if (filter.aFilters && filter.aFilters.length > 0) {
						return filter.aFilters[0].sPath !== "SalesOrg" && filter.aFilters[0].sPath !== "ServiceOrg";
					}
					return true;
				});
				if (oFilterForICP.aFilters.length !== 0) {
					aFilters.push(oFilterForICP);
				}
			}

			if (bCaseState === "open" || bCaseState === "all") {
				var tileSpecificFilters1 = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0011"), //In Process Backoffice
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0012"), //Responsible's Action
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0019"), //In MCC Focus Teams | E0020 = OBSOLETE
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0027") //?? | E0026 = Restricted
					], false)
				],
					true
				);
			}
			if (bCaseState === "closed" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0012"), //Responsible's Action
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0013"), //Confirmed
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0014"), //Completed
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0017"), //??
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0018") //??
					], false),
					this.getClosedDateFilter("ClosingDate")
				],
					true
				);

			}

			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
					tileSpecificFilters1,
					tileSpecificFilters2
				],
					false
				));
			}

			aFilters.push(new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "ZZM"));
			aFilters.push(new sap.ui.model.Filter("ActResult", sap.ui.model.FilterOperator.EQ, "Z2ZS460006"));

			this.getView().getModel("viewModel").setProperty("/bLoadingStatePA", true);

			var oPrioritySorter = new sap.ui.model.Sorter("Priority", false);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);

			return new Promise(function (resolve, reject) {
				oICModel.read("/MCCActivitiesSet", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					sorters: [oPrioritySorter, oChangeDateSorter],
					urlParameters: {
						"$expand": "toProducts"
					},
					success: function (data) {
						this.getView().getModel("viewModel").setProperty("/bLoadingStatePA", false);
						// Berechnung oder Anpassungen an den Daten vornehmen
						data.results.forEach(function (result) {
							if (result.Rating === "") {
								result.Rating = "unrated";
							}
							if (result.Category === "ZZM") {
								result.objectType = "Planned CPC Engagment";
							}
							result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
							result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
							result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
							result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
							result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
							result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
							result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);
						}, this);

						resolve(data);
					}.bind(this),
					error: function (data) {
						this.getView().getModel("viewModel").setProperty("/bLoadingStatePA", false);
						reject(data);
					}.bind(this)
				});
			}.bind(this));
		},

		// _calculateRatingPA: function (data) {
		// 	var oViewModel = this.getView().getModel("viewModel");
		// 	var iGreen = 0;
		// 	var iYellow = 0;
		// 	var iRed = 0;
		// 	var iUnrated = 0;
		// 	data.results.forEach(function (oCase) {
		// 		switch (oCase.Rating) {
		// 		case "A":
		// 			iGreen++;
		// 			break;
		// 		case "B":
		// 			iYellow++;
		// 			break;
		// 		case "C":
		// 			iRed++;
		// 			break;
		// 		default:
		// 			iUnrated++;
		// 		}
		// 	});
		// 	oViewModel.setProperty("/iTabAllPA", data.results.length);
		// 	oViewModel.setProperty("/iTabGreenPA", iGreen);
		// 	oViewModel.setProperty("/iTabYellowPA", iYellow);
		// 	oViewModel.setProperty("/iTabRedPA", iRed);
		// 	oViewModel.setProperty("/iTabUnratedPA", iUnrated);
		// },

		_updateTableClosed: function () {
			var aFilters = [];
			var oTable = this.getView().byId("tableClosed");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			var bCaseFilter = this.getOwnerComponent().getModel("data").getProperty("/taskForcesFilter");
			this.getView().byId("dataIconTabBarClosed").setSelectedKey("All");

			if (!bCaseState) {
				bCaseState = "closed";
			}

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			if (bCaseState === "closed" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
					], false),
					this.getClosedDateFilter("ClosingDate")
				],
					true
				);

			}

			if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
					tileSpecificFilters2
				], false));
			}

			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04"));

			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				// urlParameters: {
				// 	"$select": "CaseId,CaseTitle,CustomerText,Region,StatusT,Rating,CreateDate,CustomerErpNo,ServiceOrgT,HasNotes"
				// },
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);

					this._calculateRating(data);
					data.results.forEach(function (oCase) {
						if (oCase.Rating === "") {
							oCase.Rating = "unrated";
						}
						if (oCase.DbsMaintenanceRanking === "0") {
							oCase.DbsMaintenanceRanking = "";
						}
						oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);

						switch (oCase.CustomerType) {
							case "ZSCUSTYP05":
								oCase.objectType = "Critical Customer Management";
								break;
							case "ZSCUSTYP04":
								oCase.objectType = "Critical Period Coverage";
								break;
						}

					}.bind(this));
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "tableData");
					this.readImplementationPartner(oModel).then(function () {
						setTimeout(function () {
							oTable.rerender();
						}, 200);
					}.bind(this));
					//MISSIONRADAR 2211	
					this.readMissionRadarValues(oModel, "results");
					this.loadClosedProducts();

					if (bCaseFilter !== "none") {
						var oIconTabBar = this.getView().byId("dataIconTabBarClosed");
						oIconTabBar.setSelectedKey(bCaseFilter);
						oIconTabBar.fireSelect();
					}
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		loadClosedProducts: function () {
			var aFilters = [];
			var oTable = this.getView().byId("tableClosed");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "closed";
			}

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			if (bCaseState === "closed" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
					], false),
					this.getClosedDateFilter("ClosingDate")
				],
					true
				);

			}

			if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
					tileSpecificFilters2
				], false));
			}

			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04"));

			var oICModel = this.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			oICModel.read("/CustomerEngagementSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$expand": "toProducts",
					"$select": "CaseId,toProducts"
				},
				success: function (data) {
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					var oModel = this.getOwnerComponent().getModel("tableData");
					var aAlreadyAdded = oModel.getData().results;

					data.results.forEach(function (oCase) {
						oCase.ProductVersions = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.Product = this.formatter.concatProducts(oCase.toProducts.results, "ProductT");
						oCase.ProductCategory = this.formatter.concatProducts(oCase.toProducts.results, "ProductCatT");
						oCase.ProductLine = this.formatter.concatProducts(oCase.toProducts.results, "ProductLineT");
						oCase.ProductVer = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.ProductLineKeys = this.formatter.concatProducts(oCase.toProducts.results, "ProductLine");
						oCase.ProductKeys = this.formatter.concatProducts(oCase.toProducts.results, "Product");

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.CaseId === oCase.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = oCase.toProducts;
								aTmp[i].toLastNotes = oCase.toLastNotes;
								aTmp[i].ProductVersions = oCase.ProductVersions;
								aTmp[i].Product = oCase.Product;
								aTmp[i].ProductCategory = oCase.ProductCategory;
								aTmp[i].ProductLine = oCase.ProductLine;
								aTmp[i].ProductVer = oCase.ProductVer;
								aTmp[i].ProductLineKeys = oCase.ProductLineKeys;
								aTmp[i].ProductKeys = oCase.ProductKeys;
							});
						}
					}.bind(this));
					this._updateFilteredCount();
					oModel.refresh();
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		handleOpenIssuesCasePress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("dataPA").getPath();
			var oProperty = this.getModel("dataPA").getProperty(sPath);

			if (oProperty.ObjectId.startsWith("ESC")) {
				this._openSosApp(oProperty["sys_id"], "&transType=sn_customerservice_escalation");
			} else {
				this._openWindow(oProperty.LinkToActivity);
			}
		},

		handleCustomerPress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("dataPA").getPath();
			var oProperty = this.getModel("dataPA").getProperty(sPath);
			var sErpCustNo = oProperty.CustomerErpNo || oProperty.ErpCustNo || oProperty.CustomerNo;
			var oRouter = this.getRouter();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},
		onOpenUser: function (oEv) {
			// if (oEv.getSource().data("EmplRespUser")) {
			// 	this.formatter.openUser(oEv, oEv.getSource().data("EmplRespUser"));
			// } 
			// else
			if (oEv.getSource().data("userid")) {
				this.formatter.openUser(oEv, oEv.getSource().data("userid"));
			}
			//else {
			// 	this.formatter.openUser(oEv, oEv.getSource().data("useridBDM"));
			// }
		},
		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("tableData").getPath();
			var oProperty = this.getModel("tableData").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},
		handleGlobalUltimatePressPA: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("dataPA").getPath();
			var oProperty = this.getModel("dataPA").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		customSorting: function (oEvent) {
			var oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingColumn");
			var oMCCiColumn = this.byId("mcci");
			var oPreventionScoreColumn = this.byId("preventionScore");
			var oTable = this.getView().byId("table");
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");

			if (bCaseState === "closed") {
				oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingColumnClosed");
				oMCCiColumn = this.byId("mcciClosed");
				oPreventionScoreColumn = this.byId("preventionScoreClosed");
				oTable = this.getView().byId("tableClosed");
			}

			var oCurrentColumn = oEvent.getParameter("column");
			if (oCurrentColumn !== oGUMaintenanceRankingColumn && oCurrentColumn !== oMCCiColumn && oCurrentColumn !== oPreventionScoreColumn) {
				//oGUMaintenanceRankingColumn.setSorted(false); //No multi-column sorting
				return;
			}
			oEvent.preventDefault();
			var sOrder = oEvent.getParameter("sortOrder");

			if (oCurrentColumn == oMCCiColumn || oCurrentColumn == oPreventionScoreColumn) {
				this.customSortingBaseFloat(oCurrentColumn, sOrder, oTable);
			} else {
				this.customSortingBase(oCurrentColumn, sOrder, oGUMaintenanceRankingColumn, oTable);
			}
		},

		customSortingPA: function (oEvent) {
			var oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingPAColumn");
			var oCurrentColumn = oEvent.getParameter("column");
			if (oCurrentColumn !== oGUMaintenanceRankingColumn) {
				//oGUMaintenanceRankingColumn.setSorted(false); //No multi-column sorting
				return;
			}
			oEvent.preventDefault();
			var sOrder = oEvent.getParameter("sortOrder");
			this.customSortingBase(oCurrentColumn, sOrder, oGUMaintenanceRankingColumn, "tablePA");
		},
		changeCaseState: function () {
			this._updateTable();
			this._updateTablePlannedActivities();
			this._updateTableClosed();
		},
		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("tableData").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		}
	});
});