sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/FilterOperator",
	'sap/m/MessageToast',
	'sap/m/Dialog',
	'sap/m/Button',
	'sap/ui/core/HTML',
	'sap/m/Text',
	"sap/m/Label",
	"sap/m/Panel",
	"sap/m/MessageBox",
	"com/sap/mcconedashboard/model/formatter",
	"sap/ui/core/Fragment",
	"com/sap/mcconedashboard/model/Constants",
	"sap/gantt/misc/Format",
	"sap/gantt/misc/Utility",
	"sap/gantt/library",
	"com/sap/mcconedashboard/utils/DataProcessor",
	"./../connector/TranslationConnector",
	"com/sap/mcconedashboard/connector/SNOWConnector",
	"com/sap/mcconedashboard/connector/HANADBConnector",
	"com/sap/mcconedashboard/utils/Tag",
	"sap/base/Log",

], function (BaseController, History, Filter, JSONModel, FilterOperator, MessageToast, Dialog, Button, HTML, Text, Label, Panel,
	MessageBox,
	formatter, Fragment, Constants, Format, Utility, GanttLibrary, DataProcessor, TranslationConnector, SNOWConnector, HANADBConnector, Tag, Logger) {
	"use strict";

	var DebugMode = false; // SET TO TRUE TO USE JSON FILES FOR CUSTOMER HISTORY AND MISSION RADAR

	var TimeUnit = GanttLibrary.config.TimeUnit;
	var errorShown = false; //Avoid multiple similar Error Messages for failed ajax calls

	var oTimeLineOptions = {
		"OneHour": {
			innerInterval: {
				unit: TimeUnit.hour,
				span: 1,
				range: 90
			},
			largeInterval: {
				unit: TimeUnit.day,
				span: 1,
				pattern: "dd.MM.YYYY"
			},
			smallInterval: {
				unit: TimeUnit.hour,
				span: 1,
				pattern: "HH:mm"
			}
		},
		"TwelveHours": {
			innerInterval: {
				unit: TimeUnit.hour,
				span: 12,
				range: 90
			},
			largeInterval: {
				unit: TimeUnit.day,
				span: 1,
				pattern: "dd.MM.YYYY"
			},
			smallInterval: {
				unit: TimeUnit.hour,
				span: 12,
				pattern: "HH:mm"
			}
		},
		"OneDay": {
			innerInterval: {
				unit: TimeUnit.day,
				span: 1,
				range: 90
			},
			largeInterval: {
				unit: TimeUnit.month,
				span: 1,
				pattern: "LLLL YYYY"
			},
			smallInterval: {
				unit: TimeUnit.day,
				span: 1,
				pattern: "dd"
			}
		},
		"OneMonth": {
			innerInterval: {
				unit: TimeUnit.month,
				span: 1,
				range: 90
			},
			largeInterval: {
				unit: TimeUnit.year,
				span: 1,
				format: "YYYY"
			},
			smallInterval: {
				unit: TimeUnit.month,
				span: 1,
				pattern: "LLL"
			}
		}
	};
	return BaseController.extend("com.sap.mcconedashboard.controller.Customer", {

		formatter: formatter,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.mcconedashboard.view.Customer
		 */
		onInit: function () {
			//create local model to read customer related data and bind these to the specific views
			var oCustomerData = {
				reloadCustomer: true,
				selectedPieChartText: ""
			};
			var oCustomerModel = new sap.ui.model.json.JSONModel(oCustomerData);
			this.getOwnerComponent().setModel(oCustomerModel, "customerModel");
			//this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getRouter().getRoute("Customer").attachPatternMatched(this._onObjectMatched, this);
			this._tblRendered = false;

			//set gantt start / end time
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMddhhMMss"
			});
			var start = oFormat.format(this._getGanttStartDate());
			var end = oFormat.format(this._getGanttEndDate());

			var oZoomStrategy = this.getView().byId("ganttZoomStrategy");
			oZoomStrategy.setTimeLineOptions(oTimeLineOptions);
			oZoomStrategy.setTimeLineOption(oTimeLineOptions["OneDay"]);

			this.getView().byId("totalTime").setStartTime(start);
			this.getView().byId("totalTime").setEndTime(end);
			this.getView().byId("visibleTime").setStartTime(start);
			this.getView().byId("visibleTime").setEndTime(end);

			//pie chart
			this.getView().setModel(new JSONModel({
				data: []
			}), "pieChart");
			var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrame");
			oVizFrame.setVizProperties({
				legend: {
					title: {
						visible: true
					},
					showFullLabel: true
				},
				plotArea: {
					dataLabel: {
						visible: true,
						type: "value"
					}
				},
				legendGroup: {
					linesOfWrap: 2,
					layout: {
						width: "50%"
					}
				},
				title: {
					visible: false
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});
			oVizFrame.setModel(this.getView().getModel("pieChart"));

		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.sap.mcconedashboard.view.Customer
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.sap.mcconedashboard.view.Customer
		 */
		onAfterRendering: function () {
			//Change visible row count of Critical incidents table in Object Page;
			/*var tabID = this.getView().byId(this.getView().byId("critin2").getSelectedView()).createId("xmlInXml") + "--tabInc";
			var tab = this.getView().byId(tabID);
			tab.setVisibleRowCount(10);*/
			this.getView().byId("customerOverviewTable").addEventDelegate({
				"onAfterRendering": function (oEv) {
					if (!this._tblRendered) {
						setTimeout(function () {
							oEv.srcControl.invalidate();
						}, 300);

						this._tblRendered = true;
					}
				}.bind(this)
			});

		},

		_onObjectMatched: function (oEvent) {
			var sErpCustNo = oEvent.getParameter("arguments").ErpCustNo;
			if (sErpCustNo && sErpCustNo !== "" && sErpCustNo !== null) {
				var oModel = this.getModel();
				var oCustomerModel = this.getModel("customerModel");

				var oObjectPageLayout = this.getView().byId("ObjectPageLayout");
				oObjectPageLayout.setSelectedSection("customerOverviewSec");

				var oArgs = oEvent.getParameter("arguments");
				var that = this;
				this._handleMissionRadarAndAnonymizedMode(oArgs);
				this._handleFeatureFlags(oArgs);

				if (!oCustomerModel.getProperty("/reloadCustomer")) {
					return null;
				}

				this.getView().byId("pieTypeButton").setSelectedKey("product");
				//is not relevant here this.getView().setModel(new JSONModel([]), "productsModel");

				oCustomerModel.setProperty("/reloadCustomer", false);
				oCustomerModel.setProperty("/selectedPieChartText", "");

				this.getView().getModel("pieChart").setProperty("/data", []);

				//set visibility of the chart initially to false, only show, if data is available
				this.getView().byId("CustomerProductLineChartContainer").setProperty("visible", false);

				this.getView().setModel(new JSONModel({
					showSubscriptionButton: false,
					subscriptionAction: "ADD",
					subscriptionID: "",
					missionRadarValuesVisible: false
				}), "viewModel");

				var sObjectPath = this.getModel().createKey("CustomerSet", {
					ErpCustNo: sErpCustNo
				});
				oCustomerModel.setProperty("/bBindView", true);
				this.trackEvent("Customer: Customer View opened");
				this._bindView("/" + sObjectPath);
				this._readFavorits(sErpCustNo);
				this._readCustomerTags(sErpCustNo);

				/**
				 * navigate to top issues section when top issues where pressed in mcccases view
				 **/
				var bSelectTopIssue = this.getModel("settings").getProperty("/showTopIssuesSection");
				if (bSelectTopIssue) {
					//set value to default when navigation finished
					this.getModel("settings").setProperty("/showTopIssuesSection", false);
					this.onSelectTopIssue();
				} else {
					//reset the filters and sorters of the table
					var oCustomerOverviewTable = this.getView().byId("customerOverviewTable");
					var oTableBinding = oCustomerOverviewTable.getBinding();
					oTableBinding.filter();
				}

				//clear counter data initially
				//first section of Customer 360° view
				oCustomerModel.setProperty("/CustomerOverview", []);
				oCustomerModel.setProperty("/bLoadingState", true);
				oCustomerModel.setProperty("/AmountAll", 0);
				oCustomerModel.setProperty("/AmountGlobalEscalations", 0);
				oCustomerModel.setProperty("/AmountCims", 0);
				oCustomerModel.setProperty("/AmountCriticalCustomerManagement", 0);
				oCustomerModel.setProperty("/AmountTaskForces", 0);
				oCustomerModel.setProperty("/AmountOutages", 0);
				oCustomerModel.setProperty("/AmountCriticalPeriodCoverage", 0);
				oCustomerModel.setProperty("/AmountTopCriticalCustomers", 0);
				oCustomerModel.setProperty("/AmountCrossIssues", 0);
				oCustomerModel.setProperty("/AmountBusinessDownSituations", 0);

				oCustomerModel.setProperty("/AmountXTecEngagements", 0);
				oCustomerModel.setProperty("/AmountPECriticalEngagements", 0);

				//second section of Customer 360° view
				oCustomerModel.setProperty("/CustomerOverviewOpenIssues", []);
				oCustomerModel.setProperty("/bLoadingStateOpenIssues", true);
				oCustomerModel.setProperty("/AmountAllOpenIssues", 0);
				oCustomerModel.setProperty("/AmountTopIssues", 0);
				oCustomerModel.setProperty("/AmountMCCIssues", 0);
				oCustomerModel.setProperty("/AmountCCMRequests", 0);
				oCustomerModel.setProperty("/AmountMCCTopCriticalCustomer", 0);
				oCustomerModel.setProperty("/AmountCPCRequests", 0);
				oCustomerModel.setProperty("/AmountCPCActivityRequests", 0);
				oCustomerModel.setProperty("/AmountCCMActivityRequests", 0);
				oCustomerModel.setProperty("/AmountTechnicalSupportRequests", 0);
				oCustomerModel.setProperty("/AmountCimsRequest", 0);
				oCustomerModel.setProperty("/AmountTechnicalBackofficeRequests", 0);

				oCustomerModel.setProperty("/AmountGlobalEscalationRequests", 0);
				oCustomerModel.setProperty("/AmountMCCSosRequest", 0);
				oCustomerModel.setProperty("/AmountBusinessDown", 0);
				oCustomerModel.setProperty("/AmountGoLiveEndangered", 0);
				oCustomerModel.setProperty("/AmountGoLiveAnnouncement", 0);

				//third section of Customer 360° view
				oCustomerModel.setProperty("/AmountAllHighPrioTickets", 0);
				oCustomerModel.setProperty("/AmountVeryHighPrioTickets", 0);
				oCustomerModel.setProperty("/AmountHighPrioTickets", 0);

				//MCCI Values
				oCustomerModel.setProperty("/mcci", null);
				oCustomerModel.setProperty("/mcciColor", null);
				oCustomerModel.setProperty("/trend", null);
				oCustomerModel.setProperty("/preventionScore", null);
				oCustomerModel.setProperty("/preventionScoreDesc", null);
				oCustomerModel.setProperty("/preventionScoreColor", null);
				oCustomerModel.setProperty("/preventionScoreIcon", null);
				oCustomerModel.setProperty("/missionRadarValuesVisible", false);
				oCustomerModel.setProperty("/AmountAllGoLives", 0);

				//AI Value
				oCustomerModel.setProperty("/AISummary", undefined);

				//set the visibility of the "back to Main page button" in case it was a direct call to this view
				//otherwise the end user would not have a possiblity to navigate to the main page of the app
				// var sPreviousHash = History.getInstance().getPreviousHash();
				// if (sPreviousHash === undefined) {
				// 	this.getModel("settings").setProperty("/ShowBackToMainPage", true);
				// 	this.trackEvent("Customer: display - direct");
				// } else {
				// 	this.getModel("settings").setProperty("/ShowBackToMainPage", false);
				// }
			}
		},

		//Jump to Customer Overview Section after navigating back and forwarth to prevent Customer History not refreshing
		onBeforeShow: function (oEvent) {
			var oObjectPageLayout = this.byId("ObjectPageLayout");
			var oSectionToNavigate = this.byId("customerOverviewSec");
			oObjectPageLayout.scrollToSection(oSectionToNavigate.getId());
		},

		_loadCustomerLogo: function (sErpCustNo) {
			var oSettings = this.getOwnerComponent().getModel("settings");
			var oHeader = this.getView().byId("objectPageHeader");
			sErpCustNo = oSettings.getProperty("/isAnonymizedMode") ? "" : sErpCustNo;
			if (sErpCustNo && sErpCustNo !== "" && sErpCustNo !== null) {

				var sPath = sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/ic/sap/opu/odata/sap/";
				var sUrl = sPath + "ZS_APP_DEP_SRV/CustomerSet('" + sErpCustNo + "')/$value";

				function waitForObjectImageAndSetProperty() {
					return new Promise(function (resolve) {
						function checkObjectImage() {
							var oObjectImage = oHeader.getAggregation("_objectImage");
							if (oObjectImage) {
								resolve(oObjectImage);
							} else {
								setTimeout(checkObjectImage, 100);
							}
						}

						checkObjectImage();
					});
				}

				this._getImageStream(sUrl).then(function (sBase64) {
					oHeader.setObjectImageURI(sBase64);
					return waitForObjectImageAndSetProperty();
				}).then(function (oObjectImage) {
					oObjectImage.setProperty("backgroundSize", "contain");
				});
			}
		},

		_readFavorits: function (sErpCustNo) {
			var oFavModel = this.getModel("userProfile");
			oFavModel.read("/Entries", {
				filters: [new Filter("Attribute", FilterOperator.EQ, "FAVORITE_CUSTOMERS")],
				success: function (data) {
					this.getModel("favoriteModel").setProperty("/userFavorites", data.results);
					this._checkForFavorite(sErpCustNo);
				}.bind(this),
				error: function (data) { }
			});
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function (sObjectPath) {
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					dataRequested: function () { },
					dataReceived: function (oEv) {
						var oData = oEv.getParameter("data");
						if (oData) {
							this.getModel("customerModel").setProperty("/WebSite", oData.WebSite);
							this.getModel("customerModel").setProperty("/LinkToAccount", oData.LinkToAccount);
							this.getModel("customerModel").setProperty("/Name1", oData.Name1);
							this.getModel("customerModel").setProperty("/Name2", oData.Name2);
							this.getModel("customerModel").setProperty("/Gu", oData.Gu);
							this.getModel("customerModel").setProperty("/GuErpNo", oData.GuErpNo);
							this.getModel("customerModel").setProperty("/ErpCustNo", oData.ErpCustNo);
							this.getModel("customerModel").setProperty("/linkWebsiteVisible", oData.WebSite !== "");
							this.getModel("customerModel").setProperty("/linkICPAccount", oData.LinkToAccount !== "");
							this.getModel("customerModel").setProperty("/linkInnovationReviewDashboard", oData.Gu !== "");
							this.getModel("customerModel").setProperty("/linkEWADashboard", oData.ErpCustNo !== "");
							this.getModel("customerModel").setProperty("/linkMCCMissionRadar", oData.ErpCustNo !== "");
							//check if subscription button should be shown
							this.getView().getModel("viewModel").setProperty("/showSubscriptionButton", this._showSubscriptionButtonBasedOnAuth(oData));
							if (this.getView().getModel("viewModel").getProperty("/showSubscriptionButton")) {
								//check in the existing subscriptions, if there is already an entry for this customer/gu
								this._checkSubscriptionStatusForCustomer(oData.GuErpNo, oData.ErpCustNo);
							}

							//load image
							this._loadCustomerLogo(oData.Partner);

						} else {
							this._noCustomerFound();
							this.getView().unbindElement();
						}
					}.bind(this),
					change: function () {
						if (this.getView().getBindingContext() && this.getModel("customerModel").getProperty("/bBindView")) {
							this.getView().byId("favoriteBtn").setVisible(true);
							//this.getView().byId("linkWebsite").setVisible(true);
							//this.getView().byId("linkICPAccount").setVisible(true);
							//this.getView().byId("linkInnovationReviewDashboard").setVisible(true);

							this.getModel("customerModel").setProperty("/bBindView", false);

							var oContext = this.getView().getBindingContext().getObject();
							//only check for global ultimate if the hash value and context value are the same, otherwise this can lead to inconsistency
							var oCustomerNoHash = this.getRouter().getHashChanger().getHash().substring(9);
							//remove leading zeros of oCustomerNoHash
							oCustomerNoHash = parseInt(oCustomerNoHash, 10).toString();
							this._setBusyIndicatorCustomerModel();
							if (oCustomerNoHash === oContext.ErpCustNo) {
								this._checkForGlobalUltimate(oContext);
								this._resetCustomerHistoryModelAndRefreshGantt();
							}

							//load image
							this._loadCustomerLogo(oContext.Partner);

							this.getModel("customerModel").setProperty("/WebSite", oContext.WebSite);
							this.getModel("customerModel").setProperty("/LinkToAccount", oContext.LinkToAccount);
							this.getModel("customerModel").setProperty("/Gu", oContext.Gu);
							this.getModel("customerModel").setProperty("/GuErpNo", oContext.GuErpNo);
							this.getModel("customerModel").setProperty("/ErpCustNo", oContext.ErpCustNo);
							this.getModel("customerModel").setProperty("/linkWebsiteVisible", oContext.WebSite !== "");
							this.getModel("customerModel").setProperty("/linkICPAccount", oContext.LinkToAccount !== "");
							this.getModel("customerModel").setProperty("/linkInnovationReviewDashboard", oContext.Gu !== "");
							this.getModel("customerModel").setProperty("/linkEWADashboard", oContext.ErpCustNo !== "");
							this.getModel("customerModel").setProperty("/linkMCCMissionRadar", oContext.ErpCustNo !== "");
							//check if subscription button should be shown
							this.getView().getModel("viewModel").setProperty("/showSubscriptionButton", this._showSubscriptionButtonBasedOnAuth(oContext));
							if (this.getView().getModel("viewModel").getProperty("/showSubscriptionButton")) {
								//check in the existing subscriptions, if there is already an entry for this customer/gu
								this._checkSubscriptionStatusForCustomer(oContext.GuErpNo, oContext.ErpCustNo);
							}
						}
					}.bind(this)
				}
			});
		},

		/**
		 *Check if customer is global ultimate
		 * differntiate in filter criteria if it is a global ultimate or just a customer
		 */
		_checkForGlobalUltimate: function (oContext) {
			var that = this;
			this._bCustomerHistoryLoaded = false;
			this.sErpCustNo = oContext.ErpCustNo;
			var oModel = this.getModel();
			var oSettings = this.getOwnerComponent().getModel("settings").getData();
			var oFilterBC, oFilterMCS;
			this.oFilter;
			this.GuErpNo = oContext.GuErpNo;
			this.GuNo = oContext.Gu;
			if (oContext.IsGlobalUltimate === "X") {
				//Global Ultimate
				this.isGlobalUltimate = "X";
				this.oFilter = new Filter("GuErpNo", FilterOperator.EQ, oContext.GuErpNo);
				//currently no data is found in BC* system for GU filter
				oFilterBC = new Filter("GlobalUltimate", FilterOperator.EQ, oContext.GuErpNo);
				oFilterMCS = new Filter("gu_erp_no", FilterOperator.EQ, oContext.GuErpNo);
			} else {
				this.isGlobalUltimate = "";
				this.oFilter = new Filter("CustomerErpNo", FilterOperator.EQ, this.sErpCustNo);
				oFilterBC = new Filter("ErpCustNo", FilterOperator.EQ, this.sErpCustNo);
				oFilterMCS = new Filter("customer_erp_no", FilterOperator.EQ, this.sErpCustNo);
			}

			//read Service NOW Tags; get tags, which have been created in the last half year (maybe this needs to be changed later?)
			var oCimPromise;
			var oBusinessDownSituationsPromise;
			var oServiceNowTagPromise = this._readServiceNowTags(function () {
				oCimPromise = that._readCims(that.sErpCustNo, oServiceNowTagPromise);
				oBusinessDownSituationsPromise = that._readBusinessDownSituations(that.sErpCustNo, oServiceNowTagPromise);
				aPromises.push(oBusinessDownSituationsPromise);

			});

			//NOt needed anymore, because AUTH in Backend has been adapted read addtional customer related data and set the customerModel for IC* data
			//	if (oSettings.ShowGlobalAggregation || oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations) {
			//in case of anonymized mode, no GEM or Cross Issues should be returned
			if (oSettings.isAnonymizedMode === false) {
				var oGlobalEscPromise = this._readGlobalEscalations(this.oFilter);
				var oCrossIssueSet = this._readCrossIssues(this.oFilter);
			}

			const pExecutiveEscalations = this._readExecutiveEscalations(this.sErpCustNo)
			var oGlobalEscRequPromise = this._readGlobalEscalationRequests(this.oFilter);
			var oCustEngagementsPromise = this._readCustomerEngagements(this.oFilter);
			var oTaskForcesPromise = this._readTaskForces(this.oFilter);
			var oCritSitPromise = this._readCriticalSituations(this.oFilter);
			//var oCimPromise = this._readCims(this.sErpCustNo, oServiceNowTagPromise);

			var oHighPrioTicketsPromise = this._readHighPrioTickets(this.sErpCustNo);

			var oMCCActPromise = this._readMCCActivities(this.oFilter);
			var oTopIssuesPromise = this._readTopIssuesSet(this.oFilter);
			var oCustomerVisitsPromise = this._readCustomerVisits(this.oFilter);

			var aPromises = [oGlobalEscRequPromise, oCritSitPromise, oMCCActPromise, oTopIssuesPromise, oCustEngagementsPromise, oCimPromise,
				oTaskForcesPromise, oHighPrioTicketsPromise, oCrossIssueSet, oCustomerVisitsPromise, pExecutiveEscalations
			];

			var oOutagesModel = this.getOwnerComponent().getModel("outageMainModel");
			var oOutagesPromise = new Promise(function (resolve, reject) {
				oOutagesModel.metadataLoaded(true).then(
					function () {
						var oOutagesPromise = this._readOutages(this.sErpCustNo, oOutagesModel);
						oOutagesPromise.then(function (data) {
							resolve(data);
						});
						//aPromises.push(oOutagesPromise);
					}.bind(this),
					function () {
						resolve();
					}.bind(this)
				);
			}.bind(this));

			aPromises.push(oOutagesPromise);
			//	if (oSettings.ShowGlobalAggregation || oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations) {
			aPromises.push(oGlobalEscPromise);
			//	}

			var oFilterModel = this.getModel("filterModel");
			var oCPCRequestsPromise = this._readCPCRequests(oFilterModel);
			aPromises.push(oCPCRequestsPromise);

			var oCCMTSRRequestsPromise = this._readCCMRequestsAndTechnicalSupportRequests(oFilterModel);
			aPromises.push(oCCMTSRRequestsPromise);

			var oBTechnicalBackofficePromise = this._readTechnicalBackofficeRequests(this.sErpCustNo);
			aPromises.push(oBTechnicalBackofficePromise);


			Promise.all(aPromises).then(function (aResults) {
				var bVisible = this.getView().byId("hboxBusy").getVisible();
				var bVisibleOpenIssues = this.getView().byId("hboxBusyOpenIssues").getVisible();
				this.getView().byId("hboxBusy").setVisible(!bVisible);
				this.getView().byId("hboxBusyOpenIssues").setVisible(!bVisibleOpenIssues);

				this.getView().byId("customerOverviewTable").setBusy(false);
				this.getView().byId("customerOverviewTableOpenIssues").setBusy(false);

				this.readImplementationPartner(this.getModel("customerModel"));
				//MISSIONRADAR 2211
				this.readMissionRadarValues(this.getModel("customerModel"));
				this.updateGoLivesFromHPI();

				var oCustomerTable = this.getView().byId("customerOverviewTable");
				oCustomerTable.getColumns().forEach(function (col) {
					col.setFiltered(false);
					col.setFilterValue("");
					col.setSorted(false);
					col.filter();
				});
				oCustomerTable.sort();

				var oCustomerTableOpenIssues = this.getView().byId("customerOverviewTableOpenIssues");
				oCustomerTableOpenIssues.getColumns().forEach(function (col) {
					col.setFiltered(false);
					col.setFilterValue("");
					col.setSorted(false);
					col.filter();
				});
				oCustomerTableOpenIssues.sort();

				//reset table filters / sorters / icon tab bar
				var oIconTabBar = this.getView().byId("iconTabBar");
				var oIconTabBarOpenIssues = this.getView().byId("iconTabBarOpenIssues");
				oIconTabBar.setSelectedKey("All");
				oIconTabBar.fireSelect({
					key: "All"
				});
				oIconTabBarOpenIssues.setSelectedKey("All");
				oIconTabBarOpenIssues.fireSelect({
					key: "All"
				});

			}.bind(this), function (err) {
				var bVisible = this.getView().byId("hboxBusy").getVisible();
				this.getView().byId("hboxBusy").setVisible(!bVisible);

				var bVisibleOpenIssues = this.getView().byId("hboxBusyOpenIssues").getVisible();
				this.getView().byId("hboxBusy").setVisible(!bVisibleOpenIssues);
			});

		},

		onSectionChange: function (oEv) {
			var oSection = oEv.getParameter("section");
			if (oSection.getId().includes("customerHistorySection") && !this._bCustomerHistoryLoaded) {
				this._bCustomerHistoryLoaded = true;
				//read customer history
				this.readCustomerHistoryData(this.sErpCustNo, this.oFilter);
			} else if (oSection.getId().includes("goLivesSection") && !this._bGoLivesLoaded) {
				this._bGoLivesLoaded = true;

			}
		},

		onMCCMissionRadarPress: function (oEvent) {
			var sPath = oEvent.getSource().getBindingContext().getPath();
			var oProperty = this.getModel().getProperty(sPath);
			var sErpCustNo = oProperty.ErpCustNo;
			var sUrl = this.getResourceBundle().getText("mccMissionRadarURL") + this.pad(sErpCustNo, 10) + "&page=25531575-1196-4236-9ffb-815c95f5af1f&mode=view&f01Model=t.3:Ccktks07u5dfgma9urn1gm6h969&f01Dim=CUSTOMER_ID";
			this._openWindow(sUrl);
		},

		onObjectStatusPress: function (oEvent) {
			var sPath = oEvent.getSource().getBindingContext().getPath();
			var oProperty = this.getModel().getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);

			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		onOpenInfoPress: function (oEvent) {
			var oButton = oEvent.getSource();

			// create popover
			if (!this._oInformationLinkPopover) {
				Fragment.load({
					name: "com.sap.mcconedashboard.view.fragment.InformationLinksPopover",
					controller: this
				}).then(function (pPopover) {
					this._oInformationLinkPopover = pPopover;
					this.getView().addDependent(this._oInformationLinkPopover);
					this._oInformationLinkPopover.openBy(oButton);
				}.bind(this));
			} else {
				this._oInformationLinkPopover.openBy(oButton);
			}
		},

		onFavoritePress: function (oEvent) {
			var objectPageHeader = oEvent.getSource().getParent();
			var sPath = objectPageHeader.getBindingContext().getPath();
			var sErpCustNo = this.getModel().getProperty(sPath).ErpCustNo;
			var sErpCustNoZeors = this._addLeadingZeros(sErpCustNo);
			var favoriteBtn = this.getView().byId("favoriteBtn");
			var aFavorites = this.getModel("favoriteModel").getProperty("/userFavorites") || [];
			var oFavModel = this.getModel("userProfile");
			favoriteBtn.setEnabled(false);
			this.getModel("favoriteModel").setProperty("/reload", true);
			if (objectPageHeader.getMarkFavorite() && aFavorites.length > 0) {
				//for loop über userProfile model!
				for (var i = 0; i < aFavorites.length; i++) {
					if (aFavorites[i].Value === sErpCustNoZeors) {
						var sField = aFavorites[i].Field;
						if (sField && sField !== "") {
							oFavModel.remove("/Entries(Username='',Attribute='FAVORITE_CUSTOMERS',Field='" + sField + "')", {
								success: function () {
									sap.m.MessageToast.show("Favorite customer successfully removed.");
									favoriteBtn.setEnabled(true);
								}.bind(this),
								error: function () {
									sap.m.MessageToast.show("Error when removing favorite customer.");
									favoriteBtn.setEnabled(true);
								}.bind(this)
							});
							favoriteBtn.setIcon("sap-icon://add-favorite");
							favoriteBtn.setTooltip("Add to favorite");
						}
					}
				}

			} else if (!objectPageHeader.getMarkFavorite()) {

				oFavModel.create("/Entries", {
					"Attribute": "FAVORITE_CUSTOMERS",
					"Value": sErpCustNoZeors
				}, {
					success: function (data) {
						sap.m.MessageToast.show("Favorite customer successfully added.");
						favoriteBtn.setIcon("sap-icon://unfavorite");
						favoriteBtn.setTooltip("Remove from favorite");
						favoriteBtn.setEnabled(true);

						var aFilters = [
							new Filter("Attribute", FilterOperator.EQ, "FAVORITE_CUSTOMERS"),
							new Filter("Value", FilterOperator.EQ, data.Value)
						];

						oFavModel.read("/Entries", {
							filters: [new Filter(aFilters, true)],
							success: function (oData) {
								//add favorite to model
								var oModel = this.getModel("favoriteModel");
								var customer = oData.results.find(function (result) {
									return result.Value === data.Value;
								});
								aFavorites.push(customer);
								oModel.setProperty("/userFavorites", aFavorites);
							}.bind(this)
						});

					}.bind(this),
					error: function (e) {
						sap.m.MessageToast.show("Error when adding favorite customer");
						favoriteBtn.setEnabled(true);
					}.bind(this)
				});
				this.trackEvent("Favorite: added - customer view");
			}
			objectPageHeader.setMarkFavorite(!objectPageHeader.getMarkFavorite());

		},

		onNavBack: function (oEvent) {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", false);

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = this.getRouter();
				oRouter.navTo("Global", {
					"?query": this._getQueryParameter()
				});
			}
		},

		onNavHome: function (oEvent) {
			//nav back to start page of the MCC One Dashboard
			var oRouter = this.getRouter();
			oRouter.navTo("Global", {
				"?query": this._getQueryParameter()
			});
		},

		updateCustomerModel: function (sCustomerSet, data) {
			var oModel = this.getView().getModel("customerView");
			oModel.setProperty(sCustomerSet, data);

		},

		_readCPCRequests: function (oFilterModel) {
			var aFilters = [];
			oFilterModel.refresh(true);

			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "open";
			}

			var sRegion = oFilterModel.getProperty("/regionText");
			var oFilterForICP = oFilterModel.getProperty("/oFilterForCriticalPeriodCoverage");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			/*if (typeof sRegion !== "undefined" && sRegion !== "") {

				var aRegionHelp = this.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.country;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var eqFilters = regionCountryValues.map(function (country) {
					return new sap.ui.model.Filter("CustomerCountry", sap.ui.model.FilterOperator.EQ, country);
				});

				var regionFilter = new sap.ui.model.Filter({
					filters: eqFilters,
					and: false //OR
				});

				// Combine the regionFilter with filterCondition using AND conjunction
				aFilters.push(regionFilter);

			} */

			//Show only for ExpectedAction and Type
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("ExpectedAction", sap.ui.model.FilterOperator.EQ, "accept_engagement")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "AccER")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			//Use only those entries that do not have a EndDate set or it is in the future
			var today = new Date();
			today.setDate(today.getDate());

			/*
			var closedDateFilter = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.GE, today),
					new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.EQ, null)
				], false)
			],
				true
			);
			aFilters.push(closedDateFilter);
			*/

			var startDateFilter = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.GE, today),
					new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, null)
				], false)
			],
				true
			);
			aFilters.push(startDateFilter);

			var oModel = this.getOwnerComponent().getModel("subModel");
			var that = this;

			oModel.read("/MCCObject", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$select": "ExpectedAction, GoLiveDate, StartDate, EndDate, EscalationID, ProductLineID, ProductLineName, Type"
				},
				success: function (data) {
					that._loadServiceNowCPCRequestsWithHANAIds(data);
				}.bind(this),
				error: function (data) {
				}.bind(this)
			});

		},

		_loadServiceNowCPCRequestsWithHANAIds: function (aMCCObjects) {
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");

			if (aMCCObjects.results.length > 0 && (this.sErpCustNo !== null || this.sErpCustNo !== undefined)) {
				var escalationIDs = aMCCObjects.results.map(function (obj) {
					return obj.EscalationID;
				});

				// Filter out empty or null values
				var validEscalationIDs = escalationIDs.filter(function (id) {
					return id !== null && id !== '';
				});

				// Combine all valid Escalation IDs into a string for the filter
				var escalationIDsString = validEscalationIDs.join(',');

				var sFilterString = "ORDERBYu_task_record.priority^state=103^u_escalation_type=6";
				sFilterString += "^numberIN" + escalationIDsString;
				//sFilterString += "^numberINESC0489274,ESC0494268"

				sFilterString += "^u_customer_3.number=" + this._addLeadingZeros(this.sErpCustNo);

				if (typeof sRegion !== "undefined" && sRegion !== "") {

					var aRegionHelp = this.getModel("countryRegionModel").getData();
					var selectedRegions = sRegion.split(","); // Split the selected regions into an array

					// Create an object to map selected regions to filterBasis (given in countryRegionModel)
					var regionFilterBasisMap = {
						"EMEA North": "subsubregion",
						"EMEA South": "subsubregion",
						"NA": "region",
						"APJ": "region",
						"MEE": "subregion",
						"GTC": "subregion",
						"LAC": "subregion"
					};

					var regionCountryValues = [];

					// Iterate through selectedRegions and create filters based on filterBasis
					selectedRegions.forEach(function (region) {
						var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

						// Filter regionCountries based on the chosen filter basis
						var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
							return item[filterBasis] === region;
						});

						// Add regionCountryValues for the current region to the array
						regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
							return regionCountry.countryCode;
						}));
					});

					// Extend sFilterString based on regionCountryValues
					if (regionCountryValues.length > 0) {
						var regionFilters = regionCountryValues.map(function (country) {
							return "u_customer_3.country=" + encodeURIComponent(country);
						}).join("^OR");

						// Append the new regionFilters to the existing sFilterString
						sFilterString += "^" + regionFilters;
					}

				}

				if (aFilter && aFilter.length > 0) {
					aFilter.forEach(function (filter) {
						sFilterString += "^" + filter;
					});
				}

				sFilterString = "sysparm_query=" + encodeURIComponent(sFilterString);

				//sFilterString = sFilterString.replaceAll("^", "%5e");
				//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
				if (sFilterString.startsWith("%5esysparm_query")) {
					sFilterString.replace("%5esysparm_query", "sysparm_query");
				}
				sFilterString += "&sysparm_fields=";
				sFilterString += encodeURIComponent(Constants.fieldsForCPCTableWithoutParameter);

				return new Promise(function (resolve, reject) {
					var body = {
						"batch_request_id": 1,
						"rest_requests": [{
							"headers": [
								{ "name": "Content-Type", "value": "application/json" },
								{ "name": "Accept", "value": "application/json" }
							],
							"url": "/api/now/table/sn_customerservice_escalation?" + sFilterString,
							"method": "GET",
							"id": "0000014383DUMMY",
							"exclude_response_headers": "true"
						}]
					};
					body = JSON.stringify(body);
					$.ajax({
						method: "POST",
						contentType: "application/json",
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
						data: body,
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						error: function () {
							resolve();
						},
						success: function (oData) {
							oData = JSON.parse(atob(oData.serviced_requests[0].body));
							oData.result.forEach(function (item) {
								//Adjustments for CPC View
								item["PriorityT"] = this.formatter.getCimPriority(item["u_task_record.priority"], this);
								item["priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"], this);
								item["CountryT"] = this.formatter.getCountryName(item["u_customer_3.country"], this);
								item["Region"] = this.getRegionByCountryOrCountryCode(item["u_customer_3.country"], this);
								item["u_request_reason"] = this.formatter.formatSNOWRequestReason(item["u_request_reason"], this);
								item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"], this);
								item["state"] = this.formatter.getCimEscalationStatus(item["state"], this);
								item["approval_set_formatted"] = this.formatter.getDaysHoursMinSince(item["approval_set"], this);
								item["ObjectId"] = item["number"];
								item["ShortDescription"] = item["short_description"];
								item["StatusT"] = item["state"];
								item["CustomerText"] = item["u_customer_3.name"];
								item["CustomerErpNo"] = item["u_customer_3.number"];
								item["CustomerBpNo"] = item["u_customer_3.u_sap_crm_bp_number"];
								item["EmplRespName"] = item["assigned_to.first_name"] + " " + item["assigned_to.last_name"];
								item["EmplRespUser"] = item["assigned_to.employee_number"];
								item["CreationDate"] = item["sys_created_on"];
								item["ChangeDate"] = item["sys_updated_on"];
								item["AssignmentGroup"] = item["assignment_group.name"];

								// Mapping with HANA Data
								var mappedObject = aMCCObjects.results.find(function (mccItem) {
									return mccItem.EscalationID === item.number;
								});

								if (mappedObject) {
									item["Product"] = mappedObject.ProductLineName;
									item["ProductLineID"] = mappedObject.ProductLineID;
									item["ActualsStartDate"] = mappedObject.StartDate;
									item["ActualsEndDate"] = mappedObject.EndDate;
									item["GoLiveDate"] = mappedObject.GoLiveDate;
								}
							}.bind(this));
							this._convertDataForCustomerOverview("CPCRequests", oData.result);
							this.getOwnerComponent().getModel("customerModel").setProperty("/AmountCPCRequests", oData.result.length);
							resolve(oData);
						}.bind(this)
					});
				}.bind(this));
			}
		},

		_readCCMRequestsAndTechnicalSupportRequests: function (oFilterModel) {
			var aFilters = [];
			oFilterModel.refresh(true);

			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "open";
			}

			var sRegion = oFilterModel.getProperty("/regionText");
			var oFilterForICP = oFilterModel.getProperty("/oFilterForCriticalPeriodCoverage");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			/*if (typeof sRegion !== "undefined" && sRegion !== "") {

				var aRegionHelp = this.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.country;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var eqFilters = regionCountryValues.map(function (country) {
					return new sap.ui.model.Filter("CustomerCountry", sap.ui.model.FilterOperator.EQ, country);
				});

				var regionFilter = new sap.ui.model.Filter({
					filters: eqFilters,
					and: false //OR
				});

				// Combine the regionFilter with filterCondition using AND conjunction
				aFilters.push(regionFilter);

			} */

			//Show only for ExpectedAction and Type
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "AccER")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			var oModel = this.getOwnerComponent().getModel("subModel");
			var that = this;

			oModel.read("/MCCObject", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$select": "ExpectedAction, GoLiveDate, StartDate, EndDate, EscalationID, ProductLineID, ProductLineName, Type"
				},
				success: function (data) {
					let ccmPromise = new Promise((resolve, reject) => {
						that._loadServiceNowCCMRequestsWithHANAIds(data, resolve, reject);
					});

					let tsrPromise = new Promise((resolve, reject) => {
						that._loadServiceNowTechnicalSupportRequestsWithHANAIds(data, resolve, reject);
					});

					Promise.all([ccmPromise, tsrPromise]).then(() => {
						resolve();
					}).catch((error) => {
						reject(error);
					});

				}.bind(this),
				error: function (error) {
					reject(error);
				}.bind(this)
			});

		},

		_loadServiceNowCCMRequestsWithHANAIds: function (aMCCObjects) {
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");

			if (aMCCObjects.results.length > 0 && (this.sErpCustNo !== null || this.sErpCustNo !== undefined)) {
				var escalationIDs = aMCCObjects.results.map(function (obj) {
					return obj.EscalationID;
				});

				// Filter out empty or null values
				var validEscalationIDs = escalationIDs.filter(function (id) {
					return id !== null && id !== '';
				});

				// Combine all valid Escalation IDs into a string for the filter
				var escalationIDsString = validEscalationIDs.join(',');

				var sFilterString = "ORDERBYu_task_record.priority^state=100^u_escalation_type=5";
				sFilterString += "^numberIN" + escalationIDsString;
				sFilterString += "^u_customer_3.number=" + this._addLeadingZeros(this.sErpCustNo);

				//sFilterString += "^numberINESC0489274,ESC0494268"

				if (typeof sRegion !== "undefined" && sRegion !== "") {

					var aRegionHelp = this.getModel("countryRegionModel").getData();
					var selectedRegions = sRegion.split(","); // Split the selected regions into an array

					// Create an object to map selected regions to filterBasis (given in countryRegionModel)
					var regionFilterBasisMap = {
						"EMEA North": "subsubregion",
						"EMEA South": "subsubregion",
						"NA": "region",
						"APJ": "region",
						"MEE": "subregion",
						"GTC": "subregion",
						"LAC": "subregion"
					};

					var regionCountryValues = [];

					// Iterate through selectedRegions and create filters based on filterBasis
					selectedRegions.forEach(function (region) {
						var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

						// Filter regionCountries based on the chosen filter basis
						var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
							return item[filterBasis] === region;
						});

						// Add regionCountryValues for the current region to the array
						regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
							return regionCountry.countryCode;
						}));
					});

					// Extend sFilterString based on regionCountryValues
					if (regionCountryValues.length > 0) {
						var regionFilters = regionCountryValues.map(function (country) {
							return "u_customer_3.country=" + encodeURIComponent(country);
						}).join("^OR");

						// Append the new regionFilters to the existing sFilterString
						sFilterString += "^" + regionFilters;
					}

				}

				if (aFilter && aFilter.length > 0) {
					aFilter.forEach(function (filter) {
						sFilterString += "^" + filter;
					});
				}

				sFilterString = "sysparm_query=" + encodeURIComponent(sFilterString);

				if (sFilterString.startsWith("%5esysparm_query")) {
					sFilterString.replace("%5esysparm_query", "sysparm_query");
				}
				sFilterString += "&sysparm_fields=";
				sFilterString += encodeURIComponent(Constants.fieldsForCPCTableWithoutParameter);

				return new Promise(function (resolve, reject) {
					var body = {
						"batch_request_id": 1,
						"rest_requests": [{
							"headers": [
								{ "name": "Content-Type", "value": "application/json" },
								{ "name": "Accept", "value": "application/json" }
							],
							"url": "/api/now/table/sn_customerservice_escalation?" + sFilterString,
							"method": "GET",
							"id": "0000014383DUMMY",
							"exclude_response_headers": "true"
						}]
					};
					body = JSON.stringify(body);
					$.ajax({
						method: "POST",
						contentType: "application/json",
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
						data: body,
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						error: function () {
							resolve();
						},
						success: function (oData) {
							oData = JSON.parse(atob(oData.serviced_requests[0].body));
							oData.result.forEach(function (item) {
								//Adjustments for CCM View
								item["PriorityT"] = this.formatter.getCimPriority(item["u_task_record.priority"], this);
								item["priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"], this);
								item["CountryT"] = this.formatter.getCountryName(item["u_customer_3.country"], this);
								item["Region"] = this.getRegionByCountryOrCountryCode(item["u_customer_3.country"], this);
								item["u_request_reason"] = this.formatter.formatSNOWRequestReason(item["u_request_reason"], this);
								item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"], this);
								item["state"] = this.formatter.getCimEscalationStatus(item["state"], this);
								item["approval_set_formatted"] = this.formatter.getDaysHoursMinSince(item["approval_set"], this);
								item["ObjectId"] = item["number"];
								item["ShortDescription"] = item["short_description"];
								item["StatusT"] = item["state"];
								item["CustomerText"] = item["u_customer_3.name"];
								item["CustomerErpNo"] = item["u_customer_3.number"];
								item["CustomerBpNo"] = item["u_customer_3.u_sap_crm_bp_number"];
								item["EmplRespName"] = item["assigned_to.first_name"] + " " + item["assigned_to.last_name"];
								item["EmplRespUser"] = item["assigned_to.employee_number"];
								item["CreationDate"] = item["sys_created_on"];
								item["ChangeDate"] = item["sys_updated_on"];
								item["AssignmentGroup"] = item["assignment_group.name"];

								// Mapping with HANA Data
								var mappedObject = aMCCObjects.results.find(function (mccItem) {
									return mccItem.EscalationID === item.number;
								});

								if (mappedObject) {
									item["Product"] = mappedObject.ProductLineName;
									item["ProductLineID"] = mappedObject.ProductLineID;
									item["ActualsStartDate"] = mappedObject.StartDate;
									item["ActualsEndDate"] = mappedObject.EndDate;
									item["GoLiveDate"] = mappedObject.GoLiveDate;
								}
							}.bind(this));
							this._convertDataForCustomerOverview("CCMRequests", oData.result);
							this.getOwnerComponent().getModel("customerModel").setProperty("/AmountCCMRequests", oData.result.length);
							resolve(oData);
						}.bind(this)
					});
				}.bind(this));
			}
		},

		_loadServiceNowTechnicalSupportRequestsWithHANAIds: function (aMCCObjects) {
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");

			if (aMCCObjects.results.length > 0) {
				var escalationIDs = aMCCObjects.results.map(function (obj) {
					return obj.EscalationID;
				});

				// Filter out empty or null values
				var validEscalationIDs = escalationIDs.filter(function (id) {
					return id !== null && id !== '';
				});

				// Combine all valid Escalation IDs into a string for the filter
				var escalationIDsString = validEscalationIDs.join(',');

				var sFilterString = "ORDERBYu_task_record.priority^state=100^u_escalation_type=7";
				sFilterString += "^numberIN" + escalationIDsString;
				sFilterString += "^u_customer_3.number=" + this._addLeadingZeros(this.sErpCustNo);

				//sFilterString += "^numberINESC0489274,ESC0494268"

				if (typeof sRegion !== "undefined" && sRegion !== "") {

					var aRegionHelp = this.getModel("countryRegionModel").getData();
					var selectedRegions = sRegion.split(","); // Split the selected regions into an array

					// Create an object to map selected regions to filterBasis (given in countryRegionModel)
					var regionFilterBasisMap = {
						"EMEA North": "subsubregion",
						"EMEA South": "subsubregion",
						"NA": "region",
						"APJ": "region",
						"MEE": "subregion",
						"GTC": "subregion",
						"LAC": "subregion"
					};

					var regionCountryValues = [];

					// Iterate through selectedRegions and create filters based on filterBasis
					selectedRegions.forEach(function (region) {
						var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

						// Filter regionCountries based on the chosen filter basis
						var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
							return item[filterBasis] === region;
						});

						// Add regionCountryValues for the current region to the array
						regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
							return regionCountry.countryCode;
						}));
					});

					// Extend sFilterString based on regionCountryValues
					if (regionCountryValues.length > 0) {
						var regionFilters = regionCountryValues.map(function (country) {
							return "u_customer_3.country=" + encodeURIComponent(country);
						}).join("^OR");

						// Append the new regionFilters to the existing sFilterString
						sFilterString += "^" + regionFilters;
					}

				}

				if (aFilter && aFilter.length > 0) {
					aFilter.forEach(function (filter) {
						sFilterString += "^" + filter;
					});
				}

				sFilterString = "sysparm_query=" + encodeURIComponent(sFilterString);
				//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
				if (sFilterString.startsWith("%5esysparm_query")) {
					sFilterString.replace("%5esysparm_query", "sysparm_query");
				}
				sFilterString += "&sysparm_fields=";
				sFilterString += encodeURIComponent(Constants.fieldsForCPCTableWithoutParameter);

				return new Promise(function (resolve, reject) {
					var body = {
						"batch_request_id": 1,
						"rest_requests": [{
							"headers": [
								{ "name": "Content-Type", "value": "application/json" },
								{ "name": "Accept", "value": "application/json" }
							],
							"url": "/api/now/table/sn_customerservice_escalation?" + sFilterString,
							"method": "GET",
							"id": "0000014383DUMMY",
							"exclude_response_headers": "true"
						}]
					};
					body = JSON.stringify(body);
					$.ajax({
						method: "POST",
						contentType: "application/json",
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
						data: body,
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						error: function () {
							resolve();
						},
						success: function (oData) {
							oData = JSON.parse(atob(oData.serviced_requests[0].body));
							oData.result.forEach(function (item) {
								//Adjustments for CCM View
								item["PriorityT"] = this.formatter.getCimPriority(item["u_task_record.priority"], this);
								item["priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"], this);
								item["CountryT"] = this.formatter.getCountryName(item["u_customer_3.country"], this);
								item["Region"] = this.getRegionByCountryOrCountryCode(item["u_customer_3.country"], this);
								item["u_request_reason"] = this.formatter.formatSNOWRequestReason(item["u_request_reason"], this);
								item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"], this);
								item["state"] = this.formatter.getCimEscalationStatus(item["state"], this);
								item["approval_set_formatted"] = this.formatter.getDaysHoursMinSince(item["approval_set"], this);
								item["ObjectId"] = item["number"];
								item["ShortDescription"] = item["short_description"];
								item["StatusT"] = item["state"];
								item["CustomerText"] = item["u_customer_3.name"];
								item["CustomerErpNo"] = item["u_customer_3.number"];
								item["CustomerBpNo"] = item["u_customer_3.u_sap_crm_bp_number"];
								item["EmplRespName"] = item["assigned_to.first_name"] + " " + item["assigned_to.last_name"];
								item["EmplRespUser"] = item["assigned_to.employee_number"];
								item["CreationDate"] = item["sys_created_on"];
								item["ChangeDate"] = item["sys_updated_on"];
								item["AssignmentGroup"] = item["assignment_group.name"];

								// Mapping with HANA Data
								var mappedObject = aMCCObjects.results.find(function (mccItem) {
									return mccItem.EscalationID === item.number;
								});

								if (mappedObject) {
									item["Product"] = mappedObject.ProductLineName;
									item["ProductLineID"] = mappedObject.ProductLineID;
									item["ActualsStartDate"] = mappedObject.StartDate;
									item["GoLiveDate"] = mappedObject.GoLiveDate;
								}
							}.bind(this));
							this._convertDataForCustomerOverview("TechnicalSupportRequests", oData.result);
							this.getOwnerComponent().getModel("customerModel").setProperty("/AmountTechnicalSupportRequests", oData.result.length);
							resolve(oData);
						}.bind(this)
					});
				}.bind(this));
			}
		},

		_readTechnicalBackofficeRequests: function (sCustomer) {
			sCustomer = this.pad(sCustomer, 10);
			var sFilterString = "ORDERBYu_task_record.priority^state=100^u_escalation_type=0^u_task_record.account.number=" + sCustomer;
			sFilterString = "sysparm_query=" + encodeURIComponent(sFilterString);

			//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
			if (sFilterString.startsWith("%5esysparm_query")) {
				sFilterString.replace("%5esysparm_query", "sysparm_query");
			}
			sFilterString += "&sysparm_fields=";
			sFilterString += encodeURIComponent(Constants.fieldsForBDMTableWithoutParamter);

			return new Promise(function (resolve, reject) {
				var body = {
					"batch_request_id": 1,
					"rest_requests": [{
						"headers": [
							{ "name": "Content-Type", "value": "application/json" },
							{ "name": "Accept", "value": "application/json" }
						],
						"url": "/api/now/table/sn_customerservice_escalation?" + sFilterString,
						"method": "GET",
						"id": "0000014383DUMMY",
						"exclude_response_headers": "true"
					}]
				};
				body = JSON.stringify(body);
				$.ajax({
					method: "POST",
					contentType: "application/json",
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
					data: body,
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					error: function () {
						resolve();
					},
					success: function (data) {
						data = JSON.parse(atob(data.serviced_requests[0].body));
						//is not relevant here	var oProductsModel = this.getView().getModel("productsModel");
						//is not relevant here	var oProductsModelData = oProductsModel.getData();
						data.result.forEach(function (item) {
							item["u_task_record.account.country_text"] = this.formatter.getCountryName(item["u_task_record.account.country"], this);
							item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"]);
							item["u_task_record.priority"] = this.formatter.getCimPriority(item["u_task_record.priority"]);
							item["u_task_record.priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"], this);
							item.toProducts = {
								results: []
							};
							if (item["u_task_record.u_install_base_item.u_product.model_number"] !== "") {
								item.ProductKeys = item["u_task_record.u_install_base_item.u_product.model_number"];
								item.ProductLineKeys = item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"];
								//item.HasNotes = item["escalation_justification"] !== "" ? "X" : "";
								item.HasNotes = item["u_business_impact"] !== "" || item["u_executive_summary"] !== "" || item["u_next_steps"] !== "" ?
									"X" : "";
								item.toProducts.results.push({
									CaseId: item["u_task_record.number"],
									Main: "",
									Product: item["u_task_record.u_install_base_item.u_product.model_number"],
									ProductT: item["u_task_record.u_install_base_item.u_product.display_name"],
									ProductCat: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id"],
									ProductCatT: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_name"],
									ProductLine: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"],
									ProductLineT: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_name"],
									ProductVersion: item["u_task_record.u_install_base_item.u_product_version.model_number"],
									ProductVersionT: item["u_task_record.u_install_base_item.u_product_version.display_name"]
								});
							}
							//is not relevant here
							//Check for Object type - should only be added if it is a CIM and not a CIM requests
							// if (item["state"] === "101") {
							// 	oProductsModelData = oProductsModelData.concat(item.toProducts.results);
							// 	oProductsModel.setData(oProductsModelData);
							// 	oProductsModel.refresh();
							// }
						}.bind(this));

						this._convertDataForCustomerOverview("TechnicalBackofficeRequests", data.result);
						this.getModel("customerModel").setProperty("/AmountTechnicalBackofficeRequests", data.result.length);

						resolve(data);
					}.bind(this)
				});
			}.bind(this));
		},

		_readServiceNowTags: function (callback) {
			//read Service NOW Tags; get tags, which have been created in the last half year (maybe this needs to be changed later?)
			return new Promise(function (resolve, reject) {
				var dateOffset = (24 * 60 * 60 * 1000) * Constants.serviceNowTagsCreatedSinceDays;
				var dateInPast = new Date();
				dateInPast.setTime(dateInPast.getTime() - dateOffset);
				var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd" // we need a format like 2022-12-24
				});
				dateInPast = oFormat.format(dateInPast);
				var sFilterString =
					"sysparm_query=id_type=Escalation%5elabel.sys_created_on%3Ejavascript:gs.dateGenerate(%27" + dateInPast +
					"%27,%2700:00:00%27)%5elabel.global=true&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";

				$.ajax({
					method: "GET",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					contentType: "application/json",
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
					success: function (oData) {
						resolve(oData);
						if (typeof callback === "function") {
							callback();
						}
					}.bind(this),
					error: function (err) {
						resolve();
						if (typeof callback === "function") {
							callback(flags);
						}
					}.bind(this)
				});
			}.bind(this));
		},

		_readBusinessDownSituations: function (sCustomer, oServiceNowTagPromise) {
			sCustomer = this.pad(sCustomer, 10);
			var sFilterString = "ORDERBYu_task_record.priority^state=101^u_task_record.account.number=" + sCustomer + "^u_escalation_type=0^u_request_reason=7^ORu_request_reason=8^ORu_request_reason=9^ORu_request_reason=10";
			sFilterString = "sysparm_query=" + encodeURIComponent(sFilterString);

			//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
			if (sFilterString.startsWith("%5esysparm_query")) {
				sFilterString.replace("%5esysparm_query", "sysparm_query");
			}
			sFilterString += "&sysparm_fields=";
			sFilterString += encodeURIComponent(Constants.fieldsForBDMTableWithoutParamter);

			return new Promise(function (resolve, reject) {
				var body = {
					"batch_request_id": 1,
					"rest_requests": [{
						"headers": [
							{ "name": "Content-Type", "value": "application/json" },
							{ "name": "Accept", "value": "application/json" }
						],
						"url": "/api/now/table/sn_customerservice_escalation?" + sFilterString,
						"method": "GET",
						"id": "0000014383DUMMY",
						"exclude_response_headers": "true"
					}]
				};
				body = JSON.stringify(body);
				$.ajax({
					method: "POST",
					contentType: "application/json",
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
					data: body,
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					error: function () {
						resolve();
					},
					success: function (data) {
						data = JSON.parse(atob(data.serviced_requests[0].body));
						oServiceNowTagPromise.then(function (oTagData) { //wait for ServiceNow Tag data to be retrieved
							//is not relevant here	var oProductsModel = this.getView().getModel("productsModel");
							//is not relevant here	var oProductsModelData = oProductsModel.getData();
							data.result.forEach(function (item) {
								item["u_task_record.account.country_text"] = this.formatter.getCountryName(item["u_task_record.account.country"],
									this);
								item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"]);
								item["u_task_record.priority"] = this.formatter.getCimPriority(item["u_task_record.priority"]);
								item["u_task_record.priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"]);
								item.toProducts = {
									results: []
								};
								if (item["u_task_record.u_install_base_item.u_product.model_number"] !== "") {
									item.ProductKeys = item["u_task_record.u_install_base_item.u_product.model_number"];
									item.ProductLineKeys = item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"];
									item.HasNotes = item["u_business_impact"] !== "" || item["u_executive_summary"] !== "" || item["u_next_steps"] !==
										"" ?
										"X" : "";
									item.toProducts.results.push({
										CaseId: item["u_task_record.number"],
										Main: "",
										Product: item["u_task_record.u_install_base_item.u_product.model_number"],
										ProductT: item["u_task_record.u_install_base_item.u_product.display_name"],
										ProductCat: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id"],
										ProductCatT: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_name"],
										ProductLine: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"],
										ProductLineT: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_name"],
										ProductVersion: item["u_task_record.u_install_base_item.u_product_version.model_number"],
										ProductVersionT: item["u_task_record.u_install_base_item.u_product_version.display_name"]
									});
								}
								//Check for Object type - should only be added if it is a CIM and not a CIM requests
								//is not relevant here if (item["state"] === "101") {
								//is not relevant here 	oProductsModelData = oProductsModelData.concat(item.toProducts.results);
								//is not relevant here 	oProductsModel.setData(oProductsModelData);
								//is not relevant here 	oProductsModel.refresh();
								//is not relevant here}

								this._setPieModel(item.toProducts.results);

								// set ServiceNow Tag Information
								var oTagElement = oTagData.result.filter(function (val) {
									return val["id_display"] === item.number; //"ESC0140066"; //
								});
								if (oTagElement) {
									item.CaseTag = "";
									oTagElement.forEach(function (tagElementItem, index) {
										item.CaseTag += tagElementItem['label.name'];
										if (oTagElement.length > (index + 1)) {
											item.CaseTag += ", ";
										}
									});
								}

							}.bind(this));

							//Business Down Situations
							var aBusinessDownSituations = data.result.filter(function (val) {
								return val["u_request_reason"] === "8" || val["u_request_reason"] === "9";
							});
							this._convertDataForCustomerOverview(Constants.MCCEngagementKey.BusinessDownSituations, aBusinessDownSituations);
							this.getModel("customerModel").setProperty("/AmountBusinessDownSituations", aBusinessDownSituations.length);

							//xTec Engagements
							var aXTecEngagements = data.result.filter(function (val) {
								return val["u_request_reason"] === "10";
							});
							this._convertDataForCustomerOverview(Constants.MCCEngagementKey.XTecEngagements, aXTecEngagements);
							this.getModel("customerModel").setProperty("/AmountXTecEngagements", aXTecEngagements.length);

							//PE Critical Engagements
							var aPECriticalEngagements = data.result.filter(function (val) {
								return val["u_request_reason"] === "7";
							});
							this._convertDataForCustomerOverview("PECriticalEngagements", aPECriticalEngagements);
							this.getModel("customerModel").setProperty("/AmountPECriticalEngagements", aPECriticalEngagements.length);

							resolve(data);
						}.bind(this));
					}.bind(this)
				});
			}.bind(this));

		},

		_readGlobalEscalations: function (oFilter) {
			var oModel = this.getModel();
			var aFilters = [];

			aFilters.push(oFilter);

			//ALL ongoing escalations
			//Rating =   ALL
			//Case Status = status eq '20' or status eq '30'
			//process_type  Global Escalations (ZSPRCTYP01)  -->  should be predefined in Backend
			var tileSpecificFilters = new Filter([
				new Filter([new Filter("Status", FilterOperator.EQ, "30"), new Filter(
					"Status", FilterOperator.EQ, "20")], false)
			],
				true
			);

			aFilters.push(tileSpecificFilters);

			var oRatingSorter = new sap.ui.model.Sorter("Rating", true);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);
			var oSettings = this.getOwnerComponent().getModel("settings").getData();

			return new Promise(function (resolve, reject) {
				oModel.read("/GlobalEscalationsSet", {
					filters: aFilters,
					sorters: [oRatingSorter, oChangeDateSorter],
					success: function (data) {
						//concat toProducts properties
						data.results.forEach(function (result) {
							result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
							result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
							result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
							result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
							result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
							result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
							result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);
							this._setPieModel(result.toProducts.results);
						}, this);
						this._convertDataForCustomerOverview(Constants.MCCEngagementKey.GlobalEscalations, data.results);
						this.getModel("customerModel").setProperty("/globalEscCustLevel", data.results.length);
						this.getModel("customerModel").setProperty("/AmountGlobalEscalations", data.results.length);
						this._readGlobalEscalationsProducts(oFilter, resolve);
					}.bind(this),
					error: function (data) {
						this.getModel("customerModel").setProperty("/GlobalEscalationsSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));
		},

		_readGlobalEscalationsProducts: function (oFilter, resolve) {
			var oModel = this.getModel();
			var aFilters = [];

			aFilters.push(oFilter);

			//ALL ongoing escalations
			//Rating =   ALL
			//Case Status = status eq '20' or status eq '30'
			//process_type  Global Escalations (ZSPRCTYP01)  -->  should be predefined in Backend
			var tileSpecificFilters = new Filter([
				new Filter([
					new Filter("Status", FilterOperator.EQ, "30"),
					new Filter("Status", FilterOperator.EQ, "20")
				],
					false)
			],
				true
			);

			aFilters.push(tileSpecificFilters);

			var oRatingSorter = new sap.ui.model.Sorter("Rating", true);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);

			oModel.read("/GlobalEscalationsSet", {
				urlParameters: {
					"$expand": "toProducts",
					"$select": "CaseId,toProducts,PriorityT"
				},
				filters: aFilters,
				sorters: [oRatingSorter, oChangeDateSorter],
				success: function (data) {
					var oCustomerModel = this.getModel("customerModel");
					var aAlreadyAdded = oCustomerModel.getProperty("/CustomerOverview");
					//concat toProducts properties
					data.results.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
						result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
						result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
						result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);

						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVer = result.ProductVer;
								aTmp[i].ProductLineKeys = result.ProductLineKeys;
								aTmp[i].ProductKeys = result.ProductKeys;
							});
						}

						this._setPieModel(result.toProducts.results);
					}, this);
					oCustomerModel.refresh();
					resolve(data);
				}.bind(this),
				error: function (data) {
					this.getModel("customerModel").setProperty("/GlobalEscalationsSetBusy", false);
					resolve("No data found");
				}.bind(this)
			});

		},

		_readGlobalEscalationsNotes: function (oControl, id) {
			var oModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oModel.read("/GlobalEscalationsSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});

		},

		_readGlobalEscalationRequests: function (oFilter) {
			var oModel = this.getModel();
			var aFilters = [];

			aFilters.push(oFilter);

			//ALL ongoing
			var tileSpecificFilters = new Filter([
				new Filter([new Filter("Status", FilterOperator.EQ, "E0010"), new Filter(
					"Status", FilterOperator.EQ, "E0011")], false)
			],
				true
			);

			aFilters.push(tileSpecificFilters);

			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeTime", true);

			return new Promise(function (resolve, reject) {
				oModel.read("/GlobalEscalationRequestSet", {
					filters: aFilters,
					sorters: [oChangeDateSorter],
					success: function (data) {
						data.results.forEach(function (result) {
							result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);
						}.bind(this));
						this._convertDataForCustomerOverview("GlobalEscalationRequest", data.results);
						this.getModel("customerModel").setProperty("/AmountGlobalEscalationRequests", data.results.length);

						/*this.getModel("customerModel").setProperty("/GlobalEscalationRequestSet", data.results);
						this.getModel("customerModel").setProperty("/GlobalEscalationRequestsSetBusy", false);*/
						resolve(data);
					}.bind(this),
					error: function (data) {
						this.getModel("customerModel").setProperty("/GlobalEscalationRequestsSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));
		},

		_readOutages: function (customer, oOutagesModel) {
			var aFilters = [];
			var oUrlParameters = {
				"$select": "MasterEventID,CecEventID,CecEventStartDateTime,CecEventEndDateTime,MasterEventCustomerCount,MasterEventLobCount,MasterEventServiceStatusCode,SwatModeIsActive,CecEventStatusText,MasterEventCustomerCount,MasterEventLobCount,CecEventDescription,CustomerERPID"
			};

			aFilters.push(new Filter("SwatModeIsActive", FilterOperator.EQ, 1));
			aFilters.push(new Filter("CustomerERPID", FilterOperator.EQ, customer));

			//sorter
			var aSorter = [];
			aSorter.push(new sap.ui.model.Sorter("CecEventStartDateTime", true));

			return new Promise(function (resolve, reject) {
				oOutagesModel.read("/GetSwatOutages", {
					filters: aFilters,
					urlParameters: oUrlParameters,
					sorters: aSorter,
					success: function (data) {
						//convert data
						data.results.forEach(function (obj) {
							var df = sap.ui.core.format.DateFormat.getDateTimeInstance({
								pattern: "yyyyMMddHHmmss"
							});
							var startDate = df.parse(obj.CecEventStartDateTime);
							var endDate = df.parse(obj.CecEventEndDateTime);

							obj.Description = obj.CecEventDescription;
							obj.Status = obj.SwatModeIsActive === 1 ? "On" : "Off";
							obj.CreatedOn = startDate;
							obj.ClosedOn = endDate;
							obj.Duration = this._calculateDurationBetweenDates(obj.CecEventStartDateTime, obj.CecEventEndDateTime);
						}.bind(this));
						this._convertDataForCustomerOverview("Outages", data.results);
						this.getModel("customerModel").setProperty("/AmountOutages", data.results.length);
						resolve(data);
					}.bind(this),
					error: function (data) {
						this.getModel("customerModel").setProperty("/CriticalSituationsSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));
		},

		_readCrossIssues: function (oFilter) {
			var oModel = this.getModel();
			var aFilters = [];

			aFilters.push(oFilter);

			//Top Critical Customers
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new Filter([
				new Filter([
					new Filter("Status", FilterOperator.EQ, "E0010"),
					new Filter("Status", FilterOperator.EQ, "E0011"),
					new Filter("Status", FilterOperator.EQ, "E0016")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			//set SoldToParty ID dependent on system
			var currentUrl = window.location.href;
			var sSoldToParty = currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") ? "4699754" : "20672944";
			aFilters.push(new Filter("SoldToParty", FilterOperator.EQ, sSoldToParty));

			var oRatingSorter = new sap.ui.model.Sorter("Rating", true);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);

			return new Promise(function (resolve, reject) {
				oModel.read("/CrossIssueSet", {
					filters: aFilters,
					urlParameters: {
						"$top": "9999"
					},
					sorters: [oRatingSorter, oChangeDateSorter],
					success: function (data) {

						data.results.forEach(function (result) {
							result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);
						}.bind(this));

						this._convertDataForCustomerOverview(Constants.MCCEngagementKey.CrossIssues, data.results);
						this.getModel("customerModel").setProperty("/CrossIssues", data.results.length);
						this.getModel("customerModel").setProperty("/AmountCrossIssues", data.results.length);
						this._readCrossIssuesProducts(oFilter, resolve);
					}.bind(this),
					error: function (data) {
						this.getModel("customerModel").setProperty("/CriticalSituationsSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));
		},

		_readCrossIssuesProducts: function (oFilter, resolve) {
			var oModel = this.getModel();
			var aFilters = [];

			aFilters.push(oFilter);

			//Top Critical Customers
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new Filter([
				new Filter([
					new Filter("Status", FilterOperator.EQ, "E0010"),
					new Filter("Status", FilterOperator.EQ, "E0011"),
					new Filter("Status", FilterOperator.EQ, "E0016")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			//set SoldToParty ID dependent on system
			var currentUrl = window.location.href;
			var sSoldToParty = currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") ? "4699754" : "20672944";
			aFilters.push(new Filter("SoldToParty", FilterOperator.EQ, sSoldToParty));

			var oRatingSorter = new sap.ui.model.Sorter("Rating", true);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);

			oModel.read("/CrossIssueSet", {
				filters: aFilters,
				urlParameters: {
					"$top": "9999", //needed in order to get more than 1000 results back
					"$expand": "toProducts,toAffCustomers",
					"$select": "ObjectId,toProducts,toAffCustomers,PriorityT"
				},
				sorters: [oRatingSorter, oChangeDateSorter],
				success: function (data) {
					var oCustomerModel = this.getModel("customerModel");
					var aAlreadyAdded = oCustomerModel.getProperty("/CustomerOverview");
					//concat toProducts properties
					data.results.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
						result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
						result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
						result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);

						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === result.ObjectId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVer = result.ProductVer;
								aTmp[i].ProductLineKeys = result.ProductLineKeys;
								aTmp[i].ProductKeys = result.ProductKeys;
								aTmp[i].toAffCustomers = result.toAffCustomers;
								aTmp[i].MasterEventCustomerCount = result.toAffCustomers.results.length;
							});
						}

						this._setPieModel(result.toProducts.results);
					}, this);
					resolve(data);
				}.bind(this),
				error: function (data) {
					this.getModel("customerModel").setProperty("/CriticalSituationsSetBusy", false);
					resolve("No data found");
				}.bind(this)
			});

		},

		_readCriticalSituations: function (oFilter) {
			var oModel = this.getModel();
			var aFilters = [];

			aFilters.push(oFilter);

			//Top Critical Customers
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new Filter([
				new Filter([
					new Filter("Status", FilterOperator.EQ, "71"),
					new Filter("Status", FilterOperator.EQ, "80"),
					new Filter("Status", FilterOperator.EQ, "81"),
					new Filter("Status", FilterOperator.EQ, "99")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);
			aFilters.push(new Filter("CustomerType", FilterOperator.EQ, "ZSCUSTYP06"));
			aFilters.push(new Filter("Reason", FilterOperator.EQ, "ENGA"));

			var oRatingSorter = new sap.ui.model.Sorter("Rating", true);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);

			return new Promise(function (resolve, reject) {
				oModel.read("/CustomerEngagementSet", {
					filters: aFilters,
					urlParameters: {
						"$top": "9999"
					},
					sorters: [oRatingSorter, oChangeDateSorter],
					success: function (data) {
						data.results.forEach(function (oCase) {

							oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);

						}.bind(this));
						this._convertDataForCustomerOverview(Constants.MCCEngagementKey.TopCriticalCustomers, data.results);
						this.getModel("customerModel").setProperty("/TopCriticalCustomers", data.results.length);
						this.getModel("customerModel").setProperty("/AmountTopCriticalCustomers", data.results.length);
						this._readCriticalSituationsProducts(oFilter, resolve);
					}.bind(this),
					error: function (data) {
						this.getModel("customerModel").setProperty("/CriticalSituationsSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));
		},

		_readHighPrioTickets: function (sCustomer) {
			sCustomer = this.pad(sCustomer, 10);
			var sFilterString = "sysparm_query=ORDERBYpriority%5eaccount.number=" + sCustomer + "%5epriority=1%5eORpriority=2%5estate!=3";

			sFilterString = sFilterString.replaceAll("^", "%5e");
			//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
			if (sFilterString.startsWith("%5esysparm_query")) {
				sFilterString.replace("%5esysparm_query", "sysparm_query");
			}

			sFilterString += Constants.fieldsForCimTableHighPrio;

			this.getModel("customerModel").setProperty("/HighPrioTicketsBusy", true);

			return new Promise(function (resolve, reject) {
				//AJAX CALL FOR DEV USING .JSON
				/*$.ajax({
					url: "./json/CustomerView/CustomerHighPrioTicketsExample.json",
					type: "GET",
					dataType: "json", */

				$.ajax({
					method: "GET",
					contentType: "application/json",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/sn_customerservice_case?" + sFilterString,

					success: function (data) {
						var iVeryHigh = 0,
							iHigh = 0;
						data.result.forEach(function (item) {

							//set counter for priorities very high ==1
							if (item["priority"] === "1") {
								iVeryHigh++;
							} else {
								iHigh++;
							}
							item["u_task_record.account.country_text"] = this.formatter.getCountryName(item["u_task_record.account.country"], this);
							item["action_status"] = this.formatter.getCimActionStatus(item["action_status"]);
							item["state"] = this.formatter.getCimStatus(item["state"]);
							item["priority"] = this.formatter.getCimPriority(item["priority"]);
							item["priorityMatched"] = this.formatter.sortPriorities(item["priority"]);
							item["active_escalation.escalation_justification"] = item["active_escalation.escalation_justification"] !== "" ? "X" :
								"";
							item["active_escalation.stateT"] = this.formatter.getCimEscalationStatus(item["active_escalation.state"]);
							item.toProducts = {
								results: []
							};
							if (item["u_install_base_item.u_product.model_number"] !== "") {
								item.ProductKeys = item["u_install_base_item.u_product.model_number"];
								item.ProductLineKeys = item["u_install_base_item.u_product.u_product_line_id.u_product_line_id"];
								item.toProducts.results.push({
									CaseId: item["number"],
									Main: "",
									Product: item["u_install_base_item.u_product.model_number"],
									ProductT: item["u_install_base_item.u_product.display_name"],
									ProductCat: item["u_install_base_item.u_product.u_product_line_id.u_product_category_id"],
									ProductCatT: item["u_install_base_item.u_product.u_product_line_id.u_product_category_name"],
									ProductLine: item["u_install_base_item.u_product.u_product_line_id.u_product_line_id"],
									ProductLineT: item["u_install_base_item.u_product.u_product_line_id.u_product_line_name"],
									ProductVersion: item["u_install_base_item.u_product_version.model_number"],
									ProductVersionT: item["u_install_base_item.u_product_version.display_name"]
								});
							}

							//Check if there is a product name, else try insert
							if (item["u_install_base_item.u_product_version.display_name"] == "") {
								if (item["u_product_version_on_creation.display_name"] !== "") {
									item["u_install_base_item.u_product_version.display_name"] = item[
										"u_product_version_on_creation.display_name"]
								}
							}

							//Check if there is a product number, else try insert
							if (item["u_install_base_item.u_product.model_number"] == "") {
								if (item["u_product_version_on_creation.model_number"] !== "") {
									item.toProducts.results.push({
										Product: item["u_product_version_on_creation.model_number"]
									});
									if (item.ProductKeys !== "") {
										item.ProductKeys = item["u_product_version_on_creation.model_number"]
									}
								}
							}

						}.bind(this));

						//this._convertDataForCustomerOverview("HighPrioTickets", data.result);
						this.getModel("customerModel").setProperty("/AmountAllHighPrioTickets", data.result.length);
						this.getModel("customerModel").setProperty("/AmountVeryHighPrioTickets", iVeryHigh);
						this.getModel("customerModel").setProperty("/AmountHighPrioTickets", iHigh);
						this.getModel("customerModel").setProperty("/HighPrioTicketsBusy", false);
						this.getModel("customerModel").setProperty("/HighPrioTickets", data.result);

						resolve(data);
					}.bind(this),
					error: function (err) {
						this.getModel("customerModel").setProperty("/HighPrioTicketsBusy", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));
		},

		_readCims: function (sCustomer, oServiceNowTagPromise) {
			sCustomer = this.pad(sCustomer, 10);
			var sFilterString = "sysparm_query=";
			sFilterString += encodeURIComponent("ORDERBYu_task_record.priority^state=101^ORstate=100^u_task_record.account.number=" + sCustomer + "^u_escalation_type=3");

			//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
			if (sFilterString.startsWith("%5esysparm_query")) {
				sFilterString.replace("%5esysparm_query", "sysparm_query");
			}
			sFilterString += "&sysparm_fields=";
			sFilterString += encodeURIComponent(Constants.fieldsForCimCustomerTableWithoudParameter);

			return new Promise(function (resolve, reject) {
				//sFilterString = encodeURIComponent(sFilterString);
				var body = {
					"batch_request_id": 1,
					"rest_requests": [{
						"headers": [
							{ "name": "Content-Type", "value": "application/json" },
							{ "name": "Accept", "value": "application/json" }
						],
						"url": "/api/now/table/sn_customerservice_escalation?" + sFilterString,
						"method": "GET",
						"id": "0000014383DUMMY",
						"exclude_response_headers": "true"
					}]
				};
				body = JSON.stringify(body);
				$.ajax({
					method: "POST",
					contentType: "application/json",
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
					data: body,
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					error: function () {
						resolve();
					},
					success: function (data) {
						data = JSON.parse(atob(data.serviced_requests[0].body));
						oServiceNowTagPromise.then(function (oTagData) { //wait for ServiceNow Tag data to be retrieved
							data.result.forEach(function (item) {
								item["u_task_record.country_text"] = this.formatter.getCountryName(item["u_task_record.country"], this);
								item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"]);
								item["u_task_record.priority"] = this.formatter.getCimPriority(item["u_task_record.priority"]);
								item["u_task_record.priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"]);
								item["HasNotes"] = item["escalation_justification"] !== "" ? "X" : "";
								if (item["state"] === "101") { // only add to pie chart if it is a CIM, not a CIM Request
									item.toProducts = {
										results: []
									};
									if (item["u_task_record.u_install_base_item.u_product.model_number"] !== "") {
										item.ProductKeys = item["u_task_record.u_install_base_item.u_product.model_number"];
										item.ProductLineKeys = item[
											"u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"];
										item.toProducts.results.push({
											CaseId: item["u_task_record.number"],
											Main: "",
											Product: item["u_task_record.u_install_base_item.u_product.model_number"],
											ProductT: item["u_task_record.u_install_base_item.u_product.display_name"],
											ProductCat: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id"],
											ProductCatT: item[
												"u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_name"],
											ProductLine: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"],
											ProductLineT: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_name"],
											ProductVersion: item["u_task_record.u_install_base_item.u_product_version.model_number"],
											ProductVersionT: item["u_task_record.u_install_base_item.u_product_version.display_name"]
										});
									}
									this._setPieModel(item.toProducts.results);
								}
								// set ServiceNow Tag Information
								var oTagElement = oTagData.result.filter(function (val) {
									return val["id_display"] === item.number; //"ESC0140066"; //
								});
								if (oTagElement) {
									item.CaseTag = "";
									oTagElement.forEach(function (tagElementItem, index) {
										item.CaseTag += tagElementItem['label.name'];
										if (oTagElement.length > (index + 1)) {
											item.CaseTag += ", ";
										}
									});
								}
							}.bind(this));

							var aCims = data.result.filter(function (val) {
								return val["state"] === "101";
							});
							this._convertDataForCustomerOverview(Constants.MCCEngagementKey.Cims, aCims);
							this.getModel("customerModel").setProperty("/AmountCims", aCims.length);

							var aCimsRequest = data.result.filter(function (val) {
								return val["state"] === "100";
							});
							this._convertDataForCustomerOverview("CimRequests", aCimsRequest);
							this.getModel("customerModel").setProperty("/AmountCimsRequest", aCimsRequest.length);
							resolve(data);
						}.bind(this));
					}.bind(this)
				});
			}.bind(this));
		},

		_readCriticalSituationsProducts: function (oFilter, resolve) {
			var oModel = this.getModel();
			var aFilters = [];

			aFilters.push(oFilter);

			//Top Critical Customers
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new Filter([
				new Filter([
					new Filter("Status", FilterOperator.EQ, "71"),
					new Filter("Status", FilterOperator.EQ, "80"),
					new Filter("Status", FilterOperator.EQ, "81"),
					new Filter("Status", FilterOperator.EQ, "99")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);
			aFilters.push(new Filter("CustomerType", FilterOperator.EQ, "ZSCUSTYP06"));
			aFilters.push(new Filter("Reason", FilterOperator.EQ, "ENGA"));

			var oRatingSorter = new sap.ui.model.Sorter("Rating", true);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);

			oModel.read("/CustomerEngagementSet", {
				filters: aFilters,
				urlParameters: {
					"$top": "9999", //needed in order to get more than 1000 results back
					"$expand": "toProducts",
					"$select": "CaseId,toProducts,PriorityT"
				},
				sorters: [oRatingSorter, oChangeDateSorter],
				success: function (data) {
					var oCustomerModel = this.getModel("customerModel");
					var aAlreadyAdded = oCustomerModel.getProperty("/CustomerOverview");
					//concat toProducts properties
					data.results.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
						result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
						result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
						result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);

						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVer = result.ProductVer;
								aTmp[i].ProductLineKeys = result.ProductLineKeys;
								aTmp[i].ProductKeys = result.ProductKeys;
							});
						}

						this._setPieModel(result.toProducts.results);
					}, this);
					resolve(data);
				}.bind(this),
				error: function (data) {
					this.getModel("customerModel").setProperty("/CriticalSituationsSetBusy", false);
					resolve("No data found");
				}.bind(this)
			});

		},

		_readCrossIssuesNotes: function (oControl, id) {
			var oICModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oICModel.read("/CrossIssueSet(guid'" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		_readCriticalSituationsNotes: function (oControl, id, sObjectType) {
			var oModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oModel.read("/CustomerEngagementSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results, sObjectType);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		_readTaskForces: function (oFilter) {
			var oModel = this.getModel();
			var aFilters = [];

			aFilters.push(oFilter);

			//all ongoing Critical Customer Management
			//Critical Period Coverage
			//Project Engagement Support/Guided Solution Support
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new Filter([
				new Filter([
					new Filter("Status", FilterOperator.EQ, "71"),
					new Filter("Status", FilterOperator.EQ, "80"),
					new Filter("Status", FilterOperator.EQ, "81"),
					new Filter("Status", FilterOperator.EQ, "99")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			aFilters.push(new Filter("CustomerType", FilterOperator.EQ, "ZSCUSTYP07"));

			var oRatingSorter = new sap.ui.model.Sorter("Rating", true);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);

			return new Promise(function (resolve, reject) {
				aFilters.push(new Filter("Reason", FilterOperator.EQ, "ENGA"));
				oModel.read("/CustomerEngagementSet", {
					filters: aFilters,
					urlParameters: {
						"$top": "9999"
					},
					sorters: [oRatingSorter, oChangeDateSorter],
					success: function (data) {
						data.results.forEach(function (result) {
							result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);
						}.bind(this));

						this._convertDataForCustomerOverview(Constants.MCCEngagementKey.TaskForces, data.results);
						this.getModel("customerModel").setProperty("/AmountTaskForces", data.results.length);

						this._readTaskForcesProducts(oFilter, resolve);
					}.bind(this),
					error: function (data) {
						this.getModel("customerModel").setProperty("/CriticalSituationsSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));

		},

		_readTaskForcesProducts: function (oFilter, resolve) {
			var oModel = this.getModel();
			var aFilters = [];

			aFilters.push(oFilter);

			//all ongoing Critical Customer Management
			//Critical Period Coverage
			//Project Engagement Support/Guided Solution Support
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new Filter([
				new Filter([
					new Filter("Status", FilterOperator.EQ, "71"),
					new Filter("Status", FilterOperator.EQ, "80"),
					new Filter("Status", FilterOperator.EQ, "81"),
					new Filter("Status", FilterOperator.EQ, "99")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			aFilters.push(new Filter("CustomerType", FilterOperator.EQ, "ZSCUSTYP07"));
			aFilters.push(new Filter("Reason", FilterOperator.EQ, "ENGA"));

			var oRatingSorter = new sap.ui.model.Sorter("Rating", true);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);

			oModel.read("/CustomerEngagementSet", {
				filters: aFilters,
				urlParameters: {
					"$top": "9999", //needed in order to get more than 1000 results back
					"$expand": "toProducts",
					"$select": "CaseId,toProducts,PriorityT"
				},
				sorters: [oRatingSorter, oChangeDateSorter],
				success: function (data) {
					//only append data to pie chart if it was filtered
					var aFilteredData = [];
					var oCustomerModel = this.getModel("customerModel");
					var aAlreadyAdded = oCustomerModel.getProperty("/CustomerOverview");

					data.results.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
						result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
						result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
						result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);

						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVer = result.ProductVer;
								aTmp[i].ProductLineKeys = result.ProductLineKeys;
								aTmp[i].ProductKeys = result.ProductKeys;
							});
						}
					}, this);
					aFilteredData = aFilteredData.concat(data.results);

					//concat toProducts properties
					aFilteredData.forEach(function (result) {
						this._setPieModel(result.toProducts.results);
					}, this);

					oCustomerModel.refresh();
					resolve(data);
				}.bind(this),
				error: function (data) {
					this.getModel("customerModel").setProperty("/CriticalSituationsSetBusy", false);
					resolve("No data found");
				}.bind(this)
			});

		},

		_readExecutiveEscalations: function (sCustomer) {
			sCustomer = this.pad(sCustomer, 10)
			// TODO add Executive Escalation Type here when it is available
			const sFilterString =
				"?sysparm_query=ORDERBYu_task_record.priority^state=101^u_escalation_type=7^assignment_group.nameLIKEHEAT^u_customer_3.number=" + sCustomer;
			SNOWConnector._readExecutiveEscalations(sCustomer, sFilterString, this).then((SNOWresult) => {
				this.getModel("customerModel").setProperty("/AmountExecutiveEscalations", SNOWresult.length);
				let aPromises = [HANADBConnector.loadMCCObjects(this, SNOWresult)]
				SNOWresult.forEach((oSNOWEscalation) => aPromises.push(Tag.loadTags(oSNOWEscalation)))
				Promise.all(aPromises).then((aResults) => {
					const HANAresult = aResults[0]
					HANAresult.forEach((oHANAEscalation) => {
						let oSNOWEscalation = SNOWresult.find((currentSNOWEscalation) => currentSNOWEscalation.number === oHANAEscalation["EscalationID"])
						if (!!oHANAEscalation.EndDate) oSNOWEscalation.PlanEndDate = oHANAEscalation.EndDate
						if (!!oHANAEscalation.GoLiveDate) oSNOWEscalation.GoLiveDate = oHANAEscalation.GoLiveDate
						if (!!oHANAEscalation["ClosureDate"]) oSNOWEscalation.ClosedOn = oHANAEscalation["ClosureDate"]
						if (!!oHANAEscalation["ProductID"]) {
							oSNOWEscalation.toProducts = {
								results: [{
									Product: oHANAEscalation["ProductID"],
									ProductT: oHANAEscalation["ProductText"],
									ProductLine: oHANAEscalation["ProductLineID"],
									ProductLineT: oHANAEscalation["ProductLineName"]
								}]
							}
							oSNOWEscalation.ProductKeys = oHANAEscalation["ProductID"]
							oSNOWEscalation.ProductLineKeys = oHANAEscalation["ProductLineID"]
							this._setPieModel(oSNOWEscalation.toProducts.results)
						} else oSNOWEscalation.toProducts = { results: [] }
						oSNOWEscalation.Product = oHANAEscalation["ProductText"]
						oSNOWEscalation.ProductLine = oHANAEscalation["ProductLineName"]
						oSNOWEscalation.ActResultT = formatter.formatExpectedActionExecutiveEscalation(oHANAEscalation["ExpectedAction"])
					})
				}).finally(() => this._convertDataForCustomerOverview(Constants.MCCEngagementKey.ExecutiveEscalations, SNOWresult))
			});
		},

		_readCustomerEngagements: function (oFilter) {
			var oModel = this.getModel();
			var aFilters = [];

			aFilters.push(oFilter);

			//all ongoing Critical Customer Management
			//Critical Period Coverage
			//Project Engagement Support/Guided Solution Support
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new Filter([
				new Filter([
					new Filter("Status", FilterOperator.EQ, "71"),
					new Filter("Status", FilterOperator.EQ, "80"),
					new Filter("Status", FilterOperator.EQ, "81"),
					new Filter("Status", FilterOperator.EQ, "99")
				], false),
				new Filter([
					new Filter("CustomerType", FilterOperator.EQ, "ZSCUSTYP04"),
					new Filter("CustomerType", FilterOperator.EQ, "ZSCUSTYP05")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			//aFilters.push(new Filter("CustomerType", FilterOperator.EQ, "ZSCUSTYP05"));

			var oRatingSorter = new sap.ui.model.Sorter("Rating", true);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);

			return new Promise(function (resolve, reject) {
				aFilters.push(new Filter("Reason", FilterOperator.EQ, "ENGA"));
				oModel.read("/CustomerEngagementSet", {
					filters: aFilters,
					urlParameters: {
						"$top": "9999"
					},
					sorters: [oRatingSorter, oChangeDateSorter],
					success: function (data) {

						data.results.forEach(function (result) {
							result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);
						}.bind(this));

						//Critical Customer Management
						var criticalCustomerManagement = data.results.filter(function (val) {
							return val.CustomerType === "ZSCUSTYP05";
						});

						//CCM Light Cases
						this._convertDataForCustomerOverview(Constants.MCCEngagementKey.CriticalCustomerManagement, criticalCustomerManagement);
						this.getModel("customerModel").setProperty("/AmountCriticalCustomerManagement", criticalCustomerManagement.length);

						/*var aFilteredData = [];
						var aFilters = [new Filter([
							new Filter("bCCML1", FilterOperator.EQ, true),
							new Filter("bCCML2", FilterOperator.NE, true)
						], true)];
						this.getOwnerComponent().getModel("subModel").read("/Cases", {
							filters: aFilters,
							urlParameters: {
								"$select": "CaseID,bCCML1,bCCML2"
							},
							success: function (oData) {
								//check if not a light case
								criticalCustomerManagement.forEach(function (c) {
									var oCase = oData.results.find(function (hanaCase) {
										return c.CaseId === hanaCase.CaseID.toString();
									});
									if (!oCase) {
										aFilteredData.push(c);
									}
								});

								this._convertDataForCustomerOverview(Constants.MCCEngagementKey.CriticalCustomerManagement, aFilteredData);
								this.getModel("customerModel").setProperty("/AmountCriticalCustomerManagement", aFilteredData.length);

							}.bind(this)
						});*/

						//Critical Period Coverage
						var criticalPeriodCoverage = data.results.filter(function (val) {
							return val.CustomerType === "ZSCUSTYP04";
						});
						this._convertDataForCustomerOverview("CriticalPeriodCoverage", criticalPeriodCoverage);
						this.getModel("customerModel").setProperty("/AmountCriticalPeriodCoverage", criticalPeriodCoverage.length);

						this._readCustomerEngagementsProducts(oFilter, resolve);

					}.bind(this),
					error: function (data) {
						this.getModel("customerModel").setProperty("/CriticalSituationsSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));

		},

		readImplementationPartner: function (oModel) {
			var aData = oModel.getData();
			var aFilters = [];

			//split data in multiple arrays
			var size = 50;
			var arrayOfArrays = [];
			for (var i = 0; i < aData["CustomerOverview"].length; i += size) {
				arrayOfArrays.push(aData["CustomerOverview"].slice(i, i + size));
			}

			arrayOfArrays.forEach(function (array) {
				aFilters = [];
				array.forEach((oObject) => {
					if (oObject.ObjectId && oObject.ObjectId !== "" && oObject.objectType !== "Critical Incident Management" && oObject.objectType !==
						"Global Escalation" && oObject.objectType !== Constants.MCCEngagementType.BusinessDownSituations && oObject.objectType !== Constants.MCCEngagementType.Major_SAP_Cloud_Downtimes && oObject.objectType !==
						"Technical Backoffice Requests" && oObject.objectType !== Constants.MCCEngagementType.XTecEngagements && oObject.objectType !==
						Constants.MCCEngagementType.PECriticalEngagements && oObject.objectType !== Constants.MCCEngagementType.ExecutiveEscalation) {
						aFilters.push(new Filter("CaseID", FilterOperator.EQ, oObject.ObjectId));
					}
				});
				this.getModel("subModel").read("/Cases", {
					filters: [new Filter(aFilters, false)],
					success: function (oData) {
						oData.results.forEach(function (result) {
							var oCase = aData["CustomerOverview"].filter(function (val) {
								return val.ObjectId === result.CaseID.toString();
							});
							if (oCase && oCase.length === 1) {
								oCase[0]["ImplementationPartner"] = result.PartnerName;
							}
						});
						oModel.refresh();
					}
				});
			}.bind(this));

		},

		_resetCustomerHistoryModelAndRefreshGantt: function () {
			var oCustomerHistoryModel = this.getView().getModel("customerHistory");
			errorShown = false;

			if (oCustomerHistoryModel !== undefined && oCustomerHistoryModel !== null) {
				oCustomerHistoryModel.setData({});
				var oGanttChart = this.getView().byId("gantt");
				if (oGanttChart !== undefined && oGanttChart !== null) {
					// Aktualisieren Sie das Gantt-Diagramm
					oGanttChart.getModel().refresh(true);
				}
			}
		},

		readCustomerHistoryData: function (sErpCust, oFilter) {
			//turn on busyindicator
			sErpCust = this.pad(sErpCust, 10);
			this.getView().byId("gantt").setBusyIndicatorDelay(0);
			this.getView().byId("gantt").setBusy(true);
			var aPromises = [];
			var oSettings = this.getOwnerComponent().getModel("settings").getData();
			aPromises.push(this._readCustomerHistoryEngagementCases(sErpCust));
			aPromises.push(this._readCustomerHistoryCIM(sErpCust));
			aPromises.push(this._readCustomerHistoryTBE(sErpCust));

			if (oSettings.isAnonymizedMode === false) {
				aPromises.push(this._readCustomerHistoryGEM(oFilter));
				aPromises.push(this._readCustomerHistoryCrossIssues(oFilter));
			}

			Promise.all(aPromises).then(function (aResults) {
				//push in one array
				var aData = [];
				aResults.forEach(function (arr) {
					arr.forEach(function (obj) {
						obj.cases.forEach(function (caseObj) {
							caseObj.type = obj.type;
						});
						aData.push(obj);
					});
				});
				//	aData = aData.concat(arr);
				this._readCustomerHistoryCompleted(aData);
			}.bind(this));
		},

		_addCounterToType: function (aRows) {
			var typeCounters = {};
			aRows.forEach(function (row) {
				var type = row.type;
				var cases = row.cases.length;

				// Add Number of Cases to type counter
				typeCounters[type] = typeCounters[type] || 0;
				typeCounters[type] += cases;
			});

			// Add Counter to type
			aRows.forEach(function (row) {
				var type = row.type;
				row.type = type + " (" + typeCounters[type] + ")";
			});
			return aRows;

		},

		_readCustomerHistoryCrossIssues: function (oFilter) {
			var oModel = this.getModel();
			var aFilters = [];
			var dateInPast = this._getGanttStartDate();

			aFilters.push(oFilter);

			var tileSpecificFiltersClosed = new Filter([
				new Filter([
					new Filter("Status", FilterOperator.EQ, "E0012"),
					new Filter("Status", FilterOperator.EQ, "E0013"),
					new Filter("Status", FilterOperator.EQ, "E0014"),
					new Filter("Status", FilterOperator.EQ, "E0017"),
					new Filter("Status", FilterOperator.EQ, "E0018")
				], false),
				new Filter({
					path: "ClosingDate",
					operator: FilterOperator.GE,
					value1: dateInPast
				})
			],
				true
			);

			//Top Critical Customers
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFiltersOngoing = new Filter([
				new Filter([
					new Filter("Status", FilterOperator.EQ, "E0010"),
					new Filter("Status", FilterOperator.EQ, "E0011"),
					new Filter("Status", FilterOperator.EQ, "E0016")
				], false)
			],
				true
			);
			aFilters.push(new Filter([
				tileSpecificFiltersClosed,
				tileSpecificFiltersOngoing
			],
				false
			));

			//set SoldToParty ID dependent on system
			var currentUrl = window.location.href;
			var sSoldToParty = currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") ? "4699754" : "20672944";
			aFilters.push(new Filter("SoldToParty", FilterOperator.EQ, sSoldToParty));

			var oChangeDateSorter = new sap.ui.model.Sorter("ClosingDate", true);

			return new Promise(function (resolve, reject) {
				oModel.read("/CrossIssueSet", {
					filters: aFilters,
					urlParameters: {
						"$top": "9999"
					},
					sorters: [oChangeDateSorter],
					success: function (data) {
						var aRows = [];
						data.results.forEach(function (object) {
							var to = null;
							var from = new Date(object.CreateDate);
							var bOngoing = false;
							if (object.ClosingDate) {
								to = new Date(object.ClosingDate);
							} else {
								to = new Date();
								bOngoing = true;
							}
							// If the duration is to short to show properly in the Gantt, add 6 hours to "from" for gantt and save the real "to" into var
							if ((to - from) / (1000 * 60 * 60) < 12) {
								var realTo = to;
								to = new Date(from.getTime() + (12 * 60 * 60 * 1000));
							}

							var oCase = {
								id: object.ObjectId,
								from: from,
								to: to,
								realTo: realTo,
								ongoing: bOngoing,
								status: object.StatusT,
								product: object.Product,
								type: "Cross Issues"
							};

							if (aRows.length === 0) {
								aRows.push({
									description: "",
									type: "Cross Issues",
									cases: [oCase]
								});
							} else {
								var bRowAdded = false;
								var bSameType = false;
								aRows.forEach(function (row) {
									//now check all rows where we can add the case.
									if (row.type == oCase.type) {
										bSameType = true;
										var bSameTime = row.cases.some(function (r) {
											return this.dateRangeOverlaps(from, to, r.from, r.to);
										}.bind(this));

										if (!bSameTime && !bRowAdded) {
											bRowAdded = true;
											row.cases.push(oCase);
											return;
										}
									}
								}.bind(this));

								if (!bRowAdded) {
									aRows.push({
										description: "",
										type: "Cross Issues",
										cases: [oCase]
									});
								}
							}
						}.bind(this));
						aRows = this._addCounterToType(aRows);
						resolve(aRows);
					}.bind(this),
					error: function (err) {
						resolve([]);
					}
				});
			}.bind(this));
		},

		_readCustomerHistoryGEM: function (oFilter) {
			var oModel = this.getModel();
			var aFilters = [];
			var dateInPast = this._getGanttStartDate();

			aFilters.push(oFilter);

			var tileSpecificFiltersClosed = new Filter(
				[
					new Filter([
						new Filter("Status", FilterOperator.EQ, "40")
					],
						false),
					new Filter({
						path: "ClosingDate",
						operator: FilterOperator.GE,
						value1: dateInPast
					})
				],
				true
			);

			var tileSpecificFiltersOngoing = new Filter([
				new Filter([new Filter("Status", FilterOperator.EQ, "20"), new Filter(
					"Status", FilterOperator.EQ, "30")], false)
			],
				true
			);

			aFilters.push(new Filter([
				tileSpecificFiltersClosed,
				tileSpecificFiltersOngoing
			],
				false
			));

			var oChangeDateSorter = new sap.ui.model.Sorter("ClosingDate", true);
			var oSettings = this.getOwnerComponent().getModel("settings").getData();

			return new Promise(function (resolve, reject) {
				oModel.read("/GlobalEscalationsSet", {
					filters: aFilters,
					sorters: [oChangeDateSorter],
					success: function (data) {
						var aRows = [];
						data.results.forEach(function (object) {
							var from = new Date(object.CreateDate);
							var to = null;
							var bOngoing = false;
							if (object.ClosingDate) {
								to = new Date(object.ClosingDate);
							} else {
								to = new Date();
								bOngoing = true;
							}
							// If the duration is to short to show properly in the Gantt, add 6 hours to "from" for gantt and save the real "to" into var
							if ((to - from) / (1000 * 60 * 60) < 12) {
								var realTo = to;
								to = new Date(from.getTime() + (12 * 60 * 60 * 1000));
							}

							var oCase = {
								id: object.CaseId,
								from: from,
								to: to,
								realTo: realTo,
								ongoing: bOngoing,
								status: object.StatusT,
								product: object.ProductT,
								type: "Global Escalation Management"
							};

							if (aRows.length === 0) {
								aRows.push({
									description: "",
									type: "Global Escalation Management",
									cases: [oCase]
								});
							} else {
								var bRowAdded = false;
								var bSameType = false;
								aRows.forEach(function (row) {
									//now check all rows where we can add the case.
									if (row.type == oCase.type) {
										bSameType = true;
										var bSameTime = row.cases.some(function (r) {
											return this.dateRangeOverlaps(from, to, r.from, r.to);
										}.bind(this));

										if (!bSameTime && !bRowAdded) {
											bRowAdded = true;
											row.cases.push(oCase);
											return;
										}
									}
								}.bind(this));

								if (!bRowAdded) {
									aRows.push({
										description: "",
										type: "Global Escalation Management",
										cases: [oCase]
									});
								}
							}
						}.bind(this));

						aRows = this._addCounterToType(aRows);
						resolve(aRows);
					}.bind(this),
					error: function (data) {
						resolve([]);
					}.bind(this)
				});
			}.bind(this));
		},

		_readCustomerHistoryTBE: function (sErpCust) {
			return new Promise(function (resolve, reject) {
				//set date filters
				var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd" // we need a format like 2022-12-24
				});
				var ganttStartDate = oFormat.format(this._getGanttStartDate());

				if (DebugMode) {
					//DEBUG
					var sPath = jQuery.sap.getModulePath("com.sap.mcconedashboard", "/json/CustomerHistory/TBE.json");
					$.ajax(sPath).always(function (data, stextStatus, errorThrown) {
						if (data.queryResults.CL_CUST_TBE_ESCALATIONS_ONEDASHBOARD.rows) {
							var aRows = [];
							data.queryResults.CL_CUST_TBE_ESCALATIONS_ONEDASHBOARD.rows.forEach(function (object) {
								var from = new Date(object.ESC_Created_At.title);
								var to = null;
								var bOngoing = false;
								if (object.ESC_Closed_At.title && object.ESC_Closed_At.title !== "") {
									to = new Date(object.ESC_Closed_At.title);
								} else {
									to = new Date();
									bOngoing = true;
								}
								// If the duration is to short to show properly in the Gantt, add 6 hours to "from" for gantt and save the real "to" into var
								if ((to - from) / (1000 * 60 * 60) < 12) {
									var realTo = to;
									to = new Date(from.getTime() + (12 * 60 * 60 * 1000));
								}

								var durationInHours;
								if (object.Duration_of_Business_elapsed_time_In_Hour_.value <= 0.01 || object.Duration_of_Business_elapsed_time_In_Hour_
									.value ===
									null) {
									durationInHours = object.Duration_of_Business_elapsed_time_In_Day_.value * 24;
								} else {
									durationInHours = object.Duration_of_Business_elapsed_time_In_Hour_.value;
								}
								var durationString = formatter.formatDurationToDaysHoursMinutes(durationInHours);

								var oCase = {
									id: object.Escalation_Number.title,
									from: from,
									to: to,
									realTo: realTo,
									ongoing: bOngoing,
									status: object.State.title,
									product: object.Product_Version.title,
									type: object.Escalation_Type.title,
									slaDefs: [{
										title: object.SLA_definition.title,
										duration: durationString
									}]
								};

								//CHECK IF ESC NUMBER ALREADY EXISTS
								var existingRow = aRows.find(function (row) {
									return row.cases.some(function (c) {
										return c.id === object.Escalation_Number.title;
									});
								});

								if (existingRow) {
									var existingCase = existingRow.cases.find(function (c) {
										return c.id === object.Escalation_Number.title;
									});

									// check if SLA_definition already exists for the case
									var existingSLADef = existingCase.slaDefs.find(function (def) {
										return def.title === object.SLA_definition.title;
									});

									if (existingSLADef) {
										// SLA_definition already exists, add duration to it
										existingSLADef.duration = durationString;
									} else {
										// add new SLA_definition to the case
										existingCase.slaDefs.push({
											title: object.SLA_definition.title,
											duration: durationString
										});
									}
								} else {

									if (aRows.length === 0) {
										aRows.push({
											description: "",
											type: object.Escalation_Type.title,
											cases: [oCase]
										});
									} else {
										var bRowAdded = false;
										var bSameType = false;
										aRows.forEach(function (row) {
											//now check all rows where we can add the case.
											if (row.type == oCase.type) {
												bSameType = true;
												var bSameTime = row.cases.some(function (r) {
													return this.dateRangeOverlaps(from, to, r.from, r.to);
												}.bind(this));

												if (!bSameTime && !bRowAdded) {
													bRowAdded = true;
													row.cases.push(oCase);
													return;
												}
											}
										}.bind(this));

										if (!bRowAdded) {
											aRows.push({
												description: "",
												type: object.Escalation_Type.title,
												cases: [oCase]
											});
										}
									}
								}
							}.bind(this));
							aRows = this._addCounterToType(aRows);
							resolve(aRows);
						} else {
							resolve([]);
						}
					}.bind(this));
				} else {

					//PROD NEW
					$.ajax({
						method: "POST",
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
						data: JSON.stringify([{
							"queryIdentifier": "CL_CUST_TBE_ESCALATIONS_ONEDASHBOARD",
							"filters": [{
								"filters": [{
									"operand1": {
										"elementIdentifier": "Customer_Number"
									},
									"operand2": {
										"values": [sErpCust]
									},
									"operator": "EQ"
								}],
								"conjunctionOperator": "AND"
							}, {
								"filters": [{
									"operand1": {
										"elementIdentifier": "ESC_Closed_At"
									},
									"operator": "GE",
									"operand2": {
										"values": [ganttStartDate]
									}
								}, {
									"operand1": {
										"elementIdentifier": "State"
									},
									"operator": "NE",
									"operand2": {
										"values": ["103"]
									}
								}],
								"conjunctionOperator": "OR"
							}],
							"skip": 0
						}]),
						contentType: "application/json"
					}).fail(function (data, textStatus, errorThrown) {
						if (data && data.responseJSON && data.responseJSON.message === "Not authorized on remote system: BW / DEV") {
							if (!errorShown) {
								var sText = "You are missing authorization. Please request profile auth.cust::REPORTER";
								errorShown = true;
								MessageBox.error(sText, {
									title: "Missing Authorization",
									actions: ["Request Authorization", MessageBox.Action.CLOSE],
									emphasizedAction: "Request Authorization",
									onClose: function (sAction) {
										if (sAction == "Request Authorization") {
											var win = window.open("https://" +
												"sapit-home-prod-004.launchpad.cfapps.eu10.hana.ondemand.com/site#arm-Create&/createRequest/prefilled?system=BWP_HDB&mandant=001&role=auth.cust::REPORTER",
												"_blank");
											win.opener = null;
											win.focus();
										}
										resolve([]);
									}
								});
							}
						}
						resolve([]);
					}).done(function (data, textStatus, errorThrown) {
						if (data.queryResults.CL_CUST_TBE_ESCALATIONS_ONEDASHBOARD.rows) {
							var aRows = [];
							data.queryResults.CL_CUST_TBE_ESCALATIONS_ONEDASHBOARD.rows.forEach(function (object) {
								var from = new Date(object.ESC_Created_At.title);
								var to = null;
								var bOngoing = false;
								if (object.ESC_Closed_At.title && object.ESC_Closed_At.title !== "") {
									to = new Date(object.ESC_Closed_At.title);
								} else {
									to = new Date();
									bOngoing = true;
								}
								// If the duration is to short to show properly in the Gantt, add 6 hours to "from" for gantt and save the real "to" into var
								if ((to - from) / (1000 * 60 * 60) < 12) {
									var realTo = to;
									to = new Date(from.getTime() + (12 * 60 * 60 * 1000));
								}

								var durationInHours;
								if (object.Duration_of_Business_elapsed_time_In_Hour_.value <= 0.01 || object.Duration_of_Business_elapsed_time_In_Hour_
									.value ===
									null) {
									durationInHours = object.Duration_of_Business_elapsed_time_In_Day_.value * 24;
								} else {
									durationInHours = object.Duration_of_Business_elapsed_time_In_Hour_.value;
								}
								var durationString = formatter.formatDurationToDaysHoursMinutes(durationInHours);

								var oCase = {
									id: object.Escalation_Number.title,
									from: from,
									to: to,
									realTo: realTo,
									ongoing: bOngoing,
									status: object.State.title,
									product: object.Product_Version.title,
									type: object.Escalation_Type.title,
									slaDefs: [{
										title: object.SLA_definition.title,
										duration: durationString
									}]
								};

								//CHECK IF ESC NUMBER ALREADY EXISTS
								var existingRow = aRows.find(function (row) {
									return row.cases.some(function (c) {
										return c.id === object.Escalation_Number.title;
									});
								});

								if (existingRow) {
									var existingCase = existingRow.cases.find(function (c) {
										return c.id === object.Escalation_Number.title;
									});

									// check if SLA_definition already exists for the case
									var existingSLADef = existingCase.slaDefs.find(function (def) {
										return def.title === object.SLA_definition.title;
									});

									if (existingSLADef) {
										// SLA_definition already exists, add duration to it
										existingSLADef.duration = durationString;
									} else {
										// add new SLA_definition to the case
										existingCase.slaDefs.push({
											title: object.SLA_definition.title,
											duration: durationString
										});
									}
								} else {

									if (aRows.length === 0) {
										aRows.push({
											description: "",
											type: object.Escalation_Type.title,
											cases: [oCase]
										});
									} else {
										var bRowAdded = false;
										var bSameType = false;
										aRows.forEach(function (row) {
											//now check all rows where we can add the case.
											if (row.type == oCase.type) {
												bSameType = true;
												var bSameTime = row.cases.some(function (r) {
													return this.dateRangeOverlaps(from, to, r.from, r.to);
												}.bind(this));

												if (!bSameTime && !bRowAdded) {
													bRowAdded = true;
													row.cases.push(oCase);
													return;
												}
											}
										}.bind(this));

										if (!bRowAdded) {
											aRows.push({
												description: "",
												type: object.Escalation_Type.title,
												cases: [oCase]
											});
										}
									}
								}
							}.bind(this));
							aRows = this._addCounterToType(aRows);
							resolve(aRows);
						} else {
							resolve([]);
						}
					}.bind(this));
				}
			}.bind(this));
		},

		_readCustomerHistoryCIM: function (sErpCust) {
			return new Promise(function (resolve, reject) {
				//set date filters
				var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd" // we need a format like 2022-12-24
				});
				var ganttStartDate = oFormat.format(this._getGanttStartDate());

				if (DebugMode) {
					//DEBUG
					var sPath = jQuery.sap.getModulePath("com.sap.mcconedashboard", "/json/CustomerHistory/CIM.json");
					$.ajax(sPath).always(function (data, stextStatus, errorThrown) {
						if (data.queryResults.CL_CUST_CIM_ESCALATIONS_ONEDASHBOARD.rows) {
							var aRows = [];
							data.queryResults.CL_CUST_CIM_ESCALATIONS_ONEDASHBOARD.rows.forEach(function (object) {
								var from = new Date(object.Escalation_Created_Date_Date_.title);
								var to = null;
								var bOngoing = false;
								if (object.Escalation_Closed_Date_Date_.title && object.Escalation_Closed_Date_Date_.title !== "") {
									to = new Date(object.Escalation_Closed_Date_Date_.title);
								} else {
									to = new Date();
									bOngoing = true;
								}
								// If the duration is to short to show properly in the Gantt, add 6 hours to "from" for gantt and save the real "to" into var
								if ((to - from) / (1000 * 60 * 60) < 12) {
									var realTo = to;
									to = new Date(from.getTime() + (12 * 60 * 60 * 1000));
								}

								var oCase = {
									id: object.Escalation_Number.title,
									from: from,
									to: to,
									realTo: realTo,
									ongoing: bOngoing,
									status: object.Escalation_Status.title,
									product: object.Product_Version_Text.title,
									type: object.Escalation_Type.title
								};

								if (aRows.length === 0) {
									aRows.push({
										description: "",
										type: object.Escalation_Type.title,
										cases: [oCase]
									});
								} else {
									var bRowAdded = false;
									var bSameType = false;
									aRows.forEach(function (row) {
										//now check all rows where we can add the case.
										if (row.type == oCase.type) {
											bSameType = true;
											var bSameTime = row.cases.some(function (r) {
												return this.dateRangeOverlaps(from, to, r.from, r.to);
											}.bind(this));

											if (!bSameTime && !bRowAdded) {
												bRowAdded = true;
												row.cases.push(oCase);
												return;
											}
										}
									}.bind(this));

									if (!bRowAdded) {
										aRows.push({
											description: "",
											type: object.Escalation_Type.title,
											cases: [oCase]
										});
									}
								}
							}.bind(this));
							aRows = this._addCounterToType(aRows);
							resolve(aRows);
						} else {
							resolve([]);
						}
					}.bind(this));
				} else {

					//PROD NEW
					$.ajax({
						method: "POST",
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
						data: JSON.stringify([{
							"queryIdentifier": "CL_CUST_CIM_ESCALATIONS_ONEDASHBOARD",
							"filters": [{

								"filters": [{
									"operand1": {
										"elementIdentifier": "Customer_ID"
									},
									"operand2": {
										"values": [sErpCust]
									},
									"operator": "EQ"
								},

								{
									"filters": [{
										"operand1": {
											"elementIdentifier": "Escalation_Closed_Date_Date_"
										},
										"operator": "GE",
										"operand2": {
											"values": [ganttStartDate]
										}
									}, {
										"operand1": {
											"elementIdentifier": "Escalation_Status"
										},
										"operator": "NOT_IN",
										"operand2": {
											"values": ["Closed", "Declined"]
										}
									}],
									"conjunctionOperator": "OR"
								}
								],

								"conjunctionOperator": "AND"
							}],
							"skip": 0
							//	"top": 10
						}]),
						contentType: "application/json"
					}).fail(function (data, textStatus, errorThrown) {
						if (data && data.responseJSON && data.responseJSON.message === "Not authorized on remote system: BW / DEV") {
							if (!errorShown) {
								var sText = "You are missing authorization. Please request profile auth.cust::REPORTER";
								errorShown = true;
								MessageBox.error(sText, {
									title: "Missing Authorization",
									actions: ["Request Authorization", MessageBox.Action.CLOSE],
									emphasizedAction: "Request Authorization",
									onClose: function (sAction) {
										if (sAction == "Request Authorization") {
											var win = window.open("https://" +
												"sapit-home-prod-004.launchpad.cfapps.eu10.hana.ondemand.com/site#arm-Create&/createRequest/prefilled?system=BWP_HDB&mandant=001&role=auth.cust::REPORTER",
												"_blank");
											win.opener = null;
											win.focus();
										}
									}
								});
							}
						}
						resolve([]);

					}).done(function (data, textStatus, xhr) {
						if (data.queryResults.CL_CUST_CIM_ESCALATIONS_ONEDASHBOARD.rows) {
							var aRows = [];
							data.queryResults.CL_CUST_CIM_ESCALATIONS_ONEDASHBOARD.rows.forEach(function (object) {
								var from = new Date(object.Escalation_Created_Date_Date_.title);
								var to = null;
								var bOngoing = false;
								if (object.Escalation_Closed_Date_Date_.title && object.Escalation_Closed_Date_Date_.title !== "") {
									to = new Date(object.Escalation_Closed_Date_Date_.title);
								} else {
									to = new Date();
									bOngoing = true;
								}
								// If the duration is to short to show properly in the Gantt, add 6 hours to "from" for gantt and save the real "to" into var
								if ((to - from) / (1000 * 60 * 60) < 12) {
									var realTo = to;
									to = new Date(from.getTime() + (12 * 60 * 60 * 1000));
								}

								var oCase = {
									id: object.Escalation_Number.title,
									from: from,
									to: to,
									realTo: realTo,
									ongoing: bOngoing,
									status: object.Escalation_Status.title,
									product: object.Product_Version_Text.title,
									type: object.Escalation_Type.title
								};

								if (aRows.length === 0) {
									aRows.push({
										description: "",
										type: object.Escalation_Type.title,
										cases: [oCase]
									});
								} else {
									var bRowAdded = false;
									var bSameType = false;
									aRows.forEach(function (row) {
										//now check all rows where we can add the case.
										if (row.type == oCase.type) {
											bSameType = true;
											var bSameTime = row.cases.some(function (r) {
												return this.dateRangeOverlaps(from, to, r.from, r.to);
											}.bind(this));

											if (!bSameTime && !bRowAdded) {
												bRowAdded = true;
												row.cases.push(oCase);
												return;
											}
										}
									}.bind(this));

									if (!bRowAdded) {
										aRows.push({
											description: "",
											type: object.Escalation_Type.title,
											cases: [oCase]
										});
									}
								}
							}.bind(this));
							aRows = this._addCounterToType(aRows);
							resolve(aRows);
						} else {
							resolve([]);
						}
					}.bind(this));
				}
			}.bind(this));
		},

		//PROD OLD
		/*var sPath = jQuery.sap.getModulePath("com.sap.mcconedashboard", "/json/CustomerHistory/CIM.json");
				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([{
						"queryIdentifier": "CL_CUST_CIM_ESCALATIONS_ONEDASHBOARD",
						"filters": [{
							"filters": [{
								"operand1": {
									"elementIdentifier": "Customer_ID"
								},
								"operand2": {
									"values": [sErpCust]
								},
								"operator": "EQ"
							}, {
								"operand1": {
									"elementIdentifier": "Escalation_Created_Date_Date_"
								},
								"operand2": {
									"values": [ganttStartDate]
								},
								"operator": "GE"
							}],
							"conjunctionOperator": "AND"
						}],
						"skip": 0
							//	"top": 10
					}]),
					contentType: "application/json"
				}).always(function (data, stextStatus, errorThrown) {
					if (data.queryResults.CL_CUST_CIM_ESCALATIONS_ONEDASHBOARD.rows) {
						var aRows = [];
						data.queryResults.CL_CUST_CIM_ESCALATIONS_ONEDASHBOARD.rows.forEach(function (object) {
							var from = new Date(object.Escalation_Created_Date_Date_.title);
							var to = null;
							var bOngoing = false;
							if (object.Escalation_Closed_Date_Date_.title && object.Escalation_Closed_Date_Date_.title !== "") {
								to = new Date(object.Escalation_Closed_Date_Date_.title);
							} else {
								to = new Date();
								bOngoing = true;
							}

							var oCase = {
								id: object.Escalation_Number.title,
								from: from,
								to: to,
								ongoing: bOngoing,
								status: object.Escalation_Status.title,
								product: object.Product_Version_Text.title
							};

							if (aRows.length === 0) {
								aRows.push({
									description: "",
									type: object.Escalation_Type.title,
									cases: [oCase]
								});
							} else {
								var bRowAdded = false;
								aRows.forEach(function (row) {
									//now check all rows where we can add the case.
									var bSameTime = row.cases.some(function (r) {
										return this.dateRangeOverlaps(from, to, r.from, r.to);
									}.bind(this));

									if (!bSameTime && !bRowAdded) {
										bRowAdded = true;
										row.cases.push(oCase);
										return;
									}
								}.bind(this));
								if (!bRowAdded) {
									aRows.push({
										description: "",
										type: object.Escalation_Type.title,
										cases: [oCase]
									});
								}
							}
						}.bind(this));
						aRows = this._addCounterToType(aRows);
						resolve(aRows);
					} else {
						resolve([]);
					}
				}.bind(this));
			}.bind(this));
		},*/

		_readCustomerHistoryEngagementCases: function (sErpCust) {
			return new Promise(function (resolve, reject) {

				//set date filters
				var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd" // we need a format like 2022-12-24
				});
				var ganttStartDate = oFormat.format(this._getGanttStartDate());

				//DEBUG
				if (DebugMode) {
					var sPath = jQuery.sap.getModulePath("com.sap.mcconedashboard", "/json/CustomerHistory/EngagementCases.json");
					$.ajax(sPath).always(function (data, stextStatus, errorThrown) {

						if (data.queryResults.CL_ENG_CASES_ONEDASHBOARD.rows) {
							// REMOVE GSS Cases
							var filteredRows = data.queryResults.CL_ENG_CASES_ONEDASHBOARD.rows.filter(function (object) {
								return object.Overview_Customer_Type.key !== "ZSCUSTYP01" && object.Overview_Customer_Type.key !== "ZSCUSTYP02";
							});

							var aRows = [];
							//data.queryResults.CL_ENG_CASES_ONEDASHBOARD.rows.forEach(function (object) {
							filteredRows.forEach(function (object) {
								var from = null;
								var to = null;
								var bOngoing = false;
								if (object.Creation_Date_Day_YYYYMMDD.title && object.Creation_Date_Day_YYYYMMDD.title !== "") {
									from = new Date(object.Creation_Date_Day_YYYYMMDD.title.substring(0, 4) + "-" + object.Creation_Date_Day_YYYYMMDD.title
										.substring(
											4, 6) + "-" + object.Creation_Date_Day_YYYYMMDD.title.substring(6, 8));
								}

								if (object.Closing_Date_Day_YYYYMMDD.title && object.Closing_Date_Day_YYYYMMDD.title !== "") {
									to = new Date(object.Closing_Date_Day_YYYYMMDD.title.substring(0, 4) + "-" + object.Closing_Date_Day_YYYYMMDD.title
										.substring(
											4, 6) + "-" + object.Closing_Date_Day_YYYYMMDD.title.substring(6, 8));
								} else {
									to = new Date();
									bOngoing = true;
								}
								// If the duration is to short to show properly in the Gantt, add 6 hours to "from" for gantt and save the real "to" into var
								if ((to - from) / (1000 * 60 * 60) < 12) {
									var realTo = to;
									to = new Date(from.getTime() + (12 * 60 * 60 * 1000));
								}

								var oCase = {
									id: object.Case_ID.title,
									from: from,
									to: to,
									realTo: realTo,
									ongoing: bOngoing,
									status: object.Case_Status.title,
									product: object.PPMS_Product_Name.title,
									type: object.Overview_Customer_Type.title
								};

								if (aRows.length === 0) {
									aRows.push({
										description: "",
										type: object.Overview_Customer_Type.title,
										cases: [oCase]
									});
								} else {
									var bRowAdded = false;
									var bSameType = false;
									aRows.forEach(function (row) {
										//now check all rows where we can add the case.
										if (row.type == oCase.type) {
											bSameType = true;
											var bSameTime = row.cases.some(function (r) {
												return this.dateRangeOverlaps(from, to, r.from, r.to);
											}.bind(this));

											if (!bSameTime && !bRowAdded && bSameType) {
												bRowAdded = true;
												row.cases.push(oCase);
												return;
											} else if (bSameTime && !bRowAdded && bSameType) {
												// Create new row with same type and add case to that row
												aRows.push({
													description: "",
													type: oCase.type,
													cases: [oCase]
												});
												bRowAdded = true;
												return;
											}
										}
									}.bind(this));

									if (!bRowAdded) {
										aRows.push({
											description: "",
											type: object.Overview_Customer_Type.title,
											cases: [oCase]
										});
									}
								}
							}.bind(this));
							aRows = this._addCounterToType(aRows);
							resolve(aRows);
						} else {
							resolve([]);
						}
					}.bind(this));
				} else {

					//PROD NEW FILTER WITH CLOSING DATE

					$.ajax({
						method: "POST",
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
						data: JSON.stringify([{
							"queryIdentifier": "CL_ENG_CASES_ONEDASHBOARD",
							"filters": [{
								"filters": [{
									"operand1": {
										"elementIdentifier": "Customer_ERP_Account"
									},
									"operand2": {
										"values": [sErpCust]
									},
									"operator": "EQ"
								}],
								"conjunctionOperator": "AND"
							}, {
								"filters": [{
									"operand1": {
										"elementIdentifier": "Closing_Date_Day_YYYYMMDD"
									},
									"operator": "GE",
									"operand2": {
										"values": [ganttStartDate]
									}
								}, {
									"operand1": {
										"elementIdentifier": "Case_Status"
									},
									"operator": "NE",
									"operand2": {
										"values": ["90"]
									}
								}],
								"conjunctionOperator": "OR"
							}],
							"skip": 0
						}]),
						contentType: "application/json"
					}).fail(function (data, textStatus, errorThrown) {
						if (data && data.responseJSON && data.responseJSON.message === "Not authorized on remote system: BW / DEV") {
							var sText = "You are missing authorization. Please request profile 0000_BWP_CASE_ENGAGEMENT";
							MessageBox.error(sText, {
								title: "Missing Authorization",
								actions: ["Request Authorization", MessageBox.Action.CLOSE],
								emphasizedAction: "Request Authorization",
								onClose: function (sAction) {
									if (sAction == "Request Authorization") {
										var win = window.open("https://" +
											"sapit-home-prod-004.launchpad.cfapps.eu10.hana.ondemand.com/site#arm-Create&/createRequest/prefilled?system=BWP&mandant=001&role=0000_BWP_CASE_ENGAGEMENT",
											"_blank");
										win.opener = null;
										win.focus();
									}
									resolve([]);
								}
							});
						} else {
							resolve([]);
						}
					}).done(function (data, stextStatus, errorThrown) {
						if (data.queryResults.CL_ENG_CASES_ONEDASHBOARD.rows) {

							// REMOVE GSS Cases
							var filteredRows = data.queryResults.CL_ENG_CASES_ONEDASHBOARD.rows.filter(function (object) {
								return object.Overview_Customer_Type.key !== "ZSCUSTYP01" && object.Overview_Customer_Type.key !== "ZSCUSTYP02";
							});


							var aRows = [];
							//data.queryResults.CL_ENG_CASES_ONEDASHBOARD.rows.forEach(function (object) {
							filteredRows.forEach(function (object) {
								var from = null;
								var to = null;
								var bOngoing = false;
								if (object.Creation_Date_Day_YYYYMMDD.title && object.Creation_Date_Day_YYYYMMDD.title !== "") {
									from = new Date(object.Creation_Date_Day_YYYYMMDD.title.substring(0, 4) + "-" + object.Creation_Date_Day_YYYYMMDD.title
										.substring(
											4, 6) + "-" + object.Creation_Date_Day_YYYYMMDD.title.substring(6, 8));
								}

								if (object.Closing_Date_Day_YYYYMMDD.title && object.Closing_Date_Day_YYYYMMDD.title !== "") {
									to = new Date(object.Closing_Date_Day_YYYYMMDD.title.substring(0, 4) + "-" + object.Closing_Date_Day_YYYYMMDD.title.substring(
										4, 6) + "-" + object.Closing_Date_Day_YYYYMMDD.title.substring(6, 8));
								} else {
									to = new Date();
									bOngoing = true;
								}
								// If the duration is to short to show properly in the Gantt, add 6 hours to "from" for gantt and save the real "to" into var
								if ((to - from) / (1000 * 60 * 60) < 12) {
									var realTo = to;
									to = new Date(from.getTime() + (12 * 60 * 60 * 1000));
								}

								var oCase = {
									id: object.Case_ID.title,
									from: from,
									to: to,
									realTo: realTo,
									ongoing: bOngoing,
									status: object.Case_Status.title,
									product: object.PPMS_Product_Name.title,
									type: object.Overview_Customer_Type.title
								};

								if (aRows.length === 0) {
									aRows.push({
										description: "",
										type: object.Overview_Customer_Type.title,
										cases: [oCase]
									});
								} else {
									var bRowAdded = false;
									var bSameType = false;
									aRows.forEach(function (row) {
										//now check all rows where we can add the case.
										if (row.type == oCase.type) {
											bSameType = true;
											var bSameTime = row.cases.some(function (r) {
												return this.dateRangeOverlaps(from, to, r.from, r.to);
											}.bind(this));

											if (!bSameTime && !bRowAdded) {
												bRowAdded = true;
												row.cases.push(oCase);
												return;
											}
										}
									}.bind(this));

									if (!bRowAdded) {
										aRows.push({
											description: "",
											type: object.Overview_Customer_Type.title,
											cases: [oCase]
										});
									}
								}
							}.bind(this));
							aRows = this._addCounterToType(aRows);
							resolve(aRows);
						} else {
							resolve([]);
						}
					}.bind(this));
				}
			}.bind(this));
		},

		//PROD OLD
		/*var sPath = jQuery.sap.getModulePath("com.sap.mcconedashboard", "/json/CustomerHistory/EngagementCases.json");
				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([{
						"queryIdentifier": "CL_ENG_CASES_ONEDASHBOARD",
						"filters": [{
							"filters": [{
								"operand1": {
									"elementIdentifier": "Customer_ERP_Account"
								},
								"operand2": {
									"values": [sErpCust]
								},
								"operator": "EQ"
							}, {
								"operand1": {
									"elementIdentifier": "Creation_Date_Day_YYYYMMDD"
								},
								"operand2": {
									"values": [ganttStartDate]
								},
								"operator": "GE"
							}],
							"conjunctionOperator": "AND"
						}],
						"skip": 0
							//	"top": 10
					}]),
					contentType: "application/json"
				}).always(function (data, stextStatus, errorThrown) {
					if (data.queryResults.CL_ENG_CASES_ONEDASHBOARD.rows) {
						var aRows = [];
						data.queryResults.CL_ENG_CASES_ONEDASHBOARD.rows.forEach(function (object) {
							var from = null;
							var to = null;
							var bOngoing = false;
							if (object.Creation_Date_Day_YYYYMMDD.title && object.Creation_Date_Day_YYYYMMDD.title !== "") {
								from = new Date(object.Creation_Date_Day_YYYYMMDD.title.substring(0, 4) + "-" + object.Creation_Date_Day_YYYYMMDD.title.substring(
									4, 6) + "-" + object.Creation_Date_Day_YYYYMMDD.title.substring(6, 8));
							}

							if (object.Closing_Date_Day_YYYYMMDD.title && object.Closing_Date_Day_YYYYMMDD.title !== "") {
								to = new Date(object.Closing_Date_Day_YYYYMMDD.title.substring(0, 4) + "-" + object.Closing_Date_Day_YYYYMMDD.title.substring(
									4, 6) + "-" + object.Closing_Date_Day_YYYYMMDD.title.substring(6, 8));
							} else {
								to = new Date();
								bOngoing = true;
							}

							var oCase = {
								id: object.Case_ID.title,
								from: from,
								to: to,
								ongoing: bOngoing,
								status: object.Case_Status.title,
								product: object.PPMS_Product_Name.title
							};

							if (aRows.length === 0) {
								aRows.push({
									description: "",
									type: object.Overview_Customer_Type.title,
									cases: [oCase]
								});
							} else {
								var bRowAdded = false;
								aRows.forEach(function (row) {
									//now check all rows where we can add the case.
									var bSameTime = row.cases.some(function (r) {
										return this.dateRangeOverlaps(from, to, r.from, r.to);
									}.bind(this));

									if (!bSameTime && !bRowAdded) {
										bRowAdded = true;
										row.cases.push(oCase);
										return;
									}
								}.bind(this));
								if (!bRowAdded) {
									aRows.push({
										description: "",
										type: object.Overview_Customer_Type.title,
										cases: [oCase]
									});
								}
							}
						}.bind(this));
						aRows = this._addCounterToType(aRows);
						resolve(aRows);
					} else {
						resolve([]);
					}
				}.bind(this));
			}.bind(this));
		},*/

		_readCustomerHistoryCompleted: function (aData) {
			var oModel = new JSONModel();
			var oStructure = {
				"root": {
					"children": []
				}
			};

			// create an empty object to store nodes for each type
			var typeNodes = {};

			// loop through all data objects and add them to corresponding type nodes
			aData.forEach(function (d) {
				var type = d.type;
				if (!typeNodes[type]) {
					// create a new node for the type if it doesn't exist
					typeNodes[type] = {
						description: type,
						children: []
					};
				}
				// add the data object to the children array of the type node
				typeNodes[type].children.push(d);
			});

			// add all type nodes to the root node of the oStructure object
			for (var type in typeNodes) {
				oStructure.root.children.push(typeNodes[type]);
			}

			//Sort Order to be shown in the GanttChartTable
			var sortOrder = ['Global Escalation Management', 'Top Critical Customer', 'Technical Backoffice Engagement',
				'MCC Critical Customer Management',
				'MCC Critical Period Coverage', 'Critical Incident Management', 'MCC Guided Solution Support Active',
				'MCC Guided Solution Support Completed', 'Cross Issues'
			];

			oStructure.root.children.sort(function (a, b) {
				return sortOrder.indexOf(a.description) - sortOrder.indexOf(b.description);
			});

			oModel.setData(oStructure);
			this.getView().setModel(oModel, "customerHistory");
			//turn off busyindicator
			this.getView().byId("gantt").setBusy(false);
		},

		onGanttShapePress: function (oEv) {
			var oShape = oEv.getParameter("shape");
			if (oShape) {
				var oData = oShape.getBindingContext("customerHistory").getObject();
				var slaContent = this.getSlaContent(oData);
				var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MMM dd, yyyy HH:mm z"
				});

				var that = this;
				var oPopover = new sap.m.ResponsivePopover({
					showHeader: false,
					showCloseButton: false,
					placement: "Auto",
					content: new sap.ui.layout.form.SimpleForm({
						layout: "ResponsiveGridLayout",
						editable: false,
						title: oData.type,
						content: [
							new sap.m.Label({
								text: "ID"
							}),
							new sap.m.Link({
								text: oData.id,
								press: function () {
									if(oData.type.includes("Cross Issues")) {
										that._openCrossIssueInNewTab(oData.id);
									} else if(oData.type.includes("MCC Critical Period Coverage")) {
										that._openCaseInNewTab(oData.id);
									} else if(oData.type.includes("Critical Incident Management")) {
										var win = window.open("https://" + "itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + oData.id, "_blank");
										win.opener = null;
										win.focus();
									} else if(oData.type.includes("Technical Backoffice Engagement")) {
										var win = window.open("https://" + "itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + oData.id, "_blank");
										win.opener = null;
										win.focus();
									} else if(oData.type.includes("Global Escalation Management")) {
										that._openCaseInNewTab(oData.id);
									} else if(oData.type.includes("MCC Guided Solution Support Active")) {
										that._openCaseInNewTab(oData.id);

									} else if(oData.type.includes("MCC Guided Solution Support Completed")) {
										that._openCaseInNewTab(oData.id);

									} else if(oData.type.includes("MCC Critical Customer Management")) {
										that._openCaseInNewTab(oData.id);
									} else if(oData.type.includes("Top Critical Customer")) {
										that._openCaseInNewTab(oData.id);
									}
								}
							}),
							/*	new sap.m.Label({
									text: "Type"
								}),
								new sap.m.Text({
									text: oData.type
								}), */
							new sap.m.Label({
								text: "Start date"
							}),
							new sap.m.Text({
								text: oFormat.format(oData.from)
							}),
							new sap.m.Label({
								text: "End date",
								visible: !oData.ongoing
							}),
							new sap.m.Text({
								text: oFormat.format(oData.realTo !== undefined && oData.realTo !== null ? oData.realTo : oData.to), //use realTo if there is one defined
								visible: !oData.ongoing
							}),
							new sap.m.Label({
								text: "Status"
							}),
							new sap.m.Text({
								text: oData.status
							}),
							new sap.m.Label({
								text: "Product",
								visible: oData.product !== "" && oData.product !== null
							}),
							new sap.m.Text({
								text: oData.product,
								visible: oData.product !== "" && oData.product !== null
							})
						].concat(slaContent)
					})
				}).addStyleClass("sapUiContentPadding");
				oPopover.openBy(oShape);
			}
		},

		getSlaContent: function (oData) {
			var slaTitles = ["ZBDM_SITUATION", "PE Critical SLA", "Golive Endangered SLA", "xTec SLA"]; //SLA Titles that should be shown in Popover
			var slaContent = [];
			if (oData.type === "Technical Backoffice Engagement" && oData.slaDefs && oData.slaDefs.length > 0) {
				slaContent = oData.slaDefs.filter(function (sla) {
					return slaTitles.indexOf(sla.title) > -1;
				}).map(function (sla) {
					switch (sla.title) {
						case "ZBDM_SITUATION":
							sla.titlePopover = "Business Down Duration";
							break;
						case "PE Critical SLA":
							sla.titlePopover = "PE-Critical Engagement Duration";
							break;
						case "Golive Endangered SLA":
							sla.titlePopover = "Go-Live Endangered Engagement Duration";
							break;
						case "xTec SLA":
							sla.titlePopover = "xTec Engagement Duration";
							break;
					}
					return [
						new sap.m.Label({
							text: sla.titlePopover
						}),
						new sap.m.Text({
							text: sla.duration
						})
					];
				}).filter(function (sla) {
					return sla[1].getText() !== "0 minute";
				});
			}
			return slaContent;
		},

		_getGanttStartDate: function () {
			return new Date(new Date(new Date().setMonth(new Date().getMonth() - 6)).setDate(1));
		},

		_getGanttEndDate: function () {
			return new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);
		},

		// read the information for MCCi and Prevention Score from C4S System
		// for the header information we also need to show trends
		readMissionRadarValuesOld: function (oModel) {
			//only if the flag is set, the data should be read
			//UPDATE 01.11.2023 - Always active
			//if (this.getModel("settings").getProperty("/showMissionRadar")) {
			var aData = oModel.getData();
			var that = this;

			//json model for mission radar trend values micro chart
			var oMicroChartConfiguration = {
				"threshold": 0,
				"showThresholdValue": true,
				"thresholdDisplayValue": "0",
				"showThresholdLine": true,
				"showPoints": true
			};
			var oMissionRadarTrendValuesModel = new sap.ui.model.json.JSONModel(oMicroChartConfiguration);
			this.getOwnerComponent().setModel(oMissionRadarTrendValuesModel, "missionRadar");

			//MISSIONRADAR 2211
			// we need to loop throught all shown engagements, because there could be different customers involved
			//for the C4S call we need to add the leading zeros
			var aEngagementListErpNumbers = [that.pad(aData.ErpCustNo, 10)];
			aData["CustomerOverview"].forEach(function (c) {
				if (!aEngagementListErpNumbers.includes(that.pad(c.CustomerNo, 10)) && c.CustomerNo !== "") {
					aEngagementListErpNumbers.push(that.pad(c.CustomerNo, 10));
				}
			}.bind(this));
			//we need submit todays date in format "2022-09-23" to get the current values
			var today = new Date();
			//var today = new Date("2022-10-28");
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd" // we need a format like 2022-12-24
			});
			today = oFormat.format(today);
			//we need to read the data of the last 14 days (we have to go back 13 days, because today also counts)
			var dateOffset = (24 * 60 * 60 * 1000) * 13;
			var dateInPast = new Date();
			//var dateInPast = new Date("2022-10-28");
			dateInPast.setTime(dateInPast.getTime() - dateOffset);
			dateInPast = oFormat.format(dateInPast);

			if (aEngagementListErpNumbers.length > 0) {
				//Read data for the list view
				//	$.ajax("./json/ExampleC4SCustomerView.json", { // only for testing - load the data from a relative URL (the Data.json file in the same directory)
				//	as soon as we are able to test in the test environment we need to use the following call

				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([{
						"queryIdentifier": "CL_MCCI_CRM_NOW",
						"elementList": [
							"Customer_Text", "PREVENTION_SCORE", "MCCI", "ERP_Account", "SNAPSHOT_DATE", "Trend"
						],
						"sortSteps": [{
							"elementIdentifier": "SNAPSHOT_DATE",
							"direction": "DESC"
						}],
						"filters": [{
							"filters": [{
								"operand1": {
									"elementIdentifier": "ERP_Account"
								},
								"operand2": {
									"values": aEngagementListErpNumbers
								},
								"operator": "EQ"
							}, {
								"operand1": {
									"elementIdentifier": "SNAPSHOT_DATE"
								},
								"operand2": {
									"values": [dateInPast]
								},
								"operator": "GE"
							}],
							"conjunctionOperator": "AND"
						}],
						"skip": 0
						//	"top": 10
					}]),
					contentType: "application/json"
				}).always(function (data, stextStatus, errorThrown) {
					if (data.queryResults && data.queryResults.CL_MCCI_CRM_NOW && data.queryResults.CL_MCCI_CRM_NOW.rows.length > 0) {
						//that.getView().getModel("viewModel").setProperty("/missionRadarValuesVisible", true);
						var sHighestMCCi = parseFloat("0"),
							sLowestPreventionScore = parseFloat("100");
						aData["CustomerOverview"].forEach(function (oDataElement) {
							var oCase = data.queryResults.CL_MCCI_CRM_NOW.rows.filter(function (val) {
								return val.ERP_Account.key === that.pad(oDataElement.CustomerNo, 10);
							});
							// we should get the first entry only, if it is from today, otherwise it would be older data, because we are reading the last 14 days
							//therefore it could also be, that there is no data for specific customers, because they have no ongoing cases in the relevant timeframes for Mission Control values
							if (oCase && oCase.length >= 1 && (oCase[0].SNAPSHOT_DATE.key === today)) {
								oDataElement.MCCi = Math.round(oCase[0].MCCI.value).toString();
								oDataElement.Trend = Math.round(oCase[0].Trend.value).toString();
								oDataElement.PreventionScore = Math.round(oCase[0].PREVENTION_SCORE.value).toString();
								// if (parseFloat(oDataElement.MCCi) > parseFloat(sHighestMCCi)) {
								// 	sHighestMCCi = oDataElement.MCCi;
								// }
								// if (parseFloat(oDataElement.PreventionScore) < parseFloat(sLowestPreventionScore)) {
								// 	sLowestPreventionScore = oDataElement.PreventionScore;
								// }
							}
						});

						//read data shown in the header
						//MCCI- if current customer is a GU, then take the highest current value from all customer; if not, then just read the customers current value
						//Prevention Score - if the current customer is a GU, then take the lowest current value from all customers; if not, then just read the customers current value

						var aPointsMCCiLine = [],
							aPointsPreventionScoreLine = [],
							sLeftTopLabel = "",
							sRightTopLabel = "",
							sLeftBottomLabel = "",
							sRightBottomLabel = "",
							noDataCounter = 0;

						for (var i = 0; i < 14; i++) {
							//we need to loop through the results per day, because we need to get the highest/lowest values per day (in case of GU it could also be one of the child values)
							var dateOffset = (24 * 60 * 60 * 1000) * i;
							var dateInPast = new Date();
							//var dateInPast = new Date("2022-10-28");
							dateInPast.setTime(dateInPast.getTime() - dateOffset);
							dateInPast = oFormat.format(dateInPast);
							var sTempHighestMCCi = parseFloat("0"),
								aTempHighestTrend,
								sTempLowestPreventionScore = parseFloat("100");

							// get all values for a specific date
							var aCases = data.queryResults.CL_MCCI_CRM_NOW.rows.filter(function (val) {
								return val.SNAPSHOT_DATE.key === dateInPast;
							});

							if (aCases && aCases.length >= 1) {
								aCases.forEach(function (oDataElement) {
									if (oDataElement.MCCI.value > parseFloat(sTempHighestMCCi)) {
										sTempHighestMCCi = oDataElement.MCCI.value;
									}
									if (!aTempHighestTrend || oDataElement.Trend.value > parseFloat(aTempHighestTrend)) {
										aTempHighestTrend = oDataElement.Trend.value;
									}

									if (oDataElement.PREVENTION_SCORE.value < parseFloat(sTempLowestPreventionScore)) {
										sTempLowestPreventionScore = oDataElement.PREVENTION_SCORE.value;
									}
								});

								aPointsMCCiLine.push({
									"x": 130 - (10 * i),
									"y": sTempHighestMCCi
								});
								aPointsPreventionScoreLine.push({
									"x": 130 - (10 * i),
									"y": sTempLowestPreventionScore
								});
								if (i === (0 + noDataCounter)) {
									sRightTopLabel = sTempHighestMCCi;
									sRightBottomLabel = sTempLowestPreventionScore;
								}
								//	if (i === 13) {
								//we don't need the index check here, because the current highest value, should always be overwritten by the next higher one
								sLeftTopLabel = sTempHighestMCCi;
								sLeftBottomLabel = sTempLowestPreventionScore;
								//	}
								//the first entry contains the current values and can therefore be set as the separate values above the trend chart
								if (dateInPast === today) {
									oModel.setProperty("/mcci", Math.round(sTempHighestMCCi));
									oModel.setProperty("/mcciColor", that.formatter._formatMcciColor(Math.round(sTempHighestMCCi)));
									oModel.setProperty("/trend", Math.round(aTempHighestTrend));
									oModel.setProperty("/preventionScore", Math.round(aTempHighestTrend));
									oModel.setProperty("/preventionScoreDesc", that.formatter._formatTrendDesc(Math.round(aTempHighestTrend)));
									oModel.setProperty("/preventionScoreColor", that.formatter._formatTrendColor(Math.round(aTempHighestTrend)));
									oModel.setProperty("/preventionScoreIcon", that.formatter._formatTrendIcon(Math.round(aTempHighestTrend)));
									that.getView().getModel("viewModel").setProperty("/missionRadarValuesVisible", true);
								}

							} else {
								noDataCounter++;
							}

						}
						oMissionRadarTrendValuesModel.setProperty("/leftTopLabel", "Criticality " + Math.round(sLeftTopLabel));
						oMissionRadarTrendValuesModel.setProperty("/rightTopLabel", Math.round(sRightTopLabel));
						oMissionRadarTrendValuesModel.setProperty("/leftBottomLabel", "Risk " + Math.round(sLeftBottomLabel));
						oMissionRadarTrendValuesModel.setProperty("/rightBottomLabel", Math.round(sRightBottomLabel));
						oMissionRadarTrendValuesModel.setProperty("/lines", [{
							points: aPointsMCCiLine
						}, {
							points: aPointsPreventionScoreLine
						}]);

						oModel.refresh();
					} else {
						that.getView().getModel("viewModel").setProperty("/missionRadarValuesVisible", false);
						// that.getView().byId("c4sErrorTest").setText("Response received: \n\nHTTP Status Code: " + n.status + "\n\n" + "Response Text: \n" +
						// 	JSON.stringify(e));
					}
				});
			}
			//}
		},

		readMissionRadarValues: function (oCustomerModel, bNoData) {
			var that = this;
			var sCustomerID = oCustomerModel.getData().ErpCustNo;
			var sCustomerIDWithZeros = this._addLeadingZeros(sCustomerID);
			//we need submit todays date in format "2022-09-23" to get the current values
			var today = new Date(); //("2022-10-28");
			var yesterday = new Date(today);
			yesterday.setDate(today.getDate() - 1); // Subtract 1 day from today's date
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd" // we need a format like 2022-12-24
			});
			today = oFormat.format(today);
			yesterday = oFormat.format(yesterday);
			var filterCondition;

			if (bNoData === true) {
				filterCondition = {
					operand1: { elementIdentifier: "SNAPSHOT_DATE" },
					operand2: { values: [yesterday] },
					operator: "EQ"
				};
			} else {
				filterCondition = {
					operand1: { elementIdentifier: "SNAPSHOT_DATE" },
					operand2: { values: [today] },
					operator: "EQ"
				};
			}

			var combinedFilter = {
				filters: [filterCondition]
			};

			var customerFilterCondition = {
				operand1: { elementIdentifier: "CUSTOMER_ID" },
				operand2: { values: [sCustomerIDWithZeros] },
				operator: "EQ"
			};

			combinedFilter.filters.push(customerFilterCondition);

			if (DebugMode == true) {

				//DEVELOPMENT
				$.ajax({
					url: "./json/CustomerView/CustomerMissionRadarValuesExample.json",
					type: "GET",
					dataType: "json",
					success: function (data) {
						var item = data.queryResults.CL_MCCI_V2_CURRENT.rows[0];
						item.preventionScoreDesc = that.formatter._formatTrendDesc(Math.round(item.TREND_28_DAYS.value));
						item.preventionScoreColor = that.formatter._formatTrendColor(Math.round(item.TREND_28_DAYS.value));
						item.preventionScoreIcon = that.formatter._formatTrendIcon(Math.round(item.TREND_28_DAYS.value));
						item.preventionScoreThreeDaysDesc = that.formatter._formatTrendDesc(Math.round(item.TREND_3_DAYS.value));
						item.preventionScoreThreeDaysColor = that.formatter._formatTrendColor(Math.round(item.TREND_3_DAYS.value));
						item.preventionScoreThreeDaysIcon = that.formatter._formatTrendIcon(Math.round(item.TREND_3_DAYS.value));

						oCustomerModel.setProperty("/mcci", Math.round(item.MCCI.value));
						oCustomerModel.setProperty("/mcciColor", that.formatter._formatMcciColor(Math.round(item.MCCI.value)));
						oCustomerModel.setProperty("/trend", Math.round(item.TREND_28_DAYS.value));
						oCustomerModel.setProperty("/preventionScoreDesc", item.preventionScoreDesc);
						oCustomerModel.setProperty("/preventionScoreColor", item.preventionScoreColor);
						oCustomerModel.setProperty("/preventionScoreIcon", item.preventionScoreThreeDaysIcon);
						that.getView().getModel("viewModel").setProperty("/missionRadarValuesVisible", true);

					},
					error: function (xhr, textStatus, errorThrown) {
						that.getView().getModel("viewModel").setProperty("/missionRadarValuesVisible", false);
					}
				});

			} else {

				//PROD
				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([
						{
							"queryIdentifier": "CL_MCCI_V2_CURRENT",
							"elementList": [
								"SNAPSHOT_DATE", "CUSTOMER_ID", "ERP_Account", "Global_Ultimate", "Internal_Sales_Segment", "Global_Ultimate_Name", "MCCI", "TREND_28_DAYS", "TREND_3_DAYS", "CCM_CASES", "CPC_CASES", "TF_CASES", "TC2_CASES", "GEM_CASES", "OPEN_NOW_P1", "OPEN_NOW_P2", "MCC_SOL_AREA", "MCC_SOL_AREA_RANK"
							],
							"filters": [combinedFilter],
							//"top": 9999,
							"skip": 0
						}]),
					contentType: "application/json",
					success: function (data) {
						if (data.queryResults.CL_MCCI_V2_CURRENT && data.queryResults.CL_MCCI_V2_CURRENT.rows.length > 0) {
							var item = data.queryResults.CL_MCCI_V2_CURRENT.rows[0];
							if (item.MCCI.value === 0 && (!bNoData || bNoData === false)) {
								that.readMissionRadarValues(oCustomerModel, true);
							} else {
								item.preventionScoreDesc = that.formatter._formatTrendDesc(Math.round(item.TREND_28_DAYS.value));
								item.preventionScoreColor = that.formatter._formatTrendColor(Math.round(item.TREND_28_DAYS.value));
								item.preventionScoreIcon = that.formatter._formatTrendIcon(Math.round(item.TREND_28_DAYS.value));
								item.preventionScoreThreeDaysDesc = that.formatter._formatTrendDesc(Math.round(item.TREND_3_DAYS.value));
								item.preventionScoreThreeDaysColor = that.formatter._formatTrendColor(Math.round(item.TREND_3_DAYS.value));
								item.preventionScoreThreeDaysIcon = that.formatter._formatTrendIcon(Math.round(item.TREND_3_DAYS.value));

								oCustomerModel.setProperty("/mcci", Math.round(item.MCCI.value));
								oCustomerModel.setProperty("/mcciColor", that.formatter._formatMcciColor(Math.round(item.MCCI.value)));
								oCustomerModel.setProperty("/trend", Math.round(item.TREND_28_DAYS.value));
								oCustomerModel.setProperty("/preventionScoreDesc", item.preventionScoreDesc);
								oCustomerModel.setProperty("/preventionScoreColor", item.preventionScoreColor);
								oCustomerModel.setProperty("/preventionScoreIcon", item.preventionScoreIcon);
								that.getView().getModel("viewModel").setProperty("/missionRadarValuesVisible", true);
							}
						} else if (!bNoData || bNoData === false) {
							//Try finding MCCI Values from yesterday if there is no entries for today
							that.readMissionRadarValues(oCustomerModel, true);
						} else {
							console.log("No MCCI Data for today and yesterday");
							that.getView().getModel("viewModel").setProperty("/missionRadarValuesVisible", false);
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						that.getView().getModel("viewModel").setProperty("/missionRadarValuesVisible", false);
					}
				});
			}
		},

		_readCustomerEngagementsProducts: function (oFilter, resolve) {
			var oModel = this.getModel();
			var aFilters = [];

			aFilters.push(oFilter);

			//all ongoing Critical Customer Management
			//Critical Period Coverage
			//Project Engagement Support/Guided Solution Support
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new Filter([
				new Filter([
					new Filter("Status", FilterOperator.EQ, "71"),
					new Filter("Status", FilterOperator.EQ, "80"),
					new Filter("Status", FilterOperator.EQ, "81"),
					new Filter("Status", FilterOperator.EQ, "99")
				], false),
				new Filter([
					new Filter("CustomerType", FilterOperator.EQ, "ZSCUSTYP04"),
					new Filter("CustomerType", FilterOperator.EQ, "ZSCUSTYP05")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			var oRatingSorter = new sap.ui.model.Sorter("Rating", true);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);
			aFilters.push(new Filter("Reason", FilterOperator.EQ, "ENGA"));
			oModel.read("/CustomerEngagementSet", {
				filters: aFilters,
				urlParameters: {
					"$top": "9999", //needed in order to get more than 1000 results back
					"$expand": "toProducts",
					"$select": "CaseId,CustomerType,toProducts,PriorityT"
				},
				sorters: [oRatingSorter, oChangeDateSorter],
				success: function (data) {
					//only append data to pie chart if it was filtered
					var aFilteredData = [];
					var oCustomerModel = this.getModel("customerModel");
					var aAlreadyAdded = oCustomerModel.getProperty("/CustomerOverview");

					//Critical Customer Management
					var criticalCustomerManagement = data.results.filter(function (val) {
						return val.CustomerType === "ZSCUSTYP05";
					});
					criticalCustomerManagement.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
						result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
						result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
						result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);

						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVer = result.ProductVer;
								aTmp[i].ProductLineKeys = result.ProductLineKeys;
								aTmp[i].ProductKeys = result.ProductKeys;
							});
						}
					}, this);
					aFilteredData = aFilteredData.concat(criticalCustomerManagement);

					//Critical Period Coverage
					var criticalPeriodCoverage = data.results.filter(function (val) {
						return val.CustomerType === "ZSCUSTYP04";
					});
					criticalPeriodCoverage.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
						result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
						result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");

						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVer = result.ProductVer;
								aTmp[i].ProductLineKeys = result.ProductLineKeys;
								aTmp[i].ProductKeys = result.ProductKeys;
							});
						}
					}, this);
					aFilteredData = aFilteredData.concat(criticalPeriodCoverage);

					//concat toProducts properties
					aFilteredData.forEach(function (result) {
						this._setPieModel(result.toProducts.results);
					}, this);

					oCustomerModel.refresh();
					resolve(data);
				}.bind(this),
				error: function (data) {
					this.getModel("customerModel").setProperty("/CriticalSituationsSetBusy", false);
					resolve("No data found");
				}.bind(this)
			});

		},

		_readCustomerEngagementsNotes: function (oControl, id, sObjectType) {
			var oModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oModel.read("/CustomerEngagementSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results, sObjectType);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});

		},

		_readCustomerVisits: function (oFilter) {
			var oModel = this.getModel();
			var aFilters = [];
			aFilters.push(oFilter);

			//Filter only TopIssues with status "New" (E0010), "In Process Backoffice" (E0011), "Responsible's Action" (E0012), "In MCC  Dep Rooms" (E0019), "In Process CIM" (E0020)
			var tileSpecificFilters = new Filter([
				new Filter([
					new Filter("StatusT", FilterOperator.EQ, "New"),
					new Filter("StatusT", FilterOperator.EQ, "In Process Backoffice"),
					new Filter("StatusT", FilterOperator.EQ, "In MCC Focus Teams")
				], false)
			],
				true
			);

			aFilters.push(tileSpecificFilters);
			aFilters.push(new Filter("Category", FilterOperator.EQ, "ZVM"));
			aFilters.push(new Filter("ProcessType", FilterOperator.EQ, "ZS46"));

			var oPrioritySorter = new sap.ui.model.Sorter("Priority", false);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);
			return new Promise(function (resolve, reject) {
				oModel.read("/MCCActivitiesSet", {
					filters: aFilters,
					urlParameters: {
						"$expand": "toProducts"
					},
					sorters: [oPrioritySorter, oChangeDateSorter],
					success: function (data) {
						data.results.forEach(function (result) {
							result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
							result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
							result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
							result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
							result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
							result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
							result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);
						}, this);

						this._convertDataForCustomerOverview("CustomerVisits", data.results);
						this.getModel("customerModel").setProperty("/AmountCustomerVisits", data.results.length);

						resolve(data);
					}.bind(this),
					error: function (data) {
						this.getModel("customerModel").setProperty("/MCCActivitiesSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));
		},

		_readMCCActivities: function (oFilter) {
			var oModel = this.getModel();
			var aFilters = [];
			aFilters.push(oFilter);

			//Filter only TopIssues with status "New" (E0010), "In Process Backoffice" (E0011), "Responsible's Action" (E0012), "In MCC  Dep Rooms" (E0019), "In Process CIM" (E0020)
			var tileSpecificFilters = new Filter([
				new Filter([
					new Filter("Status", FilterOperator.EQ, "E0010"),
					new Filter("Status", FilterOperator.EQ, "E0011"),
					new Filter("Status", FilterOperator.EQ, "E0012"),
					new Filter("Status", FilterOperator.EQ, "E0019"),
					new Filter("Status", FilterOperator.EQ, "E0027")
				], false)
			],
				true
			);
			var tileSpecificCategoryFilters = new Filter([
				new Filter([
					new Filter("Category", FilterOperator.EQ, "ZYO"),
					new Filter("Category", FilterOperator.EQ, "ZYP"),
					new Filter("Category", FilterOperator.EQ, "ZZM"),
					new Filter("Category", FilterOperator.EQ, "ZZD"),
					new Filter("Category", FilterOperator.EQ, "ZZR"),
					new Filter("Category", FilterOperator.EQ, "ZB2"),
					new Filter("Category", FilterOperator.EQ, "ZB9"),
					new Filter("Category", FilterOperator.EQ, "Z88"),
					new Filter("Category", FilterOperator.EQ, "Z91"),
					new Filter("Category", FilterOperator.EQ, "Z90"),
					new Filter("Category", FilterOperator.EQ, "Z93"),
					new Filter("Category", FilterOperator.EQ, "ZYT")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);
			aFilters.push(tileSpecificCategoryFilters);

			var oPrioritySorter = new sap.ui.model.Sorter("Priority", false);
			var oChangeDateSorter = new sap.ui.model.Sorter("ChangeDate", true);
			return new Promise(function (resolve, reject) {
				oModel.read("/MCCActivitiesSet", {
					filters: aFilters,
					urlParameters: {
						"$expand": "toProducts"
					},
					sorters: [oPrioritySorter, oChangeDateSorter],
					success: function (data) {
						data.results.forEach(function (result) {
							result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
							result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
							result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
							result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
							result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
							result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
							result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);
						}, this);

						//split in MCC Activities and MCC Issues
						var aMccIssues = data.results.filter(function (val) {
							return val.Category === "ZYP";
						});
						this._convertDataForCustomerOverview("MCCIssue", aMccIssues);
						this.getModel("customerModel").setProperty("/AmountMCCIssues", aMccIssues.length);


						var aMCCTopCriticalCustomer = data.results.filter(function (val) {
							return val.Category === "ZYT";
						});
						this._convertDataForCustomerOverview("MCCTopCriticalCustomer", aMCCTopCriticalCustomer);
						this.getModel("customerModel").setProperty("/AmountMCCTopCriticalCustomer", aMCCTopCriticalCustomer.length);


						var aCCMRequests = data.results.filter(function (val) {
							return val.Category === "ZYO";
						});
						this._convertDataForCustomerOverview("CCMActivityRequests", aCCMRequests);
						this.getModel("customerModel").setProperty("/AmountCCMActivityRequests", aCCMRequests.length);

						var aCPCRequests = data.results.filter(function (val) {
							return val.Category === "ZZM";
						});
						this._convertDataForCustomerOverview("CPCActivityRequests", aCPCRequests);
						this.getModel("customerModel").setProperty("/CPCActivityRequests", aCPCRequests.length);

						/*
						var aTechnicalSupportuests = data.results.filter(function (val) {
							return val.Category === "ZZD";
						});
						this._convertDataForCustomerOverview("TechnicalSupportRequests", aTechnicalSupportuests);
						this.getModel("customerModel").setProperty("/AmountTechnicalSupportRequests", aTechnicalSupportuests.length);

						var aMCCSosRequests = data.results.filter(function (val) {
							return val.Category === "ZZR";
						});
						this._convertDataForCustomerOverview("MCCSosRequests", aMCCSosRequests);
						this.getModel("customerModel").setProperty("/AmountMCCSosRequests", aMCCSosRequests.length);
						*/

						var aGoLiveEndngered = data.results.filter(function (val) {
							return val.Category === "Z90" &&
								val.Priority === "1" &&
								val.Status === "E0011" &&
								(val.Reason === "A1ZS0000010010" || val.Reason === "A1ZS0000010050" || val.Reason === "A1ZS0000010060" || val.Reason ===
									"A1ZS0000010100");
						});
						this._convertDataForCustomerOverview("GoLiveEndangered", aGoLiveEndngered);
						this.getModel("customerModel").setProperty("/AmountGoLiveEndangered", aGoLiveEndngered.length);

						var aGoLiveAnnounts = data.results.filter(function (val) {
							return (val.Category === "Z90" || val.Category === "ZB2") &&
								val.Priority === "5" &&
								val.ActResult === "Z2ZS460050" &&
								(val.Reason === "A1ZS0000010040" || val.Reason === "A1ZS0000010050" || val.Reason === "A1ZS0000010060" || val.Reason ===
									"A1ZS0000010100");
						});
						this._convertDataForCustomerOverview("GoLiveAnnouncement", aGoLiveAnnounts);
						this.getModel("customerModel").setProperty("/AmountGoLiveAnnouncement", aGoLiveAnnounts.length);

						resolve(data);
					}.bind(this),
					error: function (data) {
						this.getModel("customerModel").setProperty("/MCCActivitiesSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));
		},

		_readTopIssuesSet: function (oFilter) {
			var oModel = this.getModel();
			var aFilters = [];
			aFilters.push(oFilter);

			//Filter only TopIssues with status "New" (E0010), "Approved" (E0011), "In Process" (E0014), "Responsible Action" (E0018)
			var tileSpecificFilters = new Filter([
				new Filter([new Filter("Status", FilterOperator.EQ, "E0010"), new Filter(
					"Status", FilterOperator.EQ, "E0011"), new Filter("Status", FilterOperator.EQ,
						"E0014"),
				new sap
					.ui.model.Filter("Status", FilterOperator.EQ, "E0018")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			var oPrioritySorter = new sap.ui.model.Sorter("Priority", false);

			return new Promise(function (resolve, reject) {
				oModel.read("/TopIssuesSet", {
					filters: aFilters,
					sorters: [oPrioritySorter],
					urlParameters: {
						"$expand": "toProducts",
						"$inlinecount": "allpages",
						"$top": "1000"
					},
					success: function (data) {
						data.results.forEach(function (result) {
							result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
							result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
							result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
							result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
							result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
							result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
							result.priorityMatched = this.formatter.sortPriorities(result.PriorityT);
						}, this);
						this._convertDataForCustomerOverview("TopIssues", data.results);
						this.getModel("customerModel").setProperty("/AmountTopIssues", data.results.length);
						/*this.getModel("customerModel").setProperty("/TopIssuesSet", data.results);
						this.getModel("customerModel").setProperty("/TopIssuesSetBusy", false);*/
						resolve(data);
					}.bind(this),
					error: function (data) {
						this.getModel("customerModel").setProperty("/TopIssuesSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));
		},

		onPieTypeChanged: function (oEv) {
			var oModel = this.getView().getModel("pieChart");
			oModel.setData({
				data: []
			});
			var sKey = this.getView().byId("iconTabBar").getSelectedKey();
			this._filterTable(sKey, "");
			this._filterTableOpenIssues(sKey, "");
			var aAllProducts = this.getView().byId("customerOverviewTable").getBinding("rows").getModel().getProperty("/CustomerOverview");
			aAllProducts.forEach(function (val) {
				if (val.toProducts) {
					this._setPieModel(val.toProducts.results);
				}
			}.bind(this));
			this.trackEvent("PieChart: type changed");
		},

		_setPieModel: function (results) {

			var sType = this.getView().byId("pieTypeButton").getSelectedKey() === "productLine" ? "ProductLine" : "Product";
			var sText = this.getView().byId("pieTypeButton").getSelectedKey() === "productLine" ? "ProductLineT" : "ProductT";
			var oModel = this.getView().getModel("pieChart");
			if (results && results.length > 0) {
				var oData = oModel.getData();
				var aAlreadyAdded = [];
				results.forEach(function (result, idx) {
					if (result[sType] !== "") {
						//check if data is available
						var aTmp = oData.data.filter(function (val) {
							return val.key === result[sType];
						});

						//if not, create new entry. Otherwise count ++
						if (aTmp.length === 0) {
							oData.data.push({
								"key": result[sType],
								"description": result[sText],
								"count": 1
							});
						} else {
							if (aAlreadyAdded.indexOf(result[sType] + "," + result.CaseId) === -1) {
								aTmp[0].count++;
							}
						}
						aAlreadyAdded.push(result[sType] + "," + result.CaseId);
					}
				});
				//sort
				var aSortedData = oModel.getData();
				aSortedData.data.sort(function (a, b) {
					if (a.count < b.count) {
						return 1;
					} else if (a.count > b.count) {
						return -1;
					}
					if (a.description < b.description) {
						return -1;
					} else if (a.description > b.description) {
						return 1;
					}

				});
				oModel.setData(aSortedData);
				oModel.refresh();
				//set visibility of the chart
				this.getView().byId("CustomerProductLineChartContainer").setProperty("visible", true);
			}

			setTimeout(function () {
				$(".viz-legend-title").text(this.getView().byId("pieTypeButton").getSelectedKey() === "productLine" ? "Product Lines" :
					"Products");
			}.bind(this), 0);
		},

		_convertDataForCustomerOverview: function (sEntityName, aData) {

			var oCustomerModel = this.getModel("customerModel");
			var sObjectType = "";
			var aPropertyNamesToTransform = [];
			var bIsOngoingCriticalEngagementsTable = false;
			var bIsHighPriorityTable = false;
			//switch case for determing if attributes needs to be adjusted
			switch (sEntityName) {
				case "Outages":
					bIsOngoingCriticalEngagementsTable = true;
					sObjectType = Constants.MCCEngagementType.Major_SAP_Cloud_Downtimes;
					aPropertyNamesToTransform = [{
						"SourceName": "CecEventID",
						"TargetName": "ObjectId"
					}];

					break;
				case "HighPrioTickets":
					if (sEntityName === "HighPrioTickets") {
						bIsOngoingCriticalEngagementsTable = false;
						bIsHighPriorityTable = true;
						sObjectType = "High Priority Tickets";
					}
					aPropertyNamesToTransform = [{
						"SourceName": "active_escalation.number",
						"TargetName": "ObjectId"
					}, {
						"SourceName": "cs_account.u_region",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "correlation_id",
						"TargetName": "BcpIncId"
					}, {
						"SourceName": "account.country",
						"TargetName": "Country"
					}, {
						"SourceName": "account.country_text",
						"TargetName": "CountryT"
					}, {
						"SourceName": "u_bcp_link",
						"TargetName": "BcpIncUrl"
					}, {
						"SourceName": "short_description",
						"TargetName": "Description"
					}, {
						"SourceName": "cs_account.name",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "cs_account.number",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "u_install_base_item.u_product.u_product_line_id.u_product_category_name",
						"TargetName": "ProductCategory"
					}, {
						"SourceName": "u_install_base_item.u_product.u_product_line_id.u_product_category_id",
						"TargetName": "ProductCategoryId"
					}, {
						"SourceName": "u_install_base_item.u_product.u_product_line_id.u_product_line_name",
						"TargetName": "ProductLine"
					}, {
						"SourceName": "u_install_base_item.u_product.u_product_line_id.u_product_line_id",
						"TargetName": "ProductLineId"
					}, {
						"SourceName": "u_install_base_item.u_product.display_name",
						"TargetName": "Product"
					}, {
						"SourceName": "u_install_base_item.u_product.model_number",
						"TargetName": "ProductId"
					}, {
						"SourceName": "u_install_base_item.u_product_version.display_name",
						"TargetName": "ProductVer"
					}, {
						"SourceName": "u_install_base_item.u_product_version.model_number",
						"TargetName": "ProductVerId"
					}, {
						"SourceName": "active_escalation.escalation_justification",
						"TargetName": "escalation_justification"
					}, {
						"SourceName": "HasNotes",
						"TargetName": "HasNotes"
					}, {
						"SourceName": "u_app_component.u_name",
						"TargetName": "ComponentName"
					}, {
						"SourceName": "state",
						"TargetName": "Status"
					}, {
						"SourceName": "active_escalation.assigned_to.name",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "active_escalation.assigned_to.employee_number",
						"TargetName": "EmplRespUser"
					}, {
						"SourceName": "opened_at",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "u_last_user_updated_on",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "priority",
						"TargetName": "Priority"
					}, {
						"SourceName": "PriorityT",
						"TargetName": "Priority"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "assigned_to.name",
						"TargetName": "Processor"
					}, {
						"SourceName": "assigned_to.name",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "assigned_to.employee_number",
						"TargetName": "ProcessorId"
					}, {
						"SourceName": "number",
						"TargetName": "EscalationRecordId"
					}, {
						"SourceName": "active_escalation.state",
						"TargetName": "EscalationStatus"
					}, {
						"SourceName": "active_escalation.approval",
						"TargetName": "ApprovalStatus"
					}, {
						"SourceName": "active_escalation.requested_by.name",
						"TargetName": "Requestor"
					}, {
						"SourceName": "active_escalation.requested_by.employee_number",
						"TargetName": "RequestorId"
					}, {
						"SourceName": "u_next_action_due",
						"TargetName": "NextUpdateTime"
					}];
					break;

				case Constants.MCCEngagementKey.BusinessDownSituations:
					bIsOngoingCriticalEngagementsTable = true;
					sObjectType = Constants.MCCEngagementType.BusinessDownSituations;

					aPropertyNamesToTransform = [{
						"SourceName": "u_task_record.priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "number",
						"TargetName": "ObjectId"
					}, {
						"SourceName": "u_task_record.account.u_region",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "u_task_record.correlation_id",
						"TargetName": "BcpIncId"
					}, {
						"SourceName": "u_task_record.sys_id",
						"TargetName": "SysID"
					}, {
						"SourceName": "u_task_record.account.country",
						"TargetName": "Country"
					}, {
						"SourceName": "u_task_record.account.country_text",
						"TargetName": "CountryT"
					}, {
						"SourceName": "u_task_record.u_bcp_link",
						"TargetName": "BcpIncUrl"
					}, {
						"SourceName": "u_task_record.short_description",
						"TargetName": "Description"
					}, {
						"SourceName": "u_task_record.account.name",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "u_task_record.assigned_to.name",
						"TargetName": "Processor"
					}, {
						"SourceName": "u_task_record.assigned_to.name",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "u_task_record.assigned_to.employee_number",
						"TargetName": "ProcessorId"
					}, {
						"SourceName": "u_task_record.account.number",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_name",
						"TargetName": "ProductCategory"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id",
						"TargetName": "ProductCategoryId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_name",
						"TargetName": "ProductLine"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id",
						"TargetName": "ProductLineId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.display_name",
						"TargetName": "Product"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.model_number",
						"TargetName": "ProductId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product_version.display_name",
						"TargetName": "ProductVer"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product_version.model_number",
						"TargetName": "ProductVerId"
					}, {
						"SourceName": "escalation_justification",
						"TargetName": "escalation_justification"
					}, {
						"SourceName": "HasNotes",
						"TargetName": "HasNotes"
					}, {
						"SourceName": "u_task_record.u_app_component.u_name",
						"TargetName": "ComponentName"
					}, {
						"SourceName": "u_task_record.state",
						"TargetName": "Status"
					}, {
						"SourceName": "assigned_to.name",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "assigned_to.employee_number",
						"TargetName": "EmplRespUser"
					}, {
						"SourceName": "sys_created_on",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "u_last_user_updated_on",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "u_task_record.correlation_id",
						"TargetName": "BcpID"
					}, {
						"SourceName": "u_task_record.u_bcp_link",
						"TargetName": "BcpIdUrl"
					}, {
						"SourceName": "u_task_record.number",
						"TargetName": "EscalationRecordId"
					}, {
						"SourceName": "approval",
						"TargetName": "ApprovalStatus"
					}, {
						"SourceName": "requested_by.name",
						"TargetName": "Requestor"
					}, {
						"SourceName": "requested_by.employee_number",
						"TargetName": "RequestorId"
					}, {
						"SourceName": "u_task_record.priority",
						"TargetName": "Priority"
					}, {
						"SourceName": "u_task_record.priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "state",
						"TargetName": "EscalationStatus"
					}, {
						"SourceName": "u_next_update_time",
						"TargetName": "NextUpdateTime"
					}];
					break;

				case Constants.MCCEngagementKey.XTecEngagements:
				case Constants.MCCEngagementKey.PECriticalEngagements:
				case "TechnicalBackofficeRequests":
					if (sEntityName === Constants.MCCEngagementKey.XTecEngagements) {
						bIsOngoingCriticalEngagementsTable = true;
						sObjectType = Constants.MCCEngagementType.XTecEngagements;
					} else if (sEntityName === Constants.MCCEngagementKey.PECriticalEngagements) {
						bIsOngoingCriticalEngagementsTable = true;
						sObjectType = Constants.MCCEngagementType.PECriticalEngagements;
					} else if (sEntityName === "TechnicalBackofficeRequests") {
						bIsOngoingCriticalEngagementsTable = false;
						sObjectType = "Technical Backoffice Requests";
					}
					aPropertyNamesToTransform = [{
						"SourceName": "u_task_record.priority",
						"TargetName": "Priority"
					}, {
						"SourceName": "u_task_record.priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "number",
						"TargetName": "ObjectId"
					}, {
						"SourceName": "u_task_record.account.u_region",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "u_task_record.correlation_id",
						"TargetName": "BcpIncId"
					}, {
						"SourceName": "u_task_record.sys_id",
						"TargetName": "SysID"
					}, {
						"SourceName": "u_task_record.account.country",
						"TargetName": "Country"
					}, {
						"SourceName": "u_task_record.account.country_text",
						"TargetName": "CountryT"
					}, {
						"SourceName": "u_task_record.u_bcp_link",
						"TargetName": "BcpIncUrl"
					}, {
						"SourceName": "u_task_record.short_description",
						"TargetName": "Description"
					}, {
						"SourceName": "u_task_record.account.name",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "u_task_record.assigned_to.name",
						"TargetName": "Processor"
					}, {
						"SourceName": "u_task_record.assigned_to.name",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "u_task_record.assigned_to.employee_number",
						"TargetName": "ProcessorId"
					}, {
						"SourceName": "u_task_record.account.number",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_name",
						"TargetName": "ProductCategory"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id",
						"TargetName": "ProductCategoryId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_name",
						"TargetName": "ProductLine"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id",
						"TargetName": "ProductLineId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.display_name",
						"TargetName": "Product"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.model_number",
						"TargetName": "ProductId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product_version.display_name",
						"TargetName": "ProductVer"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product_version.model_number",
						"TargetName": "ProductVerId"
					}, {
						"SourceName": "escalation_justification",
						"TargetName": "escalation_justification"
					}, {
						"SourceName": "HasNotes",
						"TargetName": "HasNotes"
					}, {
						"SourceName": "u_task_record.u_app_component.u_name",
						"TargetName": "ComponentName"
					}, {
						"SourceName": "u_task_record.state",
						"TargetName": "Status"
					}, {
						"SourceName": "assigned_to.name",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "assigned_to.employee_number",
						"TargetName": "EmplRespUser"
					}, {
						"SourceName": "sys_created_on",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "u_last_user_updated_on",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "u_task_record.correlation_id",
						"TargetName": "BcpID"
					}, {
						"SourceName": "u_task_record.u_bcp_link",
						"TargetName": "BcpIdUrl"
					}, {
						"SourceName": "u_task_record.number",
						"TargetName": "EscalationRecordId"
					}, {
						"SourceName": "approval",
						"TargetName": "ApprovalStatus"
					}, {
						"SourceName": "requested_by.name",
						"TargetName": "Requestor"
					}, {
						"SourceName": "requested_by.employee_number",
						"TargetName": "RequestorId"
					}, {
						"SourceName": "u_task_record.priority",
						"TargetName": "Priority"
					}, {
						"SourceName": "u_task_record.priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "state",
						"TargetName": "EscalationStatus"
					}, {
						"SourceName": "u_next_update_time",
						"TargetName": "NextUpdateTime"
					}];
					break;
				case Constants.MCCEngagementKey.Cims:
				case "CimRequests":
					if (sEntityName === Constants.MCCEngagementKey.BusinessDownSituations) {
						bIsOngoingCriticalEngagementsTable = true;
						sObjectType = Constants.MCCEngagementType.BusinessDownSituations;
					} else if (sEntityName === Constants.MCCEngagementKey.XTecEngagements) {
						bIsOngoingCriticalEngagementsTable = true;
						sObjectType = Constants.MCCEngagementType.XTecEngagements;
					} else if (sEntityName === Constants.MCCEngagementKey.PECriticalEngagements) {
						bIsOngoingCriticalEngagementsTable = true;
						sObjectType = Constants.MCCEngagementType.PECriticalEngagements;
					} else if (sEntityName === "TechnicalBackofficeRequests") {
						bIsOngoingCriticalEngagementsTable = false;
						sObjectType = "Technical Backoffice Requests";
					} else if (sEntityName === Constants.MCCEngagementKey.Cims) {
						bIsOngoingCriticalEngagementsTable = true;
						sObjectType = "Critical Incident Management";
					} else if (sEntityName === "CimRequests") {
						bIsOngoingCriticalEngagementsTable = false;
						sObjectType = "CIM Requests";
					}

					aPropertyNamesToTransform = [{
						"SourceName": "number",
						"TargetName": "ObjectId"
					}, {
						"SourceName": "u_task_record.account.u_region",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "u_task_record.correlation_id",
						"TargetName": "BcpIncId"
					}, {
						"SourceName": "u_task_record.sys_id",
						"TargetName": "SysID"
					}, {
						"SourceName": "u_task_record.account.country",
						"TargetName": "Country"
					}, {
						"SourceName": "u_task_record.account.country_text",
						"TargetName": "CountryT"
					}, {
						"SourceName": "u_task_record.u_bcp_link",
						"TargetName": "BcpIncUrl"
					}, {
						"SourceName": "u_task_record.short_description",
						"TargetName": "Description"
					}, {
						"SourceName": "u_task_record.account.name",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "u_task_record.assigned_to.name",
						"TargetName": "Processor"
					}, {
						"SourceName": "u_task_record.assigned_to.name",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "u_task_record.assigned_to.employee_number",
						"TargetName": "ProcessorId"
					}, {
						"SourceName": "u_task_record.account.number",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_name",
						"TargetName": "ProductCategory"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id",
						"TargetName": "ProductCategoryId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_name",
						"TargetName": "ProductLine"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id",
						"TargetName": "ProductLineId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.display_name",
						"TargetName": "Product"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.model_number",
						"TargetName": "ProductId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product_version.display_name",
						"TargetName": "ProductVer"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product_version.model_number",
						"TargetName": "ProductVerId"
					}, {
						"SourceName": "escalation_justification",
						"TargetName": "escalation_justification"
					}, {
						"SourceName": "HasNotes",
						"TargetName": "HasNotes"
					}, {
						"SourceName": "u_task_record.u_app_component.u_name",
						"TargetName": "ComponentName"
					}, {
						"SourceName": "u_task_record.state",
						"TargetName": "Status"
					}, {
						"SourceName": "assigned_to.name",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "assigned_to.employee_number",
						"TargetName": "EmplRespUser"
					}, {
						"SourceName": "sys_created_on",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "u_last_user_updated_on",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "u_task_record.correlation_id",
						"TargetName": "BcpID"
					}, {
						"SourceName": "u_task_record.u_bcp_link",
						"TargetName": "BcpIdUrl"
					}, {
						"SourceName": "u_task_record.number",
						"TargetName": "EscalationRecordId"
					}, {
						"SourceName": "approval",
						"TargetName": "ApprovalStatus"
					}, {
						"SourceName": "requested_by.name",
						"TargetName": "Requestor"
					}, {
						"SourceName": "requested_by.employee_number",
						"TargetName": "RequestorId"
					}, {
						"SourceName": "u_task_record.priority",
						"TargetName": "Priority"
					}, {
						"SourceName": "u_task_record.priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "state",
						"TargetName": "EscalationStatus"
					}, {
						"SourceName": "u_next_update_time",
						"TargetName": "NextUpdateTime"
					}];
					break;
				case 'GlobalEscalations':
					bIsOngoingCriticalEngagementsTable = true;

					sObjectType = "Global Escalation";

					aPropertyNamesToTransform = [{
						"SourceName": "CaseId",
						"TargetName": "ObjectId"
					}, {
						"SourceName": "LinkToCase",
						"TargetName": "ObjectLink"
					}, {
						"SourceName": "ServiceOrgT",
						"TargetName": "ServiceOrg"
					}, {
						"SourceName": "CaseTitle",
						"TargetName": "Description"
					}, {
						"SourceName": "CustomerText",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "Function",
						"TargetName": "StatusReport"
					}, {
						"SourceName": "PriorityT",
						"TargetName": "Priority"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "Processor",
						"TargetName": "Processor"
					}, {
						"SourceName": "ProcessorUrl",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "RegionT",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "CreateDate",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "",
						"TargetName": "Country"
					}, {
						"SourceName": "ChangeDate",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "Product",
						"TargetName": "Product"
					}, {
						"SourceName": "ProductCategory",
						"TargetName": "ProductCategory"
					}, {
						"SourceName": "ProductLine",
						"TargetName": "ProductLine"
					}, {
						"SourceName": "ProductVer",
						"TargetName": "ProductVer"
					}, {
						"SourceName": "ServiceTeamT",
						"TargetName": "ServiceTeam"
					}, {
						"SourceName": "MasterCodeT",
						"TargetName": "CustomerSegment"
					}, {
						"SourceName": "Responsible",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "ResponsibleId",
						"TargetName": "ResponsibleId"
					}, {
						"SourceName": "PlanEndDate",
						"TargetName": "PlanEndDate"
					}, {
						"SourceName": "",
						"TargetName": "GoLiveDate"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}, {
						"SourceName": "ImplementationPartnerT",
						"TargetName": "ImplementationPartner"
					}];
					break;
				case Constants.MCCEngagementKey.CrossIssues:
					bIsOngoingCriticalEngagementsTable = true;
					sObjectType = Constants.MCCEngagementType.CrossIssue;

					aPropertyNamesToTransform = [{
						"SourceName": "ObjectId", //zu ändern
						"TargetName": "ObjectId"
					}, {
						"SourceName": "CaseTitle",
						"TargetName": "Description"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "PriorityT",
						"TargetName": "Priority"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "ServiceOrgT",
						"TargetName": "ServiceOrg"
					}, {
						"SourceName": "RegionT",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "CreateDate",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "ChangeDate",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "Product",
						"TargetName": "Product"
					}, {
						"SourceName": "ProductCategory",
						"TargetName": "ProductCategory"
					}, {
						"SourceName": "ProductLine",
						"TargetName": "ProductLine"
					}, {
						"SourceName": "ProductVer",
						"TargetName": "ProductVer"
					}, {
						"SourceName": "ServiceTeamT",
						"TargetName": "ServiceTeam"
					}, {
						"SourceName": "MasterCodeT",
						"TargetName": "CustomerSegment"
					}, {
						"SourceName": "Responsible",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "ResponsibleId",
						"TargetName": "ResponsibleId"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}, {
						"SourceName": "RequestedStartDate",
						"TargetName": "PlanEndDate"
					}];
					break;
				case Constants.MCCEngagementKey.CriticalCustomerManagement:
				case Constants.MCCEngagementKey.CriticalPeriodCoverage:
				case Constants.MCCEngagementKey.TaskForces:
				case Constants.MCCEngagementKey.TopCriticalCustomers:
					bIsOngoingCriticalEngagementsTable = true;
					sObjectType = sEntityName;
					if (sEntityName === Constants.MCCEngagementKey.CriticalCustomerManagement) {
						sObjectType = "Critical Customer Management";
					} else if (sEntityName === Constants.MCCEngagementKey.CriticalPeriodCoverage) {
						sObjectType = "Critical Period Coverage";
					} else if (sEntityName === Constants.MCCEngagementKey.TopCriticalCustomers) {
						sObjectType = Constants.MCCEngagementType.TopCriticalCustomers;
					} else if (sEntityName === Constants.MCCEngagementKey.TaskForces) {
						sObjectType = Constants.MCCEngagementType.TaskForces;
					}

					aPropertyNamesToTransform = [{
						"SourceName": "CaseId",
						"TargetName": "ObjectId"
					}, {
						"SourceName": "LinkToCase",
						"TargetName": "ObjectLink"
					}, {
						"SourceName": "CaseTitle",
						"TargetName": "Description"
					}, {
						"SourceName": "CustomerText",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "Function",
						"TargetName": "StatusReport"
					}, {
						"SourceName": "PriorityT",
						"TargetName": "Priority"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "Processor",
						"TargetName": "Processor"
					}, {
						"SourceName": "ProcessorUrl",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "ServiceOrgT",
						"TargetName": "ServiceOrg"
					}, {
						"SourceName": "RegionT",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "CreateDate",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "ChangeDate",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "Product",
						"TargetName": "Product"
					}, {
						"SourceName": "ProductCategory",
						"TargetName": "ProductCategory"
					}, {
						"SourceName": "ProductLine",
						"TargetName": "ProductLine"
					}, {
						"SourceName": "ProductVer",
						"TargetName": "ProductVer"
					}, {
						"SourceName": "ServiceTeamT",
						"TargetName": "ServiceTeam"
					}, {
						"SourceName": "MasterCodeT",
						"TargetName": "CustomerSegment"
					}, {
						"SourceName": "Responsible",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "ResponsibleId",
						"TargetName": "ResponsibleId"
					}, {
						"SourceName": "PlanEndDate",
						"TargetName": "PlanEndDate"
					}, {
						"SourceName": "GoLiveDate",
						"TargetName": "GoLiveDate"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}];

					break;

				case "CCMRequests":
				case "CPCRequests":
				case "TechnicalSupportRequests":
					if (sEntityName === 'CPCRequests') {
						sObjectType = "CPC Requests";
					} else if (sEntityName === 'CCMRequests') {
						sObjectType = "CCM Requests";
					} else if (sEntityName === "TechnicalSupportRequests") {
						sObjectType = "MCC Support Requests";
					}

					aPropertyNamesToTransform = [{
						"SourceName": "LinkToActivity",
						"TargetName": "ObjectLink"
					}, {
						"SourceName": "IncidentComponent",
						"TargetName": "ComponentName"
					}, {
						"SourceName": "CustomerTicketId",
						"TargetName": "BcpIncId"
					}, {
						"SourceName": "CustomerText",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "PriorityT",
						"TargetName": "Priority"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "Processor",
						"TargetName": "Processor"
					}, {
						"SourceName": "ProcessorUrl",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "CreationDate",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "ChangeDate",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "ServiceTeamName",
						"TargetName": "ServiceTeam"
					}, {
						"SourceName": "Region",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "ServiceOrgT",
						"TargetName": "ServiceOrg"
					}, {
						"SourceName": "PlannedStartDate",
						"TargetName": "PlannedStartDate"
					}, {
						"SourceName": "PlannedEndDate",
						"TargetName": "PlannedEndDate"
					}, {
						"SourceName": "ActualsStartDate",
						"TargetName": "ActualsStartDate"
					}, {
						"SourceName": "ActualsEndDate",
						"TargetName": "ActualsEndDate"
					}, {
						"SourceName": "GoLiveDate",
						"TargetName": "GoLiveDate"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}, {
						"SourceName": "short_description",

						"TargetName": "Description"
					}, {
						"SourceName": "assignment_group.name",
						"TargetName": "ServiceTeam"
					}];
					break;
				case 'MCCActivities':
				case 'MCCIssue':
				case "MCCTopCriticalCustomer":
				case "MCCSosRequests":
				case "GoLiveEndangered":
				case "GoLiveAnnouncement":
				case "CustomerVisits":
				case "CPCActivityRequests":
				case "CCMActivityRequests":

					if (sEntityName === 'MCCActivities') {
						sObjectType = "MCC Activity";
					} else if (sEntityName === 'MCCIssue') {
						sObjectType = "MCC Issue";
					} else if (sEntityName === "MCCSosRequests") {
						sObjectType = "MCC SOS Requests";
					} else if (sEntityName === "GoLiveEndangered") {
						sObjectType = "Go Live Endangered";
					} else if (sEntityName === "GoLiveAnnouncement") {
						sObjectType = "Go Live Announcement";
					} else if (sEntityName === "MCCTopCriticalCustomer") {
						sObjectType = "TC2 Evaluation Request";
					} else if (sEntityName === "CustomerVisits") {
						sObjectType = "Customer Visits";
					} else if (sEntityName === "CPCActivityRequests") {
						sObjectType = "CPC Requests (Activities)";
					} else if (sEntityName === "CCMActivityRequests") {
						sObjectType = "CCM Requests (Activities)";
					}

					aPropertyNamesToTransform = [{
						"SourceName": "LinkToActivity",
						"TargetName": "ObjectLink"
					}, {
						"SourceName": "IncidentComponent",
						"TargetName": "ComponentName"
					}, {
						"SourceName": "CustomerTicketId",
						"TargetName": "BcpIncId"
					}, {
						"SourceName": "ServiceOrgT",
						"TargetName": "ServiceOrg"
					}, {
						"SourceName": "CustomerText",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "PriorityT",
						"TargetName": "Priority"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "Processor",
						"TargetName": "Processor"
					}, {
						"SourceName": "ProcessorUrl",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "CreationDate",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "ChangeDate",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "ServiceTeamName",
						"TargetName": "ServiceTeam"
					}, {
						"SourceName": "RegionT",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "PlannedStartDate",
						"TargetName": "PlannedStartDate"
					}, {
						"SourceName": "PlannedEndDate",
						"TargetName": "PlannedEndDate"
					}, {
						"SourceName": "ActualsStartDate",
						"TargetName": "ActualsStartDate"
					}, {
						"SourceName": "ActualsEndDate",
						"TargetName": "ActualsEndDate"
					}, {
						"SourceName": "GoLiveDate",
						"TargetName": "GoLiveDate"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}];

					break;
				case 'GlobalEscalationRequest':
					sObjectType = "Global Escalation Request";
					aPropertyNamesToTransform = [{
						"SourceName": "LinkToRequest",
						"TargetName": "ObjectLink"
					}, {
						"SourceName": "CustomerText",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "ServiceOrgT",
						"TargetName": "ServiceOrg"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "RegionT",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "CreateTime",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "ChangeTime",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "ServiceTeamName",
						"TargetName": "ServiceTeam"
					}, {
						"SourceName": "MasterCodeT",
						"TargetName": "CustomerSegment"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}];
					break;
				case 'TopIssues':

					sObjectType = "Top Issue";
					aPropertyNamesToTransform = [{
						"SourceName": "LinkToTopi",
						"TargetName": "ObjectLink"
					}, {
						"SourceName": "CustomerText",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "PriorityT",
						"TargetName": "Priority"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "RegionT",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "ServiceOrgT",
						"TargetName": "ServiceOrg"
					}, {
						"SourceName": "CreationDate",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "ChangeDate",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "PlanEndDate",
						"TargetName": "PlanEndDate"
					}, {
						"SourceName": "",
						"TargetName": "GoLiveDate"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}, {
						"SourceName": "RequestedStartDate",
						"TargetName": "RequestedStartDate"
					}, {
						"SourceName": "RequestedEndDate",
						"TargetName": "RequestedEndDate"
					}];
					break;

				case Constants.MCCEngagementKey.ExecutiveEscalations: {

					sObjectType = Constants.MCCEngagementType.ExecutiveEscalation;
					bIsOngoingCriticalEngagementsTable = true;
					break;
				}
			}

			if (bIsOngoingCriticalEngagementsTable) {
				if (aData.length > 0) {
					var aTransformedData = oCustomerModel.getProperty("/CustomerOverview");
					aData.forEach(function (oData) {
						var oTransformedObject = {};
						oTransformedObject.objectType = sObjectType;
						var aSourceObjectKeys = Object.keys(oData);
						aSourceObjectKeys.forEach(function (sSourceKey) {

							//not supported in Internet Explorer...
							//var oObjectToTransform = aPropertyNamesToTransform.find(obj => obj.SourceName === sSourceKey);

							var findObjectById = function (aSource, sId) {
								for (var i = 0; i < aSource.length; i++) {
									if (aSource[i].SourceName === sId) {
										return aSource[i];
									}
								}
								return null;

							};
							var oObjectToTransform = findObjectById(aPropertyNamesToTransform, sSourceKey);
							if (oObjectToTransform) {
								//convert data
								oTransformedObject[oObjectToTransform.TargetName] = oData[sSourceKey];
							} else {
								// move current data to a new object
								oTransformedObject[sSourceKey] = oData[sSourceKey];
							}

						}.bind(this));
						aTransformedData.push(oTransformedObject);
					}.bind(this));
					oCustomerModel.setProperty("/CustomerOverview", aTransformedData);
					oCustomerModel.setProperty("/AmountAll", aTransformedData.length);
					oCustomerModel.refresh(true);
				} else {
					this.getView().byId("customerOverviewTable").setBusy(false);
				}
			} else if (bIsHighPriorityTable) {
				if (aData.length > 0) {
					oCustomerModel.setProperty("/HighPrioTickets", aData);
					oCustomerModel.refresh(true);
				}

			} else {
				if (aData.length > 0) {
					var aTransformedData = oCustomerModel.getProperty("/CustomerOverviewOpenIssues");
					aData.forEach(function (oData) {
						var oTransformedObject = {};
						oTransformedObject.objectType = sObjectType;
						var aSourceObjectKeys = Object.keys(oData);
						aSourceObjectKeys.forEach(function (sSourceKey) {

							//not supported in Internet Explorer...
							//var oObjectToTransform = aPropertyNamesToTransform.find(obj => obj.SourceName === sSourceKey);

							var findObjectById = function (aSource, sId) {
								for (var i = 0; i < aSource.length; i++) {
									if (aSource[i].SourceName === sId) {
										return aSource[i];
									}
								}
								return null;

							};
							var oObjectToTransform = findObjectById(aPropertyNamesToTransform, sSourceKey);
							if (oObjectToTransform) {
								//convert data
								oTransformedObject[oObjectToTransform.TargetName] = oData[sSourceKey];
							} else {
								// move current data to a new object
								oTransformedObject[sSourceKey] = oData[sSourceKey];
							}

						}.bind(this));
						aTransformedData.push(oTransformedObject);
					}.bind(this));
					oCustomerModel.setProperty("/CustomerOverviewOpenIssues", aTransformedData);
					oCustomerModel.setProperty("/AmountAllOpenIssues", aTransformedData.length);
					oCustomerModel.refresh(true);
				} else {
					this.getView().byId("customerOverviewTableOpenIssues").setBusy(false);
				}
			}

			//for loop to modify / adjust the data structure for the overall table

		},

		onPieChartSelected: function (oEv) {
			var sProductLine = oEv.getParameter("data")[0].data["Products"];
			var sKey = this.getView().byId("iconTabBar").getSelectedKey();
			var sKeyOpenIssues = this.getView().byId("iconTabBarOpenIssues").getSelectedKey();
			this._filterTable(sKey, sProductLine);
			this._filterTableOpenIssues(sKeyOpenIssues, sProductLine);
			this._pieChanged = sProductLine;
			this.trackEvent("Customer: filtered - product lines");
		},

		onPieChartDeselected: function (oEv) {
			//only real deselect attach
			if (this._pieChanged === oEv.getParameter("data")[0].data["Products"]) {
				var sKey = this.getView().byId("iconTabBar").getSelectedKey();
				var sKeyOpenIssues = this.getView().byId("iconTabBarOpenIssues").getSelectedKey();
				this._filterTable(sKey, "");
				this._filterTableOpenIssues(sKeyOpenIssues, "");
			}
		},

		handleTabBarSelectOpenIssues: function (oEv) {
			var sKey = oEv.getParameter("key");
			this._filterTableOpenIssues(sKey, "");
		},

		handleTabBarSelect: function (oEv) {
			var sKey = oEv.getParameter("key");
			var oPieSelection = this.getView().byId("idVizFrame").vizSelection();
			var sPieChartSelection = "";
			if (oPieSelection && oPieSelection.length === 1) {
				sPieChartSelection = oPieSelection[0].data["Products"];
			}

			this._filterTable(sKey, sPieChartSelection);
		},

		_filterTable: function (sKey, sPieChartSelection) {
			var oTableBinding = this.getView().byId("customerOverviewTable").getBinding("rows");
			var aFilters = [];
			var sPieType = this.getView().byId("pieTypeButton").getSelectedKey();
			if (sPieChartSelection !== "") {
				var sFilterProperty = sPieType === "productLine" ? "ProductLineKeys" : "ProductKeys";
				var oPieFilter = new Filter(sFilterProperty, FilterOperator.Contains, sPieChartSelection);
				aFilters.push(oPieFilter);
			}

			var oFilter = {};
			switch (sKey) {
				case Constants.MCCEngagementKey.GlobalEscalations:
					oFilter = new Filter("objectType", FilterOperator.EQ, Constants.MCCEngagementType.GlobalEscalation);
					break;
				case Constants.MCCEngagementKey.CriticalCustomerManagement:
					oFilter = new Filter("objectType", FilterOperator.EQ, Constants.MCCEngagementType.CriticalCustomerManagement);
					break;
				case Constants.MCCEngagementKey.CriticalPeriodCoverage:
					oFilter = new Filter("objectType", FilterOperator.EQ, Constants.MCCEngagementType.CriticalPeriodCoverage);
					break;
				case Constants.MCCEngagementKey.TopCriticalCustomers:
					oFilter = new Filter("objectType", FilterOperator.EQ, Constants.MCCEngagementType.TopCriticalCustomers);
					break;
				case Constants.MCCEngagementKey.CrossIssues:
					oFilter = new Filter("objectType", FilterOperator.EQ, Constants.MCCEngagementType.CrossIssue);
					break;
				case Constants.MCCEngagementKey.BusinessDownSituations:
					oFilter = new Filter("objectType", FilterOperator.EQ, Constants.MCCEngagementType.BusinessDownSituations);
					break;
				case Constants.MCCEngagementKey.XTecEngagements:
					oFilter = new Filter("objectType", FilterOperator.EQ, Constants.MCCEngagementType.XTecEngagements);
					break;
				case Constants.MCCEngagementKey.PECriticalEngagements:
					oFilter = new Filter("objectType", FilterOperator.EQ, Constants.MCCEngagementType.PECriticalEngagements);
					break;
				case Constants.MCCEngagementKey.Cims:
					oFilter = new Filter("objectType", FilterOperator.EQ, Constants.MCCEngagementType.CriticalIncidentManagement);
					break;
				case Constants.MCCEngagementKey.TaskForces:
					oFilter = new Filter("objectType", FilterOperator.EQ, Constants.MCCEngagementType.TaskForces);
					break;
				case Constants.MCCEngagementKey.Major_SAP_Cloud_Downtimes:
					oFilter = new Filter("objectType", FilterOperator.EQ, Constants.MCCEngagementType.Major_SAP_Cloud_Downtimes);
					break;
				case Constants.MCCEngagementKey.ExecutiveEscalations:
					oFilter = new Filter("objectType", FilterOperator.EQ, Constants.MCCEngagementType.ExecutiveEscalation);
					break;
			}

			if (!jQuery.isEmptyObject(oFilter)) {
				aFilters.push(oFilter);
			}

			if (aFilters.length > 0) {
				oTableBinding.filter(aFilters);
			} else {
				oTableBinding.filter();
			}

			//now update counts
			this._updateFilterCounts(sKey, sPieChartSelection);

		},

		_filterTableOpenIssues: function (sKey, sPieChartSelection) {
			var oTableBinding = this.getView().byId("customerOverviewTableOpenIssues").getBinding("rows");
			var aFilters = [];

			var sPieType = this.getView().byId("pieTypeButton").getSelectedKey();
			if (sPieChartSelection !== "") {
				var sFilterProperty = sPieType === "productLine" ? "ProductLineKeys" : "ProductKeys";
				var oPieFilter = new Filter(sFilterProperty, FilterOperator.Contains, sPieChartSelection);
				aFilters.push(oPieFilter);
			}

			var visSelection = this.getView().byId("idVizFrame").vizSelection();
			if (visSelection && visSelection.length === 1) {
				var sText = this.getView().getModel("i18n").getProperty("selectenPieChartText");
				sText = sText.replace("{type}", sPieType === "productLine" ? "Product Line" : "Product");
				sText = sText.replace("{value}", visSelection[0].data["Products.d"]);
				this.getView().getModel("customerModel").setProperty("/selectedPieChartText", sText);
			} else {
				this.getView().getModel("customerModel").setProperty("/selectedPieChartText", "");
			}

			var oFilter = {};
			switch (sKey) {
				case "CustomerVisits":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Customer Visits");
					break;
				case "MCCSosRequests":
					oFilter = new Filter("objectType", FilterOperator.EQ, "MCC SOS Requests");
					break;
				case "GoLiveEndangered":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Go Live Endangered");
					break;
				case "GoLiveAnnouncement":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Go Live Announcement");
					break;
				case 'GlobalEscalationRequests':
					oFilter = new Filter("objectType", FilterOperator.EQ, "Global Escalation Request");
					break;
				// case 'CriticalSituations':
				// 	oFilter = new Filter("objectType", FilterOperator.EQ, "Critical MCC Customer Situation");
				// 	break;
				case 'MCCActivities':
					oFilter = new Filter("objectType", FilterOperator.EQ, "MCC Activity");
					break;
				case 'MCCIssue':
					oFilter = new Filter("objectType", FilterOperator.EQ, "MCC Issue");
					break;
				case 'TopIssues':
					oFilter = new Filter("objectType", FilterOperator.EQ, "Top Issue");
					break;
				case 'CCMRequests':
					oFilter = new Filter("objectType", FilterOperator.EQ, "CCM Requests");
					break;
				case 'MCCTopCriticalCustomer':
					oFilter = new Filter("objectType", FilterOperator.EQ, "TC2 Evaluation Request");
					break;
				case 'CPCRequests':
					oFilter = new Filter("objectType", FilterOperator.EQ, "CPC Requests");
					break;
				case 'TechnicalSupportRequests':
					oFilter = new Filter("objectType", FilterOperator.EQ, "MCC Support Requests");
					break;
				case 'CimRequests':
					oFilter = new Filter("objectType", FilterOperator.EQ, "CIM Requests");
					break;
				case "TechnicalBackofficeRequests":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Technical Backoffice Requests");
					break;
				case "CPCActivityRequests":
					oFilter = new Filter("objectType", FilterOperator.EQ, "CPC Requests (Activities)");
					break;
				case "CCMActivityRequests":
					oFilter = new Filter("objectType", FilterOperator.EQ, "CCM Requests (Activities)");
					break;
			}

			if (!jQuery.isEmptyObject(oFilter)) {
				aFilters.push(oFilter);
			}

			if (aFilters.length > 0) {
				oTableBinding.filter(aFilters);
			} else {
				oTableBinding.filter();
			}

			//now update counts
			this._updateFilterCountsOpenIssues(sKey, sPieChartSelection);

		},

		_updateFilterCounts: function (sKey, sPieChartSelection) {
			var aRows = this.getModel("customerModel").getProperty("/CustomerOverview");
			var oCustomerModel = this.getModel("customerModel");
			var oTabs = [{
				"objectType": Constants.MCCEngagementType.GlobalEscalation,
				"countProp": "AmountGlobalEscalations",
				"key": Constants.MCCEngagementKey.GlobalEscalations
			}, {
				"objectType": Constants.MCCEngagementType.CriticalCustomerManagement,
				"countProp": "AmountCriticalCustomerManagement",
				"key": Constants.MCCEngagementKey.CriticalCustomerManagement
			}, {
				"objectType": Constants.MCCEngagementType.TaskForces,
				"countProp": "AmountTaskForces",
				"key": Constants.MCCEngagementKey.TaskForces
			}, {
				"objectType": Constants.MCCEngagementType.Major_SAP_Cloud_Downtimes,
				"countProp": "AmountOutages",
				"key": Constants.MCCEngagementKey.Major_SAP_Cloud_Downtimes
			}, {
				"objectType": Constants.MCCEngagementType.CriticalPeriodCoverage,
				"countProp": "AmountCriticalPeriodCoverage",
				"key": Constants.MCCEngagementKey.CriticalPeriodCoverage
			}, {
				"objectType": Constants.MCCEngagementType.TopCriticalCustomers,
				"countProp": "AmountTopCriticalCustomers",
				"key": Constants.MCCEngagementKey.TopCriticalCustomers
			}, {
				"objectType": Constants.MCCEngagementType.CrossIssue,
				"countProp": "AmountCrossIssues",
				"key": Constants.MCCEngagementKey.CrossIssues
			}, {
				"objectType": Constants.MCCEngagementType.BusinessDownSituations,
				"countProp": "AmountBusinessDownSituations",
				"key": Constants.MCCEngagementKey.BusinessDownSituations
			}, {
				"objectType": Constants.MCCEngagementType.XTecEngagements,
				"countProp": "AmountXTecEngagements",
				"key": Constants.MCCEngagementKey.XTecEngagements
			}, {
				"objectType": Constants.MCCEngagementType.PECriticalEngagements,
				"countProp": "AmountPECriticalEngagements",
				"key": Constants.MCCEngagementKey.PECriticalEngagements
			}, {
				"objectType": "Critical Incident Management",
				"countProp": "AmountCims",
				"key": Constants.MCCEngagementKey.Cims
			}, {
				"objectType": Constants.MCCEngagementType.ExecutiveEscalation,
				"countProp": "AmountExecutiveEscalations",
				"key": Constants.MCCEngagementKey.ExecutiveEscalations
			}
			];

			if (sPieChartSelection === "") {
				//All
				oCustomerModel.setProperty("/AmountAll", aRows.length);
				//Others
				oTabs.forEach(function (tab) {
					var aTmp = aRows.filter(function (row) {
						return row.objectType === tab.objectType;
					});
					oCustomerModel.setProperty("/" + tab.countProp, aTmp.length);
				});
			} else if (sPieChartSelection !== "") {
				//All
				var iAll = 0;
				var sPieType = this.getView().byId("pieTypeButton").getSelectedKey();
				var sProperty = sPieType === "productLine" ? "ProductLine" : "Product";
				aRows.forEach(function (row) {
					if (row.toProducts && row.toProducts.results.length > 0) {
						var aTmp = [];
						row.toProducts.results.forEach(function (prod) {
							if (prod[sProperty] === sPieChartSelection) {
								if (aTmp.indexOf(prod[sProperty]) === -1) {
									aTmp.push(prod[sProperty]);
									iAll++;
								}
							}
						});
					}
				});
				oCustomerModel.setProperty("/AmountAll", iAll);
				//Others
				oTabs.forEach(function (tab) {
					var iTmp = 0;
					var aTmp = aRows.filter(function (row) {
						return row.objectType === tab.objectType;
					});
					if (aTmp.length > 0) {
						aTmp.forEach(function (tmp) {
							if (tmp.toProducts && tmp.toProducts.results.length > 0) {
								var aTmp = [];
								tmp.toProducts.results.forEach(function (prod) {
									if (prod[sProperty] === sPieChartSelection) {
										if (aTmp.indexOf(prod[sProperty]) === -1) {
											aTmp.push(prod[sProperty]);
											iTmp++;
										}
									}
								});
							}
						});
					}
					oCustomerModel.setProperty("/" + tab.countProp, iTmp);

					if (sKey === tab.key && iTmp === 0) {
						this._filterTable("All", sPieChartSelection);
					}
				}.bind(this));
			}
		},

		_updateFilterCountsOpenIssues: function (sKey, sPieChartSelection) {
			var aRows = this.getModel("customerModel").getProperty("/CustomerOverviewOpenIssues");
			var oCustomerModel = this.getModel("customerModel");
			var oTabs = [{
				"objectType": "MCC SOS Requests",
				"countProp": "AmountMCCSosRequests",
				"key": "MCCSosRequests"
			}, {
				"objectType": "Customer Visits",
				"countProp": "AmountCustomerVisits",
				"key": "CustomerVisits"
			}, {
				"objectType": "Go Live Endangered",
				"countProp": "AmountGoLiveEndangered",
				"key": "GoLiveEndangered"
			}, {
				"objectType": "Go Live Announcement",
				"countProp": "AmountGoLiveAnnouncement",
				"key": "GoLiveAnnouncement"
			}, {
				"objectType": "Global Escalation Request",
				"countProp": "AmountGlobalEscalationRequests",
				"key": "GlobalEscalationRequests"
				// }, {???
				// 	"objectType": "Critical MCC Customer Situation",
				// 	"countProp": "AmountCriticalSituations",
				// 	"key": "CriticalSituations"
				// }, {???
				// 	"objectType": "Critical Incident",
				// 	"countProp": "AmountCriticalIncidents",
				// 	"key": "CriticalIncidents"
			}, {
				"objectType": "Top Issue",
				"countProp": "AmountTopIssues",
				"key": "TopIssues"
			}, {
				"objectType": "MCC Issue",
				"countProp": "AmountMCCIssues",
				"key": "MCCIssue"
			}, {
				"objectType": "CCM Requests",
				"countProp": "AmountCCMRequests",
				"key": "CCMRequests"
			}, {
				"objectType": "TC2 Evaluation Request",
				"countProp": "AmountMCCTopCriticalCustomer",
				"key": "MCCTopCriticalCustomer"
			}, {
				"objectType": "CPC Requests",
				"countProp": "AmountCPCRequests",
				"key": "CPCRequests"
			}, {
				"objectType": "CPC Requests (Activities)",
				"countProp": "AmountCPCActivityRequests",
				"key": "CPCActivityRequests"
			}, {
				"objectType": "CCM Requests (Activities)",
				"countProp": "AmountCCMActivityRequests",
				"key": "CCMActivityRequests"
			}, {
				"objectType": "MCC Support Requests",
				"countProp": "AmountTechnicalSupportRequests",
				"key": "TechnicalSupportRequests"
			}, {
				"objectType": "CIM Requests",
				"countProp": "AmountCimsRequest",
				"key": "CimRequests"
			}, {
				"objectType": "Technical Backoffice Requests",
				"countProp": "AmountTechnicalBackofficeRequests",
				"key": "TechnicalBackofficeRequests"
			}];
			if (sPieChartSelection === "") {
				//All
				oCustomerModel.setProperty("/AmountAllOpenIssues", aRows.length);
				//Others
				oTabs.forEach(function (tab) {
					var aTmp = aRows.filter(function (row) {
						return row.objectType === tab.objectType;
					});
					oCustomerModel.setProperty("/" + tab.countProp, aTmp.length);
				});
			} else if (sPieChartSelection !== "") {
				//All
				var iAll = 0;
				var sPieType = this.getView().byId("pieTypeButton").getSelectedKey();
				var sProperty = sPieType === "productLine" ? "ProductLine" : "Product";
				aRows.forEach(function (row) {
					if (row.toProducts && row.toProducts.results.length > 0) {
						var aTmp = [];
						row.toProducts.results.forEach(function (prod) {
							if (prod[sProperty] === sPieChartSelection) {
								if (aTmp.indexOf(prod[sProperty]) === -1) {
									aTmp.push(prod[sProperty]);
									iAll++;
								}
							}
						});
					}
				});
				oCustomerModel.setProperty("/AmountAllOpenIssues", iAll);
				//Others
				oTabs.forEach(function (tab) {
					var iTmp = 0;
					var aTmp = aRows.filter(function (row) {
						return row.objectType === tab.objectType;
					});
					if (aTmp.length > 0) {
						aTmp.forEach(function (tmp) {
							if (tmp.toProducts && tmp.toProducts.results.length > 0) {
								var aTmp = [];
								tmp.toProducts.results.forEach(function (prod) {
									if (prod[sProperty] === sPieChartSelection) {
										if (aTmp.indexOf(prod[sProperty]) === -1) {
											aTmp.push(prod[sProperty]);
											iTmp++;
										}
									}
								});
							}
						});
					}
					oCustomerModel.setProperty("/" + tab.countProp, iTmp);

					if (sKey === tab.key && iTmp === 0) {
						this._filterTableOpenIssues("All", sPieChartSelection);
					}
				}.bind(this));
			}

		},

		handleCaseIdPress: function (oEvent) {
			MessageToast.show("Open Case");
		},

		createInnovationReviewLink: function (sGlobalUltimate) {
			var sUrl = this.getResourceBundle().getText("innovationReviewUrl") + "/innovation-review-dashboard/gu/" + sGlobalUltimate +
				"/adoption/history/";
			return sUrl;
		},

		_checkForFavorite: function (sErpCustNo) {
			var sErpCustNoZeros = this._addLeadingZeros(sErpCustNo);
			var aFavorites = this.getModel("favoriteModel").getProperty("/userFavorites");
			var objectPageHeader = this.getView().byId("objectPageHeader");
			var favoriteBtn = this.getView().byId("favoriteBtn");
			aFavorites = aFavorites ? aFavorites : [];
			for (var i = 0; i < aFavorites.length; i++) {
				if (aFavorites[i].Value === sErpCustNoZeros) {
					objectPageHeader.setMarkFavorite(true);
					favoriteBtn.setIcon("sap-icon://unfavorite");
					favoriteBtn.setTooltip("Remove from favorite");
					return;
				}
			}
			objectPageHeader.setMarkFavorite(false);
			favoriteBtn.setIcon("sap-icon://add-favorite");
			favoriteBtn.setTooltip("Add to favorite");
		},

		_noCustomerFound: function () {
			var oObjectPageHeader = this.getView().byId("objectPageHeader");
			var sNoData = this.getResourceBundle().getText("noCustomerDataFound");
			//set Page header title
			oObjectPageHeader.setObjectTitle(sNoData);

			//disable links in customer header --> links do not work correctly
			this.getModel("customerModel").setProperty("/linkWebsiteVisible", false);
			this.getModel("customerModel").setProperty("/linkICPAccount", false);
			this.getModel("customerModel").setProperty("/linkInnovationReviewDashboard", false);
			this.getModel("customerModel").setProperty("/linkEWADashboard", false);
			this.getModel("customerModel").setProperty("/linkMCCMissionRadar", false);
			this.getView().byId("favoriteBtn").setVisible(false);

			this.getView().byId("hboxBusy").setVisible(false);
			this.getView().byId("hboxBusyOpenIssues").setVisible(false);
			this.getView().byId("customerOverviewTable").setBusy(false);
			this.getView().byId("customerOverviewTableOpenIssues").setBusy(false);

			var oCustomerModel = this.getModel("customerModel");
			//clear Model data when no customer data was found
			oCustomerModel.setProperty("/GlobalEscalationsSet", null);
			oCustomerModel.setProperty("/GlobalEscalationRequestSet", null);
			oCustomerModel.setProperty("/CriticalSituationsSet", null);
			oCustomerModel.setProperty("/MCCActivitiesSet", null);
			oCustomerModel.setProperty("/TopIssuesSet", null);
			oCustomerModel.setProperty("/BusinessDown", null);

			//clear counter data when no customer data was found
			//first section of Customer 360° view
			oCustomerModel.setProperty("/AmountAll", 0);
			oCustomerModel.setProperty("/AmountGlobalEscalations", 0);
			oCustomerModel.setProperty("/AmountCims", 0);
			oCustomerModel.setProperty("/AmountCriticalCustomerManagement", 0);
			oCustomerModel.setProperty("/AmountTaskForces", 0);
			oCustomerModel.setProperty("/AmountOutages", 0);
			oCustomerModel.setProperty("/AmountCriticalPeriodCoverage", 0);
			oCustomerModel.setProperty("/AmountTopCriticalCustomers", 0);
			oCustomerModel.setProperty("/AmountCrossIssues", 0);
			oCustomerModel.setProperty("/AmountBusinessDownSituations", 0);
			oCustomerModel.setProperty("/AmountXTecEngagements", 0);
			oCustomerModel.setProperty("/AmountPECriticalEngagements", 0);

			//second section of Customer 360° view
			oCustomerModel.setProperty("/AmountAllOpenIssues", 0);
			oCustomerModel.setProperty("/AmountTopIssues", 0);
			oCustomerModel.setProperty("/AmountMCCIssues", 0);
			oCustomerModel.setProperty("/AmountCCMRequests", 0);
			oCustomerModel.setProperty("/AmountMCCTopCriticalCustomer", 0);
			oCustomerModel.setProperty("/AmountCPCRequests", 0);
			oCustomerModel.setProperty("/AmountTechnicalSupportRequests", 0);
			oCustomerModel.setProperty("/AmountCimsRequest", 0);
			oCustomerModel.setProperty("/AmountTechnicalBackofficeRequests", 0);

			oCustomerModel.setProperty("/AmountGlobalEscalationRequests", 0);
			oCustomerModel.setProperty("/AmountMCCSosRequest", 0);
			oCustomerModel.setProperty("/AmountBusinessDown", 0);
			oCustomerModel.setProperty("/AmountGoLiveEndangered", 0);
			oCustomerModel.setProperty("/AmountGoLiveAnnouncement", 0);

			//third section of Customer 360° view
			oCustomerModel.setProperty("/AmountAllHighPrioTickets", 0);
			oCustomerModel.setProperty("/AmountVeryHighPrioTickets", 0);
			oCustomerModel.setProperty("/AmountHighPrioTickets", 0);

			oCustomerModel.setProperty("/AmountAllGoLives", 0);

			//AI Data
			oCustomerModel.setProperty("/AISummary", undefined);

			MessageToast.show(sNoData);
		},

		onSelectTopIssue: function (oEvent) {
			/*var oObjectPageLayout = this.getView().byId("ObjectPageLayout");
			var oTopIssuesSection = this.getView().byId("topIssuesSec");
			oObjectPageLayout.setSelectedSection(oTopIssuesSection);*/

			var oTableBinding = this.getView().byId("customerOverviewTable").getBinding("rows");
			var aFilters = [];
			var oFilter = {};

			oFilter = new Filter("objectType", FilterOperator.EQ, "Top Issue");

			if (!jQuery.isEmptyObject(oFilter)) {
				aFilters.push(oFilter);
				oTableBinding.filter(aFilters);
			}

			//also adjust the icon tab bar
			var oIconTabBar = this.getView().byId("iconTabBar");
			oIconTabBar.setSelectedKey("TopIssues");
		},

		/**
		 * After navigation to customer fact sheet each table shows busy indicator
		 * until the request for the appropriate table finishes
		 */
		_setBusyIndicatorCustomerModel: function () {
			var oCustomerModel = this.getModel("customerModel");
			//after navigation each table shows a busy indicator
			oCustomerModel.setProperty("/GlobalEscalationsSetBusy", true);
			oCustomerModel.setProperty("/GlobalEscalationRequestsSetBusy", true);
			oCustomerModel.setProperty("/CriticalSituationsSetBusy", true);
			oCustomerModel.setProperty("/MCCActivitiesSetBusy", true);
			oCustomerModel.setProperty("/TopIssuesSetBusy", true);
			oCustomerModel.setProperty("/BusinessDownBusy", true);

			this.getView().byId("customerOverviewTable").setBusy(true);
			this.getView().byId("customerOverviewTableOpenIssues").setBusy(true);
		},

		handleObjectPress: function (oEvent) {
			const sPath = oEvent.getSource().getParent().getBindingContext("customerModel").getPath();
			const oProperty = this.getModel("customerModel").getProperty(sPath);
			const sCaseId = oProperty.ObjectId;
			const oRouter = this.getRouter();

			switch (oProperty.objectType) {
				case Constants.MCCEngagementType.CriticalIncidentManagement:
				case "CIM Requests":
				case "Technical Backoffice Requests":
				case Constants.MCCEngagementType.XTecEngagements:
				case Constants.MCCEngagementType.PECriticalEngagements:
				case Constants.MCCEngagementType.BusinessDownSituations: {
					this._openSosApp(oProperty["sys_id"], "&transType=sn_customerservice_escalation");
					break;
				}
				case "PE Critical Situations":
				case "Global Escalation Request": {
					this._openWindow(oProperty.ObjectLink);
					break;
				}
				case Constants.MCCEngagementType.Major_SAP_Cloud_Downtimes: {
					const sUrl = "https://go.sap.corp/downtime-dashboard#/swatactivationdetails/" + sCaseId;
					this._openWindow(sUrl);
					break;
				}
				case Constants.MCCEngagementType.CrossIssue: {
					this.getRouter().navTo("CrossIssueDetails", {
						"?query": this._getQueryParameter(),
						"objectId": oProperty.ObjectId
					});
					break;
				}
				case Constants.MCCEngagementType.ExecutiveEscalation: {
					const sUrl = formatter.formatEscalationURL(oProperty["sys_id"])
					this._openWindow(sUrl);
					break;
				}
				default: {
					this.getOwnerComponent().getModel("case").setProperty("/reload", true);
					oRouter.navTo("CaseDetails", {
						"?query": this._getQueryParameter(),
						CaseId: sCaseId
					});
				}
			}
		},

		onObjectNewTab: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("customerModel").getPath();
			var oProperty = this.getModel("customerModel").getProperty(sPath);
			var sCaseId = oProperty.ObjectId;

			switch (oProperty.objectType) {
				case Constants.MCCEngagementType.CriticalIncidentManagement:
				case "CIM Requests":
				case "Technical Backoffice Requests":
				case Constants.MCCEngagementType.XTecEngagements:
				case Constants.MCCEngagementType.PECriticalEngagements:
				case Constants.MCCEngagementType.BusinessDownSituations:
				case "PE Critical Situations":
				case "Global Escalation Request":
				case Constants.MCCEngagementType.ExecutiveEscalation:
				case Constants.MCCEngagementType.Major_SAP_Cloud_Downtimes: {
					this.handleObjectPress(oEvent)
					break;
				}
				case Constants.MCCEngagementType.CrossIssue: {
					this._openCrossIssueInNewTab(oProperty.ObjectId);
					break;
				}
				default: {
					this._openCaseInNewTab(sCaseId);
				}
			}

		},

		handleHighPrioCasePress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("customerModel").getPath();
			var oProperty = this.getModel("customerModel").getProperty(sPath);
			//this._openSosApp(oProperty["correlation_id"], "&flag=false&sam=false",true);
			this._openServiceNowTicketURL(oProperty["sys_id"]);
		},

		handleOpenIssuesCasePress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("customerModel").getPath();
			var oProperty = this.getModel("customerModel").getProperty(sPath);


			if (oProperty.objectType === "CIM Requests" || oProperty.objectType === "Technical Backoffice Requests" || oProperty.objectType === "MCC Support Requests" || oProperty.objectType === "CCM Requests" || oProperty.objectType === "CPC Requests") {
				this._openSosApp(oProperty["sys_id"], "&transType=sn_customerservice_escalation");
			} else if (oProperty.ProcessType === "ZS46") {
				this._openSosApp(oProperty.ObjectId, "", true);
			} else {
				this._openWindow(oProperty.ObjectLink);
			}
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("customerModel").getObject();
			var sObjectType = oData.objectType;
			var sId = oData.ObjectId;
			switch (sObjectType) {
				case Constants.MCCEngagementType.CriticalCustomerManagement:
				case Constants.MCCEngagementType.TaskForces:
				case Constants.MCCEngagementType.CriticalPeriodCoverage:
				case "Guided Solution Support":
					this._readCustomerEngagementsNotes(oEv.getSource(), sId, sObjectType);
					break;
				case Constants.MCCEngagementType.TopCriticalCustomers:
					this._readCriticalSituationsNotes(oEv.getSource(), sId, sObjectType);
					break;
				case Constants.MCCEngagementType.CrossIssue:
					this._readCrossIssuesNotes(oEv.getSource(), oData.Guid, sObjectType);
					break;
				case Constants.MCCEngagementType.GlobalEscalation:
					this._readGlobalEscalationsNotes(oEv.getSource(), sId, sObjectType);
					break;
				case Constants.MCCEngagementType.ExecutiveEscalation: {
					this.openQuickInfoWithData(oEv.getSource(), {
						escalationReason: oData["u_business_impact"].replace(/^(\:)/, ""),
						executiveSummary: oData["u_executive_summary"].replace(/^(\:)/, ""),
						reasonTypeHeader: this.getView().getModel("i18n").getProperty("caseEVEngagementReason"),
					}, true);
					break;
				}
				case Constants.MCCEngagementType.CriticalIncidentManagement:
				case "CIM Requests":
				case Constants.MCCEngagementType.BusinessDownSituations:
				case Constants.MCCEngagementType.PECriticalEngagements:
				case Constants.MCCEngagementType.XTecEngagements:
					// not needed, does not have a quick Info popup case "Technical Backoffice Requests":
					this._openServiceNowQuickView(sObjectType, oEv.getSource(), oData);
			}
			this.trackEvent("Status Report: show Popover");
		},

		handleHighPrioStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("customerModel").getObject();
			var sText = oData["business_impact"],
				sText2 = oData["description"];
			new sap.m.Popover({
				title: "Quick Info",
				placement: "PreferredRightOrFlip",
				contentWidth: "40rem",
				content: [
					new sap.m.VBox({
						width: "auto"
					}).addItem(new sap.m.Label({
						design: "Bold",
						text: "Business Impact"
					}).addStyleClass("sapUiTinyMarginBegin"))
						.addItem(new sap.m.FormattedText({
							htmlText: sText
						}).addStyleClass("topIssueStatusSummary"))
						.addStyleClass("smallMarginTop"),
					new sap.m.VBox({
						width: "auto"
					}).addItem(new sap.m.Label({
						design: "Bold",
						text: "Description"
					}).addStyleClass("sapUiTinyMarginBegin")).addItem(new sap.m.FormattedText({
						htmlText: sText2
					}).addStyleClass("topIssueStatusSummary"))
						.addStyleClass("smallMarginTop sapUiSmallMarginBottom")
				]
			}).openBy(oEv.getSource());

			this.trackEvent("Status Report: show Popover");
		},

		_showSubscriptionButtonBasedOnAuth: function (oCustomer) {
			//check if user has general access to at least the aggregation view
			var oSettings = this.getOwnerComponent().getModel("settings").getData();
			if (oSettings.ShowGlobalAggregation) {
				return true;
			} else {
				return false;
			}
		},

		_checkSubscriptionStatusForCustomer: function (sGuErpNo, sErpCustNo) {
			var aFilters = [],
				aTempfilters = [];
			if (sErpCustNo !== "") {
				aTempfilters.push(new Filter("Customer", FilterOperator.Contains, sErpCustNo));
			}
			if (sGuErpNo !== "") {
				aTempfilters.push(new Filter("GlobalUltimate", FilterOperator.Contains, sGuErpNo));
			}
			var oFilter = new Filter({
				filters: aTempfilters,
				and: false
			});
			aFilters.push(oFilter);
			this.getModel("subModel").read("/MailRoles", {
				filters: aFilters,
				sorters: [new sap.ui.model.Sorter("createdAt")],
				success: function (response) {
					if (response.results.length > 0) {
						this.getView().getModel("viewModel").setProperty("/subscriptionID", response.results[0].RoleID);
						this.getView().getModel("viewModel").setProperty("/subscriptionAction", "DELETE");
					} else {
						this.getView().getModel("viewModel").setProperty("/subscriptionID", "");
						this.getView().getModel("viewModel").setProperty("/subscriptionAction", "ADD");
					}
				}.bind(this),
				error: function (err) {
					this.getView().getModel("viewModel").setProperty("/subscriptionID", "");
					this.getView().getModel("viewModel").setProperty("/subscriptionAction", "ERROR");
				}
			});

		},

		triggerSubscription: function () {
			var oSubModel = this.getModel("subModel");
			var sCustomerEngagements = "CCM,CPC";
			var oSettings = this.getOwnerComponent().getModel("settings").getData();
			if (oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations) {
				sCustomerEngagements = "GEM,CCM,CPC,TC2";
			}

			var bindingContext = this.getView().getBindingContext();
			var sCustomerERP = bindingContext.getProperty("ErpCustNo");
			var sGlobalUlimateERP = bindingContext.getProperty("GuErpNo");
			if (sCustomerERP === sGlobalUlimateERP) {
				sCustomerERP = null;
			} else {
				sGlobalUlimateERP = null;
			}

			var that = this;
			if (this.getView().getModel("viewModel").getProperty("/subscriptionAction") === "ADD") {
				oSubModel.create("/MailRoles", {
					RoleType: "SUB",
					Recipients: this.getModel("userapi").getProperty("/email"),
					UserID: this.getModel("userapi").getProperty("/name"),
					CustomerEngagement: sCustomerEngagements,
					Customer: sCustomerERP,
					GlobalUltimate: sGlobalUlimateERP
				}, {
					success: function (response) {
						if (response) {
							that.getView().getModel("viewModel").setProperty("/subscriptionID", response.RoleID);
						}
						that.getView().getModel("viewModel").setProperty("/subscriptionAction", "DELETE");
					},
					error: function (err) {
						that.getView().getModel("viewModel").setProperty("/subscriptionID", "");
					}
				});
				this.trackEvent("Subscription: Customer Add");
			} else if (this.getView().getModel("viewModel").getProperty("/subscriptionAction") === "DELETE") {
				oSubModel.remove("/MailRoles(guid'" + this.getView().getModel("viewModel").getProperty("/subscriptionID") + "')", {
					success: function (response) {
						that.getView().getModel("viewModel").setProperty("/subscriptionAction", "ADD");
						that.getView().getModel("viewModel").setProperty("/subscriptionID", "");
					},
					error: function (err) {
						that.getView().getModel("viewModel").setProperty("/subscriptionID", "");
					}
				});
			}

		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("customerModel").getObject();
			var sCaseId = oProperty.ObjectId;
			this._shopTopIssuesCountPopover(sCaseId, oEv.getSource());
		},

		handleTabBarSelectHighPrioTickets: function (oEv) {
			var sKey = oEv.getParameter("key");
			this._filterTableHighPrioTicketss(sKey, "");
		},
		_filterTableHighPrioTicketss: function (sKey, sPieChartSelection) {
			var oTableBinding = this.getView().byId("customerOverviewTableHighPrioTickets").getBinding("rows");
			var aFilters = [];

			var oFilter = {};
			switch (sKey) {
				case 'VeryHighTickets':
					oFilter = new Filter("priority", FilterOperator.EQ, "Very High");
					break;
				case "HighTickets":
					oFilter = new Filter("priority", FilterOperator.EQ, "High");
					break;
			}

			if (!jQuery.isEmptyObject(oFilter)) {
				aFilters.push(oFilter);
			}

			if (aFilters.length > 0) {
				oTableBinding.filter(aFilters);
			} else {
				oTableBinding.filter();
			}

			//now update counts
			//this._updateFilterCountsOpenIssues(sKey, sPieChartSelection);

		},
		onOpenEarlyWatchAlertWorkspace: function (sERPNumber) {
			var sUrl = this.getResourceBundle().getText("ewaURL") + this._addLeadingZeros(sERPNumber);
			return sUrl;
			//var win = window.open("https://" + "launchpad.support.sap.com/#/ewaworkspace/" + , "_blank");
			// win.opener = null;
			// win.focus();
		},
		onOpenMCCMissionRadar: function (sERPNumber) {
			//var sUrl = this.getResourceBundle().getText("mccMissionRadarURL") + this._addLeadingZeros(sERPNumber) + "%22%5D";
			var sUrl = this.getResourceBundle().getText("mccMissionRadarURL") + this.pad(sERPNumber, 10) + "&page=25531575-1196-4236-9ffb-815c95f5af1f&mode=view&f01Model=t.3:Ccktks07u5dfgma9urn1gm6h969&f01Dim=CUSTOMER_ID";
			return sUrl;
		},
		onOpenCloudReporting: function (Gu) {
			var sUrl = this.getResourceBundle().getText("cloudReportingURL") + Gu; //this._addLeadingZeros(sERPNumber) + "%22%5D";
			return sUrl;
		},
		onOpenIntelligentWorkplace: function (Gu) {
			var sUrl = this.getResourceBundle().getText("intelligentWorkplaceURL") + this._addLeadingZeros(Gu);
			return sUrl;
		},
		onOpenESRCockpit: function (Gu) {
			var sUrl = this.getResourceBundle().getText("esrCockpitURL");
			return sUrl;
		},

		_calculateDurationBetweenDates: function (start, end) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyyMMddHHmmss"
			});
			if (start && start !== "0") {
				var dStart = dateFormat.parse(start);
				var dEnd = end && end !== "0" ? dateFormat.parse(end) : new Date();
				var sResult = "";

				var diffInSeconds = Math.abs(dEnd - dStart) / 1000;
				var days = Math.floor(diffInSeconds / 60 / 60 / 24);
				var hours = Math.floor(diffInSeconds / 60 / 60 % 24);
				var minutes = Math.floor(diffInSeconds / 60 % 60);
				var seconds = Math.floor(diffInSeconds % 60);

				sResult += days > 0 ? days + "d" + " " : "";
				sResult += hours > 0 ? hours + "h" + " " : "";
				sResult += minutes > 0 ? minutes + "m" + " " : "";
				sResult += seconds > 0 ? seconds + "s" : "";

				return sResult;
			}
			return "";
		},

		onPressImpactedLob: function (oEv) {
			var oUrlParameters = {
				"$select": "MasterEventID,LoBID,LoBName",
				"$top": "100"
			};
			var oInput = oEv.getSource();
			var sId = oEv.getSource().getBindingContext("customerModel").getObject().MasterEventID;
			var aFilter = [new Filter("MasterEventID", FilterOperator.EQ, sId)];
			var oOutagesModel = this.getOwnerComponent().getModel("outageMainModel");
			if (oOutagesModel.isMetadataLoadingFailed()) {
				this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				return null;
			}
			var aSorter = [];
			aSorter.push(new sap.ui.model.Sorter("LoBName", false));

			oInput.setBusy(true);
			oOutagesModel.read("/GetSwatOutageAffectedLoBs", {
				urlParameters: oUrlParameters,
				filters: [new Filter(aFilter, true)],
				sorters: aSorter,
				success: function (data) {
					oInput.setBusy(false);
					if (data.results.length > 0) {
						var s = this.joinObj(data.results, "LoBName");
						this._openPopover("Impacted LoBs", s, oInput);
					}
				}.bind(this),
				error: function (data) {
					oInput.setBusy(false);
				}.bind(this)
			});
		},

		onPressImpactedCustomers: function (oEv) {
			var oData = oEv.getSource().getBindingContext("customerModel").getObject();
			if (oData.objectType === Constants.MCCEngagementType.CrossIssue) {
				this._openPopover("Impacted Customers", oData.toAffCustomers.results);
			} else {
				this._loadImpactedCustomersForOutages(oEv);
			}
		},

		_loadImpactedCustomersForOutages: function (oEv) {
			var oUrlParameters = {
				"$select": "MasterEventID,CustomerCRMID,CustomerERPID,CustomerName,CustomerGlobalRegionCode,CustomerGlobalRegionName,CustomerIndustryCode,CustomerIndustryName",
				"$top": "100"
			};
			var oInput = oEv.getSource();
			var sId = oEv.getSource().getBindingContext("customerModel").getObject().MasterEventID;
			var aFilter = [new Filter("MasterEventID", FilterOperator.EQ, sId)];
			var oOutagesModel = this.getOwnerComponent().getModel("outageMainModel");
			if (oOutagesModel.isMetadataLoadingFailed()) {
				this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				return null;
			}
			var aSorter = [];
			aSorter.push(new sap.ui.model.Sorter("CustomerName", false));

			oInput.setBusy(true);
			oOutagesModel.read("/GetSwatOutageAffectedCustomers", {
				urlParameters: oUrlParameters,
				filters: [new Filter(aFilter, true)],
				sorters: aSorter,
				success: function (data) {
					oInput.setBusy(false);
					if (data.results.length > 0) {
						this._openPopover("Impacted Customers", data.results);
					}
				}.bind(this),
				error: function (data) {
					oInput.setBusy(false);
				}.bind(this)
			});
		},

		_openPopover: function (title, aItems) {
			var oModel = new sap.ui.model.json.JSONModel();
			var oData = {
				"title": title,
				"items": []
			};
			//map values for model
			aItems.forEach(function (val) {
				var sCustCrm = "";
				var sCustErp = "";
				if (title === "Impacted Customers") {
					if (val.Partner !== "") {
						sCustCrm = "BP ID: " + val.Partner;
					}
					if (val.ErpCustNo !== "") {
						sCustErp = "ERP ID: " + val.ErpCustNo;
					}
				}

				oData.items.push({
					"type": title === "Impacted Customers" ? "cust" : "lob",
					"title": val.Name1 + " " + val.Name2,
					"custCrm": sCustCrm,
					"custErp": sCustErp
				});
			});
			oModel.setData(oData);
			Fragment.load({
				name: "com.sap.mcconedashboard.view.fragment.OutagesDialogList",
				controller: this
			}).then(function (oDialog) {
				oDialog.setModel(oModel, "data");
				this.getView().addDependent(oDialog);
				oDialog.open();
			}.bind(this));
		},

		onNavToCustomerView: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("data").getObject().custErp.substring(8);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oEv.getSource().getParent().close();
			oEv.getSource().getParent().destroy();
			this.getRouter().navTo("Customer", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		onListSearch: function (oEv) {
			var sQuery = oEv.getParameter("newValue");
			var oList = sap.ui.getCore().byId("outagesList");
			var aFilters = [];
			if (sQuery && sQuery.length > 0) {
				aFilters.push(new Filter([
					new Filter("title", FilterOperator.Contains, sQuery),
					new Filter("custCrm", FilterOperator.Contains, sQuery),
					new Filter("custErp", FilterOperator.Contains, sQuery)
				]));
			}
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		onListClose: function (oEv) {
			oEv.getSource().getParent().close();
			oEv.getSource().getParent().destroy();
		},

		onObjectTypePress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("customerModel").getObject().objectType;
			sObjectType = sObjectType.split("Closed ").join("");
			sObjectType = sObjectType.split(" (Activities)").join("");
			var sMsg = this._getObjectTypeInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		},

		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("customerModel").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		},

		customSorting: function (oEvent) {
			var oMCCiColumn = this.byId("mcci");
			var oPreventionScoreColumn = this.byId("preventionScore");
			var oCurrentColumn = oEvent.getParameter("column");
			if (oCurrentColumn !== oMCCiColumn && oCurrentColumn !== oPreventionScoreColumn) {
				return;
			}
			oEvent.preventDefault();
			var sOrder = oEvent.getParameter("sortOrder");
			this.customSortingBaseFloat(oCurrentColumn, sOrder, "customerOverviewTable");
		},

		_escalationsExpandToLastNotes: function (oCase, resolve, reject) {
			var oModel = this.getModel();
			oModel.read("/GlobalEscalationsSet('" + oCase.ObjectId + "')/toLastNotes", {
				success: function (data) {
					oCase.toLastNotes = data;
					resolve();
				}.bind(this),
				error: function (error) {
					console.log(error);
					reject();
				}.bind(this)

			});
		},

		_criticalSituationExpandToLastNotes: function (oCase, resolve, reject) {
			var oModel = this.getModel();
			oModel.read("/CustomerEngagementSet('" + oCase.ObjectId + "')/toLastNotes", {
				success: function (data) {
					oCase.toLastNotes = data;
					resolve();
				}.bind(this),
				error: function (error) {
					console.log(error);
					reject();
				}.bind(this)
			});
		},

		removeUserData: function (oDataSet) {
			const aProductFilter = ["CaseId", "__metadata"];
			const aNoteFilter = ["CaseGuid", "CaseId", "CreatedBy", "CreatedByName", "Tdname", "__metadata", "NoteType", "NoteTypeT", "Tdobject"]
			oDataSet['EscalationCases'].forEach((EscalationCase) => {
				var aFilter = ["ObjectLink", "ObjectId", "ServiceOrg", "CustomerName", "CustomerNo", "Processor", "ProcessorLink",
					"ServiceTeam", "EmplRespName", "ResponsibleId", "ImplementationPartner", "toNotes", "CaseGuid",
					"CaseTag", "Country", "CountryT", "CustomerCrmNp", "Gu", "GuErpNo", "GuText", "ProcessorId",
					"Region", "__metadata"];
				aFilter.forEach(key => delete EscalationCase[key])


				EscalationCase.toLastNotes.results.forEach((oNote) => {
					aNoteFilter.forEach((filter) => delete oNote[filter]);
				});

				EscalationCase.toProducts.results.forEach((oNote) => {
					aProductFilter.forEach((filter) => delete oNote[filter]);
				});

			});

			oDataSet['EngagementCases'].forEach((EngagementCase) => {
				var aFilter = ["ObjectId", "SalesRegion", "BcpIncId", "BcpIncUrl", "Country", "CountryT", "CustomerName", "CustomerNo",
					"escalation_justification", "EmplRespName", "EmplRespUser", "Processor", "ProcessorId", "ProcessorLink",
					"EscalationRecordId", "Requestor", "RequestorId", "SysId", "BcpIdUrl", "BcpID", "ServiceTeam", "ObjectLink",
					"toNotes", "CaseGuid", "CustomerCrmNo", "CustomerGuid", "CustomerType", "Gu", "GuText", "ResponsibleId",
					"SalesOrg", "SalesOrgT", "ServiceOrg"]
				aFilter.forEach((filter) => delete EngagementCase[filter]);

				EngagementCase.toLastNotes.results.forEach((oNote) => {
					aNoteFilter.forEach((filter) => delete oNote[filter]);
				});

				EngagementCase.toProducts.results.forEach((oNote) => {
					aProductFilter.forEach((filter) => delete oNote[filter]);
				})
			})
		},

		//Begin of Go Lives Section Functions (Mission Radar)

		//Read GoLives
		updateGoLivesFromHPI: function () {
			this.getView().getModel("viewModel").setProperty("/bLoadingStateGoLives", true);
			var oModel = new sap.ui.model.json.JSONModel();
			this.getOwnerComponent().setModel(oModel, "customerGoLivesData");

			var readMissionRadarGoLivesPromise = new Promise((resolve, reject) => {
				this.readMissionRadarGoLives(oModel, function (error) {
					if (error) {
						reject(error); // Reject the Promise if an error occurs
					} else {
						var oData = oModel.getData();
						if (oData && oData.items && Array.isArray(oData.items)) {
							oData.items.forEach(function (item) {
								item.Source = "HPI";
							});
						}
						resolve(); // Resolve the Promise, when function is done
					}
				});
			});

			readMissionRadarGoLivesPromise.then(() => {
				this.addGoLivesFromMCC(oModel);
			}).catch((error) => {
				console.error("Error occurred while reading mission radar go lives:", error);
				this.addGoLivesFromMCC(oModel);
			});
		},


		readMissionRadarGoLives: function (oModel, callback) {
			var sErpCustNo = this.sErpCustNo;
			var sGuErpNo = this.GuErpNo;
			var sGuNo = this.GuNo;

			// General Filter, always used
			//we need submit todays date in format "2022-09-23" and add 90 days
			var goLiveDate = new Date();
			goLiveDate.setDate(goLiveDate.getDate() + 90);
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			goLiveDate = oFormat.format(goLiveDate);

			var today = new Date(); //("2022-10-28");
			today = oFormat.format(today);

			var pastDate = new Date();
			pastDate.setDate(pastDate.getDate() - 30);
			pastDate = oFormat.format(pastDate);

			var filterConditionGE = {
				operand1: { elementIdentifier: "Calculated_Go_Live_Date" },
				operand2: { values: [pastDate] },
				operator: "GE"
			};

			var filterConditionLE = {
				operand1: { elementIdentifier: "Calculated_Go_Live_Date" },
				operand2: { values: [goLiveDate] },
				operator: "LE"
			};

			var combinedFilterDate = {
				filters: [filterConditionGE, filterConditionLE],
				conjunctionOperator: "AND"
			};

			if (sErpCustNo) {
				var sErpCustWithZeros = this._addLeadingZeros(sErpCustNo);
				var sGuWithZeros = this._addLeadingZeros(sGuNo);
				var sGuErpWithZeros = this._addLeadingZeros(sGuErpNo);
				var combinedCustomerFilter = {};

				if (this.isGlobalUltimate == "X") {

					var filterConditionGlobalCustomer = {
						operand1: { elementIdentifier: "Customer_Global_Ultimate_CRM_ID" },
						operand2: { values: [sGuWithZeros] },
						operator: "EQ"
					};

					combinedCustomerFilter = {
						filters: [filterConditionGlobalCustomer],
						conjunctionOperator: "OR"
					};

				} else {

					var filterConditionCustomer = {
						operand1: { elementIdentifier: "Customer_ERP_ID" },
						operand2: { values: [sErpCustWithZeros] },
						operator: "EQ"
					};

					combinedCustomerFilter = {
						filters: [filterConditionCustomer],
						conjunctionOperator: "OR"
					};

				}
			}

			var combinedFilter = {
				filters: [combinedFilterDate, combinedCustomerFilter],
				conjunctionOperator: "AND"
			};


			if (DebugMode == true) {


				//DEVELOPMENT
				$.ajax({
					url: "./json/MissionRadar/missionRadarGoLives.json",
					type: "GET",
					dataType: "json",
					success: function (data) {
						var items = data.queryResults.API_Call_Only_Wave_for_MCC.rows;
						oModel.setData({ items: items });
						oModel.refresh();

						if (callback && typeof callback === "function") {
							callback();
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						sap.m.MessageToast.show("Can't read JSON");

						if (callback && typeof callback === "function") {
							callback();
						}
					}
				});

			} else {

				//PROD
				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([
						{
							"queryIdentifier": "API_Call_Only_Wave_for_MCC",
							"elementList": [
								"Calculated_Go_Live_Date",
								"Next_Renewal_Date",
								"Customer_CRM_ID",
								"Customer_ERP_ID",
								"Customer",
								"Customer_Global_Ultimate",
								"Customer_Country",
								"Solution_Area",
								"Sub_Solution_Area",
								"Customer_Region",
								"Customer_Market_Unit",
								"Wave_Go_Live_Next_90_Days_Flag",
								"Project_ID",
								"Customer_Global_Ultimate_CRM_ID",
								"Customer_Global_Ultimate"
							],
							"filters": [combinedFilter],
							//"top": 100,
							//"skip": 0
						}]),
					contentType: "application/json",
					success: function (data) {
						var items = data.queryResults.API_Call_Only_Wave_for_MCC.rows;
						oModel.setData({ items: items });
						oModel.refresh();

						if (callback && typeof callback === "function") {
							callback();
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						console.log("Error while fetching data from API");

						if (callback && typeof callback === "function") {
							callback();
						}
					}
				});

			}

		},

		addGoLivesFromMCC: function (oHPIModel) {
			var oMCCModel = new sap.ui.model.json.JSONModel();
			this.getOwnerComponent().setModel(oMCCModel, "customerGoLivesDataMCC");
			var that = this;

			var readMissionRadarGoLivesFromMCCPromise = new Promise((resolve) => {
				var oMCCModel = new sap.ui.model.json.JSONModel();
				that.getOwnerComponent().setModel(oMCCModel, "customerGoLivesDataMCC");
				that.readMissionRadarGoLivesFromMCC(oMCCModel, function () {
					var oDataMCC = oMCCModel.getData();
					if (oDataMCC && oDataMCC.items && Array.isArray(oDataMCC.items)) {
						oDataMCC.items.forEach(function (item) {
							item.Source = "MCC";

							// Renaming
							item.Calculated_Go_Live_Date = item.Overview_Go_Live_Date;
							item.Customer_ERP_ID = item.Customer_ERP_Account_ID;
							item.Customer = item.Customer_ERP_Account;
							item.Customer_Global_Ultimate = item.Global_Ultimate;
							item.Customer_Country = item.Case_Main_Partner_Country;
							item.Product = item.PPMS_Product_Name;
							item.Customer_Region = that.getRegionByCountry(item.Case_Main_Partner_Country);

							// Deleting Old Names
							delete item.Overview_Go_Live_Date;
							delete item.Customer_ERP_Account_ID;
							delete item.Global_Ultimate;
							delete item.Case_Main_Partner_Country;
							delete item.Customer_ERP_Account;
							delete item.PPMS_Product_Name;
						});

						// Add MCC-Data into HPI-Model
						var oDataHPI = oHPIModel.getData();
						if (!oDataHPI.items) {
							oDataHPI.items = [];
						}
						oDataHPI.items = oDataHPI.items.concat(oDataMCC.items);

						// Sort Calculated_Go_Live_Date and then Customer_ERP_Account_ID
						oDataHPI.items.sort(function (a, b) {
							var dateA = a.Calculated_Go_Live_Date.key ? new Date(a.Calculated_Go_Live_Date.key) : null;
							var dateB = b.Calculated_Go_Live_Date.key ? new Date(b.Calculated_Go_Live_Date.key) : null;

							if (!dateA && !dateB) return 0;
							if (!dateA) return -1;
							if (!dateB) return 1;

							if (dateA < dateB) return -1;
							if (dateA > dateB) return 1;

							// If dates are equal, compare Customer_ERP_IDs
							return a.Customer_ERP_ID.key.localeCompare(b.Customer_ERP_ID.key);
						});

						oHPIModel.refresh();
					}

					resolve();
				});
			});

			readMissionRadarGoLivesFromMCCPromise.then(() => {
				that.getView().getModel("viewModel").setProperty("/bLoadingStateGoLives", false);
				if (oHPIModel.getData().items) {
					that.getView().getModel("customerModel").setProperty("/AmountAllGoLives", oHPIModel.getData().items.length);
				} else {
					that.getView().getModel("customerModel").setProperty("/AmountAllGoLives", 0);
				}
				//that.updateGoLiveMCCiTrend(oHPIModel); // Run updateGoLiveMCCiTrend, when readMissionRadarGoLivesFromMCC is resolved
			});
		},


		readMissionRadarGoLivesFromMCC: function (oModel, callback) {
			//we need submit todays date in format "2022-09-23" and add 90 days
			var goLiveDate = new Date();
			goLiveDate.setDate(goLiveDate.getDate() + 90);
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			goLiveDate = oFormat.format(goLiveDate);

			var today = new Date(); //("2022-10-28");
			today = oFormat.format(today);

			var pastDate = new Date();
			pastDate.setDate(pastDate.getDate() - 30);
			pastDate = oFormat.format(pastDate);

			var filterConditionGE = {
				operand1: { elementIdentifier: "Overview_Go_Live_Date" },
				operand2: { values: [pastDate] },
				operator: "GE"
			};

			var filterConditionLE = {
				operand1: { elementIdentifier: "Overview_Go_Live_Date" },
				operand2: { values: [goLiveDate] },
				operator: "LE"
			};

			var filterConditionNE = {
				operand1: { elementIdentifier: "Case_Status" },
				operand2: { values: ["90"] },
				operator: "NE"
			}

			var sErpCustNo = this.sErpCustNo;
			var sGuErpNo = this.GuErpNo;

			if (sErpCustNo) {
				var sErpCustNoZeros = this._addLeadingZeros(sErpCustNo);
				var sGuErpNoZeros = this._addLeadingZeros(sGuErpNo);
				var combinedCustomerFilter = {};

				if (this.isGlobalUltimate == "X") {

					var filterConditionGlobalCustomer = {
						operand1: { elementIdentifier: "GU_ERP_Account_ID" },
						operand2: { values: [sGuErpNoZeros] },
						operator: "EQ"
					};

					combinedCustomerFilter = {
						filters: [filterConditionGlobalCustomer],
						conjunctionOperator: "OR"
					};

				} else {

					var filterConditionCustomer = {
						operand1: { elementIdentifier: "Customer_ERP_Account_ID" },
						operand2: { values: [sErpCustNoZeros] },
						operator: "EQ"
					};

					combinedCustomerFilter = {
						filters: [filterConditionCustomer],
						conjunctionOperator: "OR"
					};

				}

			}

			var combinedFilter = {
				filters: [filterConditionGE, filterConditionLE, filterConditionNE, combinedCustomerFilter]
			};

			if (DebugMode == true) {

				//DEVELOPMENT
				$.ajax({
					url: "./json/MissionRadar/missionRadarGoLivesFromMCC.json",
					type: "GET",
					dataType: "json",
					data: {
						$filter: "Overview_Go_Live_Date ge '" + today + "' and Overview_Go_Live_Date le '" + goLiveDate + "' and Case_Status ne '90' and Customer_ERP_Account_ID eq '" + this.sErpCustNo + "'"
					},
					success: function (data) {
						var items = data.queryResults.CL_ENG_CASES_ONEDASHBOARD.rows;
						oModel.setData({ items: items });
						oModel.refresh();

						if (callback && typeof callback === "function") {
							callback();
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						sap.m.MessageToast.show("Can't read JSON");

						if (callback && typeof callback === "function") {
							callback();
						}
					}
				});

			} else {

				//PROD
				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([
						{
							"queryIdentifier": "CL_ENG_CASES_ONEDASHBOARD",
							"filters": [combinedFilter],
							//"top": 100,
							//"skip": 0
						}]),
					contentType: "application/json",
					success: function (data) {
						var items = data.queryResults.CL_ENG_CASES_ONEDASHBOARD.rows;
						oModel.setData({ items: items });
						oModel.refresh();

						if (callback && typeof callback === "function") {
							callback();
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						console.log("Error while fetching data from API");

						if (callback && typeof callback === "function") {
							callback();
						}
					}
				});

			}
		},

		getRegionByCountry: function (oCountry) {
			var oRegion = [];
			var aRegionHelp = this.getModel("countryRegionModel").getData();
			// Find Entry in the Array, which fits the Country
			const countryEntry = aRegionHelp.RegionHelp.find(entry => entry.country === oCountry.title);

			if (countryEntry) {
				switch (countryEntry.region) {
					case "EMEA":
						if (countryEntry.subsubregion == "EMEA South") {
							oRegion.title = "EMEA South";
							oRegion.key = "EMS";
							break;
						}
						if (countryEntry.subsubregion == "EMEA North") {
							oRegion.title = "EMEA North"
							oRegion.key = "EMS";
							break;
						}
						if (countryEntry.subregion == "MEE") {
							oRegion.title = "Middle and Eastern Europe"
							oRegion.key = "MEE";
							break;
						}
					case "NA":
						oRegion.title = "North America";
						oRegion.key = "NA";
						break;
					case "APJ":
						if (countryEntry.subregion == "GTC") {
							oRegion.title = "Greater China"
							oRegion.key = "GCH";
							break;
						} else {
							oRegion.title = "Asia Pacific Japan";
							oRegion.key = "APJ";
							break;
						}
					case "LAC":
						oRegion.title = "Latin America";
						oRegion.key = "LA";
						break;
					default:
						break;
				}
			}

			return oRegion;
		},

		onSourcePress: function (oEv) {
			var isAnonymized = this.getModel("settings").getProperty("/isAnonymizedMode");
			var oBindingContext = oEv.getSource().getBindingContext("customerGoLivesData");

			if (oBindingContext) {
				if (oBindingContext.getObject().Source == "HPI") {
					if (!isAnonymized) {
						var sHPICustProjNr = oBindingContext.getObject().Project_ID.title;
						var sUrl = this.getResourceBundle().getText("mccMissionRadarHPICustomerURL") + sHPICustProjNr;
						this._openWindow(sUrl);
						sap.m.MessageToast.show("Showing link in new tab");
					} else {
						sap.m.MessageToast.show("Can't open HPI because Anonymized Mode is active");
					}
				} else if (oBindingContext.getObject().Source == "MCC") {
					var sCaseId = oBindingContext.getObject().Case_ID.key;
					this.getOwnerComponent().getModel("case").setProperty("/reload", true);
					this.getRouter().navTo("CaseDetails", {
						"CaseId": sCaseId,
						"?query": this._getQueryParameter()
					});
				}
			}

		},

		// AI Implementation Section

		loadAiSummaryForCustomer: function (oEv) {
			//this.getView().getModel("viewModel").setProperty("/bLoadingStateAISummary", true);
			var oCustomerModel = this.getModel("customerModel");
			var oFeatureFlagsModel = this.getModel("featureFlags");
			oCustomerModel.setProperty("/AISummaryBusy", true);
			var sErpCustNo = this._addLeadingZeros(this.sErpCustNo);

			if (!this.getView().getModel("oLanguageModel")) {
				var oLanguageModel = TranslationConnector.createLanguageModel(this.getView().getModel("userProfile"));
				this.getView().setModel(oLanguageModel, "oLanguageModel");
			}


			// Check if there is already an AISummary
			if (oCustomerModel && !oCustomerModel.getProperty("/AISummary")) {
				// Use the ScenarioID from the ccsPreview FeatureFlag
				if (oFeatureFlagsModel && oFeatureFlagsModel.getProperty("/ccsPreview") && (oFeatureFlagsModel.getProperty("/ccsPreview") !== true)) {
					var requestData = {
						//"inputID": sErpCustNo, OLD APPROACH
						"ScenarioID": oFeatureFlagsModel.getProperty("/ccsPreview"),
						"CustomBody": {
							"jsonEncoded": "{\"customerID\":\"" + sErpCustNo + "\"}"
						}
					};
					var mcccacheKey = oFeatureFlagsModel.getProperty("/ccsPreview") + "_" + sErpCustNo;
				} else {
					var requestData = {
						//"inputID": sErpCustNo,
						"ScenarioID": "9649ee30-0204-4e9c-aaf8-04a96ff0cc07",
						"CustomBody": {
							"jsonEncoded": "{\"customerID\":\"" + sErpCustNo + "\"}"
						}
					};
					var mcccacheKey = "9649ee30-0204-4e9c-aaf8-04a96ff0cc07_" + sErpCustNo;
				}

				sap.m.MessageToast.show(this.getView().getModel("i18n").getProperty("customerIntelligentSummaryFetchingAI"));
				var ajaxPromise = new Promise(function (resolve, reject) {
					$.ajax({
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/mcc-aimanager/odata/v4/MCCAIManager/processScenario", //"/apimcf/mcc-aiservice/odata/v4/MCCAIManagerService/getAISummary",
						method: "POST",
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU" //,
							//"mcccachekey": mcccacheKey
						},
						contentType: "application/json",
						data: JSON.stringify(requestData),
						success: function (data, textStatus, jqXHR) {
							resolve(data);
						},
						error: function (oError) {
							Logger.error("Error while retrieving AI Summary", "", "", oError);
							sap.m.MessageBox.error(oError.responseJSON.error.message + "Can't reach AI-Service currently. Please try again later.", {
								title: "Error " + oError.status
							});
							reject(oError);
						}
					});
				});

				// Wait for Response
				ajaxPromise.then(function (data) {
					oCustomerModel.setProperty("/AISummary", data);
					this.openGPTReportPopover(oEv);
					oCustomerModel.setProperty("/AISummaryBusy", false);
				}.bind(this)).catch(function (error) {
					oCustomerModel.setProperty("/AISummaryBusy", false);
					console.error("Can't load GPT Response:", error);
				}.bind(this));
			} else if ((oCustomerModel && oCustomerModel.getProperty("/AISummary"))) {
				this.openGPTReportPopover(oEv);
				oCustomerModel.setProperty("/AISummaryBusy", false);
			}
		},


		openGPTReportPopover: function (oEv) {
			var oCustomerModel = this.getModel("customerModel");
			var sMessage;
			var oAISummary;
			if (oCustomerModel.getProperty("/AISummary")) {
				oAISummary = oCustomerModel.getProperty("/AISummary");
				sMessage = oCustomerModel.getProperty("/AISummary/responseText");
			} else {
				sMessage = "Can't load AI Summary for this customer"
			}

			if (!oCustomerModel.getProperty("/AISummary/responseID")) {
				this.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", true);
			} else {
				this.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", false);

			}

			if (!this.GPTDialogPopover) {
				this.GPTDialogPopover = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.GPTReport", this);
				this.getView().addDependent(this.GPTDialogPopover);
			}

			oCustomerModel.sMessage = sMessage;
			oCustomerModel.sOriginalMessage = sMessage;
			oCustomerModel.bIsTranslated = false;
			oCustomerModel.oAISummary = oAISummary;
			this.GPTDialogPopover.setModel(new sap.ui.model.json.JSONModel(
				oCustomerModel
			), "data");
			this.GPTDialogPopover.openBy(oEv.getSource());
			this.trackEvent("AI Summary: show Popover");

		},

		handleFeedbackChange: function (oEv) {
			this.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", true);
			var iRating = oEv.getParameter("value");
			var oModel = oEv.getSource().getModel("data");
			var oFeatureFlagsModel = this.getModel("featureFlags");
			var that = this;
			if (oModel.getProperty("/oAISummary")) {
				var sResponseID = oModel.getProperty("/oAISummary/responseID");

				if (sResponseID) {
					this.trackEvent("AI Summary: Feedback");
					// Use the ScenarioID from the ccsPreview FeatureFlag
					if (oFeatureFlagsModel && oFeatureFlagsModel.getProperty("/ccsPreview") && (oFeatureFlagsModel.getProperty("/ccsPreview") !== true)) {
						var requestData = {
							"Body": {
								"scenarioID": oFeatureFlagsModel.getProperty("/ccsPreview"),
								"xPlainID": sResponseID,
								"rating": iRating,
								"comment": ""
							}
						};
					} else {
						var requestData = {
							"Body": {
								"scenarioID": "9649ee30-0204-4e9c-aaf8-04a96ff0cc07",
								"xPlainID": sResponseID,
								"rating": iRating,
								"comment": ""
							}
						};
					}

					$.ajax({
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/mcc-aimanager/odata/v4/MCCAIManager/postFeedback",
						method: "POST",
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						contentType: "application/json",
						data: JSON.stringify(requestData),
						success: function (textStatus, jqXHR) {
							that.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", true);
							sap.m.MessageToast.show("Feedback submitted successfully");

						},
						error: function (jqXHR, textStatus, errorThrown) {
							that.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", false);
							console.error("Can't load GPT Response:", textStatus, errorThrown);
							sap.m.MessageToast.show("Feedback could not be submitted");

						}
					});
				}

			} else {
				that.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", true);
			}
		},

		handleTranslationPress: async function (oEv) {
			let translation;
			let oDataModel = this.GPTDialogPopover.getModel("data");
			let oLanguageModel = this.getView().getModel("oLanguageModel");
			let sSelectedKey = oLanguageModel.getProperty("/preselectedOption");
			if (oDataModel.oData.bIsTranslated) {
				oDataModel.oData.sMessage = oDataModel.oData.sOriginalMessage;
				oDataModel.oData.bIsTranslated = false;
			} else {
				try {
					translation = await TranslationConnector.translateText(oDataModel.oData.sOriginalMessage, sSelectedKey);
					oDataModel.oData.sMessage = translation;
					oDataModel.oData.bIsTranslated = true;
				} catch (error) {
					var errorMessage = "An unknown error occurred.";
					if (!!error.responseJSON && !!error.responseJSON.error && !!error.responseJSON.error.code) {
						errorMessage = error.responseJSON.error.message;
					} else {
						if (typeof error === 'object' && error.message) {
							errorMessage = "An unknown error occurred: " + error.message;
						}
					}
					MessageBox.error(errorMessage);
				}
			}
			oDataModel.refresh(true)
		},

		//Customer Tags Section

		_openCustomerTagsView: function (oEvent) {
			var oRouter = this.getRouter();
			var sPath = oEvent.getSource().getBindingContext().getPath();
			var oTag = oEvent.getSource().getModel().getProperty(sPath);
			var sTagName = oTag.Name;
			oRouter.navTo("CustomerTags", {
				"?query": this._getQueryParameterForCustomerTags(sTagName)
			});
		},

		_getQueryParameterForCustomerTags: function (sTagName) {
			var oParameter = {}
			if (this.getModel("settings").getProperty("/isAnonymizedMode")) {
				oParameter["isAnonymizedMode"] = "true";
			}

			if (sTagName) {
				oParameter["tags"] = sTagName;
			}

			return oParameter;
		},

		onCustomerTagsPress: function () {
			var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			var oCustomerModel = this.getModel("customerModel");
			var sTitle = oResourceBundle.getText("customerTags");
			var sErpCustNo = oCustomerModel.getProperty("/ErpCustNo");
			var oSubModel = this.getOwnerComponent().getModel("subModel");
			var sUserID = this.getModel("userapi").getProperty("/name");
			var that = this;

			// Get customer tags data from the model
			var aCustomerTags = oCustomerModel.getProperty("/customerTags");

			var oList = new sap.m.List({
				items: {
					path: "/customerTags",
					template: new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Center",
								justifyContent: "SpaceBetween",
								items: [
									new sap.m.Link({
										text: "{Title}",
										press: function (oEvent) {
											that._openCustomerTagsView(oEvent);
										}
									}).addStyleClass("sapUiTinyMarginBegin"),
									new sap.m.Button({
										icon: "sap-icon://delete",
										type: "Transparent",
										press: function (oEvent) {
											that._deleteCustomerTagPress(oEvent, oModel);
										}
									}).addStyleClass("sapUiTinyMarginEnd")
								]
							})
						]
					})
				},
				noDataText: oResourceBundle.getText("noCustomerTagsFound")
			});

			oList.setModel(oCustomerModel);

			if (aCustomerTags && aCustomerTags.length > 0) {
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(aCustomerTags);
			}

			var oAddButton = new sap.m.Button({
				text: "Add",
				type: "Emphasized",
				press: function () {
					// Open the second dialog for adding a new tag
					var oInput = new sap.m.Input({
						placeholder: oResourceBundle.getText("addTagPlaceholder"),
					});

					var oNewTagDialog = new sap.m.Dialog({
						title: "Add Customer Tag",
						contentWidth: "300px",
						content: oInput,
						endButton: new sap.m.Button({
							text: oResourceBundle.getText("close"),
							press: function () {
								oNewTagDialog.close();
							}
						}),
						beginButton: new sap.m.Button({
							text: "Add",
							type: "Emphasized",
							press: function () {
								// Get the input value and add it to the list
								var sNewTag = oInput.getValue();
								if (sNewTag) {
									var sToday = new Date();
									oSubModel.create("/MCCTags", {
										createdAt: sToday,
										createdBy: sUserID,
										modifiedAt: sToday,
										modifiedBy: sUserID,
										Name: sNewTag.toLowerCase(),
										Title: sNewTag,
										CustomerID: sErpCustNo,
										ShowInOneDashboard: true,
										Type: "Customer"

									}, {
										success: function (response) {
											sap.m.MessageToast.show("Successfully added Tag '" + sNewTag + "'");
											that._readCustomerTags(sErpCustNo, oModel);

										},
										error: function (error) {
											sap.m.MessageToast.show("Failed to create Tag");
										}
									});

									oNewTagDialog.close();
								}
							}
						})
					});
					oNewTagDialog.open();
				}
			});



			var oDialog = new sap.m.Dialog({
				title: sTitle,
				contentWidth: "300px",
				content: oList,
				endButton: new sap.m.Button({
					text: oResourceBundle.getText("close"),
					press: function () {
						oDialog.close();
					}
				}),
				beginButton: oAddButton
			});

			oDialog.open();
		},

		_deleteCustomerTagPress: function (oEvent, oModel) {
			var oCustomerModel = this.getModel("customerModel");
			var oSubModel = this.getOwnerComponent().getModel("subModel");
			var oTag = oEvent.getSource().getBindingContext().getObject();
			var sErpCustNo = oCustomerModel.getProperty("/ErpCustNo");
			var sTagID = oTag.TagID;
			var that = this;

			oSubModel.remove("/MCCTags(guid'" + sTagID + "')", {
				success: function (response) {
					that._readCustomerTags(sErpCustNo, oModel);
					sap.m.MessageToast.show("Successfully deleted Customer Tag '" + oTag.Name + "'");
				},
				error: function (error) {
					sap.m.MessageToast.show("Failed to delete Customer Tag");
				}
			});

		},

		_readCustomerTags: function (sErpCustNo, oModel) {
			var oCustomerModel = this.getModel("customerModel");
			var oSubModel = this.getOwnerComponent().getModel("subModel");
			var sUserID = this.getModel("userapi").getProperty("/name");
			var aMCCTagsFilters = [];

			aMCCTagsFilters.push(new Filter([
				new Filter("CustomerID", FilterOperator.EQ, sErpCustNo),
				new Filter("Type", FilterOperator.EQ, "Customer"),
				new Filter("createdBy", FilterOperator.EQ, sUserID)
			], true));

			oSubModel.read("/MCCTags", {
				filters: aMCCTagsFilters,
				success: function (data) {
					oCustomerModel.setProperty("/customerTags", data.results);

					var iNumTags = data.results.length;
					oCustomerModel.setProperty("/customerTagsAmount", iNumTags);

					if (oModel) {
						var aCustomerTags = oCustomerModel.getProperty("/customerTags");
						oModel.setData(aCustomerTags);
					}
				},
				error: function (error) {
					oCustomerModel.setProperty("/customerTagsAmount", 0);
					sap.m.MessageToast.show("Failed loading Customer Tags");
				}
			});

		},



	});
});