sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/model/Constants"
], function (BaseController, formatter, Constants) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.xtecEscalations", {

		formatter: formatter,

		onInit: function () {

			//create local model to read customer related data, should be this name, cause fragment reused
			var oData = {
				reload: true,
				tableLoading: true
			};
			var oModel = new sap.ui.model.json.JSONModel(oData);
			this.getOwnerComponent().setModel(oModel, "xTecSituations");

			this.getView().setModel(new sap.ui.model.json.JSONModel({
				bLoadingState: false
			}), "viewModel");

			this.getRouter().getRoute("xtecEscalations").attachPatternMatched(this._onObjectMatched, this);

		},

		_onObjectMatched: function (oEvent) {
			if (this.getModel("xTecSituations") && this.getModel("xTecSituations").getData() && this.getModel(
					"xTecSituations").getProperty(
					"/reload")) {
				this.getModel("xTecSituations").setProperty("/reload", false);
				this._updateTable();
			}
			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
		},

		_updateTable: function () {
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var aFilter = oFilterModel.getProperty("/oFilterForServiceNow");

			var sFilterString =
				"sysparm_query=ORDERBYu_expected_action%5estate=101^u_escalation_type=0^u_request_reason=10^assignment_group=e782a6a51b38081020c8fddacd4bcb44&sysparm_display_value=true";

			//Before EMEA North, EMEA South change
			// if (sRegion) {
			// 	sFilterString += "^";
			// 	sRegion.split(",").forEach(function (region, i) {
			// 		sFilterString += "u_task_record.account.u_region=" + region;
			// 		if (i < (sRegion.split(",").length - 1)) {
			// 			sFilterString += "^OR";
			// 		}
			// 	});
			// }

			if (sRegion) {
				var sRegionFilterString = "^",
					sRegionEMEAFilterString = "",
					bBothEMEAFiltersSelected = false;
				sRegion.split(",").forEach(function (region, i) {
					//For Service Now we need to implement EMEA_North and EMEA_South differently, because it is not implmeneted yet
					//we need to take the specific countries instead
					//Moreover we need to take care, that it is still working together with the other region filters like MEE and NA
					if (region === "EMEA_NORTH") {
						if (bBothEMEAFiltersSelected) {
							sRegionEMEAFilterString += "^OR";
						} else if (!sRegionFilterString.endsWith("^OR")) {
							sRegionEMEAFilterString += "^";
						}
						sRegionEMEAFilterString += Constants.emeaNorthCountries;
						bBothEMEAFiltersSelected = true;
						//e.g. %5eu_task_record.account.country=AL%5eORu_task_record.account.country=DZ
					} else if (region === "EMEA_SOUTH") {
						if (bBothEMEAFiltersSelected) {
							sRegionEMEAFilterString += "^OR";
						} else if (!sRegionFilterString.endsWith("^OR")) {
							sRegionEMEAFilterString += "^";
						}
						sRegionEMEAFilterString += Constants.emeaSouthCountries;
						bBothEMEAFiltersSelected = true;
						//e.g. %5eu_task_record.account.country=AL%5eORu_task_record.account.country=DZ
					} else {
						sRegionFilterString += "u_task_record.account.u_region=" + region;
						if (i < (sRegion.split(",").length - 1)) {
							sRegionFilterString += "^OR";
						}
					}
				});
				if (sRegionEMEAFilterString !== "" && sRegionFilterString !== "^") {
					sRegionFilterString = sRegionFilterString + sRegionEMEAFilterString.replace("^", "^OR"); // we need to add an OR, because the countries need to be handled as an OR related to the region filter in this specific case, It should not be an AND
				} else if (sRegionEMEAFilterString !== "") {
					sRegionFilterString = sRegionEMEAFilterString;
				}
				sFilterString += sRegionFilterString;
			}

			if (aFilter && aFilter.length > 0) {
				aFilter.forEach(function (filter) {
					sFilterString += "^" + filter;
				});
			}

			sFilterString = sFilterString.replaceAll("^", "%5e");
			//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
			if (sFilterString.startsWith("%5esysparm_query")) {
				sFilterString.replace("%5esysparm_query", "sysparm_query");
			}
			sFilterString += Constants.fieldsForxTecTable;
			this.getOwnerComponent().getModel("xTecSituations").setProperty("/tableLoading", true);
			var oServiceNowPromise = new Promise(function (resolve, reject) {
				$.ajax({
					method: "GET",
					contentType: "application/json",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/sn_customerservice_escalation?" + sFilterString,
					success: function (oData) {
						oData.result.forEach(function (item) {
							item["u_task_record.account.country_text"] = this.formatter.getCountryName(item["u_task_record.account.country"], this);
							if (item["u_task_record.priority"] && item["u_task_record.priority"] !== "") {
								item["u_task_record.priority.number"] = item["u_task_record.priority"].split(" - ")[0];
								item["u_task_record.priority"] = item["u_task_record.priority"].split(" - ")[1];
							}
							item["u_task_record.account.country_text"] = this.formatter.getCountryName(item["u_task_record.account.country"], this);
							item["u_task_record.priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"], this);
							//item["u_request_reason"] = this.formatter.formatSNOWRequestReason(item["u_request_reason"], this);
							//item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"], this);
							item["approval_set_formatted"] = this.formatter.getDaysHoursMinSince(item["approval_set"], this);
						}.bind(this));
						this.getOwnerComponent().getModel("xTecSituations").setProperty("/tableLoading", false);

						function compare(a, b) {
							if (a.u_expected_action > b.u_expected_action) {
								return -1;
							}
							if (a.u_expected_action < b.u_expected_action) {
								return 1;
							}
							return 0;
						}
						oData.result.sort(compare);
						var oModel = new sap.ui.model.json.JSONModel(oData);
						this.getView().setModel(oModel, "data");
						resolve();
					}.bind(this),
					error: function (err) {
						this.getOwnerComponent().getModel("xTecSituations").setProperty("/tableLoading", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			//read Service NOW Tags; get tags, which have been created in the last half year (maybe this needs to be changed later?)
			var dateOffset = (24 * 60 * 60 * 1000) * Constants.serviceNowTagsCreatedSinceDays;
			var dateInPast = new Date();
			dateInPast.setTime(dateInPast.getTime() - dateOffset);
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd" // we need a format like 2022-12-24
			});
			dateInPast = oFormat.format(dateInPast);
			sFilterString =
				"sysparm_query=id_type=Escalation%5elabel.sys_created_on%3Ejavascript:gs.dateGenerate(%27" + dateInPast +
				"%27,%2700:00:00%27)%5elabel.global=true&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";

			oServiceNowPromise.then(function (data) {
				$.ajax({
					method: "GET",
					contentType: "application/json",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
					success: function (oData) {
						this.getView().getModel("data").getData().result.forEach(function (item) {
							var oTagElement = oData.result.filter(function (val) {
								return val["id_display"] === item.number; //"ESC0140066"; //
							});
							if (oTagElement) {
								item.tag = "";
								oTagElement.forEach(function (tagElementItem, index) {
									item.tag += tagElementItem['label.name'];
									if (oTagElement.length > (index + 1)) {
										item.tag += ", ";
									}
								});
							}
						}.bind(this));
						this.getView().getModel("data").refresh();
						//	this.getView().byId("xTecTable").sort("actionColumn")
					}.bind(this),
					error: function (err) {}.bind(this)
				});
			}.bind(this));
		},

		handleCustomerPress: function (evt) {
			var object = evt.getSource().getParent().getBindingContext("data").getObject();
			var sErpCustNo = object["u_task_record.account.number"];
			var oRouter = this.getRouter();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("data").getObject();
			this._openServiceNowQuickView("Business Down Situations", oEv.getSource(), oData);

			this.trackEvent("Status Report: show Popover");
		},

		handleCasePress: function (evt) {
			var object = evt.getSource().getParent().getBindingContext("data").getObject();
			this._openSosApp(object["sys_id"], "&transType=sn_customerservice_escalation");
		}

	});

});