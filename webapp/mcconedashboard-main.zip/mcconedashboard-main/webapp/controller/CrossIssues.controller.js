sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"sap/ui/core/Fragment"
], function (BaseController, formatter, Fragment) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.CriticalPeriodCoverage", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				iTabFiltered: 0,
				bLoadingState: false,
				// iTabAllPA: 0,
				// iTabGreenPA: 0,
				// iTabYellowPA: 0,
				// iTabRedPA: 0,
				// iTabUnratedPA: 0,
				bLoadingStatePA: false,
				showObjectType: false
			}), "viewModel");
			this.getRouter().getRoute("CrossIssues").attachPatternMatched(this._onObjectMatched, this);
		},
			
		onAfterRendering: function () {
			var oTable = this.getView().byId("table");
			oTable.attachFilter(function (oEvent) {
				setTimeout(function () {
					this._updateFilteredCount();
				}.bind(this), 200); //Wait for filter execution
			}, this);
			
			//Attach Listener in case a global Filter is applied
			var oSearchField = this.getSearchField(oTable);
			oSearchField.attachSearch(function (oEvent) {
				this._updateFilteredCount();
			}, this);
		},

		_onObjectMatched: function (oEvent) {
			//in case of anonymized mode, no Cross Issues should be retunrned
			if (this.getOwnerComponent().getModel("settings").getProperty("/isAnonymizedMode") === true) {
				return null;
			}

			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);

			//Check if data was already loaded. If yes, use this data
			if (this.getOwnerComponent().getModel("data").getProperty("/reloadCrossIssues")) {
				this.getOwnerComponent().getModel("data").setProperty("/reloadCrossIssues", false);
				this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "tableData");
				this._updateTable();
			}
		},

		_updateTable: function () {
			var aFilters = [];
			var oTable = this.getView().byId("table");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICPWOTAGS");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			var bCaseFilter = this.getOwnerComponent().getModel("data").getProperty("/taskForcesFilter");
			this.getView().byId("dataIconTabBar").setSelectedKey("All");
			if (!bCaseState) {
				bCaseState = "open";
			}
			if (bCaseState === "open" || bCaseState === "all") {
				var tileSpecificFilters1 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0010"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0011"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0016")
						], false)
					],
					true
				);
			}
			if (bCaseState === "closed" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0012"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0013"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0014"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0017"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0018")
						], false),
						this.getClosedDateFilter("ChangeDate")
					],
					true
				);

			}

			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
						tileSpecificFilters1,
						tileSpecificFilters2
					],
					false
				));
			}

			//set SoldToParty ID dependent on system
			var currentUrl = window.location.href;
			var sSoldToParty = currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") ? "4699754" : "20672944";
			aFilters.push(new sap.ui.model.Filter("SoldToParty", sap.ui.model.FilterOperator.EQ, sSoldToParty));

			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oICModel = this.getOwnerComponent().getModel();

			oICModel.read("/CrossIssueSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);

					this._calculateRating(data);
					data.results.forEach(function (oCase) {
						if (oCase.Rating === "") {
							oCase.Rating = "unrated";
						}
						oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);

					}.bind(this));
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "tableData");
					this.readImplementationPartner(oModel).then(function () {
						setTimeout(function () {
							oTable.rerender();
						}, 200);
					}.bind(this));
					this.loadProducts();
					this.loadAffectedCustomers();

					if (bCaseFilter !== "none") {
						var oIconTabBar = this.getView().byId("dataIconTabBar");
						oIconTabBar.setSelectedKey(bCaseFilter);
						oIconTabBar.fireSelect();
					}
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		loadAffectedCustomers: function () {
			var aFilters = [];
			var oTable = this.getView().byId("table");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();

			// if (sRegion) {
			// 	aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, sRegion));
			// }
			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICPWOTAGS");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "open";
			}
			if (bCaseState === "open" || bCaseState === "all") {
				var tileSpecificFilters1 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0010"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0011"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0016")
						], false)
					],
					true
				);
			}
			if (bCaseState === "closed" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0012"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0013"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0014"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0017"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0018")
						], false),
						this.getClosedDateFilter("ChangeDate")
					],
					true
				);

			}

			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
						tileSpecificFilters1,
						tileSpecificFilters2
					],
					false
				));
			}

			//set SoldToParty ID dependent on system
			var currentUrl = window.location.href;
			var sSoldToParty = currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") ? "4699754" : "20672944";
			aFilters.push(new sap.ui.model.Filter("SoldToParty", sap.ui.model.FilterOperator.EQ, sSoldToParty));

			var oICModel = this.getOwnerComponent().getModel();

			oICModel.read("/CrossIssueSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$expand": "toAffCustomers",
					"$select": "ObjectId,toAffCustomers"
				},
				success: function (data) {
					var oModel = this.getOwnerComponent().getModel("tableData");
					var aAlreadyAdded = oModel.getData().results;
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					var oModel = this.getOwnerComponent().getModel("tableData");
					var aAlreadyAdded = oModel.getData().results;
					this._updateFilteredCount();

					data.results.forEach(function (oCase) {

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === oCase.ObjectId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toAffCustomers = oCase.toAffCustomers;
								aTmp[i].numAffectedCustomers = oCase.toAffCustomers.results.length;
							});
						}
					}.bind(this));

					oModel.refresh();
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		loadProducts: function () {
			var aFilters = [];
			var oTable = this.getView().byId("table");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();

			// if (sRegion) {
			// 	aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, sRegion));
			// }
			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICPWOTAGS");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "open";
			}
			if (bCaseState === "open" || bCaseState === "all") {
				var tileSpecificFilters1 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0010"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0011"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0016")
						], false)
					],
					true
				);
			}
			if (bCaseState === "closed" || bCaseState === "all") {
				var tileSpecificFilters2 = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0012"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0013"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0014"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0017"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0018")
						], false),
						this.getClosedDateFilter("ChangeDate")
					],
					true
				);

			}

			if (bCaseState === "open") {
				aFilters.push(tileSpecificFilters1);
			} else if (bCaseState === "closed") {
				aFilters.push(tileSpecificFilters2);
			} else if (bCaseState === "all") {
				aFilters.push(new sap.ui.model.Filter([
						tileSpecificFilters1,
						tileSpecificFilters2
					],
					false
				));
			}

			//set SoldToParty ID dependent on system
			var currentUrl = window.location.href;
			var sSoldToParty = currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") ? "4699754" : "20672944";
			aFilters.push(new sap.ui.model.Filter("SoldToParty", sap.ui.model.FilterOperator.EQ, sSoldToParty));

			var oICModel = this.getOwnerComponent().getModel();

			oICModel.read("/CrossIssueSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$expand": "toProducts",
					"$select": "ObjectId,toProducts"
				},
				success: function (data) {
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					var oModel = this.getOwnerComponent().getModel("tableData");
					var aAlreadyAdded = oModel.getData().results;
					this._updateFilteredCount();

					data.results.forEach(function (oCase) {
						oCase.ProductVersions = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.Product = this.formatter.concatProducts(oCase.toProducts.results, "ProductT");
						oCase.ProductCategory = this.formatter.concatProducts(oCase.toProducts.results, "ProductCatT");
						oCase.ProductLine = this.formatter.concatProducts(oCase.toProducts.results, "ProductLineT");
						oCase.ProductVer = this.formatter.concatProducts(oCase.toProducts.results, "ProductVersionT");
						oCase.ProductLineKeys = this.formatter.concatProducts(oCase.toProducts.results, "ProductLine");
						oCase.ProductKeys = this.formatter.concatProducts(oCase.toProducts.results, "Product");

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === oCase.ObjectId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = oCase.toProducts;
								aTmp[i].toLastNotes = oCase.toLastNotes;
								aTmp[i].ProductVersions = oCase.ProductVersions;
								aTmp[i].Product = oCase.Product;
								aTmp[i].ProductCategory = oCase.ProductCategory;
								aTmp[i].ProductLine = oCase.ProductLine;
								aTmp[i].ProductVer = oCase.ProductVer;
								aTmp[i].ProductLineKeys = oCase.ProductLineKeys;
								aTmp[i].ProductKeys = oCase.ProductKeys;
							});
						}
					}.bind(this));

					oModel.refresh();
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		readNotes: function (oControl, id) {
			var oICModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oICModel.read("/CrossIssueSet(guid'" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		onPressImpactedCustomers: function (oEv) {
			var toAffCustomers = oEv.getSource().getBindingContext("tableData").getObject().toAffCustomers;
			this._openPopover("Impacted Customers", toAffCustomers.results);
		},

		_openPopover: function (title, aItems) {
			var oModel = new sap.ui.model.json.JSONModel();
			var oData = {
				"title": title,
				"items": []
			};
			//map values for model
			aItems.forEach(function (val) {
				var sCustCrm = "";
				var sCustErp = "";
				if (title === "Impacted Customers") {
					if (val.Partner !== "") {
						sCustCrm = "BP ID: " + val.Partner;
					}
					if (val.ErpCustNo !== "") {
						sCustErp = "ERP ID: " + val.ErpCustNo;
					}
				}

				oData.items.push({
					"type": title === "Impacted Customers" ? "cust" : "lob",
					"title": val.Name1 + " " + val.Name2,
					"custCrm": sCustCrm,
					"custErp": sCustErp
				});
			});
			oModel.setData(oData);
			Fragment.load({
				name: "com.sap.mcconedashboard.view.fragment.OutagesDialogList",
				controller: this
			}).then(function (oDialog) {
				oDialog.setModel(oModel, "data");
				this.getView().addDependent(oDialog);
				oDialog.open();
			}.bind(this));
		},

		onNavToCustomerView: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("data").getObject().custErp.substring(8);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oEv.getSource().getParent().close();
			oEv.getSource().getParent().destroy();
			this.getRouter().navTo("Customer", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		onListSearch: function (oEv) {
			var sQuery = oEv.getParameter("newValue");
			var oList = sap.ui.getCore().byId("outagesList");
			var aFilters = [];
			if (sQuery && sQuery.length > 0) {
				aFilters.push(new sap.ui.model.Filter([
					new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("custCrm", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("custErp", sap.ui.model.FilterOperator.Contains, sQuery)
				]));
			}
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		onListClose: function (oEv) {
			oEv.getSource().getParent().close();
			oEv.getSource().getParent().destroy();
		},

		handleRatingIconTabBarSelect: function (oEv) {
			var oTable = this.getView().byId("table");
			var sRatingKey = oEv.getSource().getSelectedKey();
			var aFilter = [];
			
			// Reset all table filters
			oTable.getColumns().forEach(function (oColumn) {
				oColumn.filter(null);
				oColumn.setFilterValue("");
			});
			this.clearSearchField(oTable);
			
			if (sRatingKey !== "All") {
				aFilter.push(new sap.ui.model.Filter("Rating", "EQ", sRatingKey));
			}
			oTable.getBinding("rows").filter(aFilter);
			this._updateFilteredCount();
		},

		onCase: function (oEv) {
			var sObjectId = oEv.getSource().getBindingContext("tableData").getObject().ObjectId;
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);
			this.getRouter().navTo("CrossIssueDetails", {
				"?query": this._getQueryParameter(),
				"objectId": sObjectId
			});
		},

		onCaseNewTab: function (oEv) {
			var sObjectId = oEv.getSource().getBindingContext("tableData").getObject().ObjectId;
			this._openCrossIssueInNewTab(sObjectId);
		},

		onCustomer: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("tableData").getObject().CustomerErpNo;
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("Customer", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		_calculateRating: function (data) {
			var oViewModel = this.getView().getModel("viewModel");
			var iGreen = 0;
			var iYellow = 0;
			var iRed = 0;
			var iUnrated = 0;
			data.results.forEach(function (oCase) {
				switch (oCase.Rating) {
				case "A":
					iGreen++;
					break;
				case "B":
					iYellow++;
					break;
				case "C":
					iRed++;
					break;
				default:
					iUnrated++;
				}
			});
			oViewModel.setProperty("/iTabAll", data.results.length);
			oViewModel.setProperty("/iTabGreen", iGreen);
			oViewModel.setProperty("/iTabYellow", iYellow);
			oViewModel.setProperty("/iTabRed", iRed);
			oViewModel.setProperty("/iTabUnrated", iUnrated);
			this._updateFilteredCount();
		},

		_updateFilteredCount: function () {
			var oTable = this.getView().byId("table");
			var iFilteredCount = oTable.getBinding("rows").getLength();
			var aFilters = oTable.getBinding("rows").aFilters;
			if (aFilters && aFilters.length > 0) {
				var iLengths = oTable.getBinding("rows").iLengths;
				if (iLengths) {
					iFilteredCount = oTable.getBinding("rows").iLength - iLengths.sum();
				} else {
					iFilteredCount = oTable.getBinding("rows").iLength;
				}
			}
			this.getView().getModel("viewModel").setProperty("/iTabFiltered", iFilteredCount);
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("tableData").getObject();
			var sId = oData.Guid;
			this.readNotes(oEv.getSource(), sId);
			this.trackEvent("Status Report: show Popover");
		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("tableData").getObject();
			var sObjectId = oProperty.ObjectId;
			this._shopTopIssuesCountPopover(sObjectId, oEv.getSource());
		},

		handleOpenIssuesCasePress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("dataPA").getPath();
			var oProperty = this.getModel("dataPA").getProperty(sPath);

			if (oProperty.objectType === "Planned CPC Engagment") {
				this._openWindow(oProperty.LinkToActivity);
			}
			// else {
			// 	this._openSosApp(oProperty["active_escalation.sys_id"]);
			// }
		},
		handleCustomerPress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("dataPA").getPath();
			var oProperty = this.getModel("dataPA").getProperty(sPath);
			var sErpCustNo = oProperty.CustomerErpNo || oProperty.ErpCustNo || oProperty.CustomerNo;
			var oRouter = this.getRouter();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},
		onOpenUser: function (oEv) {
			// if (oEv.getSource().data("EmplRespUser")) {
			// 	this.formatter.openUser(oEv, oEv.getSource().data("EmplRespUser"));
			// } 
			// else
			if (oEv.getSource().data("userid")) {
				this.formatter.openUser(oEv, oEv.getSource().data("userid"));
			}
			//else {
			// 	this.formatter.openUser(oEv, oEv.getSource().data("useridBDM"));
			// }
		},
		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("tableData").getPath();
			var oProperty = this.getModel("tableData").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},
		handleGlobalUltimatePressPA: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("dataPA").getPath();
			var oProperty = this.getModel("dataPA").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},
		customSorting: function (oEvent) {
			var oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingColumn");
			var oCurrentColumn = oEvent.getParameter("column");
			if (oCurrentColumn !== oGUMaintenanceRankingColumn) {
				//oGUMaintenanceRankingColumn.setSorted(false); //No multi-column sorting
				return;
			}
			oEvent.preventDefault();
			var sOrder = oEvent.getParameter("sortOrder");
			this.customSortingBase(oCurrentColumn, sOrder, oGUMaintenanceRankingColumn, "table");
		},
		customSortingPA: function (oEvent) {
			var oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingPAColumn");
			var oCurrentColumn = oEvent.getParameter("column");
			if (oCurrentColumn !== oGUMaintenanceRankingColumn) {
				//oGUMaintenanceRankingColumn.setSorted(false); //No multi-column sorting
				return;
			}
			oEvent.preventDefault();
			var sOrder = oEvent.getParameter("sortOrder");
			this.customSortingBase(oCurrentColumn, sOrder, oGUMaintenanceRankingColumn, "tablePA");
		},
		changeCaseState: function () {
			this._updateTable();
		},
		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("tableData").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		}

	});

});