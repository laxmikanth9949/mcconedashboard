sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast"
], function (BaseController, formatter, Filter, FilterOperator, MessageToast) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.CREEngagements", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				bLoadingState: false,
				// iTabAllPA: 0,
				// iTabGreenPA: 0,
				// iTabYellowPA: 0,
				// iTabRedPA: 0,
				// iTabUnratedPA: 0,
				iTabFiltered: 0,
				bLoadingStatePA: false,
				showObjectType: false
			}), "viewModel");

			//Attach Listener in case a global Filter is applied
			var oTable = this.getView().byId("table");
			var oSearchField = this.getSearchField(oTable);
			oSearchField.attachSearch(function (oEvent) {
				this._updateFilteredCount();
			}, this);

		},


		onAfterRendering: function () {
			if (this.getRouter().getRoute("CREEngagements")) {
				if (!this._tabBarInitialized) {
					var oTabBar = this.getView().byId("creEngagementsTabBar");
					if (oTabBar) {
						this._tabBarInitialized = true;
						this.getRouter().getRoute("CREEngagements").attachPatternMatched(this._onObjectMatched, this);
					}
				}
			}

			var oTable = this.getView().byId("table");
			oTable.attachFilter(function (oEvent) {
				setTimeout(function () {
					this._updateFilteredCount();
				}.bind(this), 200); //Wait for filter execution
			}, this);

		},

		_onObjectMatched: function (oEvent) {
			var oTabBar = this.getView().byId("creEngagementsTabBar");
			var oArgs = oEvent.getParameter("arguments");
			if (oArgs["?query"] && oArgs["?query"].showInternal === "true") {
				this.showInternal = true;
			} else {
				this.showInternal = false;
			}
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);


			//Check if data was already loaded. If yes, use this data
			this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "tableData");
			this.getOwnerComponent().getModel("data").setProperty("/reloadCreEngagements", false);
			var sState = "ongoing"
			if (this.getOwnerComponent().getModel("data").getProperty("/creEngagementsState") === "closed") {
				sState = "closed"
				oTabBar.setSelectedKey("closed")
			} else {
				oTabBar.setSelectedKey("ongoing")
			}
			this._updateTable(sState);
		},

		_updateTable: function (sState) {
			var aFilters = [];
			var oTable = this.getView().byId("table");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = oFilterModel.getProperty("/regionText");

			var oFilterForICP = oFilterModel.getProperty("/oFilterForCriticalEventCoverage");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			/* Only apply Region Filter if there is no Country Filter set
			if (typeof sRegion !== "undefined" && sRegion !== "" && !oFilterForICP.aFilters.some(filterGroup => {
				return filterGroup.aFilters.some(subFilter => subFilter.sPath.includes("Country"));
			})) { */

			/*
			if (typeof sRegion !== "undefined" && sRegion !== "") {

				var aRegionHelp = this.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.country;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var eqFilters = regionCountryValues.map(function (country) {
					return new sap.ui.model.Filter("CustomerCountry", sap.ui.model.FilterOperator.EQ, country);
				});

				var regionFilter = new sap.ui.model.Filter({
					filters: eqFilters,
					and: false //OR
				});


				// Combine the regionFilter with filterCondition using AND conjunction
				aFilters.push(regionFilter);

			} */



			if (sState === "ongoing") {
				var tileSpecificFilters = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "SWATSTAT01"),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "SWATSTAT05"),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "SWATSTAT06")
					], false),
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "SWAT")
					], false)
				],
					true
				);
			} else {
				var tileSpecificFilters = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "SWATSTAT02"),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "SWATSTAT04"),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "SWATSTAT08")
					], false),
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "SWAT")
					], false)
				],
					true
				);

				//Only Showing Closed Entries for the past 4 weeks
				var pastDate = new Date();
				pastDate.setDate(pastDate.getDate() - 364);

				var closedDateFilter = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("ClosureDate", sap.ui.model.FilterOperator.GE, pastDate)
					], false)
				],
					true
				);

				aFilters.push(closedDateFilter);
			}

			aFilters.push(tileSpecificFilters);


			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			oTable.setBusy(true);
			var that = this;

			oModel.read("/MCCObject", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				/*urlParameters: {
					"$expand": "toNotes"
				}, */
				success: function (data) {
					oTable.setBusy(false);
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "tableData");
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
					this._updateFilteredCount();
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
				}.bind(this)
			});
		},

		getRegionByCountry: function (sCountry) {
			var sRegion;
			var aRegionHelp = this.getModel("countryRegionModel").getData();
			// Find Entry in the Array, which fits the Country
			const countryEntry = aRegionHelp.RegionHelp.find(entry => entry.country === sCountry);

			if (countryEntry) {
				switch (countryEntry.region) {
					case "EMEA":
						if (countryEntry.subsubregion == "EMEA South") {
							sRegion = "EMEA South";
							break;
						}
						if (countryEntry.subsubregion == "EMEA North") {
							sRegion = "EMEA North"
							break;
						}
						if (countryEntry.subregion == "MEE") {
							sRegion = "MEE"
							break;
						}
					case "NA":
						sRegion = "NA";
						break;
					case "APJ":
						if (countryEntry.subregion == "GTC") {
							sRegion = "GTC"
							break;
						} else {
							sRegion = "APJ";
							break;
						}
					case "LAC":
						sRegion = "LAC";
						break;
					default:
						break;
				}
			}

			return sRegion;
		},

		handleCreEngagements: function (oEv) {
			var sState = oEv.getParameter("selectedKey");
			var oTable = this.getView().byId("table");

			// Reset all table filters
			oTable.getColumns().forEach(function (oColumn) {
				oColumn.filter(null);
				oColumn.setFilterValue("");
			});
			this.clearSearchField(oTable);

			this._updateTable(sState);
		},

		_updateFilteredCount: function () {
			var oTable = this.getView().byId("table");
			var iFilteredCount = oTable.getBinding("rows").getLength();
			var aFilters = oTable.getBinding("rows").aFilters;
			if (aFilters && aFilters.length > 0) {
				var iLengths = oTable.getBinding("rows").iLengths;
				if (iLengths) {
					iFilteredCount = oTable.getBinding("rows").iLength - iLengths.sum();
				} else {
					iFilteredCount = oTable.getBinding("rows").iLength;
				}
			}
			this.getView().getModel("viewModel").setProperty("/iTabFiltered", iFilteredCount);
		},

		onCase: function (oEv) {
			var sObjectID = oEv.getSource().getBindingContext("tableData").getObject().ObjectID;
			this.getOwnerComponent().getModel("data").setProperty("/reload", true);
			/*this.getRouter().navTo("CriticalEventCoverageDetails", {
				"?query": this._getQueryParameter(),
				"ObjectID": sObjectID
			});*/
		},

		onOpenUser: function (oEv) {
			if (oEv.getSource().data("userid")) {
				this.formatter.openUser(oEv, oEv.getSource().data("userid"));
			}
		},

		clearAllFilters: function (oEvent) {
			var oTable = oEvent.getSource().getParent().getParent();
			var aColumns = oTable.getColumns();
			oTable.getBinding().aSorters = null;

			//reset filter value for each column 

			for (var i = 0; i < aColumns.length; i++) {
				oTable.filter(aColumns[i], null);
				if (aColumns[i].getSorted()) {
					aColumns[i].setSorted(false);
				}
				aColumns[i].setFilterValue("");
				aColumns[i].setFiltered(false);
			}
			
			this.clearSearchField(oTable);

		},

		clearSearchField: function (oTable) {
			var oControl = this.getSearchField(oTable);
			if (oControl !== null) {
				oControl.setValue("");
				oControl.fireSearch();
			}
			return;
		}
	});
});