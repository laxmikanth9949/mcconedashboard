sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/FilterOperator",
	'sap/m/MessageToast',
	'sap/m/Dialog',
	'sap/m/Button',
	'sap/ui/core/HTML',
	'sap/m/Text',
	"sap/m/Label",
	"sap/m/Panel",
	"com/sap/mcconedashboard/model/formatter",
	"sap/ui/core/Fragment",
	"com/sap/mcconedashboard/model/Constants"
], function (BaseController, History, Filter, JSONModel, FilterOperator, MessageToast, Dialog, Button, HTML, Text, Label, Panel,
	formatter, Fragment, Constants) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.Solution", {

		formatter: formatter,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.mcconedashboard.view.Solution
		 */
		onInit: function () {
			var oSolutionData = {
				reload: true,
				selectedPieChartText: "",
				titleImageVisible: true,
				titleTextVisible: true
			};

			if (!this.getOwnerComponent().getModel("solutionModel")) {
				var oSolutionModel = new sap.ui.model.json.JSONModel(oSolutionData);
				this.getOwnerComponent().setModel(oSolutionModel, "solutionModel");
			}

			this.getRouter().getRoute("Solution").attachPatternMatched(this._onObjectMatched, this);

			var oRequestsLoadedModel = new sap.ui.model.json.JSONModel({
				supportRequestsLoaded: false
			});
			this.getView().setModel(oRequestsLoadedModel, "requestsLoadedModel");

			//this._supportRequestsLoaded = false;

			//pie chart
			this.getView().setModel(new JSONModel({
				data: []
			}), "pieChart");
			var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrame");
			oVizFrame.setVizProperties({
				legend: {
					title: {
						visible: true
					},
					showFullLabel: true
				},
				plotArea: {
					dataLabel: {
						visible: true,
						type: "value"
					}
				},
				legendGroup: {
					linesOfWrap: 2,
					layout: {
						width: "50%"
					}
				},
				title: {
					visible: false
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});
			oVizFrame.setModel(this.getView().getModel("pieChart"));

		},

		onAfterRendering: function () { },

		_onObjectMatched: function (oEv) {
			var oSolutionModel = this.getOwnerComponent().getModel("solutionModel");

			if (!oSolutionModel.getProperty("/reload")) {
				return null;
			}

			var oArgs = oEv.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);

			this.getOwnerComponent().getModel("solutionModel").setProperty("/titleImageVisible", true);
			this.getOwnerComponent().getModel("solutionModel").setProperty("/titleTextVisible", true);

			this.getView().byId("pieTypeButton").setSelectedKey("product");
			this.getView().byId("solutionTabBar").setSelectedKey("Ongoing");
			//	this._supportRequestsLoaded = false;
			var oRequestsLoadedModel = this.getView().getModel("requestsLoadedModel");
			oRequestsLoadedModel.setProperty("/supportRequestsLoaded", false);

			oSolutionModel.setProperty("/reload", false);
			oSolutionModel.setProperty("/selectedPieChartText", "");
			var sSolution = oEv.getParameter("arguments").Solution;
			oSolutionModel.setProperty("/solution", sSolution);
			this.getView().getModel("pieChart").setProperty("/data", []);
			this.getModel("appDepModelNoBatch").read("/SolutionSet('" + sSolution + "')", {
				urlParameters: {
					"$expand": "toSolutionProdLin"
				},
				success: function (oData) {
					oData.toSolutionProdLin.results.sort(function (a, b) {
						return (a.PlName < b.PlName) ? -1 : (a.PlName > b.PlName) ? 1 : 0;
					});
					this.getView().setModel(new JSONModel(oData), "solution");
					this._loadDataForTables(oData.toSolutionProdLin.results, sSolution);
					this._loadDataForSupportRequests(oData.toSolutionProdLin.results, sSolution);
				}.bind(this)
			});

			oSolutionModel.setProperty("/SolutionOverview", []);
			oSolutionModel.setProperty("/bLoadingState", true);
			oSolutionModel.setProperty("/AmountAll", 0);
			oSolutionModel.setProperty("/AmountGlobalEscalations", 0);
			oSolutionModel.setProperty("/AmountBusinessDownSituations", 0);

			oSolutionModel.setProperty("/AmountXTecEngagements", 0);
			oSolutionModel.setProperty("/AmountPECriticalEngagements", 0);
			oSolutionModel.setProperty("/AmountTechnicalBackofficeRequests", 0);

			oSolutionModel.setProperty("/AmountCriticalCustomerManagement", 0);
			oSolutionModel.setProperty("/AmountCriticalPeriodCoverage", 0);
			oSolutionModel.setProperty("/AmountTaskForces", 0);
			oSolutionModel.setProperty("/AmountCrossIssues", 0);
			oSolutionModel.setProperty("/AmountCriticalEventCoverages", 0);
			oSolutionModel.setProperty("/AmountCriticalEventCoveragesClosed", 0);
			oSolutionModel.setProperty("/AmountTopCriticalCustomers", 0);

			// closed issues
			oSolutionModel.setProperty("/SolutionOverviewClosed", []);
			oSolutionModel.setProperty("/bLoadingState", true);
			oSolutionModel.setProperty("/AmountAllClosed", 0);
			oSolutionModel.setProperty("/AmountGlobalEscalationsClosed", 0);
			oSolutionModel.setProperty("/AmountBusinessDownSituationsClosed", 0);

			oSolutionModel.setProperty("/AmountXTecEngagementsClosed", 0);
			oSolutionModel.setProperty("/AmountPECriticalEngagementsClosed", 0);
			oSolutionModel.setProperty("/AmountTechnicalBackofficeRequests", 0);

			oSolutionModel.setProperty("/AmountCriticalCustomerManagementClosed", 0);
			oSolutionModel.setProperty("/AmountCriticalPeriodCoverageClosed", 0);
			oSolutionModel.setProperty("/AmountTaskForces", 0);
			oSolutionModel.setProperty("/AmountCrossIssues", 0);
			oSolutionModel.setProperty("/CriticalEventCoverages", 0);
			oSolutionModel.setProperty("/CriticalEventCoveragesClosed", 0);
			oSolutionModel.setProperty("/AmountTopCriticalCustomersClosed", 0);
			//^closed issues

			oSolutionModel.setProperty("/SolutionOverviewOpenIssues", []);
			oSolutionModel.setProperty("/bLoadingStateOpenIssues", true);
			oSolutionModel.setProperty("/AmountAllOpenIssues", 0);
			oSolutionModel.setProperty("/AmountTopIssues", 0);
			oSolutionModel.setProperty("/AmountMCCIssues", 0);
			oSolutionModel.setProperty("/AmountMCCTopCriticalCustomer", 0);
			oSolutionModel.setProperty("/AmountCCMRequests", 0);
			oSolutionModel.setProperty("/AmountCPCRequests", 0);
			oSolutionModel.setProperty("/AmountCPCActivityRequests", 0);
			oSolutionModel.setProperty("/AmountCCMActivityRequests", 0);
			oSolutionModel.setProperty("/AmountTechnicalSupportRequests", 0);
			oSolutionModel.setProperty("/AmountGlobalEscalationRequests", 0);
			oSolutionModel.setProperty("/AmountMCCSosRequest", 0);
			oSolutionModel.setProperty("/AmountBusinessDown", 0);
			oSolutionModel.setProperty("/AmountGoLiveEndangered", 0);
			oSolutionModel.setProperty("/AmountGoLiveAnnouncement", 0);
			oSolutionModel.setProperty("/AmountAllMCCIssues", 0);

			//Solution Logo
			//TODO Solution Icons: the call for reading the icons from the share took too long and therefore we switched back to the local app storage
			//it might be changed in future to use the Document Management of the MCC Tools Team to retrieve files from the share faster

			//QUICK SOLUTION TO AVOID THE USAGE OF OLD PICTURES - REMOVE IF CONDITION IF NOT NEEDED ANYMORE
			var solutionLogo = null;

			//QUICK SOLUTION TO AVOID THE USAGE OF OLD PICTURES - REMOVE IF CONDITION IF NOT NEEDED ANYMORE
			if (sSolution == "ARIBA") {
				solutionLogo = sap.ui.require.toUrl("com/sap/mcconedashboard/image/NOPICTUREHERE.png");
			} else {
				solutionLogo = sap.ui.require.toUrl("com/sap/mcconedashboard/image/" + sSolution + ".png");
			}
			this.getView().setModel(new JSONModel({
				solutionLogo: solutionLogo
			}), "solutionLogo");
		},

		onSectionChange: function (oEv) {
			var oRequestsLoadedModel = this.getView().getModel("requestsLoadedModel");

			if (oEv.getParameter("key") === "OpenIssues" && (oRequestsLoadedModel.getProperty("/supportRequestsLoaded")) === false) {
				var sSolution = this.getOwnerComponent().getModel("solutionModel").getProperty("/solution");
				var aProdLines = this.getView().getModel("solution").getData().toSolutionProdLin.results;
				this._loadDataForSupportRequests(aProdLines, sSolution);
			}
		},

		_readCPCRequests: function (aProdLines, oFilterModel) {
			var aFilters = [];
			oFilterModel.refresh(true);

			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "open";
			}

			var sRegion = oFilterModel.getProperty("/regionText");
			var oFilterForICP = oFilterModel.getProperty("/oFilterForCriticalPeriodCoverage");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			/* Region Filtering gemoved for this Call since the CustomerCountry field is not filled
			if (typeof sRegion !== "undefined" && sRegion !== "") {

				var aRegionHelp = this.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.country;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var eqFilters = regionCountryValues.map(function (country) {
					return new sap.ui.model.Filter("CustomerCountry", sap.ui.model.FilterOperator.EQ, country);
				});

				var regionFilter = new sap.ui.model.Filter({
					filters: eqFilters,
					and: false //OR
				});

				// Combine the regionFilter with filterCondition using AND conjunction
				aFilters.push(regionFilter);

			} */

			//Show only for ExpectedAction and Type
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("ExpectedAction", sap.ui.model.FilterOperator.EQ, "accept_engagement")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "AccER")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			//Filter for ProductLineIDs
			if (aProdLines && aProdLines.length > 0) {
				var productLineFilters = aProdLines.map(function (prodLineID) {
					return new sap.ui.model.Filter("ProductLineID", sap.ui.model.FilterOperator.EQ, prodLineID);
				});

				// Combine all individual filters with OR operator
				var combinedProductLineFilter = new sap.ui.model.Filter({
					filters: productLineFilters,
					and: false // false indicates OR operator
				});
				aFilters.push(combinedProductLineFilter);
			}

			//Use only those entries that do not have a EndDate set or it is in the future
			var today = new Date();
			today.setDate(today.getDate());

			/*
			var closedDateFilter = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.GE, today),
					new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.EQ, null)
				], false)
			],
				true
			);
			aFilters.push(closedDateFilter);
			*/

			var startDateFilter = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.GE, today),
					new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, null)
				], false)
			],
				true
			);
			aFilters.push(startDateFilter);

			var oModel = this.getOwnerComponent().getModel("subModel");
			var that = this;

			oModel.read("/MCCObject", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$select": "ExpectedAction, GoLiveDate, StartDate, EndDate, EscalationID, ProductLineID, ProductLineName, Type"
				},
				success: function (data) {
					that._loadServiceNowCPCRequestsWithHANAIds(data);
				}.bind(this),
				error: function (data) {
				}.bind(this)
			});

		},

		_loadServiceNowCPCRequestsWithHANAIds: function (aMCCObjects) {
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");

			if (aMCCObjects.results.length > 0) {
				var escalationIDs = aMCCObjects.results.map(function (obj) {
					return obj.EscalationID;
				});

				// Filter out empty or null values
				var validEscalationIDs = escalationIDs.filter(function (id) {
					return id !== null && id !== '';
				});

				// Combine all valid Escalation IDs into a string for the filter
				var escalationIDsString = validEscalationIDs.join(',');

				var sFilterString = "ORDERBYu_task_record.priority^state=103^u_escalation_type=6";
				sFilterString += "^numberIN" + escalationIDsString;

				if (typeof sRegion !== "undefined" && sRegion !== "") {

					var aRegionHelp = this.getModel("countryRegionModel").getData();
					var selectedRegions = sRegion.split(","); // Split the selected regions into an array

					// Create an object to map selected regions to filterBasis (given in countryRegionModel)
					var regionFilterBasisMap = {
						"EMEA North": "subsubregion",
						"EMEA South": "subsubregion",
						"NA": "region",
						"APJ": "region",
						"MEE": "subregion",
						"GTC": "subregion",
						"LAC": "subregion"
					};

					var regionCountryValues = [];

					// Iterate through selectedRegions and create filters based on filterBasis
					selectedRegions.forEach(function (region) {
						var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

						// Filter regionCountries based on the chosen filter basis
						var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
							return item[filterBasis] === region;
						});

						// Add regionCountryValues for the current region to the array
						regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
							return regionCountry.countryCode;
						}));
					});

					// Extend sFilterString based on regionCountryValues
					if (regionCountryValues.length > 0) {
						var regionFilters = regionCountryValues.map(function (country) {
							return "u_customer_3.country=" + encodeURIComponent(country);
						}).join("^OR");

						// Append the new regionFilters to the existing sFilterString
						sFilterString += "^" + regionFilters;
					}

				}

				if (aFilter && aFilter.length > 0) {
					aFilter.forEach(function (filter) {
						sFilterString += "^" + filter;
					});
				}

				sFilterString = "sysparm_query=" + encodeURIComponent(sFilterString);
				//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
				if (sFilterString.startsWith("%5esysparm_query")) {
					sFilterString.replace("%5esysparm_query", "sysparm_query");
				}

				sFilterString += "&sysparm_fields=";
				sFilterString += encodeURIComponent(Constants.fieldsForCPCTableWithoutParameter);

				return new Promise(function (resolve, reject) {
					var body = {
						"batch_request_id":1, 
						"rest_requests":[{
							"headers": [
								{"name":"Content-Type", "value":"application/json"},
								{"name":"Accept","value":"application/json"}
							],
							"url": "/api/now/table/sn_customerservice_escalation?" + sFilterString,
							"method":"GET",
							"id":"0000014383DUMMY",
							"exclude_response_headers": "true"
						}]
					};
					body = JSON.stringify(body);
					$.ajax({
						method: "POST",
						contentType: "application/json",
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
						data: body,
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						error: function() {
							resolve();
						},
						success: function(oData) {
							oData = JSON.parse(atob(oData.serviced_requests[0].body));
							oData.result.forEach(function (item) {
								//Adjustments for CPC View
								item["PriorityT"] = this.formatter.getCimPriority(item["u_task_record.priority"], this);
								item["priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"], this);
								item["CountryT"] = this.formatter.getCountryName(item["u_customer_3.country"], this);
								item["Region"] = this.getRegionByCountryOrCountryCode(item["u_customer_3.country"], this);
								item["u_request_reason"] = this.formatter.formatSNOWRequestReason(item["u_request_reason"], this);
								item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"], this);
								item["state"] = this.formatter.getCimEscalationStatus(item["state"], this);
								item["approval_set_formatted"] = this.formatter.getDaysHoursMinSince(item["approval_set"], this);
								item["ObjectId"] = item["number"];
								item["ShortDescription"] = item["short_description"];
								item["StatusT"] = item["state"];
								item["CustomerText"] = item["u_customer_3.name"];
								item["CustomerErpNo"] = item["u_customer_3.number"];
								item["CustomerBpNo"] = item["u_customer_3.u_sap_crm_bp_number"];
								item["EmplRespName"] = item["assigned_to.first_name"] + " " + item["assigned_to.last_name"];
								item["EmplRespUser"] = item["assigned_to.employee_number"];
								item["CreationDate"] = item["sys_created_on"];
								item["ChangeDate"] = item["sys_updated_on"];
								item["AssignmentGroup"] = item["assignment_group.name"];

								// Mapping with HANA Data
								var mappedObject = aMCCObjects.results.find(function (mccItem) {
									return mccItem.EscalationID === item.number;
								});

								if (mappedObject) {
									item["Product"] = mappedObject.ProductLineName;
									item["ProductLineID"] = mappedObject.ProductLineID;
									item["ActualsStartDate"] = mappedObject.StartDate;
									item["ActualsEndDate"] = mappedObject.EndDate;
									item["GoLiveDate"] = mappedObject.GoLiveDate;
								}
							}.bind(this));
							this._convertDataForSolutionOverview("CPCRequests", oData.result);
							this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCPCRequests", oData.result.length);
							resolve(oData);
						}.bind(this)
					});
				}.bind(this));
			}

		},

		_readCCMRequestsAndTechnicalSupportRequests: function (aProdLines, oFilterModel) {
			var aFilters = [];
			oFilterModel.refresh(true);

			var sRegion = this.getRegionFilterModel();
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/taskForcesState");
			if (!bCaseState) {
				bCaseState = "open";
			}

			var sRegion = oFilterModel.getProperty("/regionText");
			var oFilterForICP = oFilterModel.getProperty("/oFilterForCriticalPeriodCoverage");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			/* Removing the Region Fitler since the field is not filled currently and the SN Filter will apply anyway
			if (typeof sRegion !== "undefined" && sRegion !== "") {

				var aRegionHelp = this.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.country;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var eqFilters = regionCountryValues.map(function (country) {
					return new sap.ui.model.Filter("CustomerCountry", sap.ui.model.FilterOperator.EQ, country);
				});

				var regionFilter = new sap.ui.model.Filter({
					filters: eqFilters,
					and: false //OR
				});

				// Combine the regionFilter with filterCondition using AND conjunction
				aFilters.push(regionFilter);

			} */

			//Show only for ExpectedAction and Type
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "AccER")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			//Filter for ProductLineIDs
			if (aProdLines && aProdLines.length > 0) {
				var productLineFilters = aProdLines.map(function (prodLineID) {
					return new sap.ui.model.Filter("ProductLineID", sap.ui.model.FilterOperator.EQ, prodLineID);
				});

				// Combine all individual filters with OR operator
				var combinedProductLineFilter = new sap.ui.model.Filter({
					filters: productLineFilters,
					and: false // false indicates OR operator
				});
				aFilters.push(combinedProductLineFilter);
			}

			var oModel = this.getOwnerComponent().getModel("subModel");
			var that = this;

			oModel.read("/MCCObject", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$select": "ExpectedAction, GoLiveDate, StartDate, EndDate, EscalationID, ProductLineID, ProductLineName, Type"
				},
				success: function (data) {
					let ccmPromise = new Promise((resolve, reject) => {
						that._loadServiceNowCCMRequestsWithHANAIds(data, resolve, reject);
					});

					let tsrPromise = new Promise((resolve, reject) => {
						that._loadServiceNowTechnicalSupportRequestsWithHANAIds(data, resolve, reject);
					});

					Promise.all([ccmPromise, tsrPromise]).then(() => {
						resolve();
					}).catch((error) => {
						reject(error);
					});
				}.bind(this),
				error: function (error) {
					reject(error);
				}.bind(this)
			});

		},

		_loadServiceNowCCMRequestsWithHANAIds: function (aMCCObjects) {
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");

			if (aMCCObjects.results.length > 0) {
				var escalationIDs = aMCCObjects.results.map(function (obj) {
					return obj.EscalationID;
				});

				// Filter out empty or null values
				var validEscalationIDs = escalationIDs.filter(function (id) {
					return id !== null && id !== '';
				});

				// Combine all valid Escalation IDs into a string for the filter
				var escalationIDsString = validEscalationIDs.join(',');

				var sFilterString = "ORDERBYu_task_record.priority^state=100^u_escalation_type=5";
				sFilterString += "^numberIN" + escalationIDsString;

				//sFilterString += "^numberINESC0489274,ESC0494268"

				if (typeof sRegion !== "undefined" && sRegion !== "") {

					var aRegionHelp = this.getModel("countryRegionModel").getData();
					var selectedRegions = sRegion.split(","); // Split the selected regions into an array

					// Create an object to map selected regions to filterBasis (given in countryRegionModel)
					var regionFilterBasisMap = {
						"EMEA North": "subsubregion",
						"EMEA South": "subsubregion",
						"NA": "region",
						"APJ": "region",
						"MEE": "subregion",
						"GTC": "subregion",
						"LAC": "subregion"
					};

					var regionCountryValues = [];

					// Iterate through selectedRegions and create filters based on filterBasis
					selectedRegions.forEach(function (region) {
						var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

						// Filter regionCountries based on the chosen filter basis
						var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
							return item[filterBasis] === region;
						});

						// Add regionCountryValues for the current region to the array
						regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
							return regionCountry.countryCode;
						}));
					});

					// Extend sFilterString based on regionCountryValues
					if (regionCountryValues.length > 0) {
						var regionFilters = regionCountryValues.map(function (country) {
							return "u_customer_3.country=" + encodeURIComponent(country);
						}).join("^OR");

						// Append the new regionFilters to the existing sFilterString
						sFilterString += "^" + regionFilters;
					}

				}

				if (aFilter && aFilter.length > 0) {
					aFilter.forEach(function (filter) {
						sFilterString += "^" + filter;
					});
				}
				
				sFilterString = "sysparm_query=" + encodeURIComponent(sFilterString);
				//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
				if (sFilterString.startsWith("%5esysparm_query")) {
					sFilterString.replace("%5esysparm_query", "sysparm_query");
				}

				sFilterString += "&sysparm_fields=";
				sFilterString += encodeURIComponent(Constants.fieldsForCPCTableWithoutParameter);

				return new Promise(function (resolve, reject) {
					var body = {
						"batch_request_id":1, 
						"rest_requests":[{
							"headers": [
								{"name":"Content-Type", "value":"application/json"},
								{"name":"Accept","value":"application/json"}
							],
							"url": "/api/now/table/sn_customerservice_escalation?" + sFilterString,
							"method":"GET",
							"id":"0000014383DUMMY",
							"exclude_response_headers": "true"
						}]
					};
					body = JSON.stringify(body);
					$.ajax({
						method: "POST",
						contentType: "application/json",
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
						data: body,
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						error: function() {
							resolve();
						},
						success: function(oData) {
							oData = JSON.parse(atob(oData.serviced_requests[0].body));
							oData.result.forEach(function (item) {
								//Adjustments for CCM View
								item["PriorityT"] = this.formatter.getCimPriority(item["u_task_record.priority"], this);
								item["priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"], this);
								item["CountryT"] = this.formatter.getCountryName(item["u_customer_3.country"], this);
								item["Region"] = this.getRegionByCountryOrCountryCode(item["u_customer_3.country"], this);
								item["u_request_reason"] = this.formatter.formatSNOWRequestReason(item["u_request_reason"], this);
								item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"], this);
								item["state"] = this.formatter.getCimEscalationStatus(item["state"], this);
								item["approval_set_formatted"] = this.formatter.getDaysHoursMinSince(item["approval_set"], this);
								item["ObjectId"] = item["number"];
								item["ShortDescription"] = item["short_description"];
								item["StatusT"] = item["state"];
								item["CustomerText"] = item["u_customer_3.name"];
								item["CustomerErpNo"] = item["u_customer_3.number"];
								item["CustomerBpNo"] = item["u_customer_3.u_sap_crm_bp_number"];
								item["EmplRespName"] = item["assigned_to.first_name"] + " " + item["assigned_to.last_name"];
								item["EmplRespUser"] = item["assigned_to.employee_number"];
								item["CreationDate"] = item["sys_created_on"];
								item["ChangeDate"] = item["sys_updated_on"];
								item["AssignmentGroup"] = item["assignment_group.name"];

								// Mapping with HANA Data
								var mappedObject = aMCCObjects.results.find(function (mccItem) {
									return mccItem.EscalationID === item.number;
								});

								if (mappedObject) {
									item["Product"] = mappedObject.ProductLineName;
									item["ProductLineID"] = mappedObject.ProductLineID;
									item["ActualsStartDate"] = mappedObject.StartDate;
									item["ActualsEndDate"] = mappedObject.EndDate;
									item["GoLiveDate"] = mappedObject.GoLiveDate;
								}
							}.bind(this));
							this._convertDataForSolutionOverview("CCMRequests", oData.result);
							this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCCMRequests", oData.result.length);
							resolve(oData);
						}.bind(this)
					});
				}.bind(this));
			}
		},

		_loadServiceNowTechnicalSupportRequestsWithHANAIds: function (aMCCObjects) {
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");

			if (aMCCObjects.results.length > 0) {
				var escalationIDs = aMCCObjects.results.map(function (obj) {
					return obj.EscalationID;
				});

				// Filter out empty or null values
				var validEscalationIDs = escalationIDs.filter(function (id) {
					return id !== null && id !== '';
				});

				// Combine all valid Escalation IDs into a string for the filter
				var escalationIDsString = validEscalationIDs.join(',');

				var sFilterString = "ORDERBYu_task_record.priority^state=100^u_escalation_type=7";
				sFilterString += "^numberIN" + escalationIDsString;

				//sFilterString += "^numberINESC0489274,ESC0494268"

				if (typeof sRegion !== "undefined" && sRegion !== "") {

					var aRegionHelp = this.getModel("countryRegionModel").getData();
					var selectedRegions = sRegion.split(","); // Split the selected regions into an array

					// Create an object to map selected regions to filterBasis (given in countryRegionModel)
					var regionFilterBasisMap = {
						"EMEA North": "subsubregion",
						"EMEA South": "subsubregion",
						"NA": "region",
						"APJ": "region",
						"MEE": "subregion",
						"GTC": "subregion",
						"LAC": "subregion"
					};

					var regionCountryValues = [];

					// Iterate through selectedRegions and create filters based on filterBasis
					selectedRegions.forEach(function (region) {
						var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

						// Filter regionCountries based on the chosen filter basis
						var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
							return item[filterBasis] === region;
						});

						// Add regionCountryValues for the current region to the array
						regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
							return regionCountry.countryCode;
						}));
					});

					// Extend sFilterString based on regionCountryValues
					if (regionCountryValues.length > 0) {
						var regionFilters = regionCountryValues.map(function (country) {
							return "u_customer_3.country=" + encodeURIComponent(country);
						}).join("^OR");

						// Append the new regionFilters to the existing sFilterString
						sFilterString += "^" + regionFilters;
					}

				}

				if (aFilter && aFilter.length > 0) {
					aFilter.forEach(function (filter) {
						sFilterString += "^" + filter;
					});
				}

				sFilterString = "sysparm_query=" + encodeURIComponent(sFilterString);
				
				//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
				if (sFilterString.startsWith("%5esysparm_query")) {
					sFilterString.replace("%5esysparm_query", "sysparm_query");
				}

				sFilterString += "&sysparm_fields=";
				sFilterString += encodeURIComponent(Constants.fieldsForCPCTableWithoutParameter);

				return new Promise(function (resolve, reject) {
					var body = {
						"batch_request_id":1, 
						"rest_requests":[{
							"headers": [
								{"name":"Content-Type", "value":"application/json"},
								{"name":"Accept","value":"application/json"}
							],
							"url": "/api/now/table/sn_customerservice_escalation?" + sFilterString,
							"method":"GET",
							"id":"0000014383DUMMY",
							"exclude_response_headers": "true"
						}]
					};
					body = JSON.stringify(body);
					$.ajax({
						method: "POST",
						contentType: "application/json",
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
						data: body,
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						error: function() {
							resolve();
						},
						success: function(oData) {
							oData = JSON.parse(atob(oData.serviced_requests[0].body));
							oData.result.forEach(function (item) {
								//Adjustments for CCM View
								item["PriorityT"] = this.formatter.getCimPriority(item["u_task_record.priority"], this);
								item["priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"], this);
								item["CountryT"] = this.formatter.getCountryName(item["u_customer_3.country"], this);
								item["Region"] = this.getRegionByCountryOrCountryCode(item["u_customer_3.country"], this);
								item["u_request_reason"] = this.formatter.formatSNOWRequestReason(item["u_request_reason"], this);
								item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"], this);
								item["state"] = this.formatter.getCimEscalationStatus(item["state"], this);
								item["approval_set_formatted"] = this.formatter.getDaysHoursMinSince(item["approval_set"], this);
								item["ObjectId"] = item["number"];
								item["ShortDescription"] = item["short_description"];
								item["StatusT"] = item["state"];
								item["CustomerText"] = item["u_customer_3.name"];
								item["CustomerErpNo"] = item["u_customer_3.number"];
								item["CustomerBpNo"] = item["u_customer_3.u_sap_crm_bp_number"];
								item["EmplRespName"] = item["assigned_to.first_name"] + " " + item["assigned_to.last_name"];
								item["EmplRespUser"] = item["assigned_to.employee_number"];
								item["CreationDate"] = item["sys_created_on"];
								item["ChangeDate"] = item["sys_updated_on"];
								item["AssignmentGroup"] = item["assignment_group.name"];

								// Mapping with HANA Data
								var mappedObject = aMCCObjects.results.find(function (mccItem) {
									return mccItem.EscalationID === item.number;
								});

								if (mappedObject) {
									item["Product"] = mappedObject.ProductLineName;
									item["ProductLineID"] = mappedObject.ProductLineID;
									item["ActualsStartDate"] = mappedObject.StartDate;
									item["GoLiveDate"] = mappedObject.GoLiveDate;
								}
							}.bind(this));
							this._convertDataForSolutionOverview("TechnicalSupportRequests", oData.result);
							this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountTechnicalSupportRequests", oData.result.length);
							resolve(oData);
						}.bind(this)
					});
				}.bind(this));
			}
		},

		_loadDataForSupportRequests: function (aProductLines, sSolution) {
			var oRequestsLoadedModel = this.getView().getModel("requestsLoadedModel");

			if (oRequestsLoadedModel.getProperty("/supportRequestsLoaded") === false) {

				//	var oSettings = this.getOwnerComponent().getModel("settings").getData();

				var oFilterModel = this.oView.getModel("filterModel");
				var sRegion = oFilterModel.getProperty("/region");
				var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");

				var oFilterModelICPGER = oFilterModel.getProperty("/oFilterModelICPGER");
				//var oFilterForMCS = oFilterModel.getProperty("/oFilterModelMCS");
				//var oFilterForBusinessDown = oFilterModel.getProperty("/oFilterModelBD");
				var oFilterForServiceNow = oFilterModel.getProperty("/oFilterForServiceNow");
				var oFilterForServiceNowForCPC = oFilterModel.getProperty("/oFilterForServiceNowForCPC");
				var aPromises = [];

				this.getView().setModel(new JSONModel([]), "productsModel");

				this.aProdLines = [];
				aProductLines.forEach(function (pl) {
					this.aProdLines.push(pl.PlKey);
				}.bind(this));

				//Open Issues Table
				var oMCCActPromise = this._readMCCActivities(this.aProdLines, oFilterForICP);
				var oTopIssuesPromise = this._readTopIssuesSet(this.aProdLines, oFilterForICP);
				var oCPCRequestsPromise = this._readCPCRequests(this.aProdLines, oFilterModel);
				var oCCMTSRRequestsPromise = this._readCCMRequestsAndTechnicalSupportRequests(this.aProdLines, oFilterModel);


				aPromises = [oTopIssuesPromise, oMCCActPromise, oCPCRequestsPromise, oCCMTSRRequestsPromise];

				if (sSolution === "All") {
					var oGlobalEscalationRequestPromise = this._readGlobalEscalationRequests(this.aProdLines, oFilterModelICPGER);
					aPromises.push(oGlobalEscalationRequestPromise);
				}

				var oBTechnicalBackofficePromise = this._readTechnicalBackofficeRequests(this.aProdLines, sRegion, oFilterForServiceNow);
				aPromises.push(oBTechnicalBackofficePromise);

				Promise.all(aPromises).then(function () {
					this.getView().byId("hboxBusyOpenIssues").setVisible(false);
					this.getView().byId("solutionOverviewTableOpenIssues").setBusy(false);

					this.readImplementationPartner(this.getOwnerComponent().getModel("solutionModel"));

					var oSolutionTable = this.getView().byId("solutionOverviewTable");
					oSolutionTable.getColumns().forEach(function (col) {
						col.setFiltered(false);
						col.setFilterValue("");
						col.setSorted(false);
						col.filter();
					});
					oSolutionTable.sort();

					//also "All" Tile should show the pie chart	
					this.getView().byId("SolutionProductLineChartContainer").setVisible(true); //sSolution !== "All");
					this._setPieModel(sSolution, "product");

					//reset table filters / sorters / icon tab bar
					var oIconTabBar = this.getView().byId("iconTabBar");
					//var oIconTabBarOpenIssues = this.getView().byId("iconTabBarOpenIssues");

					var sKey = this.getOwnerComponent().getModel("solutionModel").getProperty("/preSelectKey");

					if (!sKey) {
						sKey = "All";
					}
					oIconTabBar.setSelectedKey(sKey);
					oIconTabBar.fireSelect({
						key: sKey
					});

				}.bind(this), function (err) {
					var bVisible = this.getView().byId("hboxBusy").getVisible();
					this.getView().byId("hboxBusy").setVisible(!bVisible);

					var bVisibleOpenIssues = this.getView().byId("hboxBusyOpenIssues").getVisible();
					this.getView().byId("hboxBusy").setVisible(!bVisibleOpenIssues);
				}.bind(this));
				//this._supportRequestsLoaded = true;
				var oRequestsLoadedModel = this.getView().getModel("requestsLoadedModel");
				oRequestsLoadedModel.setProperty("/supportRequestsLoaded", true);
			}
		},

		_loadDataForTables: function (aProductLines, sSolution) {
			var oSettings = this.getOwnerComponent().getModel("settings").getData();

			var oFilterModel = this.oView.getModel("filterModel");
			var sRegion = oFilterModel.getProperty("/region");
			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			var oFilterForICPwithouthTags = oFilterModel.getProperty("/oFilterModelICPWOTAGS");
			var oFilterForCEC = oFilterModel.getProperty("/oFilterForCriticalEventCoverage");

			//	var oFilterModelICPGER = oFilterModel.getProperty("/oFilterModelICPGER");
			//	var oFilterForMCS = oFilterModel.getProperty("/oFilterModelMCS");
			//	var oFilterForBusinessDown = oFilterModel.getProperty("/oFilterModelBD");
			var oFilterForServiceNow = oFilterModel.getProperty("/oFilterForServiceNow");
			var aPromises = [];

			this.getView().setModel(new JSONModel([]), "productsModel");

			this.aProdLines = [];
			aProductLines.forEach(function (pl) {
				this.aProdLines.push(pl.PlKey);
			}.bind(this));

			//read Service NOW Tags; get tags, which have been created in the last half year (maybe this needs to be changed later?)
			var oServiceNowTagPromise = this._readServiceNowTags();

			var oCustEngagementsPromise = this._readCustomerEngagements(this.aProdLines, oFilterForICP);
			var oCritSitPromise = this._readCriticalSituations(this.aProdLines, oFilterForICP);
			var oTaskForcesPromis = this._readTaskForces(this.aProdLines, oFilterForICP);
			var oBusinessDownSituationsPromise = this._readBusinessDownSituations(this.aProdLines, sRegion, oFilterForServiceNow,
				oServiceNowTagPromise);
			var oCimPromise = this._readCims(this.aProdLines, sRegion, oFilterForServiceNow, oServiceNowTagPromise);
			var oCriticalEventCoveragePromise = this._readCriticalEventCoverage(this.aProdLines, sRegion, oFilterForCEC);

			aPromises = [oCritSitPromise, oCustEngagementsPromise, oCimPromise, oTaskForcesPromis,
				oBusinessDownSituationsPromise, oCriticalEventCoveragePromise
			];

			if (oSettings.ShowGlobalAggregation || oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations) {
				//in case of anonymized mode, no GEM should be retunrned
				if (oSettings.isAnonymizedMode === false) {
					var oGlobalEscPromise = this._readGlobalEscalations(this.aProdLines, oFilterForICP);
					aPromises.push(oGlobalEscPromise);
				}
			}
			//in case of anonymized mode, no Cross Issues should be retunrned
			if (oSettings.isAnonymizedMode === false) {
				var oCrossIssuesPromis = this._readCrossIssues(this.aProdLines, oFilterForICPwithouthTags);
				aPromises.push(oCrossIssuesPromis);
			}

			this.getView().byId("SolutionProductLineChartContainer").setVisible(false);

			Promise.all(aPromises).then(function () {
				var bVisible = this.getView().byId("hboxBusy").getVisible();
				this.getView().byId("hboxBusy").setVisible(!bVisible);
				this.getView().byId("solutionOverviewTable").setBusy(false);
				this.readImplementationPartner(this.getOwnerComponent().getModel("solutionModel"));
				//MISSIONRADAR 2211	
				this.readMissionRadarValues(this.getOwnerComponent().getModel("solutionModel"));
				var oSolutionTable = this.getView().byId("solutionOverviewTable");
				oSolutionTable.getColumns().forEach(function (col) {
					col.setFiltered(false);
					col.setFilterValue("");
					col.setSorted(false);
					col.filter();
				});
				oSolutionTable.sort();

				//also "All" Tile should show the pie chart	
				this.getView().byId("SolutionProductLineChartContainer").setVisible(true); //sSolution !== "All");
				this._setPieModel(sSolution, "product");

				//reset table filters / sorters / icon tab bar
				var oIconTabBar = this.getView().byId("iconTabBar");
				//var oIconTabBarOpenIssues = this.getView().byId("iconTabBarOpenIssues");

				var sKey = this.getOwnerComponent().getModel("solutionModel").getProperty("/preSelectKey");

				if (!sKey) {
					sKey = "All";
				}
				oIconTabBar.setSelectedKey(sKey);
				oIconTabBar.fireSelect({
					key: sKey
				});

			}.bind(this), function (err) {
				var bVisible = this.getView().byId("hboxBusy").getVisible();
				this.getView().byId("hboxBusy").setVisible(!bVisible);

				var bVisibleOpenIssues = this.getView().byId("hboxBusyOpenIssues").getVisible();
				this.getView().byId("hboxBusy").setVisible(!bVisibleOpenIssues);
			});
		},

		_readGlobalEscalations: function (aProductLines, oFilterForICP) {
			var oModel = this.getModel();
			var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICP, aProductLines, "ProductLine");

			//ALL ongoing escalations
			//Rating =   ALL
			//Case Status = status eq '20' or status eq '30'
			//process_type  Global Escalations (ZSPRCTYP01)  -->  should be predefined in Backend
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter(
						"Status", sap.ui.model.FilterOperator.EQ, "30"),
					new sap.ui.model.Filter(
						"Status", sap.ui.model.FilterOperator.EQ, "20"),
					new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "40") //Closed
						], false),
						this.getClosedDateFilter("ClosingDate")
					],
						true
					),
				], false)
				// or status eq 40 
			],
				true
			);

			oFinalFilter.push(tileSpecificFilters);
			var oSettings = this.getOwnerComponent().getModel("settings").getData();

			return new Promise(function (resolve, reject) {
				oModel.read("/GlobalEscalationsSet", {
					filters: oFinalFilter,
					success: function (data) {
						//sort client at side
						data = this._sortByRanking(data);
						data.results.forEach(function (result) {
							//in case the user has only AGGR AUTH we need to assure, that the action-Icon for showing the notes, is not visible in the UI
							//RD05.22 this is not valid anymore, because the HasNotes is now covered by AUTH checks in the Backend
							// if (oSettings.ShowGlobalAggregation) {
							// 	if (!oSettings.ShowGlobalEscalations && !oSettings.ShowRegionalGlobalEscalations) {
							// 		result.HasNotes = "";
							// 	}
							// }
						}, this);
						var ongoingGlobalEscalations = data.results.filter((item) => item.Status == 20 || item.Status == 30)
						var closedGlobalEscalations = data.results.filter((item) => item.Status == 40)
						this._convertDataForSolutionOverview("GlobalEscalations", ongoingGlobalEscalations);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/globalEscCustLevel", ongoingGlobalEscalations.length);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountGlobalEscalations", ongoingGlobalEscalations.length);

						this._convertDataForSolutionOverview("ClosedGlobalEscalations", closedGlobalEscalations);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountGlobalEscalationsClosed", closedGlobalEscalations.length);

						this._readGlobalEscalationsProducts(aProductLines, oFilterForICP, resolve);
					}.bind(this),
					error: function (data) {
						this.getOwnerComponent().getModel("solutionModel").setProperty("/GlobalEscalationsSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));
		},

		_readGlobalEscalationsProducts: function (aProductLines, oFilterForICP, resolve) {
			var oModel = this.getModel();
			var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICP, aProductLines, "ProductLine");

			//ALL ongoing escalations
			//Rating =   ALL
			//Case Status = status eq '20' or status eq '30'
			//process_type  Global Escalations (ZSPRCTYP01)  -->  should be predefined in Backend
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30"), new sap.ui.model.Filter(
					"Status", sap.ui.model.FilterOperator.EQ, "20"), new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "40") //Closed
						], false),
						this.getClosedDateFilter("ClosingDate")
					],
						true
					),], false)
			],
				true
			);

			oFinalFilter.push(tileSpecificFilters);

			oModel.read("/GlobalEscalationsSet", {
				urlParameters: {
					"$expand": "toProducts"
				},
				filters: oFinalFilter,
				success: function (data) {
					//concat toProducts properties
					//sort client at side
					data = this._sortByRanking(data);

					var oSolutionModel = this.getOwnerComponent().getModel("solutionModel");
					var aAlreadyAdded = oSolutionModel.getProperty("/SolutionOverview");
					var aAlreadyAddedClosed = oSolutionModel.getProperty("/SolutionOverviewClosed");
					var oProductsModel = this.getView().getModel("productsModel");
					var oProductsModelData = oProductsModel.getData();
					data.results.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
						result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
						result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
						oProductsModelData = oProductsModelData.concat(result.toProducts.results);

						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						//closed engagements
						var aTmpClosed = aAlreadyAddedClosed.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						aTmp = aTmp.concat(aTmpClosed)
						//solutionoverview nije isto sto i solution model
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].CaseId = result.CaseId;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVer = result.ProductVer;
								aTmp[i].ProductLineKeys = result.ProductLineKeys;
								aTmp[i].ProductKeys = result.ProductKeys;
							});
						}
					}, this);
					oProductsModel.setData(oProductsModelData);
					oProductsModel.refresh();

					resolve(data);
				}.bind(this),
				error: function (data) {
					this.getOwnerComponent().getModel("solutionModel").setProperty("/GlobalEscalationsSetBusy", false);
					resolve("No data found");
				}.bind(this)
			});

		},

		_readCrossIssuesNotes: function (oControl, id) {
			var oICModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oICModel.read("/CrossIssueSet(guid'" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		_readGlobalEscalationsNotes: function (oControl, id, sObjectType) {
			var oModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oModel.read("/GlobalEscalationsSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results, sObjectType);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
					this.getOwnerComponent().getModel("solutionModel").setProperty("/GlobalEscalationsSetBusy", false);
				}.bind(this)
			});

		},

		_readTechnicalBackofficeRequests: function (aProductLines, sRegion, oFilterForServiceNow) {
			//var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICP, aProductLines, "ProductLine");

			var sFilterString = "ORDERBYu_task_record.priority^state=100^u_escalation_type=0";

			sFilterString = this._generateRegionFilterForServiceNowObjectsEscalation(sRegion, sFilterString);

			var prodLineVariable = "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id";
			var aFilter = this._getCombinedSolutionFilterCims(oFilterForServiceNow, aProductLines, prodLineVariable);

			if (aFilter && aFilter.length > 0) {
				aFilter.forEach(function (filter) {
					sFilterString += "^" + filter;
				});
			}

			sFilterString = "sysparm_query=" + encodeURIComponent(sFilterString);
			//sFilterString = sFilterString.replaceAll("^", "%5e");
			//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
			if (sFilterString.startsWith("%5esysparm_query")) {
				sFilterString.replace("%5esysparm_query", "sysparm_query");
			}

			sFilterString += "&sysparm_fields=";
 			sFilterString += encodeURIComponent(Constants.fieldsForBDMTableWithoutParamter);
			sFilterString += encodeURIComponent(",u_task_record.u_product_version_on_creation.display_name,u_task_record.u_product_version_on_creation.model_number");

			return new Promise(function (resolve, reject) {
				var body = {
					"batch_request_id":1, 
					"rest_requests":[{
						"headers": [
							{"name":"Content-Type", "value":"application/json"},
							{"name":"Accept","value":"application/json"}
						],
						"url": "/api/now/table/sn_customerservice_escalation?" + sFilterString,
						"method":"GET",
						"id":"0000014383DUMMY",
						"exclude_response_headers": "true"
					}]
				};
				body = JSON.stringify(body);
				$.ajax({
					method: "POST",
					contentType: "application/json",
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
					data: body,
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					error: function() {
						resolve();
					},
					success: function(data) {
						data = JSON.parse(atob(data.serviced_requests[0].body));
						var oProductsModel = this.getView().getModel("productsModel");
						var oProductsModelData = oProductsModel.getData();
						data.result.forEach(function (item) {
							item["u_task_record.account.country_text"] = this.formatter.getCountryName(item["u_task_record.account.country"], this);
							item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"]);
							item["u_task_record.priority"] = this.formatter.getCimPriority(item["u_task_record.priority"]);
							item["u_task_record.priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"]);
							item.toProducts = {
								results: []
							};
							if (item["u_task_record.u_install_base_item.u_product.model_number"] !== "") {
								item.ProductKeys = item["u_task_record.u_install_base_item.u_product.model_number"];
								item.ProductLineKeys = item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"];
								item.HasNotes = item["u_business_impact"] !== "" || item["u_executive_summary"] !== "" || item["u_next_steps"] !== "" ?
									"X" : "";
								item.toProducts.results.push({
									CaseId: item["u_task_record.number"],
									Main: "",
									Product: item["u_task_record.u_install_base_item.u_product.model_number"],
									ProductT: item["u_task_record.u_install_base_item.u_product.display_name"],
									ProductCat: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id"],
									ProductCatT: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_name"],
									ProductLine: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"],
									ProductLineT: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_name"],
									ProductVersion: item["u_task_record.u_install_base_item.u_product_version.model_number"],
									ProductVersionT: item["u_task_record.u_install_base_item.u_product_version.display_name"]
								});
							}

							//Check if there is a product name, else try insert
							if (item["u_task_record.u_install_base_item.u_product_version.display_name"] == "") {
								if (item["u_task_record.u_product_version_on_creation.display_name"] !== "") {
									item["u_task_record.u_install_base_item.u_product_version.display_name"] = item[
										"u_task_record.u_product_version_on_creation.display_name"]
								}
							}

							//Check if there is a product number, else try insert
							if (item["u_task_record.u_install_base_item.u_product.model_number"] == "") {
								if (item["u_task_record.u_product_version_on_creation.model_number"] !== "") {
									item.toProducts.results.push({
										Product: item["u_task_record.u_product_version_on_creation.model_number"]
									});
									if (item["u_task_record.u_product_version_on_creation.model_number"] !== "") {
										item.ProductKeys = item["u_task_record.u_product_version_on_creation.model_number"]
									}
								}
							}

							//Check for Object type - should only be added if it is a CIM and not a CIM requests
							if (item["state"] === "101" || item["state"] === "103") {
								oProductsModelData = oProductsModelData.concat(item.toProducts.results);
								oProductsModel.setData(oProductsModelData);
								oProductsModel.refresh();
							}
						}.bind(this));

						this._convertDataForSolutionOverview("TechnicalBackofficeRequests", data.result);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountTechnicalBackofficeRequests", data.result.length);

						resolve(data);
						
					}.bind(this)
				});
			}.bind(this));

		},

		_readServiceNowTags: function () {
			//read Service NOW Tags; get tags, which have been created in the last half year (maybe this needs to be changed later?)
			return new Promise(function (resolve, reject) {
				var dateOffset = (24 * 60 * 60 * 1000) * Constants.serviceNowTagsCreatedSinceDays;
				var dateInPast = new Date();
				dateInPast.setTime(dateInPast.getTime() - dateOffset);
				var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd" // we need a format like 2022-12-24
				});
				dateInPast = oFormat.format(dateInPast);
				var sFilterString =
					"sysparm_query=id_type=Escalation%5elabel.sys_created_on%3Ejavascript:gs.dateGenerate(%27" + dateInPast +
					"%27,%2700:00:00%27)%5elabel.global=true&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";

				$.ajax({
					method: "GET",
					contentType: "application/json",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
					success: function (oData) {
						resolve(oData);
					}.bind(this),
					error: function (err) {
						resolve();
					}.bind(this)
				});
			}.bind(this));
		},

		_readBusinessDownSituations: function (aProductLines, sRegion, oFilterForServiceNow, oServiceNowTagPromise) {
			//var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICP, aProductLines, "ProductLine", "Region");

			var sFilterString = "ORDERBYu_task_record.priority^state=101^u_escalation_type=0^u_request_reason=7^ORu_request_reason=8^ORu_request_reason=9^ORu_request_reason=10";

			sFilterString = this._generateRegionFilterForServiceNowObjectsEscalation(sRegion, sFilterString);

			var prodLineVariable = "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id";
			var aFilter = this._getCombinedSolutionFilterCims(oFilterForServiceNow, aProductLines, prodLineVariable);

			if (aFilter && aFilter.length > 0) {
				aFilter.forEach(function (filter) {
					sFilterString += "^" + filter;
				});
			}

			sFilterString += "^NQstate=103^sys_updated_on>javascript:gs.daysAgo(28)^u_request_reason=7^ORu_request_reason=8^ORu_request_reason=9^ORu_request_reason=10";
			if (aFilter && aFilter.length > 0) {
				aFilter.forEach(function (filter) {
					sFilterString += "^" + filter;
				});
			}

			sFilterString = "sysparm_query=" + encodeURIComponent(sFilterString);

			//sFilterString = sFilterString.replaceAll("^", "%5e");
			//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
			if (sFilterString.startsWith("%5esysparm_query")) {
				sFilterString.replace("%5esysparm_query", "sysparm_query");
			}

			sFilterString += "fieldsForBDMTable";
			sFilterString += encodeURIComponent(Constants.fieldsForBDMTableWithoutParamter);
			sFilterString += encodeURIComponent(",u_task_record.u_product_version_on_creation.display_name,u_task_record.u_product_version_on_creation.model_number");

			return new Promise(function (resolve, reject) {
				var body = {
					"batch_request_id":1, 
					"rest_requests":[{
						"headers": [
							{"name":"Content-Type", "value":"application/json"},
							{"name":"Accept","value":"application/json"}
						],
						"url": "/api/now/table/sn_customerservice_escalation?" + sFilterString,
						"method":"GET",
						"id":"0000014383DUMMY",
						"exclude_response_headers": "true"
					}]
				};
				body = JSON.stringify(body);
				$.ajax({
					method: "POST",
					contentType: "application/json",
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
					data: body,
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					error: function() {
						resolve();
					},
					success: function(data) {
						data = JSON.parse(atob(data.serviced_requests[0].body));
						oServiceNowTagPromise.then(function (oTagData) { //wait for ServiceNow Tag data to be retrieved
							var oProductsModel = this.getView().getModel("productsModel");
							var oProductsModelData = oProductsModel.getData();
							data.result.forEach(function (item) {
								item["u_task_record.account.country_text"] = this.formatter.getCountryName(item["u_task_record.account.country"],
									this);
								item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"]);
								item["u_task_record.priority"] = this.formatter.getCimPriority(item["u_task_record.priority"]);
								item["u_task_record.priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"]);
								item.toProducts = {
									results: []
								};
								if (item["u_task_record.u_install_base_item.u_product.model_number"] !== "") {
									item.ProductKeys = item["u_task_record.u_install_base_item.u_product.model_number"];
									item.ProductLineKeys = item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"];
									item.HasNotes = item["u_business_impact"] !== "" || item["u_executive_summary"] !== "" || item["u_next_steps"] !==
										"" ?
										"X" : "";
									item.toProducts.results.push({
										CaseId: item["u_task_record.number"],
										Main: "",
										Product: item["u_task_record.u_install_base_item.u_product.model_number"],
										ProductT: item["u_task_record.u_install_base_item.u_product.display_name"],
										ProductCat: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id"],
										ProductCatT: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_name"],
										ProductLine: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"],
										ProductLineT: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_name"],
										ProductVersion: item["u_task_record.u_install_base_item.u_product_version.model_number"],
										ProductVersionT: item["u_task_record.u_install_base_item.u_product_version.display_name"]
									});
								}

								//Check if there is a product name, else try insert
								if (item["u_task_record.u_install_base_item.u_product_version.display_name"] == "") {
									if (item["u_task_record.u_product_version_on_creation.display_name"] !== "") {
										item["u_task_record.u_install_base_item.u_product_version.display_name"] = item[
											"u_task_record.u_product_version_on_creation.display_name"]
									}
								}

								//Check if there is a product number, else try insert
								if (item["u_task_record.u_install_base_item.u_product.model_number"] == "") {
									if (item["u_task_record.u_product_version_on_creation.model_number"] !== "") {
										item.toProducts.results.push({
											Product: item["u_task_record.u_product_version_on_creation.model_number"]
										});
										if (item.ProductKeys !== "") {
											item.ProductKeys = item["u_task_record.u_product_version_on_creation.model_number"]
										}
									}
								}

								//Check for Object type - should only be added if it is a CIM and not a CIM requests
								if (item["state"] === "101" || item["state"] === "103") {
									oProductsModelData = oProductsModelData.concat(item.toProducts.results);
									oProductsModel.setData(oProductsModelData);
									oProductsModel.refresh();
								}

								// set ServiceNow Tag Information
								var oTagElement = oTagData.result.filter(function (val) {
									return val["id_display"] === item.number; //"ESC0140066"; //
								});
								if (oTagElement) {
									item.CaseTag = "";
									oTagElement.forEach(function (tagElementItem, index) {
										item.CaseTag += tagElementItem['label.name'];
										if (oTagElement.length > (index + 1)) {
											item.CaseTag += ", ";
										}
									});
								}

							}.bind(this));

							//Business Down Situations
							var aBusinessDownSituations = data.result.filter(function (val) {
								return (val["u_request_reason"] === "8" && val["state"] == "101") ||
									(val["u_request_reason"] === "9" && val["state"] == "101");
								//reason is this or reason is that
								// reason is this and state is this or reason is that and state is thsi
							});



							this._convertDataForSolutionOverview("BusinessDownSituations", aBusinessDownSituations);
							this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountBusinessDownSituations", aBusinessDownSituations.length);

							var aClosedBusinessDownSituations = data.result.filter(function (val) {
								return (val["u_request_reason"] === "8" && val["state"] == "103") ||
									(val["u_request_reason"] === "9" && val["state"] == "103");
								//reason is this or reason is that
								// reason is this and state is this or reason is that and state is thsi
							});

							this._convertDataForSolutionOverview("ClosedBusinessDownSituations", aClosedBusinessDownSituations);
							this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountBusinessDownSituationsClosed", aClosedBusinessDownSituations.length);



							//xTec Engagements
							var aXTecEngagements = data.result.filter(function (val) {
								return val["u_request_reason"] === "10" && val["state"] == "101";
							});
							this._convertDataForSolutionOverview("XTecEngagements", aXTecEngagements);
							this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountXTecEngagements", aXTecEngagements.length);

							var aClosedXTecEngagements = data.result.filter(function (val) {
								return val["u_request_reason"] === "10" && val["state"] == "103";
							});
							this._convertDataForSolutionOverview("XTecEngagementsClosed", aClosedXTecEngagements);
							this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountXTecEngagementsClosed", aClosedXTecEngagements.length);


							//PE Critical Engagements
							var aPECriticalEngagements = data.result.filter(function (val) {
								return val["u_request_reason"] === "7" && val["state"] == "101";
							});
							this._convertDataForSolutionOverview("PECriticalEngagements", aPECriticalEngagements);
							this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountPECriticalEngagements", aPECriticalEngagements.length);

							// closed PE Critical Engagements
							var aClosedPECriticalEngagements = data.result.filter(function (val) {
								return val["u_request_reason"] === "7" && val["state"] == "103";
							});
							this._convertDataForSolutionOverview("PECriticalEngagementsClosed", aClosedPECriticalEngagements);
							this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountPECriticalEngagementsClosed", aClosedPECriticalEngagements.length);

							resolve(data);
						}.bind(this));
						
					}.bind(this)
				});
			}.bind(this));
		},

		_readCims: function (aProductLines, sRegion, oFilterForServiceNow, oServiceNowTagPromise) {
			return new Promise(function(resolveAll){
				var sFilterString = "ORDERBYu_task_record.priority^state=100^ORstate=101^u_escalation_type=3";
				var sFilterStringClosed = "ORDERBYu_task_record.priority^state=103^u_escalation_type=3^sys_updated_on>javascript:gs.daysAgo(28)";
				//sFilterString += "^NQstate=103^sys_updated_on>javascript:gs.daysAgo(28)^u_escalation_type=3";
				
				sFilterString = this._generateRegionFilterForServiceNowObjectsEscalation(sRegion, sFilterString);
				sFilterStringClosed = this._generateRegionFilterForServiceNowObjectsEscalation(sRegion, sFilterStringClosed);


				var prodLineVariable = "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id";
				var aFilter = this._getCombinedSolutionFilterCims(oFilterForServiceNow, aProductLines, prodLineVariable);

				if (aFilter && aFilter.length > 0) {
					aFilter.forEach(function (filter) {
						sFilterString += "^" + filter;
						sFilterStringClosed += "^" + filter;
					});
				}

				if (aFilter && aFilter.length > 0) {
					aFilter.forEach(function (filter) {
						sFilterString += "^" + filter;
						sFilterStringClosed += "^" + filter;
					});
				}

				sFilterString = "sysparm_query=" + encodeURIComponent(sFilterString);
				sFilterStringClosed = "sysparm_query=" + encodeURIComponent(sFilterStringClosed);
				//sFilterString = sFilterString.replaceAll("^", "%5e");
				//sFilterStringClosed = sFilterStringClosed.replaceAll("^", "%5e");
				//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
				if (sFilterString.startsWith("%5esysparm_query")) {
					sFilterString.replace("%5esysparm_query", "sysparm_query");
				}

				if (sFilterStringClosed.startsWith("%5esysparm_query")) {
					sFilterStringClosed.replace("%5esysparm_query", "sysparm_query");
				}

				sFilterString += "&sysparm_fields=";
				sFilterString += encodeURIComponent(Constants.fieldsForCimTableWithoutParameter);
				sFilterString += encodeURIComponent(",u_task_record.u_product_version_on_creation.display_name,u_task_record.u_product_version_on_creation.model_number");

				sFilterStringClosed += "&sysparm_fields=";
				sFilterStringClosed += encodeURIComponent(Constants.fieldsForCimTableWithoutParameter);
				sFilterStringClosed += encodeURIComponent(",u_task_record.u_product_version_on_creation.display_name,u_task_record.u_product_version_on_creation.model_number");

				var oPromiseOngoing = new Promise(function (resolve, reject) {
					var body = {
						"batch_request_id":1, 
						"rest_requests":[{
							"headers": [
								{"name":"Content-Type", "value":"application/json"},
								{"name":"Accept","value":"application/json"}
							],
							"url": "/api/now/table/sn_customerservice_escalation?" + sFilterString,
							"method":"GET",
							"id":"0000014383DUMMY",
							"exclude_response_headers": "true"
						}]
					};
					body = JSON.stringify(body);
					$.ajax({
						method: "POST",
						contentType: "application/json",
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
						data: body,
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						error: function() {
							resolve();
						},
						success: function(data) {
							data = JSON.parse(atob(data.serviced_requests[0].body));
							oServiceNowTagPromise.then(function (oTagData) { //wait for ServiceNow Tag data to be retrieved
								var oProductsModel = this.getView().getModel("productsModel");
								var oProductsModelData = oProductsModel.getData();
								data.result.forEach(function (item) {
									item["u_task_record.account.country_text"] = this.formatter.getCountryName(item["u_task_record.account.country"],
										this);
									item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"]);
									item["u_task_record.priority"] = this.formatter.getCimPriority(item["u_task_record.priority"]);
									item["u_task_record.priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"]);
									item.toProducts = {
										results: []
									};
									if (item["u_task_record.u_install_base_item.u_product.model_number"] !== "") {
										item.ProductKeys = item["u_task_record.u_install_base_item.u_product.model_number"];
										item.ProductLineKeys = item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"];
										item.HasNotes = item["escalation_justification"] !== "" ? "X" : "";
										item.toProducts.results.push({
											CaseId: item["u_task_record.number"],
											Main: "",
											Product: item["u_task_record.u_install_base_item.u_product.model_number"],
											ProductT: item["u_task_record.u_install_base_item.u_product.display_name"],
											ProductCat: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id"],
											ProductCatT: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_name"],
											ProductLine: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"],
											ProductLineT: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_name"],
											ProductVersion: item["u_task_record.u_install_base_item.u_product_version.model_number"],
											ProductVersionT: item["u_task_record.u_install_base_item.u_product_version.display_name"]
										});
									}

									//Check if there is a product name, else try insert
									if (item["u_task_record.u_install_base_item.u_product_version.display_name"] == "") {
										if (item["u_task_record.u_product_version_on_creation.display_name"] !== "") {
											item["u_task_record.u_install_base_item.u_product_version.display_name"] = item[
												"u_task_record.u_product_version_on_creation.display_name"]
										}
									}

									//Check if there is a product number, else try insert
									if (item["u_task_record.u_install_base_item.u_product.model_number"] == "") {
										if (item["u_task_record.u_product_version_on_creation.model_number"] !== "") {
											item.toProducts.results.push({
												Product: item["u_task_record.u_product_version_on_creation.model_number"]
											});
											if (item["u_task_record.u_product_version_on_creation.model_number"] !== "") {
												item.ProductKeys = item["u_task_record.u_product_version_on_creation.model_number"]
											}
										}
									}

									//Check for Object type - should only be added if it is a CIM and not a CIM requests
									if (item["state"] === "101") {
										oProductsModelData = oProductsModelData.concat(item.toProducts.results);
										oProductsModel.setData(oProductsModelData);
										oProductsModel.refresh();
									}

									//Check for Object type - should only be added if it is a CIM and not a CIM requests
									//Maybe not needed? (Closed ones)
									if (item["state"] === "103") {
										oProductsModelData = oProductsModelData.concat(item.toProducts.results);
										oProductsModel.setData(oProductsModelData);
										oProductsModel.refresh();
									}

									// set ServiceNow Tag Information
									var oTagElement = oTagData.result.filter(function (val) {
										return val["id_display"] === item.number; //"ESC0140066"; //
									});
									if (oTagElement) {
										item.CaseTag = "";
										oTagElement.forEach(function (tagElementItem, index) {
											item.CaseTag += tagElementItem['label.name'];
											if (oTagElement.length > (index + 1)) {
												item.CaseTag += ", ";
											}
										});
									}

								}.bind(this));

								var aCims = data.result.filter(function (val) {
									return val["state"] === "101";
								});

								this._convertDataForSolutionOverview("Cims", aCims);
								this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCims", aCims.length);

								var aCimsRequest = data.result.filter(function (val) {
									return val["state"] === "100";
								});

								this._convertDataForSolutionOverview("CimRequests", aCimsRequest);
								this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCimsRequest", aCimsRequest.length);
								// closed critical incident management
								var aCimsClose = data.result.filter(function (val) {
									return val["state"] === "103";
								});

								this._convertDataForSolutionOverview("ClosedCims", aCimsClose); // should it be cims here?? is the same??
								this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCimsClosed", aCimsClose.length);

								resolve(data);
							}.bind(this));
						}.bind(this)
					});
				}.bind(this));

				var oPromiseClosed = new Promise(function (resolve, reject) {
					var body = {
						"batch_request_id":1, 
						"rest_requests":[{
							"headers": [
								{"name":"Content-Type", "value":"application/json"},
								{"name":"Accept","value":"application/json"}
							],
							"url": "/api/now/table/sn_customerservice_escalation?" + sFilterStringClosed,
							"method":"GET",
							"id":"0000014383DUMMY",
							"exclude_response_headers": "true"
						}]
					};
					body = JSON.stringify(body);
					$.ajax({
						method: "POST",
						contentType: "application/json",
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/v1/batch",
						data: body,
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						error: function() {
							resolve();
						},
						success: function(data) {
							data = JSON.parse(atob(data.serviced_requests[0].body));
							oServiceNowTagPromise.then(function (oTagData) { //wait for ServiceNow Tag data to be retrieved
								var oProductsModel = this.getView().getModel("productsModel");
								var oProductsModelData = oProductsModel.getData();
								data.result.forEach(function (item) {
									item["u_task_record.account.country_text"] = this.formatter.getCountryName(item["u_task_record.account.country"],
										this);
									item["u_task_record.state"] = this.formatter.getCimStatus(item["u_task_record.state"]);
									item["u_task_record.priority"] = this.formatter.getCimPriority(item["u_task_record.priority"]);
									item["u_task_record.priorityMatched"] = this.formatter.sortPriorities(item["u_task_record.priority"]);
									item.toProducts = {
										results: []
									};
									if (item["u_task_record.u_install_base_item.u_product.model_number"] !== "") {
										item.ProductKeys = item["u_task_record.u_install_base_item.u_product.model_number"];
										item.ProductLineKeys = item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"];
										item.HasNotes = item["escalation_justification"] !== "" ? "X" : "";
										item.toProducts.results.push({
											CaseId: item["u_task_record.number"],
											Main: "",
											Product: item["u_task_record.u_install_base_item.u_product.model_number"],
											ProductT: item["u_task_record.u_install_base_item.u_product.display_name"],
											ProductCat: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id"],
											ProductCatT: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_name"],
											ProductLine: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id"],
											ProductLineT: item["u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_name"],
											ProductVersion: item["u_task_record.u_install_base_item.u_product_version.model_number"],
											ProductVersionT: item["u_task_record.u_install_base_item.u_product_version.display_name"]
										});
									}

									//Check if there is a product name, else try insert
									if (item["u_task_record.u_install_base_item.u_product_version.display_name"] == "") {
										if (item["u_task_record.u_product_version_on_creation.display_name"] !== "") {
											item["u_task_record.u_install_base_item.u_product_version.display_name"] = item[
												"u_task_record.u_product_version_on_creation.display_name"]
										}
									}

									//Check if there is a product number, else try insert
									if (item["u_task_record.u_install_base_item.u_product.model_number"] == "") {
										if (item["u_task_record.u_product_version_on_creation.model_number"] !== "") {
											item.toProducts.results.push({
												Product: item["u_task_record.u_product_version_on_creation.model_number"]
											});
											if (item["u_task_record.u_product_version_on_creation.model_number"] !== "") {
												item.ProductKeys = item["u_task_record.u_product_version_on_creation.model_number"]
											}
										}
									}

									//Check for Object type - should only be added if it is a CIM and not a CIM requests
									if (item["state"] === "101") {
										oProductsModelData = oProductsModelData.concat(item.toProducts.results);
										oProductsModel.setData(oProductsModelData);
										oProductsModel.refresh();
									}

									//Check for Object type - should only be added if it is a CIM and not a CIM requests
									//Maybe not needed? (Closed ones)
									if (item["state"] === "103") {
										oProductsModelData = oProductsModelData.concat(item.toProducts.results);
										oProductsModel.setData(oProductsModelData);
										oProductsModel.refresh();
									}

									// set ServiceNow Tag Information
									var oTagElement = oTagData.result.filter(function (val) {
										return val["id_display"] === item.number; //"ESC0140066"; //
									});
									if (oTagElement) {
										item.CaseTag = "";
										oTagElement.forEach(function (tagElementItem, index) {
											item.CaseTag += tagElementItem['label.name'];
											if (oTagElement.length > (index + 1)) {
												item.CaseTag += ", ";
											}
										});
									}

								}.bind(this));

								var aCims = data.result.filter(function (val) {
									return val["state"] === "101";
								});

								this._convertDataForSolutionOverview("Cims", aCims);
								this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCims", aCims.length);

								var aCimsRequest = data.result.filter(function (val) {
									return val["state"] === "100";
								});

								this._convertDataForSolutionOverview("CimRequests", aCimsRequest);
								this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCimsRequest", aCimsRequest.length);
								// closed critical incident management
								var aCimsClose = data.result.filter(function (val) {
									return val["state"] === "103";
								});

								this._convertDataForSolutionOverview("ClosedCims", aCimsClose); // should it be cims here?? is the same??
								this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCimsClosed", aCimsClose.length);

								resolve(data);
							}.bind(this));
						}.bind(this)
					});
				}.bind(this));



				Promise.all([oPromiseOngoing,oPromiseClosed]).then(function(){
					resolveAll();
				});	

			}.bind(this));

		},
		_generateRegionFilterForServiceNowObjectsEscalation: function (sRegion, sFilterString) {
			if (sRegion) {
				var sRegionFilterString = "^",
					sRegionEMEAFilterString = "",
					bBothEMEAFiltersSelected = false;
				sRegion.split(",").forEach(function (region, i) {
					//For Service Now we need to implement EMEA_North and EMEA_South differently, because it is not implmeneted yet
					//we need to take the specific countries instead
					//Moreover we need to take care, that it is still working together with the other region filters like MEE and NA
					if (region === "EMEA_NORTH") {
						if (bBothEMEAFiltersSelected) {
							sRegionEMEAFilterString += "^OR";
						} else if (!sRegionFilterString.endsWith("^OR")) {
							sRegionEMEAFilterString += "^";
						}
						sRegionEMEAFilterString += Constants.emeaNorthCountries;
						bBothEMEAFiltersSelected = true;
						//e.g. %5eu_task_record.account.country=AL%5eORu_task_record.account.country=DZ
					} else if (region === "EMEA_SOUTH") {
						if (bBothEMEAFiltersSelected) {
							sRegionEMEAFilterString += "^OR";
						} else if (!sRegionFilterString.endsWith("^OR")) {
							sRegionEMEAFilterString += "^";
						}
						sRegionEMEAFilterString += Constants.emeaSouthCountries;
						bBothEMEAFiltersSelected = true;
						//e.g. %5eu_task_record.account.country=AL%5eORu_task_record.account.country=DZ
					} else {
						sRegionFilterString += "u_task_record.account.u_region=" + region;
						if (i < (sRegion.split(",").length - 1)) {
							sRegionFilterString += "^OR";
						}
					}
				});
				if (sRegionEMEAFilterString !== "" && sRegionFilterString !== "^") {
					sRegionFilterString = sRegionFilterString + sRegionEMEAFilterString.replace("^", "^OR"); // we need to add an OR, because the countries need to be handled as an OR related to the region filter in this specific case, It should not be an AND
				} else if (sRegionEMEAFilterString !== "") {
					sRegionFilterString = sRegionEMEAFilterString;
				}
				sFilterString += sRegionFilterString;
			}
			return sFilterString;
		},

		_readCriticalSituations: function (aProductLines, oFilterForICP) {
			var oModel = this.getModel();
			var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICP, aProductLines, "ProductLine");

			//Top Critical Customers
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99"),
					//closed TCC
					new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
						], false),
						this.getClosedDateFilter("ClosingDate")
					],
						true
					)
				], false)
			],
				true
			);
			oFinalFilter.push(tileSpecificFilters);
			oFinalFilter.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP06"));
			oFinalFilter.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			return new Promise(function (resolve, reject) {
				oModel.read("/CustomerEngagementSet", {
					filters: oFinalFilter,
					urlParameters: {
						"$top": "9999"
					},
					success: function (data) {
						//sort client at side
						var ongoingTopCriticalCustomers = {}
						ongoingTopCriticalCustomers.results = data.results.filter(function (val) {
							return val.Status != "90";
						});
						ongoingTopCriticalCustomers = this._sortByRanking(ongoingTopCriticalCustomers);
						this._convertDataForSolutionOverview("TopCriticalCustomers", ongoingTopCriticalCustomers.results);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/TopCriticalCustomers", ongoingTopCriticalCustomers.results.length);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountTopCriticalCustomers", ongoingTopCriticalCustomers.results.length);
						//resolve(data);


						//closed top critical customers
						var closedTopCriticalCustomers = {}
						closedTopCriticalCustomers.results = data.results.filter(function (val) {
							return val.Status == "90";
						});
						closedTopCriticalCustomers = this._sortByRanking(closedTopCriticalCustomers)
						this._convertDataForSolutionOverview("TopCriticalCustomersClosed", closedTopCriticalCustomers.results);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/closedTopCriticalCustomers", closedTopCriticalCustomers.results.length);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountTopCriticalCustomersClosed", closedTopCriticalCustomers.results.length);

						this._readCriticalSituationsProducts(aProductLines, oFilterForICP, resolve);
					}.bind(this),
					error: function (data) {
						this.getOwnerComponent().getModel("solutionModel").setProperty("/CriticalSituationsSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));
		},

		_readCriticalSituationsProducts: function (aProductLines, oFilterForICP, resolve) {
			var oModel = this.getModel();
			var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICP, aProductLines, "ProductLine");

			//Top Critical Customers
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99"),
					//closed TCC
					new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
						], false),
						this.getClosedDateFilter("ClosingDate")
					],
						true
					)
				], false)
			],
				true
			);
			oFinalFilter.push(tileSpecificFilters);
			oFinalFilter.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP06"));
			oFinalFilter.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			//return new Promise(function (resolve, reject) {

			oModel.read("/CustomerEngagementSet", {
				filters: oFinalFilter,
				urlParameters: {
					"$top": "9999", //needed in order to get more than 1000 results back
					"$expand": "toProducts",
					"$select": "CaseId,toProducts"
				},
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);
					//concat toProducts properties
					var oSolutionModel = this.getOwnerComponent().getModel("solutionModel");
					var aAlreadyAdded = oSolutionModel.getProperty("/SolutionOverview");
					var oProductsModel = this.getView().getModel("productsModel");
					var oProductsModelData = oProductsModel.getData();
					data.results.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
						result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
						result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
						oProductsModelData = oProductsModelData.concat(result.toProducts.results);

						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});

						var aAlreadyAddedClosed = oSolutionModel.getProperty("/SolutionOverviewClosed");
						var aTmpClosed = aAlreadyAddedClosed.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						aTmp = aTmp.concat(aTmpClosed)
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].CaseId = result.CaseId;
								aTmp[i].Product = result.Product;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVer = result.ProductVer;
								aTmp[i].ProductLineKeys = result.ProductLineKeys;
								aTmp[i].ProductKeys = result.ProductKeys;
							});
						}
					}, this);
					oProductsModel.setData(oProductsModelData);
					oProductsModel.refresh();

					resolve(data);
				}.bind(this),
				error: function (data) {
					this.getOwnerComponent().getModel("solutionModel").setProperty("/CriticalSituationsSetBusy", false);
					resolve("No data found");
				}.bind(this)
			});
			//}.bind(this));
		},

		_readCriticalSituationsNotes: function (oControl, id, sObjectType) {
			var oModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oModel.read("/CustomerEngagementSet('" + id + "')/toLastNotes", {
				success: function (data) { //show busy indicator in Popover	sap.ui.core.BusyIndicator.hide();
					this.openQuickInfoPopover(oControl, data.results, sObjectType);
				}.bind(this),
				error: function (data) { //show busy indicator in Popover	sap.ui.core.BusyIndicator.hide();
					oControl.setBusy(false);
					this.getOwnerComponent().getModel("solutionModel").setProperty("/CriticalSituationsSetBusy", false);
				}.bind(this)
			});
			//}.bind(this));
		},

		_readTaskForces: function (aProductLines, oFilterForICP) {
			var oModel = this.getModel();
			var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICP, aProductLines, "ProductLine");

			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99"),
					//closed Task Forces
					new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
						], false),
						this.getClosedDateFilter("ClosingDate")
					],
						true
					)
				], false)
			],
				true
			);
			oFinalFilter.push(tileSpecificFilters);

			oFinalFilter.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP07"));
			oFinalFilter.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			return new Promise(function (resolve, reject) {
				oModel.read("/CustomerEngagementSet", {
					filters: oFinalFilter,
					urlParameters: {
						"$top": "9999"
					},
					success: function (data) {
						//sort client at side
						var ongoingTaskForces = {}
						ongoingTaskForces.results = data.results.filter(function (val) {
							return val.Status != "90";
						});
						ongoingTaskForces = this._sortByRanking(ongoingTaskForces);
						data = this._sortByRanking(data);
						this._convertDataForSolutionOverview("TaskForces", ongoingTaskForces.results);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountTaskForces", ongoingTaskForces.results.length);

						this._readTaskForcesProducts(aProductLines, oFilterForICP, resolve);

						//closed Task Forces

						var closedTaskForces = {}
						closedTaskForces.results = data.results.filter(function (val) {
							return val.Status == "90";
						});
						closedTaskForces = this._sortByRanking(closedTaskForces)
						//closedTaskForces = ongoingTaskForces //delete this
						this._convertDataForSolutionOverview("TaskForcesClosed", closedTaskForces.results);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountTaskForcesClosed", closedTaskForces.results.length);


					}.bind(this),
					error: function (data) {
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));
		},

		_readTaskForcesProducts: function (aProductLines, oFilterForICP, resolve) {
			var oModel = this.getModel();
			var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICP, aProductLines, "ProductLine");

			//all ongoing Critical Customer Management	
			//Critical Period Coverage 
			//Project Engagement Support/Guided Solution Support
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99"),
					//closed Task Forces
					new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
						], false),
						this.getClosedDateFilter("ClosingDate")
					],
						true
					)
				], false)
			],
				true
			);
			oFinalFilter.push(tileSpecificFilters);

			oFinalFilter.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP07"));

			//return new Promise(function (resolve, reject) {
			oFinalFilter.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			oModel.read("/CustomerEngagementSet", {
				filters: oFinalFilter,
				urlParameters: {
					"$top": "9999", //needed in order to get more than 1000 results back
					"$expand": "toProducts",
					"$select": "CaseId,toProducts"
				},
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);
					//only append data to pie chart if it was filtered
					var aFilteredData = [];
					var oSolutionModel = this.getOwnerComponent().getModel("solutionModel");
					var aAlreadyAdded = oSolutionModel.getProperty("/SolutionOverview");

					data.results.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
						result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
						result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");

						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						var aAlreadyAddedClosed = oSolutionModel.getProperty("/SolutionOverviewClosed");
						var aTmpClosed = aAlreadyAddedClosed.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						aTmp = aTmp.concat(aTmpClosed)

						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].CaseId = result.CaseId;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVer = result.ProductVer;
								aTmp[i].ProductLineKeys = result.ProductLineKeys;
								aTmp[i].ProductKeys = result.ProductKeys;
							});
						}

					}, this);
					aFilteredData = aFilteredData.concat(data.results);

					//concat toProducts properties
					var oProductsModel = this.getView().getModel("productsModel");
					var oProductsModelData = oProductsModel.getData();

					aFilteredData.forEach(function (result) {
						oProductsModelData = oProductsModelData.concat(result.toProducts.results);
					}, this);
					oProductsModel.setData(oProductsModelData);
					oProductsModel.refresh();
					oSolutionModel.refresh();

					resolve(data);
				}.bind(this),
				error: function (data) {
					this.getOwnerComponent().getModel("solutionModel").setProperty("/CriticalSituationsSetBusy", false);
					resolve("No data found");
				}.bind(this)
			});
			//}.bind(this));

		},

		_readCriticalEventCoverage: function (aProdLines, sRegion, oFilterForCEC) {
			return new Promise(function (resolve) {
				var aFilters = [];

				if (oFilterForCEC && oFilterForCEC.aFilters.length > 0) {
					aFilters.push(oFilterForCEC);
				}
				if (typeof sRegion !== "undefined" && sRegion !== "") {

					var aRegionHelp = this.getModel("countryRegionModel").getData();
					var selectedRegions = sRegion.split(","); // Split the selected regions into an array

					// Create an object to map selected regions to filterBasis (given in countryRegionModel)
					var regionFilterBasisMap = {
						"EMEA North": "subsubregion",
						"EMEA South": "subsubregion",
						"NA": "region",
						"APJ": "region",
						"MEE": "subregion",
						"GTC": "subregion",
						"LAC": "subregion"
					};

					var regionCountryValues = [];

					// Iterate through selectedRegions and create filters based on filterBasis
					selectedRegions.forEach(function (region) {
						var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

						// Filter regionCountries based on the chosen filter basis
						var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
							return item[filterBasis] === region;
						});

						// Add regionCountryValues for the current region to the array
						regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
							return regionCountry.country;
						}));
					});

					// Create the regionFilter with all regionCountryValues
					var eqFilters = regionCountryValues.map(function (country) {
						return new sap.ui.model.Filter("CustomerCountry", sap.ui.model.FilterOperator.EQ, country);
					});

					var regionFilter = new sap.ui.model.Filter({
						filters: eqFilters,
						and: false //OR
					});


					// Combine the regionFilter with filterCondition using AND conjunction
					aFilters.push(regionFilter);
				}

				var tileSpecificFilters = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "CECSTAT01"),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "CECSTAT03"),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "CECSTAT11")
					], false),
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "CEC")
					], false)
				],
					true
				);

				aFilters.push(tileSpecificFilters);

				var oModel = this.getOwnerComponent().getModel("subModel");

				oModel.read("/MCCObject", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					urlParameters: {
						"$expand": "toNotes"
					},
					success: function (data) {
						var aOngoingData = [];
						var aClosedData = [];
						var aPromises = [];


						data.results.forEach(function (entry) {
							aPromises.push(new Promise(function (resolve2) {
								entry.HasNotes = entry.toNotes.results.length > 0 ? "X" : "";
								var pastDate = new Date();
								pastDate.setDate(pastDate.getDate() - 364);

								var bOngoing = entry.Status === "CECSTAT01" || entry.Status === "CECSTAT03";
								var bClosed = entry.Status === "CECSTAT11" && entry.ClosureDate.getTime() <= pastDate.getTime();

								if (bOngoing || bClosed) {
									this.getOwnerComponent().getModel("appDepModel").read("/ProductSet", {
										filters: [new sap.ui.model.Filter("ProductNR", "EQ", entry.ProductID)],
										success: function (oData) {
											var oSolution = this.getView().getModel("solution").getData();
											var aSolProdLines = oSolution.toSolutionProdLin.results;
											entry.Product = this.formatter.concatProducts(oData.results, "ProductName");
											entry.ProductKey = this.formatter.concatProducts(oData.results, "ProductNR");
											entry.ProductT = this.formatter.concatProducts(oData.results, "ProductName");
											entry.ProductLine = this.formatter.concatProducts(oData.results, "LineName");
											entry.ProductLineKey = this.formatter.concatProducts(oData.results, "LineID");
											entry.ProductLineT = this.formatter.concatProducts(oData.results, "LineName");
											entry.ProductLineKeys = this.formatter.concatProducts(oData.results, "LineID");
											entry.ProductKeys = this.formatter.concatProducts(oData.results, "ProductNR");
											oData.results.forEach(function (data) {
												var aTmp = aSolProdLines.filter(function (prodline) {
													return prodline.PlKey === data.LineID;
												});
												if (aTmp.length > 0) {
													if (bOngoing) {
														aOngoingData.push(entry);
													} else if (bClosed) {
														aClosedData.push(entry);
													}
												}
											});
											resolve2();
										}.bind(this),
										error: function () {
											resolve2();
										}
									});
								} else {
									resolve2();
								}
							}.bind(this)));
						}.bind(this));

						Promise.all(aPromises).then(function () {
							this._convertDataForSolutionOverview("CriticalEventCoverages", aOngoingData);
							this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCriticalEventCoverages", aOngoingData.length);
							this._convertDataForSolutionOverview("CriticalEventCoveragesClosed", aClosedData);
							this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCriticalEventCoveragesClosed", aClosedData.length);
							resolve();
						}.bind(this));

					}.bind(this),
					error: function (data) {
						this.getOwnerComponent().getModel("solutionModel").setProperty("/CriticalSituationsSetBusy", false);
						resolve("No data found")
					}.bind(this)
				});

			}.bind(this));
		},

		_readCrossIssues: function (aProductLines, oFilterForICPwithouthTags) {
			var oModel = this.getModel();
			var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICPwithouthTags, aProductLines, "ProductLine");

			//all ongoing Critical Customer Management	
			//Critical Period Coverage 
			//Project Engagement Support/Guided Solution Support
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0010"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0011"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0016"),
					//closed cross issues
					new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0012"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0013"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0014"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0017"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0018")
						], false),
						this.getClosedDateFilter("ChangeDate")
					],
						true
					)
				], false)
			],
				true
			);
			oFinalFilter.push(tileSpecificFilters);
			//set SoldToParty ID dependent on system
			var currentUrl = window.location.href;
			var sSoldToParty = currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") ? "4699754" : "20672944";
			oFinalFilter.push(new sap.ui.model.Filter("SoldToParty", sap.ui.model.FilterOperator.EQ, sSoldToParty));

			return new Promise(function (resolve, reject) {

				oModel.read("/CrossIssueSet", {
					filters: oFinalFilter,
					urlParameters: {
						"$top": "9999"
					},
					success: function (data) {
						//sort client at side
						var ongoingCrossIssues = {}
						ongoingCrossIssues.results = data.results.filter(function (val) {
							return val.Status == "E0010" || val.Status == "E0011" || val.Status == "E0016";
						});


						//data = this._sortByRanking(data);
						ongoingCrossIssues = this._sortByRanking(ongoingCrossIssues);

						this._convertDataForSolutionOverview("CrossIssues", ongoingCrossIssues.results);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCrossIssues", ongoingCrossIssues.results.length);

						//closed cross issues
						var closedCrossIssues = {}
						closedCrossIssues.results = data.results.filter(function (val) {
							return val.Status == "E0012" || val.Status == "E0013" || val.Status == "E0014" || val.Status == "E0017" || val.Status == "E0018";
						});
						this._convertDataForSolutionOverview("CrossIssuesClosed", closedCrossIssues.results);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCrossIssuesClosed", closedCrossIssues.results.length);


						this._readCrossIssuesProducts(aProductLines, oFilterForICPwithouthTags, resolve);

					}.bind(this),
					error: function (data) {
						this.getOwnerComponent().getModel("solutionModel").setProperty("/CriticalSituationsSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));

		},

		_readCrossIssuesProducts: function (aProductLines, oFilterForICPwithouthTags, resolve) {
			var oModel = this.getModel();
			var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICPwithouthTags, aProductLines, "ProductLine");

			//all ongoing Critical Customer Management	
			//Critical Period Coverage 
			//Project Engagement Support/Guided Solution Support
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0010"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0011"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0016"),
					//closed cross issues
					new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0012"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0013"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0014"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0017"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0018")
						], false),
						this.getClosedDateFilter("ChangeDate")
					],
						true
					)
				], false),
			],
				true
			);
			oFinalFilter.push(tileSpecificFilters);
			//set SoldToParty ID dependent on system
			var currentUrl = window.location.href;
			var sSoldToParty = currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") ? "4699754" : "20672944";
			oFinalFilter.push(new sap.ui.model.Filter("SoldToParty", sap.ui.model.FilterOperator.EQ, sSoldToParty));

			oModel.read("/CrossIssueSet", {
				filters: oFinalFilter,
				urlParameters: {
					"$top": "9999", //needed in order to get more than 1000 results back
					"$expand": "toProducts,toAffCustomers",
					"$select": "ObjectId,toProducts,toAffCustomers"
				},
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);
					//only append data to pie chart if it was filtered

					var oSolutionModel = this.getOwnerComponent().getModel("solutionModel");
					var aAlreadyAdded = oSolutionModel.getProperty("/SolutionOverview");

					data.results.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
						result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
						result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");

						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === result.ObjectId;
						});
						var aAlreadyAddedClosed = oSolutionModel.getProperty("/SolutionOverviewClosed");
						var aTmpClosed = aAlreadyAddedClosed.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						aTmp = aTmp.concat(aTmpClosed)

						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].CaseId = result.CaseId;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVer = result.ProductVer;
								aTmp[i].ProductLineKeys = result.ProductLineKeys;
								aTmp[i].ProductKeys = result.ProductKeys;
								aTmp[i].toAffCustomers = result.toAffCustomers;
								aTmp[i].MasterEventCustomerCount = result.toAffCustomers.results.length;
							});
						}

					}, this);

					//concat toProducts properties
					var oProductsModel = this.getView().getModel("productsModel");
					var oProductsModelData = oProductsModel.getData();

					data.results.forEach(function (result) {
						oProductsModelData = oProductsModelData.concat(result.toProducts.results);
					}, this);
					oProductsModel.setData(oProductsModelData);
					oProductsModel.refresh();
					oSolutionModel.refresh();

					resolve(data);
				}.bind(this),
				error: function (data) {
					this.getOwnerComponent().getModel("solutionModel").setProperty("/CriticalSituationsSetBusy", false);
					resolve("No data found");
				}.bind(this)
			});
			//}.bind(this));
		},

		_readCustomerEngagements: function (aProductLines, oFilterForICP) {
			var oModel = this.getModel();
			var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICP, aProductLines, "ProductLine");

			//all ongoing Critical Customer Management	
			//Critical Period Coverage 
			//Project Engagement Support/Guided Solution Support
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99"),
					//closed engagments

					new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
						], false),
						this.getClosedDateFilter("ClosingDate")
					],
						true
					)


				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04"),
					new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP05")
				], false)
			],
				true
			);
			oFinalFilter.push(tileSpecificFilters);

			//aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP05"));

			return new Promise(function (resolve, reject) {
				oFinalFilter.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
				oModel.read("/CustomerEngagementSet", {
					filters: oFinalFilter,
					urlParameters: {
						"$top": "9999"
					},
					success: function (data) {
						//sort client at side
						data = this._sortByRanking(data);

						//Critical Customer Management
						var criticalCustomerManagement = data.results.filter(function (val) {
							return val.CustomerType === "ZSCUSTYP05" && val.Status != "90";;
						});

						//CCM Light Cases
						this._convertDataForSolutionOverview("CriticalCustomerManagement", criticalCustomerManagement);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCriticalCustomerManagement",
							criticalCustomerManagement.length);

						//closed Critical Customer Management
						var closedCriticalCustomerManagement = data.results.filter(function (val) {
							return val.CustomerType === "ZSCUSTYP05" && val.Status == "90";
						});
						this._convertDataForSolutionOverview("CriticalCustomerManagementClosed", closedCriticalCustomerManagement);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCriticalCustomerManagementClosed",
							closedCriticalCustomerManagement.length);

						/*var aFilteredData = [];
						var aFilters = [new sap.ui.model.Filter([
							new sap.ui.model.Filter("bCCML1", sap.ui.model.FilterOperator.EQ, true),
							new sap.ui.model.Filter("bCCML2", sap.ui.model.FilterOperator.NE, true)
						], true)];
						this.getOwnerComponent().getModel("subModel").read("/Cases", {
							filters: aFilters,
							urlParameters: {
								"$select": "CaseID,bCCML1,bCCML2"
							},
							success: function (oData) {
								//check if not a light case
								criticalCustomerManagement.forEach(function (c) {
									var oCase = oData.results.find(function (hanaCase) {
										return c.CaseId === hanaCase.CaseID.toString();
									});
									if (!oCase) {
										aFilteredData.push(c);
									}
								});

								this._convertDataForSolutionOverview("CriticalCustomerManagement", aFilteredData);
								this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCriticalCustomerManagement",
									aFilteredData.length);

							}.bind(this)
						});*/

						//Critical Period Coverage
						var criticalPeriodCoverage = data.results.filter(function (val) {
							return val.CustomerType === "ZSCUSTYP04" && val.Status != "90";;
						});
						this._convertDataForSolutionOverview("CriticalPeriodCoverage", criticalPeriodCoverage);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCriticalPeriodCoverage", criticalPeriodCoverage.length);

						//closed critical period coverage
						var closedCriticalPeriodCoverage = data.results.filter(function (val) {
							return val.CustomerType === "ZSCUSTYP04" && val.Status == "90";
						});
						//closedCriticalPeriodCoverage = criticalPeriodCoverage
						this._convertDataForSolutionOverview("CriticalPeriodCoverageClosed", closedCriticalPeriodCoverage);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCriticalPeriodCoverageClosed", closedCriticalPeriodCoverage.length);


						this._readCustomerEngagementsProducts(aProductLines, oFilterForICP, resolve);

					}.bind(this),
					error: function (data) {
						this.getOwnerComponent().getModel("solutionModel").setProperty("/CriticalSituationsSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));

		},

		_readCustomerEngagementsProducts: function (aProductLines, oFilterForICP, resolve) {
			var oModel = this.getModel();
			var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICP, aProductLines, "ProductLine");

			//all ongoing Critical Customer Management	
			//Critical Period Coverage 
			//Project Engagement Support/Guided Solution Support
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99"),
					//closed engagments

					new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90") //Closed
						], false),
						this.getClosedDateFilter("ClosingDate")
					],
						true
					)
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04"),
					new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP05")
				], false)
			],
				true
			);
			oFinalFilter.push(tileSpecificFilters);

			//aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP05"));

			//return new Promise(function (resolve, reject) {
			oFinalFilter.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			oModel.read("/CustomerEngagementSet", {
				filters: oFinalFilter,
				urlParameters: {
					"$top": "9999", //needed in order to get more than 1000 results back
					"$expand": "toProducts",
					"$select": "CaseId,CustomerType,toProducts"
				},
				success: function (data) {
					//sort client at side
					data = this._sortByRanking(data);
					//only append data to pie chart if it was filtered
					var aFilteredData = [];
					var oSolutionModel = this.getOwnerComponent().getModel("solutionModel");
					var aAlreadyAdded = oSolutionModel.getProperty("/SolutionOverview");

					//Critical Customer Management
					var criticalCustomerManagement = data.results.filter(function (val) {
						return val.CustomerType === "ZSCUSTYP05";
					});
					criticalCustomerManagement.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
						result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
						result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");

						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						var aAlreadyAddedClosed = oSolutionModel.getProperty("/SolutionOverviewClosed");
						var aTmpClosed = aAlreadyAddedClosed.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						aTmp = aTmp.concat(aTmpClosed)
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].CaseId = result.CaseId;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVer = result.ProductVer;
								aTmp[i].ProductLineKeys = result.ProductLineKeys;
								aTmp[i].ProductKeys = result.ProductKeys;
							});
						}

					}, this);
					aFilteredData = aFilteredData.concat(criticalCustomerManagement);

					//Critical Period Coverage
					var criticalPeriodCoverage = data.results.filter(function (val) {
						return val.CustomerType === "ZSCUSTYP04";
					});
					criticalPeriodCoverage.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
						result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
						result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
						//check if this is already in solution model
						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.ObjectId === result.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVer = result.ProductVer;
								aTmp[i].ProductLineKeys = result.ProductLineKeys;
								aTmp[i].ProductKeys = result.ProductKeys;
							});
						}
					}, this);
					aFilteredData = aFilteredData.concat(criticalPeriodCoverage);

					//concat toProducts properties
					var oProductsModel = this.getView().getModel("productsModel");
					var oProductsModelData = oProductsModel.getData();

					aFilteredData.forEach(function (result) {
						oProductsModelData = oProductsModelData.concat(result.toProducts.results);
					}, this);
					oProductsModel.setData(oProductsModelData);
					oProductsModel.refresh();
					oSolutionModel.refresh();

					resolve(data);
				}.bind(this),
				error: function (data) {
					this.getOwnerComponent().getModel("solutionModel").setProperty("/CriticalSituationsSetBusy", false);
					resolve("No data found");
				}.bind(this)
			});
			//}.bind(this));
		},

		_readCustomerEngagementsNotes: function (oControl, id, sObjectType) {
			var oModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oModel.read("/CustomerEngagementSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results, sObjectType);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
					this.getOwnerComponent().getModel("solutionModel").setProperty("/CriticalSituationsSetBusy", false);
				}.bind(this)
			});
			//}.bind(this));

		},

		_readMCCActivities: function (aProductLines, oFilterForICP) {
			var oModel = this.getModel();

			var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICP, aProductLines, "ProductLine");
			var oFacetFilter = aProductLines.length > 0 ? oFinalFilter[1] : oFinalFilter[0];
			if (oFacetFilter) {
				oFacetFilter.aFilters = oFacetFilter.aFilters.filter(function (filter) {
					if (filter.aFilters && filter.aFilters.length > 0) {
						return filter.aFilters[0].sPath !== "SalesOrg" && filter.aFilters[0].sPath !== "ServiceOrg";
					}
					return true;
				});
				if (oFacetFilter.aFilters.length === 0) {
					oFinalFilter.splice(1, 1);
				}
			}

			//Filter only TopIssues with status "New" (E0010), "In Process Backoffice" (E0011), "Responsible's Action" (E0012), "In MCC  Dep Rooms" (E0019), "In Process CIM" (E0020)
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0010"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0011"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0012"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0019"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0027")
				], false)
			],
				true
			);
			var tileSpecificCategoryFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "ZYO"),
					new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "ZYP"),
					new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "ZZM"),
					new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "ZZD"),
					new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "ZZR"),
					new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "ZB2"),
					new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "ZB9"),
					new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "Z88"),
					new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "Z91"),
					new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "Z90"),
					new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "Z93"),
					new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "ZYT")
				], false)
			],
				true
			);
			oFinalFilter.push(tileSpecificFilters);
			oFinalFilter.push(tileSpecificCategoryFilters);

			return new Promise(function (resolve, reject) {
				oModel.read("/MCCActivitiesSet", {
					filters: oFinalFilter,
					urlParameters: {
						"$expand": "toProducts"
					},
					success: function (data) {
						data = this._sortByPriority(data);
						data.results.forEach(function (result) {
							result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
							result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
							result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
							result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
							result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
							result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
						}, this);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountAllMCCIssues", data.results.length);

						//split in MCC Activities and MCC Issues
						var aMccIssues = data.results.filter(function (val) {
							return val.Category === "ZYP";
						});
						this._convertDataForSolutionOverview("MCCIssue", aMccIssues);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountMCCIssues", aMccIssues.length);

						var aMCCTopCriticalCustomer = data.results.filter(function (val) {
							return val.Category === "ZYT";
						});
						this._convertDataForSolutionOverview("MCCTopCriticalCustomer", aMCCTopCriticalCustomer);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountMCCTopCriticalCustomer", aMCCTopCriticalCustomer.length);

						var aCCMRequests = data.results.filter(function (val) {
							return val.Category === "ZYO";
						});
						this._convertDataForSolutionOverview("CCMActivityRequests", aCCMRequests);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCCMActivityRequests", aCCMRequests.length);

						var aCPCRequests = data.results.filter(function (val) {
							return val.Category === "ZZM";
						});
						this._convertDataForSolutionOverview("CPCActivityRequests", aCPCRequests);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountCPCActivityRequests", aCPCRequests.length);

						/*	var aTechnicalSupportuests = data.results.filter(function (val) {
							return val.Category === "ZZD";
						});
						this._convertDataForSolutionOverview("TechnicalSupportRequests", aTechnicalSupportuests);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountTechnicalSupportRequests", aTechnicalSupportuests.length); */

						/*	var aMCCSosRequests = data.results.filter(function (val) {
							return val.Category === "ZZR";
						});
						this._convertDataForSolutionOverview("MCCSosRequests", aMCCSosRequests);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountMCCSosRequests", aMCCSosRequests.length); */

						var aGoLiveEndngered = data.results.filter(function (val) {
							return val.Category === "Z90" &&
								val.Priority === "1" &&
								val.Status === "E0011" &&
								(val.Reason === "A1ZS0000010010" || val.Reason === "A1ZS0000010050" || val.Reason === "A1ZS0000010060" || val.Reason ===
									"A1ZS0000010100");
						});
						this._convertDataForSolutionOverview("GoLiveEndangered", aGoLiveEndngered);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountGoLiveEndangered", aGoLiveEndngered.length);

						var aGoLiveAnnounts = data.results.filter(function (val) {
							return (val.Category === "Z90" || val.Category === "ZB2") &&
								val.Priority === "5" &&
								val.ActResult === "Z2ZS460050" &&
								(val.Reason === "A1ZS0000010040" || val.Reason === "A1ZS0000010050" || val.Reason === "A1ZS0000010060" || val.Reason ===
									"A1ZS0000010100");
						});
						this._convertDataForSolutionOverview("GoLiveAnnouncement", aGoLiveAnnounts);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountGoLiveAnnouncement", aGoLiveAnnounts.length);

						resolve(data);
					}.bind(this),
					error: function (data) {
						this.getOwnerComponent().getModel("solutionModel").setProperty("/MCCActivitiesSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));
		},

		_readGlobalEscalationRequests: function (aProductLines, oFilterForICP) {
			var oModel = this.getModel();
			var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICP, aProductLines, "ProductLine");

			//ALL ongoing 
			var tileSpecificFilters = new sap.ui.model.Filter([
				//new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ,	"ZSPRCTYP01"),
				new sap.ui.model.Filter([new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0010"), new sap.ui.model.Filter(
					"Status", sap.ui.model.FilterOperator.EQ, "E0011")], false)
			],
				true
			);

			oFinalFilter.push(tileSpecificFilters);
			var oChangedAtSorter = new sap.ui.model.Sorter("ChangeTime", true);

			return new Promise(function (resolve, reject) {
				oModel.read("/GlobalEscalationRequestSet", {
					filters: oFinalFilter,
					sorters: [oChangedAtSorter],
					success: function (data) {
						this._convertDataForSolutionOverview("GlobalEscalationRequest", data.results);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountGlobalEscalationRequests", data.results.length);
						resolve(data);
					}.bind(this),
					error: function (data) {
						reject();
					}.bind(this)
				});
			}.bind(this));

		},

		_readTopIssuesSet: function (aProductLines, oFilterForICP) {
			var oModel = this.getModel();

			var oFinalFilter = this._getCombinedSolutionFilter(oFilterForICP, aProductLines, "ProductLine");
			var oFacetFilter = aProductLines.length > 0 ? oFinalFilter[1] : oFinalFilter[0];
			if (oFacetFilter) {
				oFacetFilter.aFilters = oFacetFilter.aFilters.filter(function (filter) {
					if (filter.aFilters && filter.aFilters.length > 0) {
						return filter.aFilters[0].sPath !== "SalesOrg" && filter.aFilters[0].sPath !== "ServiceOrg";
					}
					return true;
				});
				if (oFacetFilter.aFilters.length === 0) {
					oFinalFilter.splice(1, 1);
				}
			}

			//Filter only TopIssues with status "New" (E0010), "Approved" (E0011), "In Process" (E0014), "Responsible Action" (E0018)
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0010"), new sap.ui.model.Filter(
					"Status", sap.ui.model.FilterOperator.EQ, "E0011"), new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0014"),
				new sap
					.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0018")
				], false)
			],
				true
			);
			oFinalFilter.push(tileSpecificFilters);

			return new Promise(function (resolve, reject) {
				oModel.read("/TopIssuesSet", {
					filters: oFinalFilter,
					urlParameters: {
						"$expand": "toProducts",
						"$inlinecount": "allpages",
						"$top": "1000"
					},
					success: function (data) {
						data = this._sortByPriority(data);
						data.results.forEach(function (result) {
							result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
							result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
							result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
							result.ProductVer = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");
							result.ProductLineKeys = this.formatter.concatProducts(result.toProducts.results, "ProductLine");
							result.ProductKeys = this.formatter.concatProducts(result.toProducts.results, "Product");
						}, this);
						this._convertDataForSolutionOverview("TopIssues", data.results);
						this.getOwnerComponent().getModel("solutionModel").setProperty("/AmountTopIssues", data.results.length);
						resolve(data);
					}.bind(this),
					error: function (data) {
						this.getOwnerComponent().getModel("solutionModel").setProperty("/TopIssuesSetBusy", false);
						reject("No data found");
					}.bind(this)
				});
			}.bind(this));
		},

		onPieTypeChanged: function (oEv) {
			var sSolution = this.getView().getModel("solution").getProperty("/SolKey") || "All";
			var sKey = this.getView().byId("iconTabBar").getSelectedKey();
			this._filterTable(sKey, "");
			this._filterTableOpenIssues(sKey, "");
			this._setPieModel(sSolution, oEv.getParameter("item").getKey());
			this.trackEvent("PieChart: type changed");
		},

		_setPieModel: function (sSolution, type) {
			var oModel = this.getView().getModel("pieChart");
			oModel.setData({
				data: []
			});
			if (type === "productLine") {
				var results = this.getView().getModel("productsModel").getData();
				var aProductLinesForSolution = this.getView().getModel("solution").getProperty("/toSolutionProdLin").results;

				if (results.length > 0) {

					var oData = oModel.getData();
					var aAlreadyAdded = [];
					results.forEach(function (result, idx) {
						if (result.ProductLine !== "") {
							//check if product line is in solutions product line
							var aTmpPl = aProductLinesForSolution.filter(function (pl) {
								return pl.PlKey === result.ProductLine;
							});
							//for sSolution !== "All" we do not need to take the "solutions - product lines" under consideration, just add all to the pie chart
							if (aTmpPl.length > 0 || sSolution === "All") {
								//check if data is available
								var aTmp = oData.data.filter(function (val) {
									return val.key === result.ProductLine;
								});

								//if not, create new entry. Othervise count ++
								if (aTmp.length === 0) {
									oData.data.push({
										"key": result.ProductLine,
										"description": result.ProductLineT,
										"count": 1
									});
								} else {
									if (aAlreadyAdded.indexOf(result.ProductLine + "," + result.CaseId) === -1) {
										aTmp[0].count++;
									}

								}
								aAlreadyAdded.push(result.ProductLine + "," + result.CaseId);
							}
						}
					}.bind(this));
					//set visibility of the chart
				}
			} else if (type === "product") {
				var aProducts = this._getAllAvailableProducts(sSolution);
				oModel.setData(aProducts);
			}

			//sort 
			var aSortedData = oModel.getData();
			aSortedData.data.sort(function (a, b) {
				if (a.count < b.count) {
					return 1;
				} else if (a.count > b.count) {
					return -1;
				}
				if (a.description < b.description) {
					return -1;
				} else if (a.description > b.description) {
					return 1;
				}

			});

			oModel.setData(aSortedData);
			oModel.refresh();

			setTimeout(function () {
				$(".viz-legend-title").text(this.getView().byId("pieTypeButton").getSelectedKey() === "productLine" ? "Product Lines" :
					"Products");
			}.bind(this), 0);
		},

		_getAllAvailableProducts: function (sSolution) {
			var aProducts = {
				data: []
			};
			var aProductLinesInSolution = this.getView().getModel("solution").getProperty("/toSolutionProdLin");
			var aTmp = [];
			var aProductsAlreadyInLine = "";
			var aAllProducts = this.getView().byId("solutionOverviewTable").getBinding("rows").getModel().getProperty("/SolutionOverview");
			aAllProducts.forEach(function (product) {
				aProductsAlreadyInLine = [];
				if (product.toProducts && product.toProducts.results) {
					product.toProducts.results.forEach(function (prod) {
						if (prod.Product && prod.Product !== "") {

							aTmp = aProductLinesInSolution.results.filter(function (val) {
								return val.PlKey === prod.ProductLine;
							});

							if (aTmp.length > 0 || sSolution === "All") {

								aTmp = aProducts.data.filter(function (val) {
									return val.key === prod.Product;
								});
								if (aTmp.length === 0) {
									aProducts.data.push({
										key: prod.Product,
										description: prod.ProductT,
										count: 1
									});
								} else if (aProductsAlreadyInLine.indexOf(prod.ProductT) === -1) {
									aTmp[0].count++;
								}
								aProductsAlreadyInLine.push(prod.ProductT);
							}
						}
					});
				} else if (product.objectType === "Critical Event Coverages") {
					aTmp = aProducts.data.filter(function (val) {
						return val.key === product.ProductKey;
					});
					if (aTmp.length === 0) {
						aProducts.data.push({
							key: product.ProductKey,
							description: product.Product,
							count: 1
						});
					} else if (aProductsAlreadyInLine.indexOf(product.Product) === -1) {
						aTmp[0].count++;
					}
					aProductsAlreadyInLine.push(product.Product);
				}
			});
			return aProducts;
		},

		_convertDataForSolutionOverview: function (sEntityName, aData) {
			var oSolutionModel = this.getOwnerComponent().getModel("solutionModel");
			var sObjectType = "";
			var aPropertyNamesToTransform = [];
			var bIsOngoingCritcalEngagementsTable = false;
			var bIsClosedCritcalEngagementsTable = false;

			aData.forEach(function (oCase) {
				if (oCase.DbsMaintenanceRanking === "0") {
					oCase.DbsMaintenanceRanking = "";
				}
				if (oCase.dbs_maintenance_rank === "0") {
					oCase.dbs_maintenance_rank = "";
				}
				oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);
			}.bind(this));

			//switch case for determing if attributes needs to be adjusted
			switch (sEntityName) {
				case "CriticalEventCoverages":
				case "CriticalEventCoveragesClosed":
					sObjectType = "Critical Event Coverages";

					if (sEntityName === "CriticalEventCoverages") {
						bIsOngoingCritcalEngagementsTable = true;
						bIsClosedCritcalEngagementsTable = false;
					} else {
						bIsClosedCritcalEngagementsTable = true;
						bIsOngoingCritcalEngagementsTable = false;
					}
					aPropertyNamesToTransform = [{
						"SourceName": "ObjectID",
						"TargetName": "ObjectId"
					}, {
						"SourceName": "StatusText",
						"TargetName": "Status"
					}, {
						"SourceName": "ResponsibleName",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "ResponsibleName",
						"TargetName": "EmplRespUrl"
					}, {
						"SourceName": "MCCTag",
						"TargetName": "CaseTag"

					}, {
						"SourceName": "Region",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "CustomerCountry",
						"TargetName": "CountryT"
					}, {
						"SourceName": "createdAt",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "modifiedAt",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "EndDate",
						"TargetName": "PlanEndDate"
					}];
					break;
				case 'ClosedGlobalEscalations':
				case 'GlobalEscalations':
					if (sEntityName === "ClosedGlobalEscalations") {
						bIsClosedCritcalEngagementsTable = true;
						bIsOngoingCritcalEngagementsTable = false;
						sObjectType = "Closed Global Escalation";
					}
					else if (sEntityName === "GlobalEscalations") {
						bIsOngoingCritcalEngagementsTable = true;
						bIsClosedCritcalEngagementsTable = false;
						sObjectType = "Global Escalation";
					}

					aPropertyNamesToTransform = [{
						"SourceName": "CaseId",
						"TargetName": "ObjectId"
					}, {
						"SourceName": "ServiceOrgT",
						"TargetName": "ServiceOrg"
					}, {
						"SourceName": "LinkToCase",
						"TargetName": "ObjectLink"
					}, {
						"SourceName": "CaseTitle",
						"TargetName": "Description"
					}, {
						"SourceName": "CustomerText",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "Function",
						"TargetName": "StatusReport"
					}, {
						"SourceName": "PriorityT",
						"TargetName": "Priority"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "Processor",
						"TargetName": "Processor"
					}, {
						"SourceName": "ProcessorUrl",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "RegionT",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "CreateDate",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "",
						"TargetName": "Country"
					}, {
						"SourceName": "ChangeDate",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "Product",
						"TargetName": "Product"
					}, {
						"SourceName": "ProductCategory",
						"TargetName": "ProductCategory"
					}, {
						"SourceName": "ProductLine",
						"TargetName": "ProductLine"
					}, {
						"SourceName": "ProductVer",
						"TargetName": "ProductVer"
					}, {
						"SourceName": "ServiceTeamT",
						"TargetName": "ServiceTeam"
					}, {
						"SourceName": "MasterCodeT",
						"TargetName": "CustomerSegment"
					}, {
						"SourceName": "Responsible",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "ResponsibleId",
						"TargetName": "ResponsibleId"
					}, {
						"SourceName": "PlanEndDate",
						"TargetName": "PlanEndDate"
					}, {
						"SourceName": "",
						"TargetName": "GoLiveDate"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}, {
						"SourceName": "ImplementationPartnerT",
						"TargetName": "ImplementationPartner"
					}];
					break;

				case "CimRequests":
					sObjectType = "CIM Requests";
					aPropertyNamesToTransform = [{
						"SourceName": "u_task_record.priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "number",
						"TargetName": "ObjectId"
					}, {
						"SourceName": "u_task_record.account.u_region",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "u_task_record.correlation_id",
						"TargetName": "BcpIncId"
					}, {
						"SourceName": "u_task_record.sys_id",
						"TargetName": "CaseSysID"
					}, {
						"SourceName": "u_task_record.account.country",
						"TargetName": "Country"
					}, {
						"SourceName": "u_task_record.account.country_text",
						"TargetName": "CountryT"
					}, {
						"SourceName": "u_task_record.u_bcp_link",
						"TargetName": "BcpIncUrl"
					}, {
						"SourceName": "u_task_record.short_description",
						"TargetName": "Description"
					}, {
						"SourceName": "u_task_record.account.name",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "u_task_record.assigned_to.name",
						"TargetName": "Processor"
					}, {
						"SourceName": "u_task_record.assigned_to.name",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "u_task_record.assigned_to.employee_number",
						"TargetName": "ProcessorId"
					}, {
						"SourceName": "u_task_record.account.number",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_name",
						"TargetName": "ProductCategory"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id",
						"TargetName": "ProductCategoryId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_name",
						"TargetName": "ProductLine"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id",
						"TargetName": "ProductLineId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.display_name",
						"TargetName": "Product"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.model_number",
						"TargetName": "ProductId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product_version.display_name",
						"TargetName": "ProductVer"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product_version.model_number",
						"TargetName": "ProductVerId"
					}, {
						"SourceName": "escalation_justification",
						"TargetName": "escalation_justification"
					}, {
						"SourceName": "HasNotes",
						"TargetName": "HasNotes"
					}, {
						"SourceName": "u_task_record.u_app_component.u_name",
						"TargetName": "ComponentName"
					}, {
						"SourceName": "u_task_record.state",
						"TargetName": "Status"
					}, {
						"SourceName": "assigned_to.name",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "assigned_to.employee_number",
						"TargetName": "EmplRespUser"
					}, {
						"SourceName": "sys_created_on",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "u_last_user_updated_on",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "u_task_record.correlation_id",
						"TargetName": "BcpID"
					}, {
						"SourceName": "u_task_record.u_bcp_link",
						"TargetName": "BcpIdUrl"
					}, {
						"SourceName": "u_task_record.number",
						"TargetName": "EscalationRecordId"
					}, {
						"SourceName": "approval",
						"TargetName": "ApprovalStatus"
					}, {
						"SourceName": "requested_by.name",
						"TargetName": "Requestor"
					}, {
						"SourceName": "requested_by.employee_number",
						"TargetName": "RequestorId"
					}, {
						"SourceName": "u_task_record.priority",
						"TargetName": "Priority"
					}, {
						"SourceName": "u_task_record.priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "state",
						"TargetName": "EscalationStatus"
					}, {
						"SourceName": "u_next_update_time",
						"TargetName": "NextUpdateTime"
					}];
					break;
				case "ClosedCims":
				case "ClosedBusinessDownSituations":
				case "BusinessDownSituations":
				case "Cims":
					bIsOngoingCritcalEngagementsTable = true;
					bIsClosedCritcalEngagementsTable = false;
					if (sEntityName === "Cims") {
						bIsOngoingCritcalEngagementsTable = true;
						bIsClosedCritcalEngagementsTable = false;
						sObjectType = "Critical Incident Management";
					} else if (sEntityName === "BusinessDownSituations") {
						bIsOngoingCritcalEngagementsTable = true;
						bIsClosedCritcalEngagementsTable = false;
						sObjectType = "Business Down Situations";
					} else if (sEntityName === "ClosedBusinessDownSituations") {
						bIsClosedCritcalEngagementsTable = true;
						bIsOngoingCritcalEngagementsTable = false;
						sObjectType = "Closed Business Down Situations";
					} else if (sEntityName === "ClosedCims") {
						bIsClosedCritcalEngagementsTable = true;
						bIsOngoingCritcalEngagementsTable = false;
						sObjectType = "Closed Critical Incident Management";
					}
					aPropertyNamesToTransform = [{
						"SourceName": "u_task_record.priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "number",
						"TargetName": "ObjectId"
					}, {
						"SourceName": "u_task_record.account.u_region",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "u_task_record.correlation_id",
						"TargetName": "BcpIncId"
					}, {
						"SourceName": "u_task_record.sys_id",
						"TargetName": "CaseSysID"
					}, {
						"SourceName": "u_task_record.account.country",
						"TargetName": "Country"
					}, {
						"SourceName": "u_task_record.account.country_text",
						"TargetName": "CountryT"
					}, {
						"SourceName": "u_task_record.u_bcp_link",
						"TargetName": "BcpIncUrl"
					}, {
						"SourceName": "u_task_record.short_description",
						"TargetName": "Description"
					}, {
						"SourceName": "u_task_record.account.name",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "u_task_record.assigned_to.name",
						"TargetName": "Processor"
					}, {
						"SourceName": "u_task_record.assigned_to.name",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "u_task_record.assigned_to.employee_number",
						"TargetName": "ProcessorId"
					}, {
						"SourceName": "u_task_record.account.number",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_name",
						"TargetName": "ProductCategory"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id",
						"TargetName": "ProductCategoryId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_name",
						"TargetName": "ProductLine"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id",
						"TargetName": "ProductLineId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.display_name",
						"TargetName": "Product"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.model_number",
						"TargetName": "ProductId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product_version.display_name",
						"TargetName": "ProductVer"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product_version.model_number",
						"TargetName": "ProductVerId"
					}, {
						"SourceName": "escalation_justification",
						"TargetName": "escalation_justification"
					}, {
						"SourceName": "HasNotes",
						"TargetName": "HasNotes"
					}, {
						"SourceName": "u_task_record.u_app_component.u_name",
						"TargetName": "ComponentName"
					}, {
						"SourceName": "u_task_record.state",
						"TargetName": "Status"
					}, {
						"SourceName": "assigned_to.name",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "assigned_to.employee_number",
						"TargetName": "EmplRespUser"
					}, {
						"SourceName": "sys_created_on",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "u_last_user_updated_on",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "u_task_record.correlation_id",
						"TargetName": "BcpID"
					}, {
						"SourceName": "u_task_record.u_bcp_link",
						"TargetName": "BcpIdUrl"
					}, {
						"SourceName": "u_task_record.number",
						"TargetName": "EscalationRecordId"
					}, {
						"SourceName": "approval",
						"TargetName": "ApprovalStatus"
					}, {
						"SourceName": "requested_by.name",
						"TargetName": "Requestor"
					}, {
						"SourceName": "requested_by.employee_number",
						"TargetName": "RequestorId"
					}, {
						"SourceName": "u_task_record.priority",
						"TargetName": "Priority"
					}, {
						"SourceName": "u_task_record.priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "state",
						"TargetName": "EscalationStatus"
					}, {
						"SourceName": "u_next_update_time",
						"TargetName": "NextUpdateTime"
					}];
					break;

				case "XTecEngagements":
				case "PECriticalEngagements":
				case "TechnicalBackofficeRequests":
				case "XTecEngagementsClosed":
				case "PECriticalEngagementsClosed":
					/* 	if (sEntityName === "Cims") {
							bIsOngoingCritcalEngagementsTable = true;
							bIsClosedCritcalEngagementsTable = false;
							sObjectType = "Critical Incident Management";
						} else if (sEntityName === "BusinessDownSituations") {
							bIsOngoingCritcalEngagementsTable = true;
							bIsClosedCritcalEngagementsTable = false;
							sObjectType = "Business Down Situations";
						} else if (sEntityName === "CimRequests") {
							bIsOngoingCritcalEngagementsTable = false;
							sObjectType = "CIM Requests"; */
					if (sEntityName === "XTecEngagements") {
						bIsOngoingCritcalEngagementsTable = true;
						bIsClosedCritcalEngagementsTable = false;
						sObjectType = "xTec Engagements";
					} else if (sEntityName === "XTecEngagementsClosed") {
						bIsClosedCritcalEngagementsTable = true;
						bIsOngoingCritcalEngagementsTable = false;
						sObjectType = "Closed xTec Engagements";
					} else if (sEntityName === "PECriticalEngagements") {
						bIsOngoingCritcalEngagementsTable = true;
						bIsClosedCritcalEngagementsTable = false;
						sObjectType = "PE Critical Engagements";
					} else if (sEntityName === "PECriticalEngagementsClosed") {
						bIsClosedCritcalEngagementsTable = true;
						bIsOngoingCritcalEngagementsTable = false;
						sObjectType = "Closed PE Critical Engagements";
					} else if (sEntityName === "TechnicalBackofficeRequests") {
						bIsOngoingCritcalEngagementsTable = false;
						bIsClosedCritcalEngagementsTable = false;
						sObjectType = "Technical Backoffice Requests";
					}
					aPropertyNamesToTransform = [{
						"SourceName": "number",
						"TargetName": "ObjectId"
					}, {
						"SourceName": "u_task_record.account.u_region",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "u_task_record.correlation_id",
						"TargetName": "BcpIncId"
					}, {
						"SourceName": "u_task_record.sys_id",
						"TargetName": "CaseSysID"
					}, {
						"SourceName": "u_task_record.account.country",
						"TargetName": "Country"
					}, {
						"SourceName": "u_task_record.account.country_text",
						"TargetName": "CountryT"
					}, {
						"SourceName": "u_task_record.u_bcp_link",
						"TargetName": "BcpIncUrl"
					}, {
						"SourceName": "u_task_record.short_description",
						"TargetName": "Description"
					}, {
						"SourceName": "u_task_record.account.name",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "u_task_record.assigned_to.name",
						"TargetName": "Processor"
					}, {
						"SourceName": "u_task_record.assigned_to.name",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "u_task_record.assigned_to.employee_number",
						"TargetName": "ProcessorId"
					}, {
						"SourceName": "u_task_record.account.number",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_name",
						"TargetName": "ProductCategory"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id",
						"TargetName": "ProductCategoryId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_name",
						"TargetName": "ProductLine"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id",
						"TargetName": "ProductLineId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.display_name",
						"TargetName": "Product"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product.model_number",
						"TargetName": "ProductId"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product_version.display_name",
						"TargetName": "ProductVer"
					}, {
						"SourceName": "u_task_record.u_install_base_item.u_product_version.model_number",
						"TargetName": "ProductVerId"
					}, {
						"SourceName": "escalation_justification",
						"TargetName": "escalation_justification"
					}, {
						"SourceName": "HasNotes",
						"TargetName": "HasNotes"
					}, {
						"SourceName": "u_task_record.u_app_component.u_name",
						"TargetName": "ComponentName"
					}, {
						"SourceName": "u_task_record.state",
						"TargetName": "Status"
					}, {
						"SourceName": "assigned_to.name",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "assigned_to.employee_number",
						"TargetName": "EmplRespUser"
					}, {
						"SourceName": "sys_created_on",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "u_last_user_updated_on",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "u_task_record.correlation_id",
						"TargetName": "BcpID"
					}, {
						"SourceName": "u_task_record.u_bcp_link",
						"TargetName": "BcpIdUrl"
					}, {
						"SourceName": "u_task_record.number",
						"TargetName": "EscalationRecordId"
					}, {
						"SourceName": "approval",
						"TargetName": "ApprovalStatus"
					}, {
						"SourceName": "requested_by.name",
						"TargetName": "Requestor"
					}, {
						"SourceName": "requested_by.employee_number",
						"TargetName": "RequestorId"
					}, {
						"SourceName": "u_task_record.priority",
						"TargetName": "Priority"
					}, {
						"SourceName": "u_task_record.priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "state",
						"TargetName": "EscalationStatus"
					}, {
						"SourceName": "u_next_update_time",
						"TargetName": "NextUpdateTime"
					}];
					break;
				case "CrossIssues":
				case "CrossIssuesClosed":
					if (sEntityName === "CrossIssues") {
						bIsOngoingCritcalEngagementsTable = true;
						bIsClosedCritcalEngagementsTable = false;
						sObjectType = "Cross Issue";
					}
					else if (sEntityName === "CrossIssuesClosed") {
						bIsClosedCritcalEngagementsTable = true;
						bIsOngoingCritcalEngagementsTable = false;
						sObjectType = "Closed Cross Issue";
					}

					aPropertyNamesToTransform = [{
						"SourceName": "ObjectId", //zu ändern
						"TargetName": "ObjectId"
					}, {
						"SourceName": "CaseTitle",
						"TargetName": "Description"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "PriorityT",
						"TargetName": "Priority"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "ServiceOrgT",
						"TargetName": "ServiceOrg"
					}, {
						"SourceName": "RegionT",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "CreateDate",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "ChangeDate",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "RequestedStartDate",
						"TargetName": "PlanEndDate"
					}, {
						"SourceName": "Product",
						"TargetName": "Product"
					}, {
						"SourceName": "ProductCategory",
						"TargetName": "ProductCategory"
					}, {
						"SourceName": "ProductLine",
						"TargetName": "ProductLine"
					}, {
						"SourceName": "ProductVer",
						"TargetName": "ProductVer"
					}, {
						"SourceName": "ServiceTeamT",
						"TargetName": "ServiceTeam"
					}, {
						"SourceName": "MasterCodeT",
						"TargetName": "CustomerSegment"
					}, {
						"SourceName": "Responsible",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "ResponsibleId",
						"TargetName": "ResponsibleId"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}];
					break;
				case "CriticalCustomerManagement":
				case "CriticalCustomerManagementClosed":
				case "CriticalPeriodCoverage":
				case "CriticalPeriodCoverageClosed":
				case "TaskForces":
				case "TaskForcesClosed":
				case "TopCriticalCustomers":
				case "TopCriticalCustomersClosed":
					bIsOngoingCritcalEngagementsTable = true;
					bIsClosedCritcalEngagementsTable = false;
					sObjectType = sEntityName;
					if (sEntityName === "CriticalCustomerManagement") {
						sObjectType = "Critical Customer Management";
					} else if (sEntityName === "CriticalPeriodCoverage") {
						sObjectType = "Critical Period Coverage";
					} else if (sEntityName === "TopCriticalCustomers") {
						sObjectType = "Top Critical Customers";
					} else if (sEntityName === "TaskForces") {
						sObjectType = "Task Forces";
					} else if (sEntityName === "CriticalCustomerManagementClosed") {
						bIsClosedCritcalEngagementsTable = true;
						bIsOngoingCritcalEngagementsTable = false;
						sObjectType = "Closed Critical Customer Management";
					}
					else if (sEntityName === "CriticalPeriodCoverageClosed") {
						bIsClosedCritcalEngagementsTable = true;
						bIsOngoingCritcalEngagementsTable = false;
						sObjectType = "Closed Critical Period Coverage";
					} else if (sEntityName === "TopCriticalCustomersClosed") {
						bIsClosedCritcalEngagementsTable = true;
						bIsOngoingCritcalEngagementsTable = false;
						sObjectType = "Closed Top Critical Customers";
					} else if (sEntityName === "TaskForcesClosed") {
						bIsClosedCritcalEngagementsTable = true;
						bIsOngoingCritcalEngagementsTable = false;
						sObjectType = "Closed Task Forces";
					}

					aPropertyNamesToTransform = [{
						"SourceName": "CaseId",
						"TargetName": "ObjectId"
					}, {
						"SourceName": "LinkToCase",
						"TargetName": "ObjectLink"
					}, {
						"SourceName": "CaseTitle",
						"TargetName": "Description"
					}, {
						"SourceName": "ServiceOrgT",
						"TargetName": "ServiceOrg"
					}, {
						"SourceName": "CustomerText",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "Function",
						"TargetName": "StatusReport"
					}, {
						"SourceName": "PriorityT",
						"TargetName": "Priority"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "Processor",
						"TargetName": "Processor"
					}, {
						"SourceName": "ProcessorUrl",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "RegionT",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "CreateDate",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "ChangeDate",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "Product",
						"TargetName": "Product"
					}, {
						"SourceName": "ProductCategory",
						"TargetName": "ProductCategory"
					}, {
						"SourceName": "ProductLine",
						"TargetName": "ProductLine"
					}, {
						"SourceName": "ProductVer",
						"TargetName": "ProductVer"
					}, {
						"SourceName": "ServiceTeamT",
						"TargetName": "ServiceTeam"
					}, {
						"SourceName": "MasterCodeT",
						"TargetName": "CustomerSegment"
					}, {
						"SourceName": "Responsible",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "ResponsibleId",
						"TargetName": "ResponsibleId"
					}, {
						"SourceName": "PlanEndDate",
						"TargetName": "PlanEndDate"
					}, {
						"SourceName": "GoLiveDate",
						"TargetName": "GoLiveDate"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}];

					break;
				case "CCMRequests":
				case "CPCRequests":
				case "TechnicalSupportRequests":
					if (sEntityName === 'CPCRequests') {
						sObjectType = "CPC Requests";
					} else if (sEntityName === 'CCMRequests') {
						sObjectType = "CCM Requests";
					} else if (sEntityName === "TechnicalSupportRequests") {
						sObjectType = "MCC Support Requests";
					}

					aPropertyNamesToTransform = [{
						"SourceName": "LinkToActivity",
						"TargetName": "ObjectLink"
					}, {
						"SourceName": "IncidentComponent",
						"TargetName": "ComponentName"
					}, {
						"SourceName": "CustomerTicketId",
						"TargetName": "BcpIncId"
					}, {
						"SourceName": "CustomerText",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "PriorityT",
						"TargetName": "Priority"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "Processor",
						"TargetName": "Processor"
					}, {
						"SourceName": "ProcessorUrl",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "CreationDate",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "ChangeDate",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "ServiceTeamName",
						"TargetName": "ServiceTeam"
					}, {
						"SourceName": "Region",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "ServiceOrgT",
						"TargetName": "ServiceOrg"
					}, {
						"SourceName": "PlannedStartDate",
						"TargetName": "PlannedStartDate"
					}, {
						"SourceName": "PlannedEndDate",
						"TargetName": "PlannedEndDate"
					}, {
						"SourceName": "ActualsStartDate",
						"TargetName": "ActualsStartDate"
					}, {
						"SourceName": "ActualsEndDate",
						"TargetName": "ActualsEndDate"
					}, {
						"SourceName": "GoLiveDate",
						"TargetName": "GoLiveDate"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}, {
						"SourceName": "short_description",

						"TargetName": "Description"
					}, {
						"SourceName": "assignment_group.name",
						"TargetName": "ServiceTeam"
					}];
					break;
				case "MCCActivities":
				case "MCCIssue":
				case "MCCTopCriticalCustomer":
				case "MCCSosRequests":
				case "GoLiveEndangered":
				case "GoLiveAnnouncement":
				case "CPCActivityRequests":
				case "CCMActivityRequests":

					if (sEntityName === 'MCCActivities') {
						sObjectType = "MCC Activity";
					} else if (sEntityName === 'MCCIssue') {
						sObjectType = "MCC Issue";
					} else if (sEntityName === "MCCTopCriticalCustomer") {
						sObjectType = "TC2 Evaluation Request";
					} else if (sEntityName === "MCCSosRequests") {
						sObjectType = "MCC SOS Requests";
					} else if (sEntityName === "GoLiveEndangered") {
						sObjectType = "Go Live Endangered";
					} else if (sEntityName === "GoLiveAnnouncement") {
						sObjectType = "Go Live Announcement";
					} else if (sEntityName === "CPCActivityRequests") {
						sObjectType = "CPC Requests (Activities)";
					} else if (sEntityName === "CCMActivityRequests") {
						sObjectType = "CCM Requests (Activities)";
					}

					aPropertyNamesToTransform = [{
						"SourceName": "LinkToActivity",
						"TargetName": "ObjectLink"
					}, {
						"SourceName": "IncidentComponent",
						"TargetName": "ComponentName"
					}, {
						"SourceName": "CustomerTicketId",
						"TargetName": "BcpIncId"
					}, {
						"SourceName": "CustomerText",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "PriorityT",
						"TargetName": "Priority"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "Processor",
						"TargetName": "Processor"
					}, {
						"SourceName": "ProcessorUrl",
						"TargetName": "ProcessorLink"
					}, {
						"SourceName": "CreationDate",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "ChangeDate",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "ServiceTeamName",
						"TargetName": "ServiceTeam"
					}, {
						"SourceName": "RegionT",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "ServiceOrgT",
						"TargetName": "ServiceOrg"
					}, {
						"SourceName": "PlannedStartDate",
						"TargetName": "PlannedStartDate"
					}, {
						"SourceName": "PlannedEndDate",
						"TargetName": "PlannedEndDate"
					}, {
						"SourceName": "ActualsStartDate",
						"TargetName": "ActualsStartDate"
					}, {
						"SourceName": "ActualsEndDate",
						"TargetName": "ActualsEndDate"
					}, {
						"SourceName": "GoLiveDate",
						"TargetName": "GoLiveDate"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}];
					break;
				case 'GlobalEscalationRequest':
					sObjectType = "Global Escalation Request";
					aPropertyNamesToTransform = [{
						"SourceName": "LinkToRequest",
						"TargetName": "ObjectLink"
					}, {
						"SourceName": "ServiceOrgT",
						"TargetName": "ServiceOrg"
					}, {
						"SourceName": "CustomerText",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "RegionT",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "CreateTime",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "ChangeTime",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "ServiceTeamName",
						"TargetName": "ServiceTeam"
					}, {
						"SourceName": "MasterCodeT",
						"TargetName": "CustomerSegment"
					}, {
						"SourceName": "Responsible",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "ResponsibleId",
						"TargetName": "ResponsibleId"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}];
					break;
				case 'TopIssues':

					sObjectType = "Top Issue";
					aPropertyNamesToTransform = [{
						"SourceName": "LinkToTopi",
						"TargetName": "ObjectLink"
					}, {
						"SourceName": "CustomerText",
						"TargetName": "CustomerName"
					}, {
						"SourceName": "CustomerErpNo",
						"TargetName": "CustomerNo"
					}, {
						"SourceName": "PriorityT",
						"TargetName": "Priority"
					}, {
						"SourceName": "priorityMatched",
						"TargetName": "priorityMatched"
					}, {
						"SourceName": "StatusT",
						"TargetName": "Status"
					}, {
						"SourceName": "RegionT",
						"TargetName": "SalesRegion"
					}, {
						"SourceName": "Responsible",
						"TargetName": "EmplRespName"
					}, {
						"SourceName": "ResponsibleId",
						"TargetName": "ResponsibleId"
					}, {
						"SourceName": "CreationDate",
						"TargetName": "CreatedOn"
					}, {
						"SourceName": "ChangeDate",
						"TargetName": "ChangedOn"
					}, {
						"SourceName": "PlanEndDate",
						"TargetName": "PlanEndDate"
					}, {
						"SourceName": "",
						"TargetName": "GoLiveDate"
					}, {
						"SourceName": "ClosingDate",
						"TargetName": "ClosingDate"
					}, {
						"SourceName": "RequestedStartDate",
						"TargetName": "RequestedStartDate"
					}, {
						"SourceName": "RequestedEndDate",
						"TargetName": "RequestedEndDate"
					}];
					break;
			}

			if (bIsOngoingCritcalEngagementsTable) {
				if (aData.length > 0) {
					var aTransformedData = oSolutionModel.getProperty("/SolutionOverview");
					aData.forEach(function (oData) {
						var oTransformedObject = {};
						oTransformedObject.objectType = sObjectType;
						var aSourceObjectKeys = Object.keys(oData);
						aSourceObjectKeys.forEach(function (sSourceKey) {

							//not supported in Internet Explorer...
							//var oObjectToTransform = aPropertyNamesToTransform.find(obj => obj.SourceName === sSourceKey);

							var findObjectById = function (aSource, sId) {
								for (var i = 0; i < aSource.length; i++) {
									if (aSource[i].SourceName === sId) {
										return aSource[i];
									}
								}
								return null;

							};
							var oObjectToTransform = findObjectById(aPropertyNamesToTransform, sSourceKey);

							if (oObjectToTransform) {
								//convert data	
								//in order to be able  to sort correctly, we need to transform the date strings to objects
								if (sSourceKey === "u_next_update_time" || sSourceKey === "u_last_user_updated_on" || sSourceKey === "sys_created_on") {
									var sTempDate = oData[sSourceKey],
										oTempDate = null;
									if ((typeof sTempDate === "string" || sTempDate instanceof String) && sTempDate != "") {
										//in this case we can assume, that the data is coming from ServiceNow
										//the data is already returned as UTC/GTM and therefore we should create the date in Time Zone GMT
										oTempDate = new Date(sTempDate.replace(/^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/, '$4:$5:$6 $2/$3/$1') + "Z"); // Z is needed in order to be interpreted as UTC
									}
									oTransformedObject[oObjectToTransform.TargetName] = oTempDate;
								} else {
									oTransformedObject[oObjectToTransform.TargetName] = oData[sSourceKey];
								}
							} else {
								// move current data to a new object
								oTransformedObject[sSourceKey] = oData[sSourceKey];
							}

						}.bind(this));
						aTransformedData.push(oTransformedObject);
					}.bind(this));
					oSolutionModel.setProperty("/SolutionOverview", aTransformedData);
					oSolutionModel.setProperty("/AmountAll", aTransformedData.length);
					oSolutionModel.refresh(true);
				} else {
					this.getView().byId("solutionOverviewTable").setBusy(false);
				}
			}
			else if (bIsClosedCritcalEngagementsTable) {
				if (aData.length > 0) {
					var aTransformedData = oSolutionModel.getProperty("/SolutionOverviewClosed");
					aData.forEach(function (oData) {
						var oTransformedObject = {};
						oTransformedObject.objectType = sObjectType;
						var aSourceObjectKeys = Object.keys(oData);
						aSourceObjectKeys.forEach(function (sSourceKey) {

							//not supported in Internet Explorer...
							//var oObjectToTransform = aPropertyNamesToTransform.find(obj => obj.SourceName === sSourceKey);

							var findObjectById = function (aSource, sId) {
								for (var i = 0; i < aSource.length; i++) {
									if (aSource[i].SourceName === sId) {
										return aSource[i];
									}
								}
								return null;

							};
							var oObjectToTransform = findObjectById(aPropertyNamesToTransform, sSourceKey);

							if (oObjectToTransform) {
								//convert data	
								//in order to be able  to sort correctly, we need to transform the date strings to objects
								if (sSourceKey === "u_next_update_time" || sSourceKey === "u_last_user_updated_on" || sSourceKey === "sys_created_on") {
									var sTempDate = oData[sSourceKey],
										oTempDate = null;
									if ((typeof sTempDate === "string" || sTempDate instanceof String) && sTempDate != "") {
										//in this case we can assume, that the data is coming from ServiceNow
										//the data is already returned as UTC/GTM and therefore we should create the date in Time Zone GMT
										oTempDate = new Date(sTempDate.replace(/^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/, '$4:$5:$6 $2/$3/$1') + "Z"); // Z is needed in order to be interpreted as UTC
									}
									oTransformedObject[oObjectToTransform.TargetName] = oTempDate;
								} else {
									oTransformedObject[oObjectToTransform.TargetName] = oData[sSourceKey];
								}
							} else {
								// move current data to a new object
								oTransformedObject[sSourceKey] = oData[sSourceKey];
							}

						}.bind(this));
						aTransformedData.push(oTransformedObject);
					}.bind(this));
					//closed (ongoing) engagements
					oSolutionModel.setProperty("/SolutionOverviewClosed", aTransformedData);
					oSolutionModel.setProperty("/AmountAllClosed", aTransformedData.length);
					oSolutionModel.refresh(true);
				} else {
					this.getView().byId("solutionOverviewClosedTable").setBusy(false);
				}
			}


			else {
				if (aData.length > 0) {
					var aTransformedData = oSolutionModel.getProperty("/SolutionOverviewOpenIssues");
					aData.forEach(function (oData) {
						var oTransformedObject = {};
						oTransformedObject.objectType = sObjectType;
						var aSourceObjectKeys = Object.keys(oData);
						aSourceObjectKeys.forEach(function (sSourceKey) {

							//not supported in Internet Explorer...
							//var oObjectToTransform = aPropertyNamesToTransform.find(obj => obj.SourceName === sSourceKey);

							var findObjectById = function (aSource, sId) {
								for (var i = 0; i < aSource.length; i++) {
									if (aSource[i].SourceName === sId) {
										return aSource[i];
									}
								}
								return null;

							};
							var oObjectToTransform = findObjectById(aPropertyNamesToTransform, sSourceKey);
							if (oObjectToTransform) {
								//convert data
								//in order to be able  to sort correctly, we need to transform the date strings to objects
								if (sSourceKey === "u_next_update_time" || sSourceKey === "u_last_user_updated_on" || sSourceKey === "sys_created_on") {
									var sTempDate = oData[sSourceKey],
										oTempDate = null;
									if ((typeof sTempDate === "string" || sTempDate instanceof String) && sTempDate != "") {
										//in this case we can assume, that the data is coming from ServiceNow
										//the data is already returned as UTC/GTM and therefore we should create the date in Time Zone GMT
										oTempDate = new Date(sTempDate.replace(/^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/, '$4:$5:$6 $2/$3/$1') + "Z"); // Z is needed in order to be interpreted as UTC
									}
									oTransformedObject[oObjectToTransform.TargetName] = oTempDate;
								} else {
									oTransformedObject[oObjectToTransform.TargetName] = oData[sSourceKey];
								}
							} else {
								// move current data to a new object
								oTransformedObject[sSourceKey] = oData[sSourceKey];
							}

						}.bind(this));
						aTransformedData.push(oTransformedObject);
					}.bind(this));
					oSolutionModel.setProperty("/SolutionOverviewOpenIssues", aTransformedData);
					oSolutionModel.setProperty("/AmountAllOpenIssues", aTransformedData.length);
					oSolutionModel.refresh(true);
				} else {
					this.getView().byId("solutionOverviewTableOpenIssues").setBusy(false);
				}
			}

			//for loop to modify / adjust the data structure for the overall table

		},

		onPieChartSelected: function (oEv) {
			var sProductLine = oEv.getParameter("data")[0].data["Products"];
			var sKey = this.getView().byId("iconTabBar").getSelectedKey();
			var sKeyOpenIssues = this.getView().byId("iconTabBarOpenIssues").getSelectedKey();
			this._filterTable(sKey, sProductLine);
			this._filterTableOpenIssues(sKeyOpenIssues, sProductLine);
			this._pieChanged = sProductLine;
			this.trackEvent("Solution: filtered - product lines");
		},

		onPieChartDeselected: function (oEv) {
			//only real deselect attach
			if (this._pieChanged === oEv.getParameter("data")[0].data["Products"]) {
				var sKey = this.getView().byId("iconTabBar").getSelectedKey();
				var sKeyOpenIssues = this.getView().byId("iconTabBarOpenIssues").getSelectedKey();
				this._filterTable(sKey, "");
				this._filterTableOpenIssues(sKeyOpenIssues, "");
			}
		},

		handleTabBarSelectOpenIssues: function (oEv) {
			var sKey = oEv.getParameter("key");
			var oPieSelection = this.getView().byId("idVizFrame").vizSelection();
			var sPieChartSelection = "";
			if (oPieSelection && oPieSelection.length === 1) {
				sPieChartSelection = oPieSelection[0].data["Products"];
			}

			this._filterTableOpenIssues(sKey, sPieChartSelection);
		},

		handleTabBarSelect: function (oEv) {
			var sKey = oEv.getParameter("key");
			var oPieSelection = this.getView().byId("idVizFrame").vizSelection();
			var sPieChartSelection = "";
			if (oPieSelection && oPieSelection.length === 1) {
				sPieChartSelection = oPieSelection[0].data["Products"];
			}

			this._filterTable(sKey, sPieChartSelection);
		},
		handleTabBarSelectClosedOngoing: function (oEv) {
			var sKey = oEv.getParameter("key");
			/*
			var oPieSelection = this.getView().byId("idVizFrame").vizSelection();
			var sPieChartSelection = "";
			if (oPieSelection && oPieSelection.length === 1) {
				sPieChartSelection = oPieSelection[0].data["Products"];
			}
			*/
			this._filterTableOngoingClosed(sKey);
		},

		_filterTableOngoingClosed: function (sKey) {
			var oTableBinding = this.getView().byId("solutionOverviewClosedTable").getBinding("rows");
			var aFilters = [];
			//var oClosedFilter = new Filter("objectType", FilterOperator.EQ, "Closed Critical Incident Management");
			//aFilters.push(oClosedFilter);
			/*
			var sPieType = this.getView().byId("pieTypeButton").getSelectedKey();
			if (sPieChartSelection !== "") {
				var sFilterProperty = sPieType === "productLine" ? "ProductLineKeys" : "ProductKeys";
				var oPieFilter = new Filter(sFilterProperty, FilterOperator.Contains, sPieChartSelection);
				aFilters.push(oPieFilter);
			}*/

			var oFilter = {};
			switch (sKey) {
				case 'GlobalEscalations':
					oFilter = new Filter("objectType", FilterOperator.EQ, "Closed Global Escalation");
					break;
				case 'CriticalCustomerManagement':
					oFilter = new Filter("objectType", FilterOperator.EQ, "Closed Critical Customer Management");
					break;
				case 'CriticalPeriodCoverage':
					oFilter = new Filter("objectType", FilterOperator.EQ, "Closed Critical Period Coverage");
					break;
				case 'TopCriticalCustomers':
					oFilter = new Filter("objectType", FilterOperator.EQ, "Closed Top Critical Customers");
					break;
				case "BusinessDownSituationsClosed":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Closed Business Down Situations");
					break;
				case "XTecEngagements":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Closed xTec Engagements");
					break;
				case "PECriticalEngagements":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Closed PE Critical Engagements");
					break;
				case "ClosedCims":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Closed Critical Incident Management");
					break;
				case "TaskForces":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Closed Task Forces");
					break;
				case "CrossIssues":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Closed Cross Issue");
					break;
				case "CriticalEventCoveragesClosed":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Critical Event Coverages");
					break;
			}


			if (!jQuery.isEmptyObject(oFilter)) {
				aFilters.push(oFilter);
			}

			if (aFilters.length > 0) {
				oTableBinding.filter(aFilters);
			} else {
				oTableBinding.filter();
			}

			//now update counts
			this._updateFilterCountsClosed(sKey, "");

		},

		_filterTable: function (sKey, sPieChartSelection) {
			var oTableBinding = this.getView().byId("solutionOverviewTable").getBinding("rows");
			var aFilters = [];
			var sPieType = this.getView().byId("pieTypeButton").getSelectedKey();
			if (sPieChartSelection !== "") {
				var sFilterProperty = sPieType === "productLine" ? "ProductLineKeys" : "ProductKeys";
				var oPieFilter = new Filter(sFilterProperty, FilterOperator.Contains, sPieChartSelection);
				aFilters.push(oPieFilter);
			}

			var oFilter = {};
			switch (sKey) {
				case 'GlobalEscalations':
					oFilter = new Filter("objectType", FilterOperator.EQ, "Global Escalation");
					break;
				case 'CriticalCustomerManagement':
					oFilter = new Filter("objectType", FilterOperator.EQ, "Critical Customer Management");
					break;
				case 'CriticalPeriodCoverage':
					oFilter = new Filter("objectType", FilterOperator.EQ, "Critical Period Coverage");
					break;
				case 'TopCriticalCustomers':
					oFilter = new Filter("objectType", FilterOperator.EQ, "Top Critical Customers");
					break;
				case "BusinessDownSituations":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Business Down Situations");
					break;
				case "XTecEngagements":
					oFilter = new Filter("objectType", FilterOperator.EQ, "xTec Engagements");
					break;
				case "PECriticalEngagements":
					oFilter = new Filter("objectType", FilterOperator.EQ, "PE Critical Engagements");
					break;
				case "Cims":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Critical Incident Management");
					break;
				case "TaskForces":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Task Forces");
					break;
				case "CrossIssues":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Cross Issue");
					break;
				case "CriticalEventCoverages":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Critical Event Coverages");
					break;
			}

			if (!jQuery.isEmptyObject(oFilter)) {
				aFilters.push(oFilter);
			}

			if (aFilters.length > 0) {
				oTableBinding.filter(aFilters);
			} else {
				oTableBinding.filter();
			}

			//now update counts
			this._updateFilterCounts(sKey, sPieChartSelection);

		},

		_filterTableOpenIssues: function (sKey, sPieChartSelection) {
			var oTableBinding = this.getView().byId("solutionOverviewTableOpenIssues").getBinding("rows");
			var aFilters = [];
			var sPieType = this.getView().byId("pieTypeButton").getSelectedKey();
			if (sPieChartSelection !== "") {
				var sFilterProperty = sPieType === "productLine" ? "ProductLineKeys" : "ProductKeys";
				var oPieFilter = new Filter(sFilterProperty, FilterOperator.Contains, sPieChartSelection);
				aFilters.push(oPieFilter);
			}

			var visSelection = this.getView().byId("idVizFrame").vizSelection();
			if (visSelection.length === 1) {
				var sText = this.getView().getModel("i18n").getProperty("selectenPieChartText");
				sText = sText.replace("{type}", sPieType === "productLine" ? "Product Line" : "Product");
				sText = sText.replace("{value}", visSelection[0].data["Products.d"]);
				this.getView().getModel("solutionModel").setProperty("/selectedPieChartText", sText);
			} else {
				this.getView().getModel("solutionModel").setProperty("/selectedPieChartText", "");
			}

			var oFilter = {};
			switch (sKey) {
				case "MCCSosRequests":
					oFilter = new Filter("objectType", FilterOperator.EQ, "MCC SOS Requests");
					break;
				case "GoLiveEndangered":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Go Live Endangered");
					break;
				case "GoLiveAnnouncement":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Go Live Announcement");
					break;
				case 'GlobalEscalationRequests':
					oFilter = new Filter("objectType", FilterOperator.EQ, "Global Escalation Request");
					break;
				case 'MCCActivities':
					oFilter = new Filter("objectType", FilterOperator.EQ, "MCC Activity");
					break;
				case 'MCCIssue':
					oFilter = new Filter("objectType", FilterOperator.EQ, "MCC Issue");
					break;
				case "MCCTopCriticalCustomer":
					oFilter = new Filter("objectType", FilterOperator.EQ, "TC2 Evaluation Request");
					break;
				case 'TopIssues':
					oFilter = new Filter("objectType", FilterOperator.EQ, "Top Issue");
					break;
				case 'CCMRequests':
					oFilter = new Filter("objectType", FilterOperator.EQ, "CCM Requests");
					break;
				case 'CPCRequests':
					oFilter = new Filter("objectType", FilterOperator.EQ, "CPC Requests");
					break;
				case 'TechnicalSupportRequests':
					oFilter = new Filter("objectType", FilterOperator.EQ, "MCC Support Requests");
					break;
				case "CimRequests":
					oFilter = new Filter("objectType", FilterOperator.EQ, "CIM Requests");
					break;
				case "TechnicalBackofficeRequests":
					oFilter = new Filter("objectType", FilterOperator.EQ, "Technical Backoffice Requests");
					break;
				case "CPCActivityRequests":
					oFilter = new Filter("objectType", FilterOperator.EQ, "CPC Requests (Activities)");
					break;
				case "CCMActivityRequests":
					oFilter = new Filter("objectType", FilterOperator.EQ, "CCM Requests (Activities)");
					break;
			}

			if (!jQuery.isEmptyObject(oFilter)) {
				aFilters.push(oFilter);
			}

			if (aFilters.length > 0) {
				oTableBinding.filter(aFilters);
			} else {
				oTableBinding.filter();
			}

			//now update counts
			this._updateFilterCountsOpenIssues(sKey, sPieChartSelection);

		},

		_updateFilterCountsClosed: function (sKey, sPieChartSelection) {
			var aRows = this.getOwnerComponent().getModel("solutionModel").getProperty("/SolutionOverviewClosed");
			var oSolutionModel = this.getOwnerComponent().getModel("solutionModel");

			var oTabs = [{
				"objectType": "Closed Business Down Situations",
				"countProp": "AmountBusinessDownSituationsClosed",
				"key": "BusinessDownSituationsClosed"
			},
			{
				"objectType": "Closed PE Critical Engagements",
				"countProp": "AmountPECriticalEngagementsClosed",
				"key": "PECriticalEngagements"
			},
			{
				"objectType": "Closed Critical Incident Management",
				"countProp": "AmountCimsClosed",
				"key": "ClosedCims"
			}];


			if (sPieChartSelection === "") {
				//All
				oSolutionModel.setProperty("/AmountAllClosed", aRows.length);
				//Others
				oTabs.forEach(function (tab) {
					var aTmp = aRows.filter(function (row) {
						return row.objectType === tab.objectType;
					});
					oSolutionModel.setProperty("/" + tab.countProp, aTmp.length);
				});
			}
		},



		_updateFilterCounts: function (sKey, sPieChartSelection) {
			var aRows = this.getOwnerComponent().getModel("solutionModel").getProperty("/SolutionOverview");
			var oSolutionModel = this.getOwnerComponent().getModel("solutionModel");

			var oTabs = [{
				"objectType": "Global Escalation",
				"countProp": "AmountGlobalEscalations",
				"key": "GlobalEscalations"
			}, {
				"objectType": "Business Down Situations",
				"countProp": "AmountBusinessDownSituations",
				"key": "BusinessDownSituations"
			}, {
				"objectType": "xTec Engagements",
				"countProp": "AmountXTecEngagements",
				"key": "XTecEngagements"
			}, {
				"objectType": "PE Critical Engagements",
				"countProp": "AmountPECriticalEngagements",
				"key": "PECriticalEngagements"
			}, {
				"objectType": "Critical Customer Management",
				"countProp": "AmountCriticalCustomerManagement",
				"key": "CriticalCustomerManagement"
			}, {
				"objectType": "Critical Period Coverage",
				"countProp": "AmountCriticalPeriodCoverage",
				"key": "CriticalPeriodCoverage"
			}, {
				"objectType": "Top Critical Customers",
				"countProp": "AmountTopCriticalCustomers",
				"key": "TopCriticalCustomers"
			}, {
				"objectType": "Critical Incident Management",
				"countProp": "AmountCims",
				"key": "Cims"
			}, {
				"objectType": "Task Forces",
				"countProp": "AmountTaskForces",
				"key": "TaskForces"
			}, {
				"objectType": "Cross Issue",
				"countProp": "AmountCrossIssues",
				"key": "CrossIssues"
			}, {
				"objectType": "Critical Event Coverages",
				"countProp": "AmountCriticalEventCoverages",
				"key": "CriticalEventCoverages"
			}];

			if (sPieChartSelection === "") {
				//All
				oSolutionModel.setProperty("/AmountAll", aRows.length);
				//Others
				oTabs.forEach(function (tab) {
					var aTmp = aRows.filter(function (row) {
						return row.objectType === tab.objectType;
					});
					oSolutionModel.setProperty("/" + tab.countProp, aTmp.length);
				});
			} else if (sPieChartSelection !== "") {
				//All 
				var iAll = 0;
				var sPieType = this.getView().byId("pieTypeButton").getSelectedKey();
				var sProperty = sPieType === "productLine" ? "ProductLine" : "Product";
				aRows.forEach(function (row) {
					if (row.toProducts && row.toProducts.results && row.toProducts.results.length > 0) {
						var aTmp = [];
						row.toProducts.results.forEach(function (prod) {
							if (prod[sProperty] === sPieChartSelection) {
								if (aTmp.indexOf(prod[sProperty]) === -1) {
									aTmp.push(prod[sProperty]);
									iAll++;
								}
							}
						});
					} else if (row.objectType === "Critical Event Coverages") {
						var aTmp = [];
						if (row[sProperty] === sPieChartSelection) {
							if (aTmp.indexOf(row[sProperty]) === -1) {
								aTmp.push(row[sProperty]);
								iAll++;
							}
						}
					}

					/* else if (row.objectType === "PE Critical Situations" && row.ProductLineKeys === sPieChartSelection) {
											var aTmp = [];
											if (aTmp.indexOf(row.ProductLineKeys) === -1) {
												aTmp.push(row.ProductLineKeys);
												iAll++;
											}
										}*/
				});
				oSolutionModel.setProperty("/AmountAll", iAll);
				//Others
				oTabs.forEach(function (tab) {
					var iTmp = 0;
					var aTmp = aRows.filter(function (row) {
						return row.objectType === tab.objectType;
					});
					if (aTmp.length > 0) {
						aTmp.forEach(function (tmp) {
							var aTmp = [];
							if (tmp.toProducts && tmp.toProducts.results.length > 0) {
								tmp.toProducts.results.forEach(function (prod) {
									if (prod[sProperty] === sPieChartSelection) {
										if (aTmp.indexOf(prod[sProperty]) === -1) {
											aTmp.push(prod[sProperty]);
											iTmp++;
										}
									}
								});
							} else if (tmp.objectType === "Critical Event Coverages") {
								if (tmp[sProperty] === sPieChartSelection) {
									if (!aTmp.includes(tmp[sProperty])) {
										aTmp.push(tmp[sProperty]);
										iTmp++;
									}
								}
							}
						});
					}
					oSolutionModel.setProperty("/" + tab.countProp, iTmp);

					if (sKey === tab.key && iTmp === 0) {
						this._filterTable("All", sPieChartSelection);
					}
				}.bind(this));
			}
		},

		_updateFilterCountsOpenIssues: function (sKey, sPieChartSelection) {
			var aRows = this.getOwnerComponent().getModel("solutionModel").getProperty("/SolutionOverviewOpenIssues");
			var oSolutionModel = this.getOwnerComponent().getModel("solutionModel");
			var oTabs = [{
				"objectType": "MCC SOS Requests",
				"countProp": "AmountMCCSosRequests",
				"key": "MCCSosRequests"
			}, {
				"objectType": "Go Live Endangered",
				"countProp": "AmountGoLiveEndangered",
				"key": "GoLiveEndangered"
			}, {
				"objectType": "Go Live Announcement",
				"countProp": "AmountGoLiveAnnouncement",
				"key": "GoLiveAnnouncement"
			}, {
				"objectType": "Global Escalation Request",
				"countProp": "AmountGlobalEscalationRequests",
				"key": "GlobalEscalationRequests"
			}, {
				"objectType": "Top Issue",
				"countProp": "AmountTopIssues",
				"key": "TopIssues"
			}, {
				"objectType": "MCC Issue",
				"countProp": "AmountMCCIssues",
				"key": "MCCIssue"
			}, {
				"objectType": "TC2 Evaluation Request",
				"countProp": "AmountMCCTopCriticalCustomer",
				"key": "MCCTopCriticalCustomer"

			}, {
				"objectType": "CCM Requests",
				"countProp": "AmountCCMRequests",
				"key": "CCMRequests"
			}, {
				"objectType": "CPC Requests",
				"countProp": "AmountCPCRequests",
				"key": "CPCRequests"
			}, {
				"objectType": "CPC Requests (Activities)",
				"countProp": "AmountCPCActivityRequests",
				"key": "CPCActivityRequests"
			}, {
				"objectType": "CCM Requests (Activities)",
				"countProp": "AmountCCMActivityRequests",
				"key": "CCMActivityRequests"
			}, {
				"objectType": "MCC Support Requests",
				"countProp": "AmountTechnicalSupportRequests",
				"key": "TechnicalSupportRequests"
			}, {
				"objectType": "CIM Requests",
				"countProp": "AmountCimsRequest",
				"key": "CimRequests"
			}, {
				"objectType": "Technical Backoffice Requests",
				"countProp": "AmountTechnicalBackofficeRequests",
				"key": "TechnicalBackofficeRequests"
			}];

			if (sPieChartSelection === "") {
				//All
				oSolutionModel.setProperty("/AmountAllOpenIssues", aRows.length);
				//Others
				oTabs.forEach(function (tab) {
					var aTmp = aRows.filter(function (row) {
						return row.objectType === tab.objectType;
					});
					oSolutionModel.setProperty("/" + tab.countProp, aTmp.length);
				});
			} else if (sPieChartSelection !== "") {
				//All 
				var iAll = 0;
				var sPieType = this.getView().byId("pieTypeButton").getSelectedKey();
				var sProperty = sPieType === "productLine" ? "ProductLine" : "Product";
				aRows.forEach(function (row) {
					if (row.toProducts && row.toProducts.results && row.toProducts.results.length > 0) {
						var aTmp = [];
						row.toProducts.results.forEach(function (prod) {
							if (prod[sProperty] === sPieChartSelection) {
								if (aTmp.indexOf(prod[sProperty]) === -1) {
									aTmp.push(prod[sProperty]);
									iAll++;
								}
							}
						});
					}

				});
				oSolutionModel.setProperty("/AmountAllOpenIssues", iAll);
				//Others
				oTabs.forEach(function (tab) {
					var iTmp = 0;
					var aTmp = aRows.filter(function (row) {
						return row.objectType === tab.objectType;
					});
					if (aTmp.length > 0) {
						aTmp.forEach(function (tmp) {
							if (tmp.toProducts && tmp.toProducts.results.length > 0) {
								var aTmp = [];
								tmp.toProducts.results.forEach(function (prod) {
									if (prod[sProperty] === sPieChartSelection) {
										if (aTmp.indexOf(prod[sProperty]) === -1) {
											aTmp.push(prod[sProperty]);
											iTmp++;
										}
									}
								});
							}
						});
					}
					oSolutionModel.setProperty("/" + tab.countProp, iTmp);

					if (sKey === tab.key && iTmp === 0) {
						this._filterTableOpenIssues("All", sPieChartSelection);
					}
				}.bind(this));
			}
		},

		handleCustomerPress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("solutionModel").getPath();
			var oProperty = this.getOwnerComponent().getModel("solutionModel").getProperty(sPath);
			var sErpCustNo = oProperty.CustomerErpNo || oProperty.ErpCustNo || oProperty.CustomerNo;
			var oRouter = this.getRouter();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("solutionModel").getPath();
			var oProperty = this.getOwnerComponent().getModel("solutionModel").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		handleCasePress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("solutionModel").getPath();
			var oProperty = this.getOwnerComponent().getModel("solutionModel").getProperty(sPath);
			var sCaseId = oProperty.ObjectId;
			var oRouter = this.getRouter();
			var formattedObjectType = this.returnObjectTypeWithoutClosed(oProperty.objectType);

			if (formattedObjectType === "PE Critical Situations" || formattedObjectType === "Global Escalation Request") {
				this._openWindow(oProperty.ObjectLink);
			} else if (formattedObjectType === "Critical Incident Management" || formattedObjectType === "CIM Requests" || formattedObjectType ===
				"Technical Backoffice Requests" || formattedObjectType === "xTec Engagements" || formattedObjectType ===
				"PE Critical Engagements" || formattedObjectType === "Business Down Situations") {
				this._openSosApp(oProperty["sys_id"], "&transType=sn_customerservice_escalation");
			} else if (formattedObjectType === "Cross Issue") {
				this.getRouter().navTo("CrossIssueDetails", {
					"?query": this._getQueryParameter(),
					"objectId": oProperty.ObjectId
				});
			} else if (formattedObjectType === "Critical Event Coverages") {
				this.getRouter().navTo("CriticalEventCoverageDetails", {
					"?query": this._getQueryParameter(),
					"ObjectID": oProperty.ObjectId
				});
			} else {
				this.getOwnerComponent().getModel("case").setProperty("/reload", true);
				oRouter.navTo("CaseDetails", {
					"?query": this._getQueryParameter(),
					CaseId: sCaseId
				});
			}
		},

		onCaseNewTab: function (oEv) {
			var sPath = oEv.getSource().getParent().getBindingContext("solutionModel").getPath();
			var oProperty = this.getOwnerComponent().getModel("solutionModel").getProperty(sPath);
			var sCaseId = oProperty.ObjectId;
			var formattedObjectType = this.returnObjectTypeWithoutClosed(oProperty.objectType);

			if (formattedObjectType === "PE Critical Situations" || formattedObjectType === "Global Escalation Request") {
				this._openWindow(oProperty.ObjectLink);
			} else if (formattedObjectType === "Critical Incident Management" || formattedObjectType === "CIM Requests" || formattedObjectType ===
				"Technical Backoffice Requests" || formattedObjectType ===
				"MCC Support Requests" || formattedObjectType === "xTec Engagements" || formattedObjectType ===
				"PE Critical Engagements" || formattedObjectType === "Business Down Situations" || formattedObjectType === "CPC Requests" || formattedObjectType === "CCM Requests") {
				this._openSosApp(oProperty["sys_id"], "&transType=sn_customerservice_escalation");
			} else if (formattedObjectType === "Cross Issue") {
				this._openCrossIssueInNewTab(oProperty.ObjectId);
			} else if (formattedObjectType === "Critical Event Coverages") {
				this._openCriticalEventCoverageInNewTab(oProperty.ObjectId);
			} else {
				this._openCaseInNewTab(sCaseId);
			}

		},

		handleOpenIssuesCasePress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("solutionModel").getPath();
			var oProperty = this.getOwnerComponent().getModel("solutionModel").getProperty(sPath);

			if (oProperty.objectType === "CIM Requests" || oProperty.objectType === "Technical Backoffice Requests" || oProperty.objectType === "MCC Support Requests" || oProperty.objectType === "CCM Requests" || oProperty.objectType === "CPC Requests") {
				this._openSosApp(oProperty["sys_id"], "&transType=sn_customerservice_escalation");
			} else if (oProperty.ProcessType === "ZS46") {
				this._openSosApp(oProperty.ObjectId, "", true);
			} else {
				this._openWindow(oProperty.ObjectLink);
			}
		},

		onNavHome: function (oEvent) {
			//nav back to start page of the MCC One Dashboard
			var oRouter = this.getRouter();
			oRouter.navTo("Global", {
				"?query": this._getQueryParameter(),
			});
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("solutionModel").getObject();
			var sObjectType = oData.objectType;
			sObjectType = sObjectType.replace("Closed ", "")
			var sId = oData.ObjectId;
			switch (sObjectType) {
				case "Critical Customer Management":
				case "Task Forces":
				case "Critical Period Coverage":
				case "Guided Solution Support":
					this._readCustomerEngagementsNotes(oEv.getSource(), sId, sObjectType);
					break;
				case "Top Critical Customers":
					this._readCriticalSituationsNotes(oEv.getSource(), sId, sObjectType);
					break;
				case "Cross Issue":
					this._readCrossIssuesNotes(oEv.getSource(), oData.Guid, sObjectType);
					break;
				case "Global Escalation":
					this._readGlobalEscalationsNotes(oEv.getSource(), sId, sObjectType);
					break;
				case "Critical Event Coverages":
					this.openQuickInfoPopoverCEC(oEv.getSource(), oData.toNotes.results);
					break;
					break;
				case "Critical Incident Management":
				case "Business Down Situations":
				case "CIM Requests":
				case "xTec Engagements":
				case "PE Critical Engagements":
					this._openServiceNowQuickView(sObjectType, oEv.getSource(), oData);
			}
			this.trackEvent("Status Report: show Popover");
		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("solutionModel").getObject();
			var sCaseId = oProperty.ObjectId;
			this._shopTopIssuesCountPopover(sCaseId, oEv.getSource());
		},
		customSorting: function (oEvent) {
			var oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingColumn");
			var oMCCiColumn = this.byId("mcci");
			var oPreventionScoreColumn = this.byId("preventionScore");
			var oCurrentColumn = oEvent.getParameter("column");
			if (oCurrentColumn !== oGUMaintenanceRankingColumn && oCurrentColumn !== oMCCiColumn && oCurrentColumn !== oPreventionScoreColumn) {
				//oGUMaintenanceRankingColumn.setSorted(false); //No multi-column sorting
				return;
			}
			oEvent.preventDefault();
			var sOrder = oEvent.getParameter("sortOrder");
			if (oCurrentColumn == oMCCiColumn || oCurrentColumn == oPreventionScoreColumn) {
				this.customSortingBaseFloat(oCurrentColumn, sOrder, "solutionOverviewTable");
			} else {
				this.customSortingBase(oCurrentColumn, sOrder, oGUMaintenanceRankingColumn, "solutionOverviewTable");
			}
		},
		customSortingOpenIssues: function (oEvent) {
			var oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingIssuesColumn");
			var oCurrentColumn = oEvent.getParameter("column");
			if (oCurrentColumn !== oGUMaintenanceRankingColumn) {
				//oGUMaintenanceRankingColumn.setSorted(false); //No multi-column sorting
				return;
			}
			oEvent.preventDefault();
			var sOrder = oEvent.getParameter("sortOrder");
			this.customSortingBase(oCurrentColumn, sOrder, oGUMaintenanceRankingColumn, "solutionOverviewTableOpenIssues");
		},

		readImplementationPartner: function (oModel) {
			var aData = oModel.getData();
			var aFilters = [];

			//split data in multiple arrays
			var size = 50;
			var arrayOfArrays = [];
			for (var i = 0; i < aData["SolutionOverview"].length; i += size) {
				arrayOfArrays.push(aData["SolutionOverview"].slice(i, i + size));
			}

			arrayOfArrays.forEach(function (array) {
				aFilters = [];
				array.forEach(function (c) {
					if (c.ObjectId && c.ObjectId !== "" && c.objectType !== "Critical Incident Management" && c.objectType !==
						"Global Escalation" && c.objectType !== "Business Down Situations" && c.objectType !== "xTec Engagements" && c.objectType !==
						"PE Critical Engagements" && c.objectType !==
						"Technical Backoffice Requests"
						//closed variations
						&& c.objectType !== "Closed Critical Incident Management"
						&& c.objectType !== "Closed Global Escalation"
						&& c.objectType !== "Closed Business Down Situations"
						&& c.objectType !== "Closed xTec Engagements"
						&& c.objectType !== "Closed PE Critical Engagements"
						&& c.objectType !== "Closed Technical Backoffice Requests"
					) {
						aFilters.push(new sap.ui.model.Filter("CaseID", sap.ui.model.FilterOperator.EQ, c.ObjectId));
					}
				});
				this.getModel("subModel").read("/Cases", {
					filters: [new sap.ui.model.Filter(aFilters, false)],
					success: function (oData) {
						oData.results.forEach(function (result) {
							var oCase = aData["SolutionOverview"].filter(function (val) {
								return val.ObjectId === result.CaseID.toString();
							});
							if (oCase && oCase.length === 1) {
								oCase[0]["ImplementationPartner"] = result.PartnerName;
							}
						});
						oModel.refresh();
					}
				});
			}.bind(this));

		},

		onPressImpactedCustomers: function (oEv) {
			var oData = oEv.getSource().getBindingContext("solutionModel").getObject();
			this._openPopover("Impacted Customers", oData.toAffCustomers.results);
		},
		_openPopover: function (title, aItems) {
			var oModel = new sap.ui.model.json.JSONModel();
			var oData = {
				"title": title,
				"items": []
			};
			//map values for model
			aItems.forEach(function (val) {
				var sCustCrm = "";
				var sCustErp = "";
				if (title === "Impacted Customers") {
					if (val.Partner !== "") {
						sCustCrm = "BP ID: " + val.Partner;
					}
					if (val.ErpCustNo !== "") {
						sCustErp = "ERP ID: " + val.ErpCustNo;
					}
				}

				oData.items.push({
					"type": title === "Impacted Customers" ? "cust" : "lob",
					"title": val.Name1 + " " + val.Name2,
					"custCrm": sCustCrm,
					"custErp": sCustErp
				});
			});
			oModel.setData(oData);
			Fragment.load({
				name: "com.sap.mcconedashboard.view.fragment.OutagesDialogList",
				controller: this
			}).then(function (oDialog) {
				oDialog.setModel(oModel, "data");
				this.getView().addDependent(oDialog);
				oDialog.open();
			}.bind(this));
		},

		onNavToCustomerView: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("data").getObject().custErp.substring(8);
			oEv.getSource().getParent().close();
			oEv.getSource().getParent().destroy();
			this.getRouter().navTo("Customer", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		onListSearch: function (oEv) {
			var sQuery = oEv.getParameter("newValue");
			var oList = sap.ui.getCore().byId("outagesList");
			var aFilters = [];
			if (sQuery && sQuery.length > 0) {
				aFilters.push(new sap.ui.model.Filter([
					new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("custCrm", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("custErp", sap.ui.model.FilterOperator.Contains, sQuery)
				]));
			}
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		onListClose: function (oEv) {
			oEv.getSource().getParent().close();
			oEv.getSource().getParent().destroy();
		},

		onObjectTypePress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("solutionModel").getObject().objectType;
			//sObjectType.replace("Closed ", "");
			sObjectType = sObjectType.split("Closed ").join("");
			sObjectType = sObjectType.split(" (Activities)").join("");
				var sMsg = this._getObjectTypeInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		},

		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("solutionModel").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		},

		onHeaderImageLoaded: function () {
			//set text title invisible
			this.getOwnerComponent().getModel("solutionModel").setProperty("/titleImageVisible", true);
			this.getOwnerComponent().getModel("solutionModel").setProperty("/titleTextVisible", false);
		},
		onHeaderImageError: function () {
			this.getOwnerComponent().getModel("solutionModel").setProperty("/titleTextVisible", true);
		},
		// read the information for MCCi and Prevention Score from C4S System
		// for the header information we also need to show trends
		readMissionRadarValues: function (oModel, bNoData) {
			//only if the flag is set, the data should be read
			//if (this.getModel("settings").getProperty("/showMissionRadar")) {
			var aData = oModel.getData();
			var that = this;

			//MISSIONRADAR 2211	
			// we need to loop throught all shown engagements, because there could be different customers involved
			//for the C4S call we need to add the leading zeros			
			var aEngagementListErpNumbers = [];
			aData["SolutionOverview"].forEach(function (c) {
				if (!aEngagementListErpNumbers.includes(that.pad(c.CustomerNo, 10)) && c.CustomerNo !== "") {
					aEngagementListErpNumbers.push(that.pad(c.CustomerNo, 10));
				}
			}.bind(this));

			//we need submit todays date in format "2022-09-23" to get the current values
			var today = new Date(); //("2022-10-28"); //new Date();
			var yesterday = new Date(today);
			yesterday.setDate(today.getDate() - 1); // Subtract 1 day from today's date
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd" // we need a format like 2022-12-24
			});
			today = oFormat.format(today);
			yesterday = oFormat.format(yesterday);

			if (aEngagementListErpNumbers.length > 0 && (!bNoData || bNoData === false)) {
				//Read data for the list view
				//	$.ajax("./json/ExampleC4SCustomerView.json", { // only for testing - load the data from a relative URL (the Data.json file in the same directory)
				// as soon as we are able to test in the test environment we need to use the following call

				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([{
						"queryIdentifier": "CL_MCCI_V2_CURRENT",
						"elementList": [
							"SNAPSHOT_DATE", "CUSTOMER_ID", "ERP_Account", "Global_Ultimate", "Internal_Sales_Segment", "Global_Ultimate_Name", "MCCI", "TREND_28_DAYS", "TREND_3_DAYS", "CCM_CASES", "CPC_CASES", "TF_CASES", "TC2_CASES", "GEM_CASES", "OPEN_NOW_P1", "OPEN_NOW_P2", "MCC_SOL_AREA", "MCC_SOL_AREA_RANK"
						],
						"filters": [{
							"filters": [{
								"operand1": {
									"elementIdentifier": "ERP_Account"
								},
								"operand2": {
									"values": aEngagementListErpNumbers
								},
								"operator": "EQ"
							}, {
								"operand1": {
									"elementIdentifier": "SNAPSHOT_DATE"
								},
								"operand2": {
									"values": [today]
								},
								"operator": "EQ"
							}],
							"conjunctionOperator": "AND"
						}],
						"skip": 0
					}]),
					contentType: "application/json"
				}).always(function (data, stextStatus, errorThrown) {
					if (data.queryResults && data.queryResults.CL_MCCI_V2_CURRENT && data.queryResults.CL_MCCI_V2_CURRENT.rows.length > 0) {

						//Check if every MCCI Value is 0, if so we need to use yesterdays data instead.
						var allMCCIValuesZero = data.queryResults.CL_MCCI_V2_CURRENT.rows.every(function (row) {
							return row.MCCI.value === 0;
						});

						if (allMCCIValuesZero) {
							that.readMissionRadarValues(oModel, true);
						} else {
							aData["SolutionOverview"].forEach(function (oDataElement) {
								var oCase = data.queryResults.CL_MCCI_V2_CURRENT.rows.filter(function (val) {
									return val.ERP_Account.key === that.pad(oDataElement.CustomerNo, 10);
								});
								// we should get the first entry only, if it is from today, otherwise it would be older data, because we are reading the last 14 days
								//therefore it could also be, that there is no data for specific customers, because they have no ongoing cases in the relevant timeframes for Mission Control values
								if (oCase && oCase.length >= 1 && (oCase[0].SNAPSHOT_DATE.key === today)) {
									oDataElement.MCCi = Math.round(oCase[0].MCCI.value).toString();
									oDataElement.Trend = Math.round(oCase[0].TREND_28_DAYS.value).toString();
								}
							});
							oModel.refresh();
						}
					} else if (data.queryResults && data.queryResults.CL_MCCI_V2_CURRENT && !data.queryResults.CL_MCCI_V2_CURRENT.rows.length > 0) {
						//Try to find data with SNAPSHOT_DATE = yesterday
						console.log("No MCCI Data for today, trying to find yesterdays data")
						that.readMissionRadarValues(oModel, true);
						// that.getView().byId("c4sErrorTest").setText("Response received: \n\nHTTP Status Code: " + n.status + "\n\n" + "Response Text: \n" +
						// 	JSON.stringify(e));
					} else {
						console.log("No MCCI data found")
					}
				});

			} else if (aEngagementListErpNumbers.length > 0 && (bNoData === true)) {

				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([{
						"queryIdentifier": "CL_MCCI_V2_CURRENT",
						"elementList": [
							"SNAPSHOT_DATE", "CUSTOMER_ID", "ERP_Account", "Global_Ultimate", "Internal_Sales_Segment", "Global_Ultimate_Name", "MCCI", "TREND_28_DAYS", "TREND_3_DAYS", "CCM_CASES", "CPC_CASES", "TF_CASES", "TC2_CASES", "GEM_CASES", "OPEN_NOW_P1", "OPEN_NOW_P2", "MCC_SOL_AREA", "MCC_SOL_AREA_RANK"
						],
						"filters": [{
							"filters": [{
								"operand1": {
									"elementIdentifier": "ERP_Account"
								},
								"operand2": {
									"values": aEngagementListErpNumbers
								},
								"operator": "EQ"
							}, {
								"operand1": {
									"elementIdentifier": "SNAPSHOT_DATE"
								},
								"operand2": {
									"values": [yesterday]
								},
								"operator": "EQ"
							}],
							"conjunctionOperator": "AND"
						}],
						"skip": 0
					}]),
					contentType: "application/json"
				}).always(function (data, stextStatus, errorThrown) {
					if (data.queryResults && data.queryResults.CL_MCCI_V2_CURRENT && data.queryResults.CL_MCCI_V2_CURRENT.rows.length > 0) {
						aData["SolutionOverview"].forEach(function (oDataElement) {
							var oCase = data.queryResults.CL_MCCI_V2_CURRENT.rows.filter(function (val) {
								return val.ERP_Account.key === that.pad(oDataElement.CustomerNo, 10);
							});
							// we should get the first entry only, if it is from today, otherwise it would be older data, because we are reading the last 14 days
							//therefore it could also be, that there is no data for specific customers, because they have no ongoing cases in the relevant timeframes for Mission Control values
							if (oCase && oCase.length >= 1 && (oCase[0].SNAPSHOT_DATE.key === today || oCase[0].SNAPSHOT_DATE.key === yesterday)) {
								oDataElement.MCCi = Math.round(oCase[0].MCCI.value).toString();
								oDataElement.Trend = Math.round(oCase[0].TREND_28_DAYS.value).toString();
							}
						});
						oModel.refresh();
					} else {
						console.log("No MCCI Data for today or yesterday.")
						// that.getView().byId("c4sErrorTest").setText("Response received: \n\nHTTP Status Code: " + n.status + "\n\n" + "Response Text: \n" +
						// 	JSON.stringify(e));
					}
				});
			}
			//}
		},


	});
});