sap.ui.define([
	"sap/ui/base/Object",
	"sap/m/MessageBox",
	"sap/m/Dialog",
	"sap/ui/layout/VerticalLayout",
	"sap/m/Button",
	"sap/m/Text"
], function (UI5Object, MessageBox) {
	"use strict";

	return UI5Object.extend("com.sap.mcconedashboard.controller.ErrorHandler", {

		/**
		 * Handles application errors by automatically attaching to the model events and displaying errors when needed.
		 * @class
		 * @param {sap.ui.core.UIComponent} oComponent reference to the app"s component
		 * @public
		 * @alias com.sap.mcconedashboard.controller.ErrorHandler
		 */
		constructor: function (oComponent) {
			this._oResourceBundle = oComponent.getModel("i18n").getResourceBundle();
			this._oComponent = oComponent;
			this._bMessageOpen = false;
			this._sErrorText = this._oResourceBundle.getText("errorText");
			this._AuthError = false;
			this._CRMAuthError = false;

			//================================================
			// Default Model
			//================================================
			this._oModel = oComponent.getModel();
			this._oModel.attachMetadataFailed(function (oEvent) {
				var oParams = oEvent.getParameters();
				oComponent.getModel("settings").setProperty("/defaultModel_metadataLoaded", false);
				this._showMetadataError(oParams.response);
			}, this);

			this._oModel.attachRequestFailed(function (oEvent) {
				var oParams = oEvent.getParameters();
				//it could be that there is a customer favorite stored, which is not an active customer anymore. Therefore do NOT throw any error, yet show a message in the console
				if (oParams.response.statusCode === 404 && oParams.response.responseText.indexOf("Resource not found for segment 'Customer'") !==
					0) {
					return;
				}
				// An entity that was not found in the service is also throwing a 404 error in oData.
				// We already cover this case with a notFound target so we skip it here.
				// A request that cannot be sent to the server is a technical error that we have to handle though
				if (oParams.response.statusCode !== "404" || (oParams.response.statusCode === 404 && oParams.response.responseText.indexOf(
						"Cannot POST") === 0)) {
					this._showServiceError(oParams.response);
				}
			}, this);

			this._oModel.attachMetadataLoaded(function (oEvent) {
				oComponent.getModel("settings").setProperty("/defaultModel_metadataLoaded", true);
			}, this);

			//================================================
			// BC Model
			//================================================
			// this._oBCModel = oComponent.getModel("bcModel");
			// this._oBCModel.attachMetadataFailed(function (oEvent) {
			// 	var oParams = oEvent.getParameters();
			// 	oComponent.getModel("settings").setProperty("/bcModel_metadataLoaded", false);
			// 	//this._showMetadataError(oParams.response);
			// }, this);

			// this._oBCModel.attachRequestFailed(function (oEvent) {
			// 	var oParams = oEvent.getParameters();
			// 	// An entity that was not found in the service is also throwing a 404 error in oData.
			// 	// We already cover this case with a notFound target so we skip it here.
			// 	// A request that cannot be sent to the server is a technical error that we have to handle though
			// 	if (oParams.response.statusCode !== "404" || (oParams.response.statusCode === 404 && oParams.response.responseText.indexOf(
			// 			"Cannot POST") === 0)) {
			// 		this._showServiceError(oParams.response);
			// 	}
			// }, this);

			// this._oBCModel.attachMetadataLoaded(function (oEvent) {
			// 	oComponent.getModel("settings").setProperty("/bcModel_metadataLoaded", true);
			// }, this);

			//================================================
			// DEP_APP Model - for reading customer logo
			//================================================
			this._oDepAppModel = oComponent.getModel("appDepModel");
			this._oDepAppModel.attachMetadataFailed(function (oEvent) {
				var oParams = oEvent.getParameters();
				oComponent.getModel("settings").setProperty("/app_dep_Model_metadataLoaded", false);
				//this._showMetadataError(oParams.response);
			}, this);
			this._oDepAppModel.attachRequestFailed(function (oEvent) {
				var oParams = oEvent.getParameters();
				// An entity that was not found in the service is also throwing a 404 error in oData.
				// We already cover this case with a notFound target so we skip it here.
				// A request that cannot be sent to the server is a technical error that we have to handle though
				if (oParams.response.statusCode !== "404" || (oParams.response.statusCode === 404 && oParams.response.responseText.indexOf(
						"Cannot POST") === 0)) {
					this._showServiceError(oParams.response);
				}
			}, this);

			this._oDepAppModel.attachMetadataLoaded(function (oEvent) {
				oComponent.getModel("settings").setProperty("/app_dep_Model_metadataLoaded", true);
			}, this);

			//================================================
			// MCC HANA Models subModel & solutionHub
			//================================================
			this._oSsubModelModel = oComponent.getModel("subModel");
			this._oSolutionHubModel = oComponent.getModel("solutionHub");
			this._oSsubModelModel.attachMetadataFailed(function (oEvent) {
				var oParams = oEvent.getParameters();
				oComponent.getModel("settings").setProperty("/sub_Model_metadataLoaded", false);
			}, this);
			this._oSolutionHubModel.attachMetadataFailed(function (oEvent) {
				var oParams = oEvent.getParameters();
				oComponent.getModel("settings").setProperty("/solution_Hub_Model_metadataLoaded", false);
			}, this);
			this._oSsubModelModel.attachRequestFailed(function (oEvent) {
				var oParams = oEvent.getParameters();
				// An entity that was not found in the service is also throwing a 404 error in oData.
				// We already cover this case with a notFound target so we skip it here.
				// A request that cannot be sent to the server is a technical error that we have to handle though
				if (oParams.response.statusCode !== "404" || (oParams.response.statusCode === 404 && oParams.response.responseText.indexOf(
						"Cannot POST") === 0)) {
					this._showServiceError(oParams.response);
				}
			}, this);

			this._oSsubModelModel.attachMetadataLoaded(function (oEvent) {
				oComponent.getModel("settings").setProperty("/sub_Model_metadataLoaded", true);
			}, this);

			this._oSolutionHubModel.attachRequestFailed(function (oEvent) {
				var oParams = oEvent.getParameters();
				// An entity that was not found in the service is also throwing a 404 error in oData.
				// We already cover this case with a notFound target so we skip it here.
				// A request that cannot be sent to the server is a technical error that we have to handle though
				if (oParams.response.statusCode !== "404" || (oParams.response.statusCode === 404 && oParams.response.responseText.indexOf(
						"Cannot POST") === 0)) {
					this._showServiceError(oParams.response);
				}
			}, this);

			this._oSolutionHubModel.attachMetadataLoaded(function (oEvent) {
				oComponent.getModel("settings").setProperty("/solution_Hub_Model_metadataLoaded", true);
			}, this);

			//================================================
			// MCS Dashboard Model - IC*
			//================================================
			this._oMCSModel = oComponent.getModel("mcsModel");
			this._oMCSModel.attachMetadataFailed(function (oEvent) {
				//var oParams = oEvent.getParameters();
				oComponent.getModel("settings").setProperty("/show_crm_data", Boolean(false));
				this._CRMAuthError = true;
				//in case there are no CRM authorization rights assigned, the user should also not see BW tiles
				oComponent.getModel("settings").setProperty("/show_cost_data", Boolean(false));
			}, this);

			this._oMCSModel.attachRequestFailed(function (oEvent) {
				var oParams = oEvent.getParameters();
				// An entity that was not found in the service is also throwing a 404 error in oData.
				// We already cover this case with a notFound target so we skip it here.
				// A request that cannot be sent to the server is a technical error that we have to handle though
				if (oParams.response.statusCode !== "404" || (oParams.response.statusCode === 404 && oParams.response.responseText.indexOf(
						"Cannot POST") === 0)) {
					this._showServiceError(oParams.response, "MCSDashboard");
				}
			}, this);

			this._oMCSModel.attachMetadataLoaded(function (oEvent) {
				this._CRMAuthError = false;
				oComponent.getModel("settings").setProperty("/show_crm_data", Boolean(true));
			}, this);
		},

		/**
		 * Shows a {@link sap.m.MessageBox} when the metadata call has failed.
		 * The user can try to refresh the metadata.
		 * @param {string} sDetails a technical error to be displayed on request
		 * @private
		 */
		_showMetadataError: function (sDetails) {
			var sTypeToShow = "DEFAULT";
			sap.ui.core.BusyIndicator.hide();

			//in case of no authorization show specific error message and do not enable the retry button
			if (sDetails.statusCode === 403) { //Forbidden
				this._sErrorText = this._oResourceBundle.getText("mainAuthRequestMessage0");
				sTypeToShow = "403";
			} else { //Service Unavailable
				this._sErrorText = this._oResourceBundle.getText("errorText503");
			}

			// in case of specific no auth error messages show a link-to-email
			//	if (bShowEmailLink && (this._oComponent.getModel("settings").getProperty("/noCaseDataAuthCount") < 2)) {
			if (sTypeToShow === "403") {
				var dialogEmail = new sap.m.Dialog({
					title: this._oResourceBundle.getText("errorHeaderNoAuth"),
					type: "Message",
					state: "Error",
					contentWidth: "55rem",
					content: new sap.ui.layout.VerticalLayout({
						content: [new sap.m.FormattedText({
								htmlText: this._sErrorText
							}), new sap.m.VBox({
								wrap: "Wrap",
								items: [
									new sap.m.Link({
										text: this._oResourceBundle.getText("mainAuthRequestMessage1"),
										href: this._oResourceBundle.getText("armRequestURLSUCSDB"),
										target: "_blank"
									}).addStyleClass("sapUiSmallMarginTop MCCOneBoldLinkText"),
									new sap.m.Text({
										text: this._oResourceBundle.getText("mainAuthRequestMessage2")
									}).addStyleClass("superTinyMarginRight"),
								]
							}),
							new sap.m.Text({
								text: this._oResourceBundle.getText("mainAuthRequestMessage3")
							}).addStyleClass("sapUiSmallMarginTop"),
							new sap.m.VBox({
								wrap: "Wrap",
								items: [
									new sap.m.Link({
										text: this._oResourceBundle.getText("aggrProfileRequestLinkText"),
										href: this._oResourceBundle.getText("aggrProfileRequestLink"),
										target: "_blank"
									}).addStyleClass("sapUiSmallMarginTop MCCOneBoldLinkText"),
									new sap.m.Text({
										text: this._oResourceBundle.getText("mainAuthRequestMessage4")
									}).addStyleClass("superTinyMarginRight")
								]
							}),
							new sap.m.HBox({
								wrap: "Wrap",
								items: [new sap.m.Text({
										text: this._oResourceBundle.getText("mainAuthRequestMessage5")
									}).addStyleClass("superTinyMarginRight"),
									new sap.m.Link({
										text: this._oResourceBundle.getText("authWikiUserGuideText"),
										href: this._oResourceBundle.getText("authWikiUserGuideURL"),
										target: "_blank"
									})
								]
							}).addStyleClass("sapUiSmallMarginTop")
						]
					}),
					beginButton: new sap.m.Button({
						text: "Close",
						press: function () {
							dialogEmail.close();
						}
					}),
					afterClose: function () {
						dialogEmail.destroy();
					}
				});
				dialogEmail.addStyleClass("sapUiContentPadding");
				dialogEmail.open();
			} else {

				//sap.m.Dialog needed because we want to provide the possibility to show link to Ticket create Launchpad
				/* eslint-disable  sap-no-hardcoded-url  */
				//var sErrorMessage = $(sDetails.body).find('message').first().text();
				var sErrorMessage = "";
				try {
					sErrorMessage = $(sDetails.body).find("message").first().text();
				} catch (err) {
					sErrorMessage = sDetails.body;
					if (sErrorMessage === "" && sDetails.responseText) {
						sErrorMessage = sDetails.responseText;
					}
				}

				var oPanel = new sap.m.Panel({
					expandable: true,
					expanded: false,
					width: "100%",
					headerText: this._oResourceBundle.getText("systemErrorText", sDetails.statusCode),
					content: new sap.ui.layout.VerticalLayout({
						content: [new sap.m.Text({
							text: sDetails.statusCode
						}), new sap.m.Text({
							text: sDetails.statusText
						}), new sap.m.Text({
							text: sErrorMessage,
							width: "100%"
						})]
					})
				});

				oPanel.addStyleClass("sapUiResponsiveMargin");
				//oPanel.addStyleClass("dashboardErrorPanelText");
				var dialog = new sap.m.Dialog({
					title: this._oResourceBundle.getText("errorHeader"),
					type: "Message",
					state: "Error",
					content: new sap.ui.layout.VerticalLayout({
						content: [new sap.m.Text({
								text: this._sErrorText
							}),
							new sap.m.Link({
								text: this._oResourceBundle.getText("createTicket"),
								target: "_blank",
								href: "https://itsupportportal.services.sap/itsupport?id=itsm_sc_cat_item&sys_id=b1982b441bb1c1105039a6c8bb4bcbc3&sysparm_variables=%7B%22business_service%22:%2221af9c6f1ba564905039a6c8bb4bcb61%22,%22service_offering%22:%2210c283dd1b8e259036ac10e69b4bcb28%22,%22assignment_group%22:%22e5818b511b8e259036ac10e69b4bcbd4%22,%22short_description%22:%22Issue%20with%20MCC%20One%20Dashboard%22,%22description%22:%22Issue%20Description%20and%20steps%20to%20reproduce%20this%20issue%22%7D"

								//before 12.2022	
								//href: "https://fiorilaunchpad.sap.com/sites#Help-Inbox&/create/ZINE/IMAS_SUD_MC/Issue%20with%20'MCC%20One%20Dashboard'/2//ICP/Issue%20Description%20and%20steps%20to%20reproduce%20this%20issue//////01/01/////Business%20Applications%20(HR%2C%20Billing%2C%20Sales%2C%20Controlling%2C...)"

								//before 05.2023
								//href: "https://fiorilaunchpad.sap.com/sites#Help-Inbox&/create/ZINE/IMFIT_DBS_MCC/Issue%20with%20'MCC%20One%20Dashboard'/2//ICP/Issue%20Description%20and%20steps%20to%20reproduce%20this%20issue//////01/01/////Federated%20IT%20(Presales%2C%20DBS%2C%20Education%20%26%20Training%2C...)"

							}), new sap.m.Text({
								text: this._oResourceBundle.getText("systemErrorText")
							}), oPanel
						]
					}),
					beginButton: new sap.m.Button({
						text: this._oResourceBundle.getText("close"),
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});

				dialog.addStyleClass("sapUiContentPadding");
				dialog.open();
				/* eslint-enable  sap-no-hardcoded-url  */
			}

			/* eslint-enable  sap-no-hardcoded-url  */
		},

		/**
		 * Shows a {@link sap.m.MessageBox} when a service call has failed.
		 * Only the first error message will be display.
		 * @param {string} sDetails a technical error to be displayed on request
		 * @private
		 */
		_showServiceError: function (sDetails, sType) {
			sap.ui.core.BusyIndicator.hide();
			if (this._bMessageOpen) {
				return;
			}
			this._bMessageOpen = true;
			/* eslint-disable  sap-no-hardcoded-url  */

			//in case of no authorization show specific error message and do not enable the retry button

			// No authorization to call ZS_DBS_MCS_DASHBOARD_SRV 
			var bShowEmailLink = false;
			var sErrorText = this._oResourceBundle.getText("errorTextTicket");
			if (sDetails.responseText.indexOf("User does not have the sufficient authorizations.") > -1) {
				if (sType === "MCSDashboard") {
					this._oComponent.getModel("settings").setProperty("/show_crm_data", Boolean(false));
					this._oComponent.getModel("settings").setProperty("/show_cost_data", Boolean(false));
					this._oComponent.getModel("extReportFilters").setProperty("/oDataCallStatus", "ERROR");
				}
				bShowEmailLink = true;
			}
			// No authorization to read escalation case data in IC* Landscape
			else if (sDetails.responseText.indexOf("No Auth for Escalation Data") > -1) {
				sErrorText = this._oResourceBundle.getText("errorTextAuthorizationGatewayOrIC");
				if (sType === "MCSDashboard") {
					this._oComponent.getModel("settings").setProperty("/show_crm_data", Boolean(false));
					this._oComponent.getModel("settings").setProperty("/show_cost_data", Boolean(false));
					this._oComponent.getModel("extReportFilters").setProperty("/oDataCallStatus", "ERROR");
				}
				bShowEmailLink = true;
			}

			var that = this;
			// in case of specific no auth error messages show a link-to-email
			//	if (bShowEmailLink && (this._oComponent.getModel("settings").getProperty("/noCaseDataAuthCount") < 2)) {
			if (bShowEmailLink) {
				var dialogEmail = new sap.m.Dialog({
					title: this._oResourceBundle.getText("errorHeader"),
					type: "Message",
					state: "Error",
					content: new sap.ui.layout.VerticalLayout({
						content: [new sap.m.Text({
								text: sErrorText
							}),
							new sap.m.Link({
								text: this._oResourceBundle.getText("mcsDashboardGlobal"),
								press: function () {
									sap.m.URLHelper.triggerEmail(
										"kathrin.belser@sap.com;bjarni.hirzel@sap.com;klaus.fehrer@sap.com;",
										"MCC One Dashboard App - No authorization to access global escalation data");
								}
							})
						]
					}),
					beginButton: new sap.m.Button({
						text: "Close",
						press: function () {
							that._bMessageOpen = false;
							dialogEmail.close();
						}
					}),
					afterClose: function () {
						dialogEmail.destroy();
					}
				});
				dialogEmail.addStyleClass("sapUiContentPadding");
				dialogEmail.open();
			} else if (!bShowEmailLink) {
				//sap.m.Dialog needed because we want to provide the possibility to show link to Ticket create Launchpad
				/* eslint-disable  sap-no-hardcoded-url  */
				var sErrorMessage = $(sDetails.body).find("message").first().text();
				if (sErrorMessage === "" && sDetails.responseText) {
					var data = "";
					try {
						data = JSON.parse(sDetails.responseText);
					} catch (e) {
						data = "";
					}
					if (data !== "") {
						if (data.error.message.value && data.error.message.value !== "") {
							sErrorMessage = data.error.message.value;
						}
					} else {
						sErrorMessage = sDetails.responseText;
					}
				}
				var oPanel = new sap.m.Panel({
					expandable: true,
					expanded: false,
					width: "100%",
					headerText: this._oResourceBundle.getText("systemErrorText", sDetails.statusCode),
					content: new sap.ui.layout.VerticalLayout({
						content: [new sap.m.Text({
							text: sDetails.statusCode
						}), new sap.m.Text({
							text: sDetails.statusText
						}), new sap.m.Text({
							text: sErrorMessage,
							width: "100%"
						})]
					})
				});

				oPanel.addStyleClass("sapUiResponsiveMargin");
				//oPanel.addStyleClass("dashboardErrorPanelText");
				var dialog = new sap.m.Dialog({
					title: this._oResourceBundle.getText("errorHeader"),
					type: "Message",
					state: "Error",
					content: new sap.ui.layout.VerticalLayout({
						content: [new sap.m.Text({
								text: sErrorText
							}),
							new sap.m.Link({
								text: this._oResourceBundle.getText("createTicket"),
								target: "_blank",
								href: "https://itsupportportal.services.sap/itsupport?id=itsm_sc_cat_item&sys_id=b1982b441bb1c1105039a6c8bb4bcbc3&sysparm_variables=%7B%22business_service%22:%2221af9c6f1ba564905039a6c8bb4bcb61%22,%22service_offering%22:%2210c283dd1b8e259036ac10e69b4bcb28%22,%22assignment_group%22:%22e5818b511b8e259036ac10e69b4bcbd4%22,%22short_description%22:%22Issue%20with%20MCC%20One%20Dashboard%22,%22description%22:%22Issue%20Description%20and%20steps%20to%20reproduce%20this%20issue%22%7D"

								//before 12.2022	
								//href: "https://fiorilaunchpad.sap.com/sites#Help-Inbox&/create/ZINE/IMAS_SUD_MC/Issue%20with%20'MCC%20One%20Dashboard'/2//ICP/Issue%20Description%20and%20steps%20to%20reproduce%20this%20issue//////01/01/////Business%20Applications%20(HR%2C%20Billing%2C%20Sales%2C%20Controlling%2C...)"

								//before 05.2023
								//href: "https://fiorilaunchpad.sap.com/sites#Help-Inbox&/create/ZINE/IMFIT_DBS_MCC/Issue%20with%20'MCC%20One%20Dashboard'/2//ICP/Issue%20Description%20and%20steps%20to%20reproduce%20this%20issue//////01/01/////Federated%20IT%20(Presales%2C%20DBS%2C%20Education%20%26%20Training%2C...)"

							}), new sap.m.Text({
								text: this._oResourceBundle.getText("systemErrorText")
							}), oPanel
						]
					}),
					beginButton: new sap.m.Button({
						text: "Close",
						press: function () {
							that._bMessageOpen = false;
							dialog.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});
				dialog.addStyleClass("sapUiContentPadding");
				dialog.open();
				/* eslint-enable  sap-no-hardcoded-url  */
			}

		}
	});
});