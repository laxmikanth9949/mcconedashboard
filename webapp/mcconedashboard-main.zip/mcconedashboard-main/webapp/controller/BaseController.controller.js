/*global history */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/ui/core/HTML",
	"sap/ui/core/routing/History",
	"com/sap/mcconedashboard/control/CustomFacetFilterList",
	"sap/ui/core/Fragment",
	"sapit/util/UsageTracking",
	"sap/m/FacetFilterList",
	"sap/m/MessageToast",
	"com/sap/mcconedashboard/model/Constants",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/controller/mcs/ReportDownloadHandler",
	'sap/ui/export/library',
	"sap/ui/export/Spreadsheet",
	"sap/ui/core/Icon",
	"sap/ui/core/theming/Parameters",
	"sap/base/Log",

], function (Controller, JSONModel, Filter, FilterOperator, Dialog, Button, HTML, History, CustomFacetFilterList, Fragment, UsageTracking,
	FacetFilterList, MessageToast, Constants, Formatter, ReportDownloadHandler, exportLibrary, Spreadsheet, Icon, Parameters, Logger) {
	"use strict";

	var EdmType = exportLibrary.EdmType;
	var DebugMode = false; //Set to true to read Mission Radar Values from JSON instead

	return Controller.extend("com.sap.mcconedashboard.controller.BaseController", {
		formatter: Formatter,
		facetFilter: null,
		sDownloadFunctionName: "",
		sDownloadMimeType: "PDF",
		reportDownloadHandler: ReportDownloadHandler,

		_getQueryParameter: function (oEv) {
			var oParameter = {};
			if (this.getModel("settings").getProperty("/isAnonymizedMode")) {
				oParameter["isAnonymizedMode"] = "true";
			}

			var oFeatureFlags = this.getOwnerComponent().getModel("featureFlags").getData();
			var urlParams = sap.ui.core.routing.HashChanger.getInstance().getHash().split("?")[1];
			var queryParams = new URLSearchParams(urlParams);

			// Check if there is a "ft"-Parameter in the current URL
			var ftInUrl = queryParams.get("ft");

			Object.keys(oFeatureFlags).forEach(function (key) {
				// Do not read the Flags with "mcc-onedashboard"
				if (!key.startsWith("mcc-onedashboard")) {
					if (oFeatureFlags[key] !== false && oFeatureFlags[key] !== undefined) {
						// Only include Flags that are actually set by URL, not all Flags
						if (ftInUrl && ftInUrl.includes(key)) {
							if (typeof oParameter["ft"] !== "string") {
								oParameter["ft"] = "";
							} else {
								oParameter["ft"] += ",";
							}
							oParameter["ft"] += key;
							if (typeof oFeatureFlags[key] === "string") {
								oParameter["ft"] += "(" + oFeatureFlags[key] + ")";
							}
						}
					}
				}
			});
			return oParameter;
		},


		_handleMissionRadarAndAnonymizedMode: function (oArgs) {
			//For Customer Visits the end users can also set an URL Parameter to enable the anonymization mode
			var bIsAnonymizedMode = false;
			var bShowMissionRadarValues = false;
			if (oArgs["?query"] && oArgs["?query"].isAnonymizedMode && oArgs["?query"].isAnonymizedMode === "true") {
				bIsAnonymizedMode = true;
			}
			/*if (oArgs["?query"] && oArgs["?query"].showMissionRadar && oArgs["?query"].showMissionRadar === "true") {
				bShowMissionRadarValues = true;
			}*/
			//in case app is called standalone
			if (jQuery.sap.getUriParameters()._get("isAnonymizedMode")) {
				if (jQuery.sap.getUriParameters()._get("isAnonymizedMode") === "true") {
					bIsAnonymizedMode = true;
				} else {
					bIsAnonymizedMode = false;
				}
			}
			/*if (jQuery.sap.getUriParameters()._get("showMissionRadar")) {
				if (jQuery.sap.getUriParameters()._get("showMissionRadar") === "true") {
					bShowMissionRadarValues = true;
				} else {
					bShowMissionRadarValues = false;
				}
			}
			this.getOwnerComponent().getModel("settings").setProperty("/showMissionRadar", bShowMissionRadarValues); */
			this.getOwnerComponent().getModel("settings").setProperty("/isAnonymizedMode", bIsAnonymizedMode);
		},

		//Used to read FeatureFlags set in the FeatureFlags Dashboard and to use URL Parameters to overwrite for testing use cases
		//Make sure to call this function in every controller that uses FeatureFlags to recheck for changed URL Parameters
		//Use the Callback in the controller to e.g. destroy columns if the visible variable is not enough to hide features
		//Keep in mind that if the user sets a manual value in brackets e.g. showAiSummary(test) the value of showAiSummary will be "test" - a string.
		//That might cause issues if the expected value is a boolean. You can also catch that with the callback function.
		_handleFeatureFlags: function (oArgs, callback) {
			var oFeatureFlagsModel = this.getModel("featureFlags");
			var that = this;

			var checkModelLoadedInterval = setInterval(function () {
				if (oFeatureFlagsModel && oFeatureFlagsModel.getData()) {
					clearInterval(checkModelLoadedInterval);
					oFeatureFlagsModel = that.getModel("featureFlags");
					var aFlags = oFeatureFlagsModel.getData();
					//Order of flags is relevant and needs to fit featureFlags order in FeatureFlagConnector
					var flags = {
						"showAiSummary": false,
						"showTestFeature": false,
						"ccsPreview": false
					};

					// Set flags based on the keys in aFlags
					Object.keys(aFlags).forEach(function (sFeatureFlag) {
						var flagName = sFeatureFlag.split('.').pop(); // Extract flag name from the feature flag ID
						if (flags.hasOwnProperty(flagName)) {
							flags[flagName] = aFlags[sFeatureFlag];
						}
					});

					// Update flags with values from aFlags if not set by URL parameters
					Object.keys(flags).forEach(function (flagName) {
						if (flags[flagName] === false && aFlags.hasOwnProperty("mcc-onedashboard." + flagName.toLowerCase())) {
							flags[flagName] = aFlags["mcc-onedashboard." + flagName.toLowerCase()];
						}
					});

					// Parse the "ft" parameter values and update flags accordingly
					that.parseFTParameter(oArgs["?query"] ? oArgs["?query"].ft : "", flags);


					// Update the featureFlags model
					Object.keys(flags).forEach(function (flagName) {
						that.getOwnerComponent().getModel("featureFlags").setProperty("/" + flagName, flags[flagName]);
					}, that);

					// Execute the callback function if provided
					if (typeof callback === "function") {
						callback(flags);
					}

				}
			}, 200);

		},

		parseFTParameter: function (ftParam, flags) {
			if (!ftParam) return;

			// Split the values by comma
			var ftValues = ftParam.split(",");

			// Loop through each value
			ftValues.forEach(function (value) {
				// Check if the value contains parentheses
				var matches = value.match(/^(.*)\(([^)]+)\)$/);
				if (matches) {
					// If parentheses found, extract the value inside and assign it to the corresponding flag
					var flagName = matches[1].trim();
					var flagValue = matches[2].trim();
					if (flags.hasOwnProperty(flagName)) {
						// If the value is "true" or "false", convert it to a boolean
						if (flagValue === "true") {
							flags[flagName] = true;
						} else if (flagValue === "false") {
							flags[flagName] = false;
						} else {
							flags[flagName] = flagValue;
						}
					}
				} else {
					// If no parentheses found, set the corresponding flag to true
					if (flags.hasOwnProperty(value.trim())) {
						flags[value.trim()] = true;
					}
				}
			});
		},



		dateRangeOverlaps: function (a_start, a_end, b_start, b_end) {
			if (a_start <= b_start && b_start <= a_end) return true; // b starts in a
			if (a_start <= b_end && b_end <= a_end) return true; // b ends in a
			if (b_start <= a_start && a_end <= b_end) return true; // a in b
			return false;
		},

		_openServiceNowQuickView: function (sObjectType, oControl, oData) {
			var oSettingsModel = this.getModel("settings");

			if (sObjectType === Constants.MCCEngagementType.CriticalIncidentManagement) {
				oSettingsModel.setProperty("/isCIMQuickInfo", true);
			} else {
				oSettingsModel.setProperty("/isCIMQuickInfo", false);
			}

			var oModel = new JSONModel(oData);
			if (!this.quickInfoServiceNowDialog) {
				this.quickInfoServiceNowDialog = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.QuickInfoServiceNow", this);
				this.getView().addDependent(this.quickInfoServiceNowDialog);
			}
			this.quickInfoServiceNowDialog.setModel(oModel, "data");
			this.quickInfoServiceNowDialog.openBy(oControl);
		},

		_getImageStream: function (sUrl) {
			return new Promise(function (resolve) {
				fetch(sUrl, {
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					}
				}).then(function (data) {
					if (data.status === 200) {
						data.blob().then(function (blob) {
							var reader = new FileReader();
							reader.readAsDataURL(blob);
							reader.onloadend = function () {
								resolve(reader.result);
							};
						}.bind(this));
					}
				}.bind(this));
			});
		},

		openSelectedFilterPopover: function (oEvent) {
			var oButton = oEvent.getSource(),
				oView = this.getView();

			if (!this._pPopover) {
				this._pPopover = Fragment.load({
					id: oView.getId(),
					name: "com.sap.mcconedashboard.view.fragment.FilterCriteriaDialog",
					controller: this
				}).then(function (oPopover) {
					oView.addDependent(oPopover);
					return oPopover;
				});
			}
			this._pPopover.then(function (oPopover) {
				oPopover.openBy(oButton);
			});
		},

		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */

		getClosedDateFilter: function (sProperty, customDateInPast) {
			var dateOffset = (24 * 60 * 60 * 1000) * Constants.closedCasesPastDays;
			//dateOffset *= 500//delete later
			var dateInPast = new Date();
			dateInPast.setTime(dateInPast.getTime() - dateOffset);

			return new sap.ui.model.Filter({
				path: sProperty,
				operator: sap.ui.model.FilterOperator.GE,
				value1: customDateInPast || dateInPast
			});
		},

		_isFlp: function () {
			var bIsFlp = false;
			if (sap.ushell && sap.ushell.Container) {
				bIsFlp = true;
			}
			return bIsFlp;
		},

		_openCaseInNewTab: function (sCaseId, selectedSection) {
			if (sCaseId) {
				var bIsAnonymizedModeOn = this.getModel("settings").getProperty("/isAnonymizedMode");
				//var bShowMissionRadar = this.getModel("settings").getProperty("/showMissionRadar");

				if (sap.ushell && sap.ushell.Container) {
					var sBaseUrl = window.location.protocol + '//' + window.location.host + window.location.pathname;

					var sCaseURL = this.getRouter().getURL("CaseDetails", {
						"CaseId": sCaseId
					});

					if (selectedSection && selectedSection !== "") {
						var sCaseURL = this.getRouter().getURL("CaseDetails", {
							"CaseId": sCaseId,
							query: {
								tab: selectedSection
							}
						});
					}

					sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {
						oService.hrefForExternalAsync({
							target: {
								shellHash: "#mcconedashboard-Display" + "&/" + sCaseURL,
							}
						}).then(function (sExternalHref) { // do something with the resolved sExternalHref. 
							if (bIsAnonymizedModeOn && !window.location.href.split("#")[0].includes("sAnonymizedMode=true")) {
								//sExternalHref = sExternalHref.split("&")[0] + "?isAnonymizedMode=true&showMissionRadar=" + bShowMissionRadar + "&" +
								sExternalHref = sExternalHref.split("&")[0] + "?isAnonymizedMode=true" + "&" +
									//sExternalHref.split("&")[1];
									sExternalHref.split("&")[0];
							} else {
								//sExternalHref = sExternalHref.split("&")[0] + "?isAnonymizedMode=false&showMissionRadar=" + bShowMissionRadar + "&" +
								sExternalHref = sExternalHref.split("&")[0] + "?isAnonymizedMode=false" + "&" +
									//sExternalHref.split("&")[1];
									sExternalHref.split("&")[0];
							}
							var url = window.location.href.split("#")[0] + sExternalHref;
							sap.m.URLHelper.redirect(url, true);
						});
					});
				} else {
					var sBaseUrl = window.location.protocol + '//' + window.location.host + window.location.pathname;
					if (selectedSection && selectedSection !== "") {
						sBaseUrl += "?section=" + selectedSection;
						if (bIsAnonymizedModeOn && !sap.ushell) {
							//sBaseUrl += "&isAnonymizedMode=true&showMissionRadar=" + bShowMissionRadar;
							sBaseUrl += "&isAnonymizedMode=true";
						} else {
							//sBaseUrl += "&isAnonymizedMode=false&showMissionRadar=" + bShowMissionRadar;
							sBaseUrl += "&isAnonymizedMode=false";
						}
					} else if (bIsAnonymizedModeOn && !sap.ushell) {
						//sBaseUrl += "?isAnonymizedMode=true&showMissionRadar=" + bShowMissionRadar;
						sBaseUrl += "?isAnonymizedMode=true";
					} else {
						//sBaseUrl += "?isAnonymizedMode=false&showMissionRadar=" + bShowMissionRadar;
						sBaseUrl += "?isAnonymizedMode=false";
					}

					var sCaseURL = this.getRouter().getURL("CaseDetails", {
						"CaseId": sCaseId
					});
					var sFinalCaseURL = "#/" + sCaseURL;

					var win = window.open(sBaseUrl + sFinalCaseURL, "_blank");
					win.opener = null;
				}
			}
		},

		_openCriticalEventCoverageInNewTab: function (sObjectId) {
			if (sObjectId) {
				//var sBasePath = window.location.pathname.replace(/\/[^\/]*\.?[^\/]*$/, '/');
				var sBaseUrl = window.location.protocol + '//' + window.location.host + window.location.pathname;
				//var sBaseUrl = window.location.href;

				var bIsAnonymizedModeOn = this.getModel("settings").getProperty("/isAnonymizedMode");
				//var bShowMissionRadar = this.getModel("settings").getProperty("/showMissionRadar");

				if (bIsAnonymizedModeOn && !sap.ushell) {
					//sBaseUrl += "?isAnonymizedMode=true&showMissionRadar=" + bShowMissionRadar;
					sBaseUrl += "?isAnonymizedMode=true";
				}
				var sCaseURL = this.getRouter().getURL("CriticalEventCoverageDetails", {
					"ObjectID": sObjectId
				});
				var sFinalCaseURL = "#/" + sCaseURL; //https://mcconedashboard-sapitcloudt.dispatcher.hana.ondemand.com/index.html?hc_reset#/Case/20088852
				// if (sap.ushell) { //https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites#mcconedashboard-Display&/Case/20088914
				// 	sFinalCaseURL = "#mcconedashboard-Display&/" + sCaseURL;
				// }
				// var win = window.open(sBaseUrl + sFinalCaseURL, "_blank");
				// win.opener = null;

				if (sap.ushell && sap.ushell.Container) {
					sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {
						oService.hrefForExternalAsync({
							target: {
								/*shellHash: "#mcconedashboard-Display?isAnonymizedMode=" + bIsAnonymizedModeOn + "&showMissionRadar=" + bShowMissionRadar +
									"&/" + sCaseURL */
								shellHash: "#mcconedashboard-Display?isAnonymizedMode=" + bIsAnonymizedModeOn +
									"&/" + sCaseURL
							}
						}).then(function (sExternalHref) { // do something with the resolved sExternalHref. 
							sFinalCaseURL = sExternalHref;
							var win = window.open(sBaseUrl + sFinalCaseURL, "_blank");
							win.opener = null;
						});
					});
				} else {
					var win = window.open(sBaseUrl + sFinalCaseURL, "_blank");
					win.opener = null;
				}
			}
		},

		_openCrossIssueInNewTab: function (sObjectId) {
			if (sObjectId) {
				//var sBasePath = window.location.pathname.replace(/\/[^\/]*\.?[^\/]*$/, '/');
				var sBaseUrl = window.location.protocol + '//' + window.location.host + window.location.pathname;
				//var sBaseUrl = window.location.href;

				var bIsAnonymizedModeOn = this.getModel("settings").getProperty("/isAnonymizedMode");
				//var bShowMissionRadar = this.getModel("settings").getProperty("/showMissionRadar");

				if (bIsAnonymizedModeOn && !sap.ushell) {
					//sBaseUrl += "?isAnonymizedMode=true&showMissionRadar=" + bShowMissionRadar;
					sBaseUrl += "?isAnonymizedMode=true";
				}
				var sCaseURL = this.getRouter().getURL("CrossIssueDetails", {
					"objectId": sObjectId
				});
				var sFinalCaseURL = "#/" + sCaseURL; //https://mcconedashboard-sapitcloudt.dispatcher.hana.ondemand.com/index.html?hc_reset#/Case/20088852
				// if (sap.ushell) { //https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites#mcconedashboard-Display&/Case/20088914
				// 	sFinalCaseURL = "#mcconedashboard-Display&/" + sCaseURL;
				// }
				// var win = window.open(sBaseUrl + sFinalCaseURL, "_blank");
				// win.opener = null;

				if (sap.ushell && sap.ushell.Container) {
					sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {
						oService.hrefForExternalAsync({
							target: {
								/*shellHash: "#mcconedashboard-Display?isAnonymizedMode=" + bIsAnonymizedModeOn + "&showMissionRadar=" + bShowMissionRadar +
									"&/" + sCaseURL */
								shellHash: "#mcconedashboard-Display?isAnonymizedMode=" + bIsAnonymizedModeOn +
									"&/" + sCaseURL
							}
						}).then(function (sExternalHref) { // do something with the resolved sExternalHref. 
							sFinalCaseURL = sExternalHref;
							var win = window.open(sBaseUrl + sFinalCaseURL, "_blank");
							win.opener = null;
						});
					});
				} else {
					var win = window.open(sBaseUrl + sFinalCaseURL, "_blank");
					win.opener = null;
				}
			}
		},

		_openCustomerInNewTab: function (sErpCustNo) {
			if (sErpCustNo) {
				//var sBasePath = window.location.pathname.replace(/\/[^\/]*\.?[^\/]*$/, '/');
				var sBaseUrl = window.location.protocol + '//' + window.location.host + window.location.pathname;
				//var sBaseUrl = window.location.href;

				var bIsAnonymizedModeOn = this.getModel("settings").getProperty("/isAnonymizedMode");
				//var bShowMissionRadar = this.getModel("settings").getProperty("/showMissionRadar");

				if (bIsAnonymizedModeOn && !sap.ushell) {
					//sBaseUrl += "?isAnonymizedMode=true&showMissionRadar=" + bShowMissionRadar;
					sBaseUrl += "?isAnonymizedMode=true";
				}
				var sCustomerURL = this.getRouter().getURL("Customer", {
					"ErpCustNo": sErpCustNo
				});
				var sFinalCaseURL = "#/" + sCustomerURL;

				if (sap.ushell && sap.ushell.Container) {
					sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {
						oService.hrefForExternalAsync({
							target: {
								shellHash: "#mcconedashboard-Display?isAnonymizedMode=" + bIsAnonymizedModeOn +
									"&/" + sCustomerURL
							}
						}).then(function (sExternalHref) { // do something with the resolved sExternalHref. 
							sFinalCaseURL = sExternalHref;
							var win = window.open(sBaseUrl + sFinalCaseURL, "_blank");
							win.opener = null;
						});
					});
				} else {
					var win = window.open(sBaseUrl + sFinalCaseURL, "_blank");
					win.opener = null;
				}
			}
		},

		_sortByPriority: function (data) {
			function fnMaintenanceRankingHelper(val) {
				var x = parseFloat(val);
				return x === 0 ? Infinity : x;
			}
			var sortedData = data.results.sort(function (val1, val2) {
				if (parseInt(val2.Priority) > parseInt(val1.Priority)) {
					return -1;
				} else if (parseInt(val2.Priority) < parseInt(val1.Priority)) {
					return 1;
				} else if (fnMaintenanceRankingHelper(val1.DbsMaintenanceRanking) < fnMaintenanceRankingHelper(val2.DbsMaintenanceRanking)) {
					return -1;
				} else if (fnMaintenanceRankingHelper(val1.DbsMaintenanceRanking) > fnMaintenanceRankingHelper(val2.DbsMaintenanceRanking)) {
					return 1;
				} else if (val1.ChangeDate && val2.ChangeDate && val1.ChangeDate.getTime() > val2.ChangeDate.getTime()) {
					return -1;
				} else if (val1.ChangeDate && val2.ChangeDate && val1.ChangeDate.getTime() < val2.ChangeDate.getTime()) {
					return 1;
				}
				return 0;
			});
			return {
				"results": sortedData
			};
		},

		_sortByRanking: function (data) {
			function fnMaintenanceRankingHelper(val) {
				var x = parseFloat(val);
				return x === 0 ? Infinity : x;
			}
			var sortedData = data.results.sort(function (val1, val2) {
				if (val2.Rating > val1.Rating) {
					return 1;
				} else if (val2.Rating < val1.Rating) {
					return -1;
				} else if (fnMaintenanceRankingHelper(val1.DbsMaintenanceRanking) < fnMaintenanceRankingHelper(val2.DbsMaintenanceRanking)) {
					return -1;
					//return fnMaintenanceRankingHelper(val1.DbsMaintenanceRanking) - fnMaintenanceRankingHelper(val2.DbsMaintenanceRanking);
				} else if (fnMaintenanceRankingHelper(val1.DbsMaintenanceRanking) > fnMaintenanceRankingHelper(val2.DbsMaintenanceRanking)) {
					return 1;
					//return fnMaintenanceRankingHelper(val2.DbsMaintenanceRanking) - fnMaintenanceRankingHelper(val1.DbsMaintenanceRanking);
				} else if (val1.ChangeDate && val2.ChangeDate && val1.ChangeDate.getTime() > val2.ChangeDate.getTime()) {
					return -1;
				} else if (val1.ChangeDate && val2.ChangeDate && val1.ChangeDate.getTime() < val2.ChangeDate.getTime()) {
					return 1;
				}
				return 0;
			});
			return {
				"results": sortedData
			};
		},

		readImplementationPartner: function (oModel) {
			return new Promise(function (resolve) {
				var aData = oModel.getData();
				var aFilters = [];

				//split data in multiple arrays
				var size = 50;
				var arrayOfArrays = [];
				for (var i = 0; i < aData.results.length; i += size) {
					arrayOfArrays.push(aData.results.slice(i, i + size));
				}

				arrayOfArrays.forEach(function (array) {
					aFilters = [];
					array.forEach(function (c) {
						if (c.CaseId && c.CaseId !== "" && !c.CaseId.startsWith("ESC")) {
							aFilters.push(new sap.ui.model.Filter("CaseID", sap.ui.model.FilterOperator.EQ, c.CaseId));
						}
					});
					this.getModel("subModel").read("/Cases", {
						filters: [new sap.ui.model.Filter(aFilters, false)],
						success: function (oData) {
							oData.results.forEach(function (result) {
								var oCase = aData.results.filter(function (val) {
									return val.CaseId === result.CaseID.toString();
								});
								if (oCase && oCase.length === 1) {
									oCase[0]["ImplementationPartner"] = result.PartnerName;
								}
							});
							oModel.refresh();
						}
					});
				}.bind(this));
				resolve();
			}.bind(this));

		},

		_shopTopIssuesCountPopover: function (sCaseId, oControl) {
			var oModel = this.getModel();
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.EQ, sCaseId));
			//Filter only TopIssues with status "New" (E0010), "Approved" (E0011), "In Process" (E0014), "Responsible Action" (E0018)
			aFilters.push(new sap.ui.model.Filter([
				new sap.ui.model.Filter([new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0010"), new sap.ui.model.Filter(
					"Status", sap.ui.model.FilterOperator.EQ, "E0011"), new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ,
						"E0014"),
				new sap
					.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0018")
				], false)
			],
				true
			));
			var oPrioritySorter = new sap.ui.model.Sorter("Priority", false);
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oModel.read("/TopIssuesSet", {
				filters: aFilters,
				sorters: [oPrioritySorter],
				urlParameters: {
					"$expand": "toLastNotes,toProducts",
					"$select": "Description,DescriptionLong,CaseId,toProducts,toLastNotes"
				},
				success: function (data) {
					oControl.setBusy(false);
					var oPopoverModel = new JSONModel();
					var aItems = [];
					data.results.forEach(function (issue) {
						var oData = {};
						var sDescriptionNote = "";
						var sMainProduct = "";
						var aDescriptionNotes = issue.toLastNotes.results.filter(function (note) {
							return note.NoteType === "A001";
						});
						if (aDescriptionNotes.length === 1) {
							sDescriptionNote = aDescriptionNotes[0].Text;
						}

						var oMainProduct = issue.toProducts.results.find(function (product) {
							return product.Main === "X";
						});
						if (oMainProduct) {
							sMainProduct = oMainProduct.ProductT;
						}

						oData.product = sMainProduct;
						oData.id = issue.CaseId;
						oData.title = issue.DescriptionLong !== "" ? issue.DescriptionLong : issue.Description;
						oData.description = sDescriptionNote;
						oData.iconSrc = "sap-icon://circle-task-2";
						oData.iconColor = issue.Rating === "C" ? "#b00" : issue.Rating === "B" ? "#e9730c" : issue.Rating === "A" ? "#107e3e" :
							"#6a6d70";
						aItems.push(oData);
					}.bind(this));
					if (!this.oTopOpenIssuePopover) {
						Fragment.load({
							name: "com.sap.mcconedashboard.view.fragment.OpenTopIssuesPopover",
							controller: this
						}).then(function (oPopover) {
							this.oTopOpenIssuePopover = oPopover;
							this.getView().addDependent(this.oTopOpenIssuePopover);
							this.oTopOpenIssuePopover.setModel(oPopoverModel, "data");
							oPopoverModel.setData(aItems);
							this.oTopOpenIssuePopover.openBy(oControl);
						}.bind(this));
					} else {
						oPopoverModel.setData(aItems);
						this.oTopOpenIssuePopover.setModel(oPopoverModel, "data");
						this.oTopOpenIssuePopover.openBy(oControl);
					}

				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
			this.trackEvent("Open Top Issues: show Popover");
		},

		navToCase: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("data").getObject().id;
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);

			var oRouter = this.getRouter();
			oRouter.navTo("CaseDetails", {
				CaseId: sCaseId,
				"?query": this._getQueryParameter()
			});
		},

		navToCaseFromTopIssuePopover: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("data").getObject().id;
			var aParams = this._getQueryParameter();
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);
			aParams["tab"] = "TopIssueSection";
			this.getRouter().navTo("CaseDetails", {
				CaseId: sCaseId,
				"?query": aParams
			});
			//this._openCaseInNewTab(sCaseId, "TopIssueSection");
		},

		getParsedNote: function (text, header, end) {
			var regExp = new RegExp(header.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&"), "i");
			var result = regExp.test(text);
			if (result) {
				if (end) {
					var idxStart = text.toUpperCase().indexOf(header.toUpperCase());
					var idxEnd = text.toUpperCase().indexOf(end.toUpperCase());
					if (idxStart > -1 && idxEnd > -1) {
						return text.substring(idxStart + header.length, idxEnd);
					}
				} else {
					var idx = text.toUpperCase().indexOf(header.toUpperCase());
					return text.substring(idx + header.length);
				}
			}
			return "";
		},

		getRouter: function () {
			return this.getOwnerComponent().getRouter();
		},

		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName) || this.getOwnerComponent().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		getRegionFilterModel: function () {
			var oFilterModel = this.getModel("filterModel"); //this.oView.getModel("filterModel");
			//var sRegion;
			// if (oFilterModel.getProperty("/regionalBreakdownRegion") !== null) {
			// 	sRegion = oFilterModel.getProperty("/regionalBreakdownRegion");
			// } else {
			var sRegion = oFilterModel.getProperty("/region");
			//}
			return sRegion;
		},

		/**
		 * Event handler for navigating back.
		 * If there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the master route.
		 * @public
		 */
		onNavBack: function () {
			var mobileMode = this.getModel("settings").getProperty("/isMobileMode");
			var sPreviousHash = History.getInstance().getPreviousHash();
			var oRouter = this.getRouter();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				if (mobileMode) {

					var oRouter = this.getRouter();
					oRouter.navTo("GlobalMobile", {
						"?query": this._getQueryParameter()
					});

				} else {

					var oRouter = this.getRouter();
					oRouter.navTo("Global", {
						"?query": this._getQueryParameter()
					});
					this.getOwnerComponent().getModel("settings").setProperty("/isInChartsTile", false);
					this.getOwnerComponent().getModel("settings").setProperty("/isInOperationalKPITile", false);
				}
			}

		},

		onNavHome: function (oEvent) {
			//nav back to start page of the MCC One Dashboard
			var mobileMode = this.getModel("settings").getProperty("/isMobileMode");
			var oRouter = this.getRouter();

			if (mobileMode) {
				var oRouter = this.getRouter();
				oRouter.navTo("GlobalMobile", {
					"?query": this._getQueryParameter()
				});
			} else {
				var oRouter = this.getRouter();
				oRouter.navTo("Global", {
					"?query": this._getQueryParameter()
				});
				this.getOwnerComponent().getModel("settings").setProperty("/isInChartsTile", false);
				this.getOwnerComponent().getModel("settings").setProperty("/isInOperationalKPITile", false);
			}

		},

		_addLeadingZeros: function (sErpCustNo) {
			var sLength = 10 - sErpCustNo.length;
			var sZeros = "";
			for (var i = 0; i < sLength; i++) {
				sZeros = sZeros + "0";
			}
			return sZeros + sErpCustNo;
		},

		_removeLeadingZeros: function (sCustomerErpNo) {
			var result = sCustomerErpNo.replace(/^0+/, '');
			return result;
		},

		_getLandscapeID: function () {
			var landscapeID = "ICP";
			if ((location.hostname.indexOf("br339jmc4c") > -1) || (location.hostname.indexOf("dev-mallard") > -1)) {
				landscapeID = "ICD";
			} else if ((location.hostname.indexOf("sapitcloudt") > -1) || (location.hostname.indexOf("test-kinkajou") > -1)) {
				landscapeID = "ICT";
			}
			return landscapeID;
		},

		/*
		 * Event handler for navigation to customer fact sheet
		 * Set routing parameter 'ErpCustNo' and navigate to customer fact sheet
		 */
		handleCustomerPress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("customerModel").getPath();
			var oProperty = this.getModel("customerModel").getProperty(sPath);
			var sErpCustNo = oProperty.CustomerErpNo || oProperty.ErpCustNo || oProperty.CustomerNo;
			var oRouter = this.getRouter();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);

			var oRouter = this.getRouter();
			oRouter.navTo("Customer", {
				ErpCustNo: sErpCustNo,
				"?query": this._getQueryParameter()
			});
		},

		/*
		 *Event handler when Global Ulitmate is press in any table
		 * Set Routing parameter 'ErpCustNo' and navigate to customer fact sheet
		 **/
		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("customerModel").getPath();
			var oProperty = this.getModel("customerModel").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);

			var oRouter = this.getRouter();
			oRouter.navTo("Customer", {
				ErpCustNo: sErpCustNo,
				"?query": this._getQueryParameter()
			});
		},

		openQuickInfoWithData(oControl, oNoteData, isExecutiveEscalation = false) {
			if (!!this.statusReportDialog && this.statusReportDialog.length > 0) this.statusReportDialog.destroy()
			const fragmentName = "com.sap.mcconedashboard.view.fragment.StatusReport" + (isExecutiveEscalation ? "ExecutiveEscalation" : "")
			this.statusReportDialog = sap.ui.xmlfragment(fragmentName, this);
			this.getView().addDependent(this.statusReportDialog);
			this.statusReportDialog.setModel(new JSONModel(oNoteData), "notes");

			this.statusReportDialog.openBy(oControl);
			oControl.setBusy(false);
		},
		/*
		 * Event handler to distinguish which status report function needs to be executed.
		 * 
		 */
		openQuickInfoPopover: function (oControl, aNotes, sObjectType) {
			const oNotesInfo = this._getNotesInformation(aNotes, sObjectType);
			this.openQuickInfoWithData(oControl, {
				escalationReason: oNotesInfo.escalationReason,
				executiveSummary: oNotesInfo.executiveSummary,
				reasonTypeHeader: oNotesInfo.reasonTypeHeader
			});
		},

		openQuickInfoPopoverCEC: function (oControl, aNotes) {
			var oNotesInfo = this._getNotesInformationCEC(aNotes);
			if (!this.statusReportDialogCEC) {
				this.statusReportDialogCEC = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.StatusReportCEC", this);
				this.getView().addDependent(this.statusReportDialogCEC);
			}
			this.statusReportDialogCEC.setModel(new JSONModel(oNotesInfo), "notes");
			this.statusReportDialogCEC.openBy(oControl);
		},

		openQuickInfoPopoverBusinessDown: function (oControl, aNotes, sObjectType) {
			var oNotesInfo = this._getNotesInformationBusinessDown(aNotes);
			if (!this.statusReportDialogBusinessDown) {
				this.statusReportDialogBusinessDown = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.StatusReportBusinessDown", this);
				this.getView().addDependent(this.statusReportDialogBusinessDown);
			}
			this.statusReportDialogBusinessDown.setModel(new JSONModel({
				zs16Txt: oNotesInfo.zs16Txt,
				zs17Txt: oNotesInfo.zs17Txt,
				zs18Txt: oNotesInfo.zs18Txt,
				zs16Header: oNotesInfo.zs16Header,
				zs17Header: oNotesInfo.zs17Header,
				zs18Header: oNotesInfo.zs18Header
			}), "notes");

			this.statusReportDialogBusinessDown.openBy(oControl);
			oControl.setBusy(false);
		},

		_getNotesInformationCEC: function (aNotes) {
			var summaryHeader = "";
			var summaryText = "";
			var generalHeader = "";
			var generalText = "";
			aNotes.forEach(function (note) {
				switch (note.Type) {
					case "Summary":
						summaryText = note.Text;
						summaryHeader = note.Type;
						break;
					case "General":
						generalText = note.Text;
						generalHeader = note.Type;
						break;
				}
			}.bind(this));
			return {
				summaryHeader: summaryHeader,
				summaryText: summaryText,
				generalHeader: generalHeader,
				generalText: generalText
			};
		},

		_getNotesInformation: function (aNotes, sObjectType) {
			var escalationReason = "-";
			var executiveSummary = "-";
			var reasonTypeHeader = "";
			var bEscalationReasonAlreadyExists = false;
			var bExecuteSummaryAlreadyExists = false;
			//var sObjectType = sObjectType;

			//sort by date
			aNotes = aNotes.sort(function (a, b) {
				//format time, which comes in format <d:created_at>PT15H46M10S</d:created_at> to be shown as 15:46:10
				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
				var aTMPTime = new Date(a.CreatedAt.ms + TZOffsetMs);
				var bTMPTime = new Date(b.CreatedAt.ms + TZOffsetMs);
				b.CreatedOn.setHours(bTMPTime.getHours());
				a.CreatedOn.setHours(aTMPTime.getHours());
				b.CreatedOn.setMinutes(bTMPTime.getMinutes());
				a.CreatedOn.setMinutes(aTMPTime.getMinutes());
				b.CreatedOn.setSeconds(bTMPTime.getSeconds());
				a.CreatedOn.setSeconds(aTMPTime.getSeconds());
				return b.CreatedOn.getTime() - a.CreatedOn.getTime();
			});

			aNotes.forEach(function (note) {
				switch (note.NoteType) {
					case "ZSCA":
						if (!bEscalationReasonAlreadyExists) {
							bEscalationReasonAlreadyExists = true;
							escalationReason = note.Text;
							reasonTypeHeader = "Engagement Reason";
						}
						break;
					case "Z03V":
						if (!bExecuteSummaryAlreadyExists) {
							bExecuteSummaryAlreadyExists = true;
							executiveSummary = note.Text;
						}
						break;
					case "0007": //latest Status
						if (!bExecuteSummaryAlreadyExists) {
							bExecuteSummaryAlreadyExists = true;
							if (note.CaseId.startsWith("100")) {
								var text = this.getParsedNote(note.Text, "Executive Status Summary on overall situation:", "STATUS DETAILS:");
								if (text !== "") {
									executiveSummary = text; //.replace(/^\s+|\s+$/g, '');
								} else {
									executiveSummary = note.Text;
								}
							} else if (note.CaseId.startsWith("20")) {
								var text = "";
								if (sObjectType && (sObjectType === "ZSCUSTYP05" || sObjectType === "Critical Customer Management" || sObjectType ===
									"ZSCUSTYP04" || sObjectType === "Critical Period Coverage")) { //“MCC Critical Customer Management” with id “ZSCUSTYP05; “MCC Critical Period Coverage” with id “ZSCUSTYP04”
									text = this.getParsedNote(note.Text, "Status summary on overall situation:", "DELTA SINCE LAST REPORT:");
								} else if (sObjectType && (sObjectType === "ZSCUSTYP06" || sObjectType === "Top Critical Customers")) { //“Top Critical Customer” with id “ZSCUSTYP06”
									text = this.getParsedNote(note.Text, "Executive status summary on overall situation:", "DELTA SINCE LAST REPORT:");
								} else {
									text = this.getParsedNote(note.Text, "Executive Summary", "STATUS DETAILS");
								}
								if (text !== "") {
									executiveSummary = text; //.replace(/^\s+|\s+$/g, '');
								} else {
									executiveSummary = note.Text;
								}
							}
						}

						break;
					case "0005": // Management Summary
						var sTmp = [];
						if (!bEscalationReasonAlreadyExists) {
							bEscalationReasonAlreadyExists = true;
							if (note.CaseId.startsWith("100")) {
								var text = this.getParsedNote(note.Text, "Escalation reason & Customer business impact:",
									"DE-ESCALATION STRATEGY TO OVERCOME CRITICAL SITUATION:");
								if (text !== "") {
									escalationReason = text; //.replace(/^\s+|\s+$/g, '');
								} else {
									escalationReason = note.Text;
								}
								reasonTypeHeader = "Escalation Reason";
							} else if (note.CaseId.startsWith("20")) {
								var text = "";
								if (sObjectType && (sObjectType === "ZSCUSTYP05" || sObjectType === "Critical Customer Management" || sObjectType ===
									"ZSCUSTYP04" || sObjectType === "Critical Period Coverage")) { //“MCC Critical Customer Management” with id “ZSCUSTYP05; “MCC Critical Period Coverage” with id “ZSCUSTYP04”
									text = this.getParsedNote(note.Text, "Engagement reason:", "EXIT CRITERIA:");
								} else if (sObjectType && (sObjectType === "ZSCUSTYP06" || sObjectType === "Top Critical Customers")) { //“Top Critical Customer” with id “ZSCUSTYP06”
									text = this.getParsedNote(note.Text, "Engagement reason:", "SUCCESS/EXIT CRITERIA:");
								} else {
									text = this.getParsedNote(note.Text, "Engagement Reason & Business Impact", "INITIAL ACTION PLAN");
								}
								if (text !== "") {
									escalationReason = text; //.replace(/^\s+|\s+$/g, '');
								} else {
									escalationReason = note.Text;
								}
								reasonTypeHeader = "Engagement Reason";
							}
						}

						break;
				}

			}.bind(this));
			return { //remove also leading : and linebreak
				escalationReason: escalationReason.replace(/^(\:)/, ""), //..replace(/^\s+|\s+$/g, ""),
				executiveSummary: executiveSummary.replace(/^(\:)/, ""), //..replace(/^\s+|\s+$/g, ""),
				reasonTypeHeader: reasonTypeHeader
			};
		},

		_getNotesInformationBusinessDown: function (aNotes) {
			var zs16Txt = "";
			var zs17Txt = "";
			var zs18Txt = "";
			var zs16Header = "";
			var zs17Header = "";
			var zs18Header = "";
			aNotes.forEach(function (note) {
				switch (note.NoteType) {
					case "ZS16":
						zs16Txt = note.Text;
						zs16Header = note.NoteTypeT;
						break;
					case "ZS17":
						zs17Txt = note.Text;
						zs17Header = note.NoteTypeT;
						break;
					case "ZS18":
						zs18Txt = note.Text;
						zs18Header = note.NoteTypeT;
						break;
				}

			}.bind(this));
			return {
				zs16Txt: zs16Txt,
				zs17Txt: zs17Txt,
				zs18Txt: zs18Txt,
				zs16Header: zs16Header,
				zs17Header: zs17Header,
				zs18Header: zs18Header
			};
		},

		closeStatusReportDialog: function () {
			this.statusReportDialog.close();
		},

		_filter: function (oTable) {
			var oFilter = null;

			if (this._oGlobalFilter && this._oColumnFilter) {
				oFilter = new sap.ui.model.Filter([this._oGlobalFilter, this._oColumnFilter], true);
			} else if (this._oGlobalFilter) {
				oFilter = this._oGlobalFilter;
			} else if (this._oColumnFilter) {
				oFilter = this._oColumnFilter;
			}

			if (oTable.getBinding("rows")) {
				oTable.getBinding("rows").filter(oFilter, "Application");
			}

			//reset caseIds for PDF or XLS Export
			this.getModel("settings").setProperty("/caseIdsForExport", null);
			var oBinding = oTable.getBinding("rows"); //Get hold of binding aggregation "row"
			oBinding.aIndices.forEach(function (c) {
				//for PDF/XLS Generation we need to store the case IDs
				if (this.getModel("settings").getProperty("/caseIdsForExport") === null) {
					this.getModel("settings").setProperty("/caseIdsForExport", [oBinding.oList[c].CaseId]);
				} else {
					this.getModel("settings").getProperty("/caseIdsForExport").push(oBinding.oList[c].CaseId);
				}
			}.bind(this));

		},

		filterGlobally: function (oEvent) {
			var sQuery = oEvent.getParameter("query");
			var aFilter = [];
			this._oGlobalFilter = null;
			var oTable = oEvent.getSource().getParent().getParent();

			if (sQuery) {
				var oColumns = oEvent.getSource().getParent().getParent().getColumns(); //[0].getFilterProperty()
				oColumns.forEach(function (oColumn) {
					var oFilterType = oColumn.getFilterType();
					var sFilterType = oFilterType ? oFilterType.getName() : "";
					var sFilterProperty = oColumn.getFilterProperty();
					var sFilterOperator = oColumn.getFilterOperator();
					sFilterOperator = sFilterOperator || this._getFilterOperatorByFilterType(sFilterType);

					if (!sFilterProperty) {
						return;
					}

					// Remove any other characters of sFilterProperty to avoid ignoring names like "Market_Unit"
					var sNormalizedFilterProperty = sFilterProperty.toLowerCase().replace(/[^a-z0-9]/g, '');

					// In case of specific Region or Market Unit related check, only the relevant column should be checked
					if ((sQuery.toLowerCase().startsWith("region:") && !sFilterProperty.toLowerCase().includes("region")) ||
						(sQuery.toLowerCase().startsWith("marketunit:") && !sNormalizedFilterProperty.includes("marketunit"))) {
						return;
					}

					// Use th EQ-Operator for Market Unit to be able to search for "WEST" and not show "MIDWEST"
					if (sQuery.toLowerCase().startsWith("marketunit:")) {
						sFilterOperator = "EQ";
					}
					var oFilter = null;

					if (sQuery.split(",").length > 1) {
						oFilter = [];
						// Enable the filtering by several values
						sQuery.replace(/Region:|MarketUnit:/i, "").split(",").forEach(function (value, i) {
							oFilter = this._generateFilter(sFilterProperty, sFilterOperator, value.trim());
							if (oFilter) {
								aFilter.push(oFilter);
							}
						}, this);
					} else {
						oFilter = this._generateFilter(sFilterProperty, sFilterOperator, sQuery.replace(/Region:|MarketUnit:/i, "").trim());
						if (oFilter) {
							aFilter.push(oFilter);
						}
					}
				}, this);
				this._oGlobalFilter = new Filter(aFilter, false);
			}

			this._filter(oTable);
		},

		_generateFilter: function (sFilterProperty, sFilterOperator, sQuery) {

			function daysInMonth(month, year) {
				return new Date(year, month, 0).getDate();
			}

			switch (sFilterProperty) {
				case "CreatedAt":
				case "MptPlannedEnd":
				case "ChangedAt":
				case "CreateDate":
				case "CreationDate":
				case "CreatedOn":

					var separators = ['.', '-', '\\/'];
					var aParts = sQuery.split(new RegExp('[' + separators.join('') + ']', 'g'));

					var d1 = 1,
						d2,
						m1 = 0,
						m2 = 11,
						y;

					if (aParts.length === 1 && aParts[0].length === 4) {
						y = aParts[0];
						d2 = daysInMonth(m1 + 1, y);
					} else if (aParts.length === 2 && aParts[1].length === 4) {
						y = aParts[1];
						m1 = aParts[0] - 1;
						m2 = m1;
						d2 = daysInMonth(m1 + 1, y);
					} else if (aParts.length === 3 && aParts[2].length === 4) {
						y = aParts[2];
						m1 = aParts[1] - 1;
						m2 = m1;
						d1 = aParts[0];
						d2 = d1;
					} else {
						return null;
					}

					var dateA = new Date(Date.UTC(y, m1, d1, 0, 0, 0, 0));
					var dateB = new Date(Date.UTC(y, m2, d2, 23, 59, 59, 999));

					if (dateA !== "Invalid Date" && dateB !== "Invalid Date") {
						return new Filter(sFilterProperty, sFilterOperator, dateA, dateB);
					}
					break;

				default:
					return new Filter(sFilterProperty, sFilterOperator, sQuery);
			}
			return null;

		},

		_getFilterOperatorByFilterType: function (sFilterType) {
			switch (sFilterType.split(".").pop()) {
				case "String":
					return "Contains";
				case "Date":
				case "DateTime":
					return "BT";
				case "Integer":
					return "EQ";
				default:
					return "Contains";
			}
		},

		_aColumnFilter: [],

		_addColumnFilter: function (oFilter) {
			this._removeColumnFilter(oFilter.sPath);
			this._aColumnFilter.push(oFilter);
			this._oColumnFilter = new Filter(this._aColumnFilter, true);
		},

		_removeColumnFilter: function (sFilterProperty) {
			this._aColumnFilter.forEach(function (oColumnFilter, index, object) {
				if (oColumnFilter.sPath === sFilterProperty) {
					this._aColumnFilter.splice(index, 1);
					return;
				}
			}, this);
		},

		_clearColumnFilter: function () {
			this._aColumnFilter = [];
			this._oColumnFilter = null;
		},

		filterColumns: function (oEvent) {
			var oTable = oEvent.getSource();
			var oColumn = oEvent.getParameter("column");
			var sFilterValue = oEvent.getParameter("value");
			var oFilterType = oColumn.getFilterType();
			var sFilterType = oFilterType ? oFilterType.getName() : "";
			var sFilterProperty = oColumn.getFilterProperty();
			var sFilterOperator = oColumn.getFilterOperator();
			sFilterOperator = sFilterOperator || this._getFilterOperatorByFilterType(sFilterType);

			//?
			oEvent.preventDefault();

			function clear() {
				this._removeColumnFilter(sFilterProperty);
				oColumn.setFiltered(false);
				this._filter(oTable);
			}

			if (!sFilterValue) {
				clear.apply(this);
				return;
			}

			var oFilter = this._generateFilter(sFilterProperty, sFilterOperator, sFilterValue);
			if (oFilter) {
				this._addColumnFilter(oFilter);
				oColumn.setFiltered(true);
			}

			this._filter(oTable);

		},

		clearAllFilters: function (oEvent) {
			var oTable = oEvent.getSource().getParent().getParent();
			var aColumns = oTable.getColumns();
			oTable.getBinding().aSorters = null;

			//reset filter value for each column 

			for (var i = 0; i < aColumns.length; i++) {
				oTable.filter(aColumns[i], null);
				if (aColumns[i].getSorted()) {
					aColumns[i].setSorted(false);
				}
				aColumns[i].setFilterValue("");
				aColumns[i].setFiltered(false);
			}
			this._oGlobalFilter = null;
			this._oColumnFilter = null;
			this._filter(oTable);
			this.clearSearchField(oTable);
			this.resetIconTabFilter(oTable);

		},

		resetIconTabFilter: function (oTable) {
			var oIconTabBar = null;
			var oContainer = oTable.getParent();
			while (oContainer) {
				if (oContainer.isA("sap.m.IconTabBar")) {
					oIconTabBar = oContainer;
					break;
				}
				oContainer = oContainer.getParent();
			}
			if (oIconTabBar) {
				var sSelectedKey = oIconTabBar.getSelectedKey();
				if (sSelectedKey !== "All") {
					oIconTabBar.setSelectedKey("All");
					oIconTabBar.fireSelect({
						key: "All"
					});
				}
			}
		},

		//Sets the Value of the global Searchbar to null, fires search event to refresh the table
		clearSearchField: function (oTable) {
			var oControl = this.getSearchField(oTable);
			if (oControl !== null) {
				oControl.setValue("");
				oControl.fireSearch();
			}
			return;
		},

		getSearchField: function (oTable) {
			var aExtensions = oTable.getExtension();
			for (var i = 0; i < aExtensions.length; i++) {
				var oExtension = aExtensions[i];
				if (oExtension.isA("sap.m.Toolbar")) {
					var aToolbarContent = oExtension.getContent();
					for (var j = 0; j < aToolbarContent.length; j++) {
						var oControl = aToolbarContent[j];
						if (oControl.isA("sap.m.SearchField")) {
							return oControl;
						}
					}
				}
			}
		},

		onOpenHelpPopover: function (oEvent) {
			if (this.getView().byId("helpPopoverButton")) {
				this._oHelpBtn = this.getView().byId("helpPopoverButton");
			} else {
				this._oHelpBtn = this.getView().byId("helpPopoverButtonMobile");
			}
			if (!this._oAvatarPopover) {
				Fragment.load({
					name: "com.sap.mcconedashboard.view.fragment.HelpPopover",
					controller: this
				}).then(function (pAvatarPopover) {
					this._oAvatarPopover = pAvatarPopover;
					this.getView().addDependent(this._oAvatarPopover);
					this._oAvatarPopover.openBy(this._oHelpBtn);
				}.bind(this));
			} else {
				this._oAvatarPopover.openBy(this._oHelpBtn);
			}
		},

		onOpenInternalPopover: function (oEvent) {

			// Get the button instance
			var oButton = oEvent.getSource();
			// Get the tooltip text
			var sTooltipText = oButton.getTooltip();

			// Display the tooltip as a MessageToast
			MessageToast.show(sTooltipText, {
				duration: 3000,
				my: "center top",
				at: "center top",
				of: oButton,
				collision: "fit fit",
			});

		},

		_openWindow: function (url) {
			var newWindow = window.open();
			newWindow.opener = null;
			newWindow.location = url;
		},
		/* eslint-disable  sap-no-hardcoded-url  */
		//MCC One Dashboard User Guide
		onOpenUserGuide: function (oEvent) {
			//this._openWindow("https://workzone.one.int.sap/site#workzone-home&/wiki/show/csa7CQlCTLGH3pNmvyzYMY?_lightbox=true");
			this._openWindow("https://sap.sharepoint.com/sites/202065/SitePages/MCC-ONE-Dashboard-User-Guide.aspx");
		},
		//Documentation
		onOpenDocumentation: function (oEvent) {
			//this._openWindow("https://workzone.one.int.sap/site#workzone-home&/wiki/show/XHr8waqv0ZIe6Gfk0OO5Mx");
			this._openWindow("https://sap.sharepoint.com/sites/202065/SitePages/MCC-ONE-Dashboard.aspx");
		},

		onOpenTicketingApp: function (oEvent) {
			this._openWindow(
				"https://itsupportportal.services.sap/itsupport?id=itsm_sc_cat_item&sys_id=b1982b441bb1c1105039a6c8bb4bcbc3&sysparm_variables=%7B%22business_service%22:%2221af9c6f1ba564905039a6c8bb4bcb61%22,%22service_offering%22:%2210c283dd1b8e259036ac10e69b4bcb28%22,%22assignment_group%22:%22e5818b511b8e259036ac10e69b4bcbd4%22,%22short_description%22:%22Issue%20with%20MCC%20One%20Dashboard%22,%22description%22:%22Issue%20Description%20and%20steps%20to%20reproduce%20this%20issue%22%7D"

				//before 12.2022	
				//"https://fiorilaunchpad.sap.com/sites#Help-Inbox&/create/ZINE/IMAS_SUD_MC/Issue%20with%20'MCC%20One%20Dashboard'/2//ICP/Issue%20Description%20and%20steps%20to%20reproduce%20this%20issue//////01/01/////Business%20Applications%20(HR%2C%20Billing%2C%20Sales%2C%20Controlling%2C...)"

				//before 05.2023
				//"https://fiorilaunchpad.sap.com/sites#Help-Inbox&/create/ZINE/IMFIT_DBS_MCC/Issue%20with%20'MCC%20One%20Dashboard'/2//ICP/Issue%20Description%20and%20steps%20to%20reproduce%20this%20issue//////01/01/////Federated%20IT%20(Presales%2C%20DBS%2C%20Education%20%26%20Training%2C...)"
			);
		},

		onOpenCreateAnIdea: function () {
			this._openWindow("https://im.enter.sap/sap/ino/#/idea-create?campaign=340");
		},

		onOpenMCCToolsSharePoint: function (oEvent) {
			//this._openWindow("https://workzone.one.int.sap/site#workzone-home&/groups/5LnWdLXIx1B6iNVAa24kiC/overview_page/gfzAsARcdTtVuM5bREq8xD");
			this._openWindow("https://sap.sharepoint.com/sites/202065/SitePages/MCC-Tool-Suite.aspx");
		},
		/* eslint-enable  sap-no-hardcoded-url  */
		trackEvent: function (eventName) {
			//Method to track events in the SAP IT Mobile Usage reporting
			//sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), eventName);
			UsageTracking.trackEvent(eventName, this.getOwnerComponent());
		},

		_getCombinedSolutionFilterCims: function (aFacetFilter, aProductLinesSolution, prodLineVariable) {
			var aFinalFilter = [];
			var aProductLines = [];
			var aSolutionFilter = [];
			var aCombinedFilter = [];
			//first get all product lines from facet filter
			if (aFacetFilter) {
				aFacetFilter.forEach(function (filter) {
					var aTmp = filter.split("^OR");
					if (aTmp && aTmp.length > 0 && aTmp[0].split("=")[0] === prodLineVariable) {
						aTmp.forEach(function (prodLine) {
							aProductLines.push(prodLine.split("=")[1]);
						});
					}
				});
			}

			if (aProductLines && aProductLines.length > 0) {

				if (aProductLinesSolution.length > 0) {
					aProductLinesSolution.forEach(function (solProdLine) {
						if (aProductLines.indexOf(solProdLine) > -1) {
							aSolutionFilter.push(prodLineVariable + "=" + solProdLine);
						}
					});
				} else {
					aProductLines.forEach(function (pl) {
						aSolutionFilter.push(prodLineVariable + "=" + pl);
					});
				}

				if (aSolutionFilter.length === 0) {
					aCombinedFilter.push(prodLineVariable + "=" + "99999999999999999999");
				} else {
					var sTmp = "";
					var iLength = aSolutionFilter.length;
					aSolutionFilter.forEach(function (item, idx) {
						sTmp += item;
						if ((idx + 1) < iLength) {
							sTmp += "^OR";
						}
					});
					aCombinedFilter.push(sTmp);
				}

				//also add other facet filter items
				if (aFacetFilter) {
					aFacetFilter.forEach(function (filter) {
						var aTmp = filter.split("^OR");
						if (aTmp && aTmp.length > 0 && aTmp[0].split("=")[0] !== prodLineVariable) {
							aCombinedFilter.push(filter);
						}
					});
				}
				aFinalFilter = aCombinedFilter;
			} else {

				if (aFacetFilter) {
					aFacetFilter.forEach(function (filter) {
						aFinalFilter.push(filter);
					});
				}

				if (aProductLinesSolution.length > 0) {
					var sTmp = "";
					var iLength = aProductLinesSolution.length;
					aProductLinesSolution.forEach(function (item, idx) {
						sTmp += prodLineVariable + "=" + item;
						if ((idx + 1) < iLength) {
							sTmp += "^OR";
						}
					});
					if (!aFinalFilter) {
						aFinalFilter = [];
					}
					aFinalFilter.push(sTmp);
				}
			}

			return aFinalFilter;
		},

		_getCombinedSolutionFilter: function (oFacetFilter, aProductLinesSolution, prodLineVariable) {
			var aFilters = [];
			var aFinalFilter = [];
			var aProductLines = [];

			if (oFacetFilter) {
				aFilters = aFilters.concat(oFacetFilter.aFilters);
				aProductLines = [];
				if (oFacetFilter.aFilters && oFacetFilter.aFilters.length) {
					oFacetFilter.aFilters.forEach(function (filter, idx) {
						filter.aFilters.forEach(function (val) {
							if (val.sPath === prodLineVariable) {
								aProductLines.push(val.oValue1);
							}
						});
					});
				}
			}

			if (aProductLines && aProductLines.length > 0) {
				var aCombinedFilter = [];
				var aSolutionFilter = [];

				if (aProductLinesSolution.length > 0) {
					aProductLinesSolution.forEach(function (solProdLine) {
						if (aProductLines.indexOf(solProdLine) > -1) {
							aSolutionFilter.push(new sap.ui.model.Filter(prodLineVariable, sap.ui.model.FilterOperator.EQ, solProdLine));
						}
					});
				} else {
					aProductLines.forEach(function (pl) {
						aSolutionFilter.push(new sap.ui.model.Filter(prodLineVariable, sap.ui.model.FilterOperator.EQ, pl));
					});
				}

				if (aSolutionFilter.length === 0) {
					aCombinedFilter.push(new sap.ui.model.Filter(prodLineVariable, sap.ui.model.FilterOperator.EQ, "99999999999999999999"));
				} else {
					aCombinedFilter.push(new sap.ui.model.Filter({
						filters: aSolutionFilter,
						and: false
					}));
				}
				//also add other facet filter items
				if (aFilters.length > 0) {
					oFacetFilter.aFilters.forEach(function (filter, idx) {
						var bIsProductLine = false;
						filter.aFilters.forEach(function (val) {
							if (val.sPath === prodLineVariable) {
								aProductLines.push(val.oValue1);
								bIsProductLine = true;
							}
						});
						if (!bIsProductLine) {
							aCombinedFilter.push(filter);
						}
					});
				}

				// if (sRegion) {
				// 	var aRegionFilter = [];
				// 	sRegion.split(",").forEach(function (region) {
				// 		aRegionFilter.push(new sap.ui.model.Filter(regionVariable, sap.ui.model.FilterOperator.EQ, region));
				// 	});
				// 	aCombinedFilter.push(new sap.ui.model.Filter(aRegionFilter, false));
				// }

				aFinalFilter.push(new sap.ui.model.Filter({
					filters: aCombinedFilter,
					and: true
				}));

			} else {
				if (aProductLinesSolution.length > 0) {
					var aProdLinesFilter = [];
					aProductLinesSolution.forEach(function (pl) {
						aProdLinesFilter.push(new sap.ui.model.Filter(prodLineVariable, sap.ui.model.FilterOperator.EQ, pl));
					});
					aFinalFilter.push(new sap.ui.model.Filter({
						filters: aProdLinesFilter,
						and: false
					}));
				}

				// if (sRegion) {
				// 	var aRegionFilter = [];
				// 	sRegion.split(",").forEach(function (region) {
				// 		aRegionFilter.push(new sap.ui.model.Filter(regionVariable, sap.ui.model.FilterOperator.EQ, region));
				// 	});
				// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
				// }

				if (aFilters.length > 0) {
					aFinalFilter.push(new sap.ui.model.Filter(aFilters, true));
				}
			}

			return aFinalFilter;
		},

		////////////////////////
		////////////////////////
		//MCS Dashboard integration
		////////////////////////
		////////////////////////

		handleFacetFilterResetBase: function (oEvent) {
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.setProperty("/oFilterModelICP", null);
			oFilterModel.setProperty("/oFilterModelICPWOTAGS", null);
			oFilterModel.setProperty("/oFilterModelICPGER", null);
			oFilterModel.setProperty("/oFilterModelBCP", null);
			oFilterModel.setProperty("/oFilterModelMCS", null);
			//oFilterModel.setProperty("/oFilterModelBD", null);
			oFilterModel.setProperty("/oFilterForServiceNow", null);
			oFilterModel.setProperty("/oFilterForMissionRadarCC", null);
			oFilterModel.setProperty("/oFilterForMissionRadarGoLives", null);
			oFilterModel.setProperty("/oFilterForOutages", null);
			oFilterModel.setProperty("/oFilterForBWCosts", []);

			//reset also the region
			oFilterModel.setProperty("/region", "");
			oFilterModel.setProperty("/regionText", "");

			var oFacetFilter = sap.ui.getCore().byId(oEvent.getParameter("id"));
			var aFacetFilterLists = oFacetFilter.getLists();
			for (var i = 0; i < aFacetFilterLists.length; i++) {
				if (aFacetFilterLists[i].getTitle() === "Region") {
					aFacetFilterLists[i].setSelectedKeys(JSON.parse('{"WORLD":"World"}'));
				} else {
					aFacetFilterLists[i].setSelectedKeys();
				}
			}
			this.oFilterComponent.setFaceFilterSelection(oFacetFilter);
		},

		onDownload: function (sDownloadFunctionName, sMimeType) {
			this.sDownloadFunctionName = sDownloadFunctionName;
			if (sMimeType) {
				this.sDownloadMimeType = sMimeType;
			}
			this.dialog = sap.ui.xmlfragment(this.getView().getId(),
				"com.sap.mcconedashboard.view.fragment.mcs.ConfidentialDialog", this);
			this.getView().addDependent(this.dialog);
			this.dialog.open();
		},

		onCancel: function (oEvent) {
			oEvent.getSource().getParent().close();
			oEvent.getSource().getParent().destroy();
		},


		onDownloadConfirmed: function (oController) {
			if (oController.sDownloadFunctionName === 'onPressXLS') { //Master View
				this.onPressXLS();
			} else if (oController.sDownloadFunctionName === 'onPressAdobe') { //Master View
				this.onPressAdobe();
				//not needed anymore	} else if (oController.sDownloadFunctionName === 'onPressPPT') { //Detail View
				//		this.onPressPPT();
			} else if (oController.sDownloadFunctionName === 'onPressGenerateMIME') { //Report Downlad Case LIst
				this.reportDownloadHandler.onPressGenerateMIME(this, this.sDownloadMimeType);
			} else if (oController.sDownloadFunctionName === 'onPressXLSHighPrio') {
				this.onExportToExcel();
			}
			this.dialog.close();
			this.dialog.destroy();
		},

		onExportToExcel: function () {
			var aCols, oBinding, oSettings, oSheet, oTable;
			oTable = this.getView().byId("customerOverviewTableHighPrioTickets");
			oBinding = oTable.getBinding('rows');

			if (oBinding && oBinding.getLength() > 0) {

				var customerName = oBinding.oList[0]["account.name"];

				aCols = this.createColumnConfig();

				oSettings = {
					workbook: {
						columns: aCols,
						context: {
							application: "MCC One Dashboard",
							title: "Customer Tickets Export for " + customerName,
							modifiedBy: "MCC One Dashboard, SAP",
							sheetName: "Customer Ticket Export"
						}
					},
					dataSource: oBinding,
					fileName: "Customer Tickets for " + customerName + ".xlsx"
				};

				oSheet = new Spreadsheet(oSettings);
				oSheet.build()
					.then(function () {
						MessageToast.show('Spreadsheet export has finished');
					}).finally(function () {
						oSheet.destroy();
					});
			} else {
				MessageToast.show("There is no entries to export");
			}

		},

		createColumnConfig: function () {
			return [
				{
					label: 'Object ID',
					property: 'number',
					type: EdmType.Integer,
					width: 20
				},
				{
					label: 'ServiceNow Correlation Id',
					property: 'correlation_id',
					type: EdmType.Integer,
					width: 24
				},
				{
					label: 'Description',
					property: 'short_description',
					width: 34,
					wrap: true
				},
				{
					label: 'Component',
					property: 'u_app_component.u_name',
					width: 20
				},
				{
					label: 'Priority',
					property: 'priority',
					width: 20
				},
				{
					label: 'Status',
					property: 'state',
					width: 20
				},
				{
					label: 'Action Status',
					property: 'action_status',
					width: 20
				},
				{
					label: 'Escalation Status',
					property: 'active_escalation.stateT',
					width: 20
				},
				{
					label: 'Approval Status',
					property: 'active_escalation.approval',
					width: 20
				},
				{
					label: 'Case Processing Org',
					property: 'assignment_group.name',
					width: 20
				},
				{
					label: 'Region',
					property: 'account.u_region',
					width: 20
				},
				{
					label: 'Created On',
					property: "opened_at",
					width: 20
				},
				{
					label: 'Changed On',
					property: "u_last_user_updated_on",
					width: 20
				},
				{
					label: 'Next Action Due',
					property: "u_next_action_due",
					width: 20
				},
				{
					label: 'Product Version',
					property: 'u_install_base_item.u_product_version.display_name',
					width: 32,
					wrap: true
				},
				{
					label: 'Product',
					property: 'u_install_base_item.u_product.display_name',
					width: 32,
					wrap: true
				},
				{
					label: 'Product Line',
					property: 'u_install_base_item.u_product.u_product_line_id.u_product_line_name',
					width: 32,
					wrap: true
				},
				{
					label: 'Product Category',
					property: 'u_install_base_item.u_product.u_product_line_id.u_product_category_name',
					width: 32,
					wrap: true
				},
			];
		},


		onPressAdobe: function () {
			this.trackEvent("Export:PDF");
			this.reportDownloadHandler.resetMimeFilterModel(this);
			this.getModel("extReportFilters").setProperty("/id", this.getModel("settings").getProperty("/caseIdsForExport"));
			this.reportDownloadHandler.onPressGenerateMIME(this, "PDF");
		},

		/*VARIANT MANAGEMENT EVENTS*/
		onSelectVariant: function (event) {
			this.oFilterComponent.onSelectVariant(event);
			this.trackEvent("Variant Management: Select");
		},

		onSaveVariant: function (event) {
			this.oFilterComponent.onSaveVariant(event);
			this.trackEvent("Variant Management: Save");
		},
		onManageVariant: function (event) {
			this.oFilterComponent.onManageVariant(event);

		},
		pad: function (n, length) {
			n += "";
			return n.length >= length ? n : new Array(length - n.length + 1).join("0") + n;
		},

		_openSosApp: function (id, urlParams, isActivity) {
			if (urlParams.includes("case")) {
				this._openServiceNowTicketURL(id);
				return
			}
			if (urlParams.includes("escalation")) {
				this._openServiceNowEscalationURL(id, "sn_customerservice_escalation");
				return
			}
			var currentUrl = window.location.href,
				url = "";
			if (sap.ushell) {
				//NEW URL from 01.06.2021 //https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites#mccsos-Display&/requestDetails/TwoColumnsMidExpanded/id=f2892a9b1b2cec90e6eca9babb4bcb99&transType=sn_customerservice_escalation
				/*this.oCrossAppNav = sap.ushell.Container.getServiceAsync("CrossApplicationNavigation");
				this.oCrossAppNav.toExternal({
					target: {
						shellHash: "#mccsos-Display&/requestDetail/id=" + id + "&transType=sn_customerservice_escalation"
					}
				});*/
				if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") || currentUrl.includes("port5000-workspaces")) {
					//we are in DEV environment
					//url = "https://flpsandbox-br339jmc4c.dispatcher.int.sap.eu2.hana.ondemand.com/sites/#mccsos-Display&";
					url = "https://sapit-customersupport-dev-mallard.launchpad.cfapps.eu10.hana.ondemand.com/site#mccsos-Display&";
				} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
					//we are in TEST environment
					//url = "https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites#mccsos-Display&";
					url = "https://sapit-home-test-004.launchpad.cfapps.eu10.hana.ondemand.com/site#mccsos-Display&";
				} else {
					//we are in PROD environment
					//url = "https://fiorilaunchpad.sap.com/sites#mccsos-Display&";
					url = "https://sapit-home-prod-004.launchpad.cfapps.eu10.hana.ondemand.com/site#mccsos-Display&";
				}

			} else {
				if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") || currentUrl.includes("port5000-workspaces")) {
					//we are in DEV environment
					//url = "https://mccsos-br339jmc4c.dispatcher.int.sap.eu2.hana.ondemand.com/#";
					url = "https://sapit-customersupport-dev-mallard.launchpad.cfapps.eu10.hana.ondemand.com/site#mccsos-Display&";
				} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
					//we are in TEST environment
					//url = "https://mccsos-sapitcloudt.dispatcher.hana.ondemand.com/#";
					url = "https://sapit-home-test-004.launchpad.cfapps.eu10.hana.ondemand.com/site#mccsos-Display&";
				} else {
					//we are in PROD environment
					//url = "https://mccsos-sapitcloud.dispatcher.hana.ondemand.com/#";
					url = "https://sapit-home-prod-004.launchpad.cfapps.eu10.hana.ondemand.com/site#mccsos-Display&";
				}
			}

			//NEW URL from 01.06.2021 /requestDetails/TwoColumnsMidExpanded/id=f2892a9b1b2cec90e6eca9babb4bcb99&transType=sn_customerservice_escalation
			//OLD url += "/requestDetail/id=" + id + urlParams;
			if (isActivity) {
				url += "/mccDetailRequest/TwoColumnsMidExpanded/activity_id=" + id;
			} else {
				if (id.startsWith("CS")) {
					url += "/incidentEnd/EndColumnFullScreen/id=" + id + urlParams;
				} else {
					url += "/requestDetails/TwoColumnsMidExpanded/id=" + id + urlParams;
				}
			}

			var win = window.open(url, "_blank");
			win.opener = null;

		},

		_openServiceNowEscalationURL: function (sID) {
			var currentUrl = window.location.href,
				url = "";
			if (sID !== "" && (sID.startsWith("CS") || sID.startsWith("ESC") || sID.startsWith("INC"))) {
				//We need the redirect since we do not have the NOW GUID
				if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") || currentUrl.includes("eu10.applicationstudio")) {
					//we are in dev envrionment
					//url = "https://dev.itsm.services.sap/now/cwf/agent/record/sn_customerservice_escalation/" + sID;
					url = "https://dev.itsm.services.sap/number_redirect.do?sysparm_number=" + sID;
				} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
					//we are in test envrionment
					//url = "https://test.itsm.services.sap/now/cwf/agent/record/sn_customerservice_escalation/" + sID;
					url = "https://test.itsm.services.sap/number_redirect.do?sysparm_number=" + sID;
				} else {
					//url = "https://itsm.services.sap/now/cwf/agent/record/sn_customerservice_escalation/" + sID;
					url = "https://itsm.services.sap/number_redirect.do?sysparm_number=" + sID;
				}
				var win = window.open(url, "_blank");
				win.opener = null;
			} else if (sID !== "") {
				//We got the NOW GUID, use normal method
				if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") || currentUrl.includes("eu10.applicationstudio")) {
					//we are in dev envrionment
					url = "https://dev.itsm.services.sap/now/cwf/agent/record/sn_customerservice_escalation/" + sID;
				} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
					//we are in test envrionment
					url = "https://test.itsm.services.sap/now/cwf/agent/record/sn_customerservice_escalation/" + sID;
				} else {
					url = "https://itsm.services.sap/now/cwf/agent/record/sn_customerservice_escalation/" + sID;
				}
				var win = window.open(url, "_blank");
				win.opener = null;
			}
		},

		_openServiceNowTicketURL: function (sID) {
			var currentUrl = window.location.href,
				url = "";
			if (sID !== "" && (sID.startsWith("CS") || sID.startsWith("ESC") || sID.startsWith("INC"))) {
				if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") || currentUrl.includes("eu10.applicationstudio")) {
					//we are in dev envrionment
					//url = "https://dev.itsm.services.sap/now/cwf/agent/record/sn_customerservice_case/" + sID;
					url = "https://dev.itsm.services.sap/number_redirect.do?sysparm_number=" + sID;

				} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
					//we are in test envrionment
					//url = "https://test.itsm.services.sap/now/cwf/agent/record/sn_customerservice_case/" + sID;
					url = "https://test.itsm.services.sap/number_redirect.do?sysparm_number=" + sID;
				} else {
					//url = "https://itsm.services.sap/now/cwf/agent/record/sn_customerservice_case/" + sID;
					url = "https://itsm.services.sap/number_redirect.do?sysparm_number=" + sID;

				}
				var win = window.open(url, "_blank");
				win.opener = null;
			} else if (sID !== "") {
				//We got the NOW GUID, use normal method
				if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") || currentUrl.includes("eu10.applicationstudio")) {
					//we are in dev envrionment
					url = "https://dev.itsm.services.sap/now/cwf/agent/record/sn_customerservice_case/" + sID;
				} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
					//we are in test envrionment
					url = "https://test.itsm.services.sap/now/cwf/agent/record/sn_customerservice_case/" + sID;
				} else {
					url = "https://itsm.services.sap/now/cwf/agent/record/sn_customerservice_case/" + sID;
				}
				var win = window.open(url, "_blank");
				win.opener = null;
			}
		},

		getTaskForcesDescription: function (description) {
			var sResult = "";
			description.split(" ").forEach(function (str) {
				if (Constants.upperKeyWords.indexOf(str) === -1) {
					str = str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
				}
				if (sResult === "") {
					sResult += str;
				} else {
					sResult += " " + str;
				}
			});
			return sResult;
		},
		customSortingBase: function (oCurrentColumn, sOrder, oGUMaintenanceRankingColumn, sTableId) {

			// reset the sorting status of all columns which are not sorted anymore
			var aColumns = this.byId(sTableId).getColumns();
			for (var i = 0, l = aColumns.length; i < l; i++) {
				if (oCurrentColumn !== aColumns[i]) {
					// column is not sorted anymore -> reset default and remove sorter
					aColumns[i].setSorted(false);
				}
			}
			oGUMaintenanceRankingColumn.setSorted(true);
			oGUMaintenanceRankingColumn.setSortOrder(sOrder);
			var oIntegerFormat = sap.ui.core.format.NumberFormat.getIntegerInstance();

			var oSorter = new sap.ui.model.Sorter(oGUMaintenanceRankingColumn.getSortProperty(), sOrder === sap.ui.table.SortOrder.Descending);
			//The date data in the JSON model is string based. For a proper sorting the compare function needs to be customized.
			oSorter.fnCompare = function (a, b) {
				if (b === null || b === undefined || b === "") {
					if (sOrder === sap.ui.table.SortOrder.Descending) {
						return 1;
					} else {
						return -1;
					}
				}
				if (a === null || a === undefined || a === "") {
					if (sOrder === sap.ui.table.SortOrder.Descending) {
						return -1;
					} else {
						return 1;
					}
				}

				var aa = oIntegerFormat.parse(a);
				var bb = oIntegerFormat.parse(b);

				if (aa < bb) {
					return -1;
				}
				if (aa > bb) {
					return 1;
				}
				return 0;
			};

			this.byId(sTableId).getBinding().sort(oSorter);
		},
		customSortingBaseFloat: function (oCurrentColumn, sOrder, sTableId) {

			// reset the sorting status of all columns which are not sorted anymore
			var aColumns = this.byId(sTableId).getColumns();
			for (var i = 0, l = aColumns.length; i < l; i++) {
				if (oCurrentColumn !== aColumns[i]) {
					// column is not sorted anymore -> reset default and remove sorter
					aColumns[i].setSorted(false);
				}
			}

			oCurrentColumn.setSorted(true);
			oCurrentColumn.setSortOrder(sOrder);
			var oSorter = new sap.ui.model.Sorter(oCurrentColumn.getSortProperty(), sOrder === sap.ui.table.SortOrder.Descending);
			//The date data in the JSON model is string based. For a proper sorting the compare function needs to be customized.
			oSorter.fnCompare = function (a, b) {
				if (b === null || b === undefined || b === "") {
					if (sOrder === sap.ui.table.SortOrder.Descending) {
						return 1;
					} else {
						return -1;
					}
				}
				if (a === null || a === undefined || a === "") {
					if (sOrder === sap.ui.table.SortOrder.Descending) {
						return -1;
					} else {
						return 1;
					}
				}

				var aa = parseFloat(a);
				var bb = parseFloat(b);

				if (aa < bb) {
					return -1;
				}
				if (aa > bb) {
					return 1;
				}
				return 0;
			};

			this.byId(sTableId).getBinding().sort(oSorter);
		},

		joinObj: function (a, attr) {
			var out = [];
			for (var i = 0; i < a.length; i++) {
				if (a[i][attr] !== "") {
					out.push(a[i][attr]);
				}
			}
			return out.join(", ");
		},

		onPressXLS: function () {
			// Abfrage bez. Red Escalations rausnehmen - ist nur zum Testen, da keine Kostentestdaten auf DEV 
			//|| this.getOwnerComponent().getModel("settings").getProperty("/tile_identifier") === "redEscalations"
			//in case of Top ten High Costs we need to retrieve the main case data from ICP in JSON format, enrich it with cost data and then generate the XLS 
			if (this.getOwnerComponent().getModel("data").getProperty("/executiveGEMCaseState") === "topTenHighCost") { // "topHighCosts") {
				this.trackEvent("Export/MasterCosts:XLS");
				//in case of Top Ten High Costs
				var aCols, aCasesForExport, aBWCasesForExportTemp, aCRMCasesForExportTemp, oSettings, oSheet, filteredCaseList;
				aCasesForExport = [];
				filteredCaseList = this.getModel("settings").getProperty("/caseIdsForExport");
				//get the data from ICP in JSON format
				var oFinalJsonModelPromise = this.readCasesFromICPinJSONforCostBasedXLSGeneration(filteredCaseList);
				var that = this;
				var oBusyDialog = null;
				if (!oBusyDialog) {
					oBusyDialog = new sap.m.BusyDialog({
						title: this.getResourceBundle().getText("busyDialogTitle"),
						text: this.getResourceBundle().getText("busyDialogText")
					});
					this.getView().addDependent(oBusyDialog);
				}
				// open dialog
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oBusyDialog);
				oBusyDialog.open();

				oFinalJsonModelPromise.then(function (result) {
					oBusyDialog.close();
					aCols = that.createXLSColumnConfig();
					aBWCasesForExportTemp = [];
					//that.getView().byId("tabInc").getBinding("rows").getModel().getData().GlobalEscalationsSet; 
					//that.getView().byId("tabInc").getBinding("rows").getModel("globalEscalations").getData().cases;
					var oBinding = that.getView().byId("tabInc").getBinding("rows"); //Get hold of binding aggregation "row"
					oBinding.aIndices.forEach(function (c) {
						aBWCasesForExportTemp.push(oBinding.oList[c]);
					});
					aCRMCasesForExportTemp = result.getData().cases;
					//add some confidential cost related info to the XLS Export file
					//therefore we need a counter, beause we want to show it in the first three lines
					var iTextCounter = 0;
					var iTopIssueCounter = 0,
						aActionItemTopIssueCounter = {},
						iCheckpointsCounter = 0,
						iMilestonesCounter = 0;
					if (aCRMCasesForExportTemp) {
						aCRMCasesForExportTemp.forEach(function (item) {
							if (filteredCaseList.includes(item.CaseID)) {
								if (iTextCounter < 12) {
									item.CONFIDENTIAL = that._getConfidentialTexts(iTextCounter);
									// for (var i = 0; i < aBWCasesForExportTemp.length; i++) {
									// 	// look for the entry with a matching `code` value
									// 	if (aBWCasesForExportTemp[i].case_id == item.CaseID) {
									// 		//KOSTEN Matchen
									// 		item.FORECAST = aBWCasesForExportTemp[i].customer_bp_id;
									// 	}
									// }
									iTextCounter++;
								}
								//loop through TopIssue, Milestones and Checkpoints
								//and add also the needed Cost information
								for (var k = 0; k < aBWCasesForExportTemp.length; k++) {
									// look for the entry with a matching `code` value
									if (aBWCasesForExportTemp[k].CaseId === item.CaseID) {
										//KOSTEN Matchen
										item.forecastCost = aBWCasesForExportTemp[k].TotalForecastCost;
										item.actualCost = aBWCasesForExportTemp[k].TotalActualCost;
										item.ToExt.results.forEach(function (itemL2) {
											//for (var j = 0; j < item.ToExt.length; j++) {
											if (itemL2.FieldID.indexOf("TOP_ISSUE_") >= 0) {
												if (iTopIssueCounter < itemL2.FieldID.substring(itemL2.FieldID.indexOf("E_") + 2)) {
													iTopIssueCounter++;
													aActionItemTopIssueCounter[iTopIssueCounter] = 0;
												}
												item[itemL2.FieldID] = itemL2.Data;
											}
											if (itemL2.FieldID.indexOf("ACTION_ITEM_") >= 0) {
												if (aActionItemTopIssueCounter[itemL2.FieldID.substring(itemL2.FieldID.indexOf("M_") + 2, itemL2.FieldID.indexOf(
													"M_") + 3)] < itemL2.FieldID.substring(itemL2.FieldID.indexOf("M_") + 3, itemL2.FieldID.indexOf("M_") + 4)) {
													aActionItemTopIssueCounter[itemL2.FieldID.substring(itemL2.FieldID.indexOf("M_") + 2, itemL2.FieldID.indexOf("M_") +
														3)]++;
												}
												item[itemL2.FieldID] = itemL2.Data;
											}
											if (itemL2.FieldID.indexOf("MILESTONE_") >= 0) {
												if (iMilestonesCounter < itemL2.FieldID.substring(itemL2.FieldID.indexOf("_") + 1)) {
													iMilestonesCounter++;
												}
												item[itemL2.FieldID] = itemL2.Data;
											}
											if (itemL2.FieldID.indexOf("CHECKPOINT") >= 0) {
												if (iCheckpointsCounter < itemL2.FieldID.substring(itemL2.FieldID.indexOf("_") + 1)) {
													iCheckpointsCounter++;
												}
												item[itemL2.FieldID] = itemL2.Data;
											}
										});
									}
								}
								aCasesForExport.push(item);
							}
						});
						if (filteredCaseList.length < 12) {
							for (iTextCounter; iTextCounter < 12; iTextCounter++) {
								var oAdditionalItems = {
									CONFIDENTIAL: that._getConfidentialTexts(iTextCounter)
								};
								aCasesForExport.push(oAdditionalItems);
							}
						}
						//add the needed additional Columns for TopIssue, Milestones and Checkpoints
						//only after looping through the array, we are aware of how many elements of which type needs to be added == maximum of all items needs to be added
						for (var t = 1; t <= iTopIssueCounter; t++) {
							aCols.push({
								label: that._oResourceBundle.getText("xlsTopIssue", [t]),
								property: "TOP_ISSUE_" + t,
								type: "string",
								width: "20"
							});
							for (var ait = 1; ait <= aActionItemTopIssueCounter[t]; ait++) {
								aCols.push({
									label: that._oResourceBundle.getText("xlsActionItem"),
									property: "ACTION_ITEM_" + t + ait,
									type: "string",
									width: "20"
								});
							}
						}
						for (var m = 1; m <= iMilestonesCounter; m++) {
							aCols.push({
								label: that._oResourceBundle.getText("xlsMilestone", [m]),
								property: "MILESTONE_" + m,
								type: "string",
								width: "20"
							});
						}
						for (var c = 1; c <= iCheckpointsCounter; c++) {
							aCols.push({
								label: that._oResourceBundle.getText("xlsCheckpoint", [c]),
								property: "CHECKPOINT_" + c,
								type: "string",
								width: "20"
							});
						}
					}
					oSettings = {
						workbook: {
							columns: aCols,
							context: {
								title: "Escalation Data (Confidential)",
								sheetName: "Escalation Data (Confidential) "
							}
						},
						dataSource: aCasesForExport,
						showProgress: true,
						fileName: "MCSDashboardExport_Confidential"
					};
					oSheet = new sap.ui.export.Spreadsheet(oSettings);
					oSheet.build()
						.then(function () {
							MessageToast.show("Spreadsheet export has finished");
						})
						.finally(function () {
							oSheet.destroy();
						});
				},
					function (err) {
						oBusyDialog.close();
					});
			} else {
				this.trackEvent("Export/Master:XLS");
				this.reportDownloadHandler.resetMimeFilterModel(this);
				this.getModel("extReportFilters").setProperty("/id", this.getModel("settings").getProperty("/caseIdsForExport"));
				this.reportDownloadHandler.onPressGenerateMIME(this, "XLS");
			}
		},
		/*
		 * Event handler to show engamenet Card Info
		 * 
		 */
		openEngagamentCardInfo: function (oControl, aNotes, sObjectType) {
			var oInfoText = "this should be the text";
			if (!this.engagementCardInfo) {
				this.engagementCardInfo = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.ObjectInfoCard", this);
				this.getView().addDependent(this.engagementCardInfo);
			}
			this.engagementCardInfo.setModel(new JSONModel({
				escalationReason: "oNotesInfo.escalationReason",
				executiveSummary: " oNotesInfo.executiveSummary",
				reasonTypeHeader: "oNotesInfo.reasonTypeHeader"
			}), "notes");

			this.engagementCardInfo.openBy(oControl);
			oControl.setBusy(false);

		},
		/*
		 * Event handler to show CIM on-call Duty info from BOOST oData
		 * 
		 */
		ONHOLD_openOnCallDutyInfo: function (oControl, aNotes, sObjectType) {
			if (!this.onCallDutyInfo) {
				this.onCallDutyInfo = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.OnCallDutyInfo", this);
				this.getView().addDependent(this.onCallDutyInfo);
			}

			var oModel = new sap.ui.model.json.JSONModel();
			var oData = {
				"items": []
			};
			//map values for model
			//aItems.forEach(function (val) {
			oData.items.push({
				"function": "Duty Manager",
				"name": "Susi Meier",
				"userid": "D020202",
				"mobile": "+49 151 11111",
				"phone": "",
				"email": "susi.meier@test-sap.com",
				"information": "Just a test user",
				"location": "DE ROT04",
				"note": ""
			});

			oData.items.push({
				"function": "Outage Escalation Lead",
				"name": "Dagobert Mueller",
				"userid": "D030303",
				"mobile": "+49 151 11111",
				"phone": "",
				"email": "dagobert.mueller@test-sap.com",
				"information": "Just a test user",
				"location": "DE ROT04",
				"note": ""
			});

			oData.items.push({
				"function": "CIM Lead",
				"name": "Hans Muster",
				"userid": "D010101",
				"mobile": "+49 151 11111",
				"phone": "",
				"email": "hans.muster@test-sap.com",
				"information": "Just a test user",
				"location": "DE ROT04",
				"note": ""
			});

			//	});
			oModel.setData(oData);
			this.onCallDutyInfo.setModel(oModel, "data");

			this.onCallDutyInfo.openBy(oControl);
			oControl.setBusy(false);

		},
		_loadVariants: function (sType) {
			this.getModel().read("/SearchVariantSet", {
				success: function (oData) {
					var oModel = new JSONModel(oData);
					//sap.ui.getCore().setModel(oModel, "variantManagement");
					this.getOwnerComponent().setModel(oModel, "variantManagement");
					var aDefaultVariant = oData.results.filter(function (item) {
						return item.Default === "X";
					});
					if (aDefaultVariant.length === 0 || oData.results.length === 0) {
						if (sType === "MCSCHARTS") {
							//this.oFilterComponent._updateTileNumbers();
							this.oFilterComponent.readCases(); //model, dashboardModel, oFilterModel, settingsModel
							//this.oFilterComponent.readCasesNoFiltersApply(); //model, dashboardModel, oFilterModel
							this.oFilterComponent.readCasesBWKPI(true);
						} else if (sType === "MCSOPERATIONAL") {
							//	this.oFilterComponent._updateTileNumbers(rue);
							//read is implemented in MCSOperationalInformation Controller, because there we do not use any facet filter
						}
					} else {
						//load filters from variant
						var oVariantManagement = this.getView().byId("filterVariantManagement");
						var sKey = aDefaultVariant[0].VarKey;
						oVariantManagement.setDefaultVariantKey(sKey);
						oVariantManagement.setInitialSelectionKey(sKey);
						oVariantManagement.fireSelect({
							key: sKey
						});
					}
					//we need to check, if the Variants have already been read to assure, that the default Variant is selected first, before we start the other backend calls
					this.getOwnerComponent().getModel("settings").setProperty("/initialReadOfVariantManagement", false);

				}.bind(this),
				error: function (data) {
					//we need to check, if the Variants have already been read to assure, that the default Variant is selected first, before we start the other backend calls
					this.getOwnerComponent().getModel("settings").setProperty("/initialReadOfVariantManagement", false);
				}
			});

		},

		openInfoPopup: function (oControl, sMsg) {
			var oModel = new JSONModel({
				message: sMsg
			});
			Fragment.load({
				name: "com.sap.mcconedashboard.view.fragment.InfoPopover",
				controller: this
			}).then(function (oPopover) {
				this.getView().addDependent(oPopover);
				oPopover.setModel(oModel);
				oPopover.openBy(oControl);
			}.bind(this));
		},

		returnObjectTypeTooltip: function (sType) {
			if (sType && sType !== "") {
				sType = sType.split("Closed ").join("");
				sType = sType.split(" (Activities)").join("");
				var i18nModel = this.getView().getModel("i18n");
				var i18nKey = "objectTypeTooltipFor" + sType.replaceAll(" ", "");
				return i18nModel.getProperty(i18nKey);
			}
			return "";
		},

		returnRatingTooltip: function (sRating) {
			if (sRating && sRating !== "") {
				var i18nModel = this.getView().getModel("i18n");
				var i18nKey = "ratingInfoTooltipFor" + sRating.replaceAll(" ", "");
				return i18nModel.getProperty(i18nKey);
			}
			return "";
		},

		returnObjectTypeWithoutClosed: function (sType) {
			if (sType) {
				return sType.replace("Closed ", "");
			}
			return ""

		},

		_getObjectTypeInfoByType: function (sType) {
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			var i18nKey = "objectTypeInfoFor" + sType.replaceAll(" ", "");
			return i18nModel.getProperty(i18nKey);
		},

		_getRatingInfoByType: function (sType) {
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			var i18nKey = "ratingInfoFor" + sType.replaceAll(" ", "");
			return i18nModel.getProperty(i18nKey);
		},
		handleConfirm: function () {
			this.trackEvent("Facet Filter: Facet Filter Selection confirmed");
		},

		getRegionByCountryOrCountryCode: function (sCountryOrCode) {
			var sRegion;
			var aRegionHelp = this.getModel("countryRegionModel").getData();

			//IN SN the Code is saved as USA instead of US
			if (sCountryOrCode === "USA") {
				sCountryOrCode = "US";
			}

			// Find Entry in the Array, which fits the Country or CountryCode
			const countryEntry = aRegionHelp.RegionHelp.find(entry =>
				entry.country === sCountryOrCode || entry.countryCode === sCountryOrCode
			);

			if (countryEntry) {
				switch (countryEntry.region) {
					case "EMEA":
						if (countryEntry.subsubregion == "EMEA South") {
							sRegion = "EMEA South";
							break;
						}
						if (countryEntry.subsubregion == "EMEA North") {
							sRegion = "EMEA North";
							break;
						}
						if (countryEntry.subregion == "MEE") {
							sRegion = "MEE";
							break;
						}
						sRegion = "EMEA";
						break;
					case "NA":
						sRegion = "NA";
						break;
					case "APJ":
						if (countryEntry.subregion == "GTC") {
							sRegion = "GTC";
							break;
						} else {
							sRegion = "APJ";
							break;
						}
					case "LAC":
						sRegion = "LAC";
						break;
					default:
						break;
				}
			}

			return sRegion;
		},

		applyCustomStyleBasedOnSAPui5ColorNames: function () {
			//color definitions
			//keeping this as additional possibilties on how to set colors, if class setting is not possible - check for examples further below
			// var sSapUiNegative = sap.ui.core.theming.Parameters.get("sapUiNegative");
			// var sSapUiIndication6 = sap.ui.core.theming.Parameters.get("sapUiIndication6");
			// var sPink = sap.ui.core.theming.Parameters.get("sapUiContentIllustrativeColor11");
			// var sNeonGreen = sap.ui.core.theming.Parameters.get("sapUiFieldDisabledTextColor");
			// var sColorSapUiAccentError = sap.ui.core.theming.Parameters.get("sapUiAccent3");
			// var sColorSapUiAccentInfo = sap.ui.core.theming.Parameters.get("sapUiAccent7");
			// var sColorSapUiAccentBackgroundColorError = sap.ui.core.theming.Parameters.get("sapUiAccentBackgroundColor3");
			// var sColorSapUiAccentBackgroundColorInfo = sap.ui.core.theming.Parameters.get("sapUiAccentBackgroundColor7");

			//create custom css style classes, which will be added to the application during startup
			//like this we will always have theme dependend colorings and should be also covering theme changes by end user
			var sCustomStyleSheet = "<style type='text/css'>";

			//ObjectStatusFormatting on tiles at start page
			//objectStatus Error
			sCustomStyleSheet +=
				".sapMObjStatusInverted.sapMObjStatusError.mccOneDashboardObjectStatusFormatting  .sapMObjStatusText, .sapMObjStatusError.mccOneDashboardObjectStatusFormatting .sapMObjStatusText{ background-color:" +
				Parameters.get("sapUiIndication8") +
				" !important;color:" + Parameters.get("sapUiIndication6TextColor") + "!important }";
			//hover and active seem not to work, maybe because of custom element
			// sCustomStyleSheet +=
			// 	".sapMObjStatusInverted.sapMObjStatusError.mccOneDashboardObjectStatusFormatting  .sapMObjStatusLink:hover .sapMObjStatusText,.sapMObjStatusInverted.sapMObjStatusError.mccOneDashboardObjectStatusFormatting  .sapMObjStatusLink:hover .sapMObjStatusIcon{ background-color:" +
			// 	Parameters.get("sapUiIndication8HoverBackground") +
			// 	" !important;color:" + Parameters.get("sapUiIndication8TextColor") + "!important }";

			// sCustomStyleSheet +=
			// 	".sapMObjStatusInverted.sapMObjStatusError.mccOneDashboardObjectStatusFormatting  .sapMObjStatusLink:active .sapMObjStatusText,.sapMObjStatusInverted.sapMObjStatusError.mccOneDashboardObjectStatusFormatting  .sapMObjStatusLink:active .sapMObjStatusIcon{ background-color:" +
			// 	Parameters.get("sapUiIndication8HoverBackground") +
			// 	" !important;color:" + Parameters.get("sapUiIndication8TextColor") + "!important }";

			//objectStatus Information

			sCustomStyleSheet +=
				".sapMObjStatusInverted.sapMObjStatusInformation.mccOneDashboardObjectStatusFormatting  .sapMObjStatusText, .sapMObjStatusInformation.mccOneDashboardObjectStatusFormatting .sapMObjStatusText{ background-color:" +
				Parameters.get("sapUiIndication6") +
				" !important;color:" + Parameters.get("sapUiIndication6TextColor") + "!important; text-shadow: 0 0 0.0625rem rgba(0,0,0,0.7) !important;}";

			//hover and active seem not to work, maybe because of custom element
			// sCustomStyleSheet +=
			// 	".sapMObjStatusInverted.sapMObjStatusInformation.mccOneDashboardObjectStatusFormatting  .sapMObjStatusLink:hover .sapMObjStatusText,.sapMObjStatusInverted.sapMObjStatusInformation.mccOneDashboardObjectStatusFormatting  .sapMObjStatusLink:hover .sapMObjStatusIcon{ background-color:" +
			// 	sColorSapUiAccentBackgroundColorInfo +
			// 	" !important;color:" + sColorSapUiAccentInfo + "!important }";

			// sCustomStyleSheet +=
			// 	".sapMObjStatusInverted.sapMObjStatusInformation.mccOneDashboardObjectStatusFormatting  .sapMObjStatusLink:active .sapMObjStatusText,.sapMObjStatusInverted.sapMObjStatusInformation.mccOneDashboardObjectStatusFormatting  .sapMObjStatusLink:active .sapMObjStatusIcon{ background-color:" +
			// 	sColorSapUiAccentBackgroundColorInfo +
			// 	" !important;color:" + sColorSapUiAccentInfo + "!important }";

			//ObjectStatus NOne
			sCustomStyleSheet +=
				".sapMObjStatusInverted.sapMObjStatusNone.mccOneDashboardObjectStatusFormatting  .sapMObjStatusText, .sapMObjStatusNone.mccOneDashboardObjectStatusFormatting .sapMObjStatusText{ background-color:" +
				Parameters.get("sapUiIndication3") +
				" !important;color:" + Parameters.get("sapUiIndication3TextColor") + "!important; text-shadow: 0 0 0.0625rem rgba(0,0,0,0.7) !important;}";

			//OTHER COLORS

			sCustomStyleSheet +=
				".sapMObjStatusInverted.sapMObjStatusError.mccOneDashboardObjectStatusFormatting  .sapMObjStatusText, .sapMObjStatusError.mccOneDashboardObjectStatusFormatting .sapMObjStatusText{ background-color:" +
				Parameters.get("sapUiLegend13") +
				" !important}";

			//objectStatus Information

			sCustomStyleSheet +=
				".sapMObjStatusInverted.sapMObjStatusInformation.mccOneDashboardObjectStatusFormatting  .sapMObjStatusText, .sapMObjStatusInformation.mccOneDashboardObjectStatusFormatting .sapMObjStatusText{ background-color:" +
				Parameters.get("sapUiLegend7") +
				" !important; text-shadow: 0 0 0.0625rem rgba(0,0,0,0.7) !important;}";


			//ObjectStatus NOne
			sCustomStyleSheet +=
				".sapMObjStatusInverted.sapMObjStatusNone.mccOneDashboardObjectStatusFormatting  .sapMObjStatusText, .sapMObjStatusNone.mccOneDashboardObjectStatusFormatting .sapMObjStatusText{ background-color:" +
				Parameters.get("sapUiLegend1") +
				" !important; text-shadow: 0 0 0.0625rem rgba(0,0,0,0.7) !important;}";

			//label for Anonymized access
			sCustomStyleSheet +=
				".MCCOneDashboardAnonymized{ color:" +
				Parameters.get("sapUiButtonTextColor") +
				" !important }";

			//icon color for most mcs tile icons
			sCustomStyleSheet +=
				".MCCOneDashboardTileUIIndication6 { color:" +
				Parameters.get("sapUiIndication6") +
				" !important }";

			//icon color for red mcs tile icon
			sCustomStyleSheet +=
				".MCCOneDashboardTileUINegative { color:" +
				Parameters.get("sapUiNegative") +
				" !important }";

			//icon color for rating B /Yellow/Orange
			sCustomStyleSheet +=
				".MCCOneDashboardTileUIIndication3 { color:" +
				Parameters.get("sapUiIndication3") +
				" !important }";

			//Background Color for Favorite Tiles
			sCustomStyleSheet +=
				".MCCCritSitadjustFavoriteTile { background-color:" +
				Parameters.get("sapUiTileBackground") +
				" !important }";

			sCustomStyleSheet += " </style>";
			jQuery(sCustomStyleSheet).appendTo("head");

			// Color of icons  in Executive view
			var icon = new Icon();
			var renderer = icon.getRenderer();
			var render = renderer.render;
			renderer.render = function (rm, control) {
				// Hack to avoid coloring per each icon
				var src = control.getSrc();
				//red
				if (src.indexOf("alert") > -1) {
					//control.setProperty("color", sSapUiNegative); //  "#BB0000  #d14900
					control.addStyleClass("MCCOneDashboardTileUINegative");
				} //yellow
				// else if (src.indexOf("status-critical") > -1) {
				// 	//control.setProperty("color", "#FFE303");
				// 	control.addStyleClass("MCCOneDashboardTileUIIndication6");
				// } //green 
				// else if (src.indexOf("status-completed") > -1) {
				// 	control.setProperty("color", "#61a656");
				// } 
				else if (src.indexOf("documents") > -1) {
					//control.setProperty("color", sSapUiIndication6); //"SteelBlue"
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("//error") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("kpi-corporate-performance") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("business-objects-experience") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("favorite-list") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("course-program") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("bbyd-active-sales") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("along-stacked-chart") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("flag") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("globe") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("cloud") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("people-connected") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("customer") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("group") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("activity-individual") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("business-card") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("in-progress") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("travel-request") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				} else if (src.indexOf("quality-issue") > -1) {
					control.addStyleClass("MCCOneDashboardTileUIIndication6");
				}
				render.apply(this, arguments);
			};

			//now handled via the customer stylesheet above, yet keep in case we still need it
			// var oNumericContent = new sap.m.NumericContent();
			// var numContentRenderer = oNumericContent.getRenderer();
			// var numContentRender = numContentRenderer.render;
			// numContentRenderer.render = function (rm, control) {
			// 	if (control._oIcon && control.mCustomStyleClassMap.MCCOneDashboardCustomThemening) {
			// 		var srcIcon = control._oIcon.getSrc();
			// 		control._oIcon.setProperty("color", sPink); //  "#BB0000  #d14900
			// 	}
			// 	numContentRender.apply(this, arguments);
			// };

			// var oObjectStatus = new ObjectStatus();
			// var renderer3 = oObjectStatus.getRenderer();
			// var render3 = renderer3.render;
			// renderer3.render = function (rm, control) {
			// 	if (control._oIcon && control.mCustomStyleClassMap.MCCOneDashboardCustomThemening) {
			// 		var srcIcon = control._oIcon.getSrc();
			// 		control._oIcon.setProperty("color", sNeonGreen); 
			// 	}
			// 	render3.apply(this, arguments);
			// };
		},

		doesViewExist: function (sViewName) {
			var oManifest = this.getManifest();
			//var oTarget = oManifest["sap.ui5"]["routing"]["targets"][sViewName];
			if (oManifest["sap.ui5"]["routing"]["targets"].hasOwnProperty(sViewName)) {
				// Target "sViewName" does exist
				return true;
			} else {
				// Target "sViewName" doesn't exist
				return false;
			}
		},

		reloadCurrentView: function () {
			var oComponent = this.getOwnerComponent();
			oComponent.fireMyRouteMatched();
		},

		onChangeMobileViewSwitch: function (evt) {
			var bIsAnonymizedModeOn = this.getModel("settings").getProperty("/isAnonymizedMode");
			//var bShowMissionRadar = this.getModel("settings").getProperty("/showMissionRadar");

			if (evt.getParameter("state") === true) { //mobile mode will be active
				this.getModel("settings").setProperty("/isMobileMode", true);

				if (bIsAnonymizedModeOn == true) {
					this.getModel("settings").setProperty("/isAnonymizedMode", false);
				}
				/*if (bShowMissionRadar == true) {
					this.getModel("settings").setProperty("/showMissionRadar", false);
				}*/
				this.reloadCurrentView();
			} else { //mobile mode will not be active
				this.getModel("settings").setProperty("/isMobileMode", false);
				this.reloadCurrentView();
			}
		},

		onChangeAnonymizedSwitch: function (evt) {
			//	var oSettingsModel = this.getModel("settings");
			var bIsAnonymizedModeOn = true;
			if (evt.getParameter("state") === true) { //anonymous  mode has been activated
				bIsAnonymizedModeOn = true;
			} else { //anonymous  mode has been deactivated
				bIsAnonymizedModeOn = false;
			}
			//reload whole app with parameter set or unset
			//var sBasePath = window.location.pathname.replace(/\/[^\/]*\.?[^\/]*$/, '/');
			//var sBaseUrl = window.location.href;
			//var bIsAnonymizedModeOn = this.getModel("settings").getProperty("/isAnonymizedMode");
			/*var bShowMissionRadar = this.getModel("settings").getProperty("/showMissionRadar");

			var oRouter = this.getRouter();
			oRouter.navTo("Global", {
				"?query": {
					"isAnonymizedMode": bIsAnonymizedModeOn,
					"showMissionRadar": bShowMissionRadar
				}
			});
			*/
			var oRouter = this.getRouter();
			oRouter.navTo("Global", {
				"?query": {
					"isAnonymizedMode": bIsAnonymizedModeOn
				}
			});
		},

		//UNUSED CURRENTLY SINCE THE RADAR SWITCH GOT REMOVED
		onChangeMissionRadarSwitch: function (evt) {
			//	var oSettingsModel = this.getModel("settings");
			var bIsMissionRadarModeOn = true;
			if (evt.getParameter("state") === true) { //anonymous  mode has been activated
				//	oSettingsModel.setProperty("/isAnonymizedMode", true);
				bIsMissionRadarModeOn = true;
			} else { //anonymous  mode has been deactivated
				//	oSettingsModel.setProperty("/isAnonymizedMode", false);
				bIsMissionRadarModeOn = false;
			}
			//reload whole app with parameter set or unset
			//var sBasePath = window.location.pathname.replace(/\/[^\/]*\.?[^\/]*$/, '/');

			//var sBaseUrl = window.location.href;
			var bIsAnonymizedModeOn = this.getModel("settings").getProperty("/isAnonymizedMode");

			var oRouter = this.getRouter();
			oRouter.navTo("Global", {
				"?query": {
					"isAnonymizedMode": bIsAnonymizedModeOn,
					"showMissionRadar": bIsMissionRadarModeOn
				}
			});

		},
		// read the information for MCCi and Prevention Score from C4S System
		readMissionRadarValues: function (oModel, sEntitySetName, bNoData) {
			//only if the flag is set, the data should be read
			//if (this.getModel("settings").getProperty("/showMissionRadar")) {
			var aData = oModel.getData();
			var that = this;

			//MISSIONRADAR 2211	
			// we need to loop throught all shown engagements, because there could be different customers involved
			//for the C4S call we need to add the leading zeros			
			var aEngagementListErpNumbers = [];
			aData[sEntitySetName].forEach(function (c) {
				if (!aEngagementListErpNumbers.includes(that.pad(c.CustomerErpNo, 10)) && c.CustomerErpNo !== "") {
					aEngagementListErpNumbers.push(that.pad(c.CustomerErpNo, 10));
				}
			}.bind(this));
			//we need submit todays date in format "2022-09-23" to get the current values
			var today = new Date(); //("2022-10-28"); //new Date();
			var yesterday = new Date(today);
			yesterday.setDate(today.getDate() - 1); // Subtract 1 day from today's date
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd" // we need a format like 2022-12-24
			});
			today = oFormat.format(today);
			yesterday = oFormat.format(yesterday);

			if (aEngagementListErpNumbers.length > 0 && (!bNoData || bNoData === false)) {
				//Read data for the list view
				//	$.ajax("./json/ExampleC4SCustomerView.json", { // only for testing - load the data from a relative URL (the Data.json file in the same directory)
				// as soon as we are able to test in the test environment we need to use the following call
				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([{
						"queryIdentifier": "CL_MCCI_V2_CURRENT",
						"elementList": [
							"SNAPSHOT_DATE", "CUSTOMER_ID", "ERP_Account", "Global_Ultimate", "Internal_Sales_Segment", "Global_Ultimate_Name", "MCCI", "TREND_28_DAYS", "TREND_3_DAYS", "CCM_CASES", "CPC_CASES",
							"TF_CASES", "TC2_CASES", "GEM_CASES", "OPEN_NOW_P1", "OPEN_NOW_P2", "MCC_SOL_AREA", "MCC_SOL_AREA_RANK", "Country_Code"
						],
						"filters": [{
							"filters": [{
								"operand1": {
									"elementIdentifier": "ERP_Account"
								},
								"operand2": {
									"values": aEngagementListErpNumbers
								},
								"operator": "EQ"
							}, {
								"operand1": {
									"elementIdentifier": "SNAPSHOT_DATE"
								},
								"operand2": {
									"values": [today]
								},
								"operator": "EQ"
							}],
							"conjunctionOperator": "AND"
						}],
						"skip": 0
					}]),
					contentType: "application/json"
				}).always(function (data, stextStatus, errorThrown) {
					if (data.queryResults && data.queryResults.CL_MCCI_V2_CURRENT && data.queryResults.CL_MCCI_V2_CURRENT.rows.length > 0) {

						//Check if every MCCI Value is 0, if so we need to use yesterdays data instead.
						var allMCCIValuesZero = data.queryResults.CL_MCCI_V2_CURRENT.rows.every(function (row) {
							return row.MCCI.value === 0;
						});

						if (allMCCIValuesZero) {
							that.readMissionRadarValues(oModel, sEntitySetName, true);
						} else {
							aData[sEntitySetName].forEach(function (oDataElement) {
								var oCase = data.queryResults.CL_MCCI_V2_CURRENT.rows.filter(function (val) {
									return val.ERP_Account.key === that.pad(oDataElement.CustomerErpNo, 10);
								});
								// we should get the first entry only, if it is from today, otherwise it would be older data, because we are reading the last 14 days
								//therefore it could also be, that there is no data for specific customers, because they have no ongoing cases in the relevant timeframes for Mission Control values
								if (oCase && oCase.length >= 1 && (oCase[0].SNAPSHOT_DATE.key === today)) {
									oDataElement.MCCi = Math.round(oCase[0].MCCI.value).toString();
									oDataElement.Trend = Math.round(oCase[0].TREND_28_DAYS.value).toString();
								}
							});
							oModel.refresh();
						}
					} else if (data.queryResults && data.queryResults.CL_MCCI_V2_CURRENT && !data.queryResults.CL_MCCI_V2_CURRENT.rows.length > 0) {
						//Try to find data with SNAPSHOT_DATE = yesterday
						console.log("No MCCI Data for today, trying to find yesterdays data")
						that.readMissionRadarValues(oModel, sEntitySetName, true);
						// that.getView().byId("c4sErrorTest").setText("Response received: \n\nHTTP Status Code: " + n.status + "\n\n" + "Response Text: \n" +
						// 	JSON.stringify(e));
					} else {
						console.log("No MCCI data found")
					}
				});

			} else if (aEngagementListErpNumbers.length > 0 && bNoData === true) {

				//Call again to try to find data for yesterday
				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([{
						"queryIdentifier": "CL_MCCI_V2_CURRENT",
						"elementList": [
							"SNAPSHOT_DATE", "CUSTOMER_ID", "ERP_Account", "Global_Ultimate", "Internal_Sales_Segment", "Global_Ultimate_Name", "MCCI", "TREND_28_DAYS", "TREND_3_DAYS", "CCM_CASES", "CPC_CASES",
							"TF_CASES", "TC2_CASES", "GEM_CASES", "OPEN_NOW_P1", "OPEN_NOW_P2", "MCC_SOL_AREA", "MCC_SOL_AREA_RANK", "Country_Code"
						],
						"filters": [{
							"filters": [{
								"operand1": {
									"elementIdentifier": "ERP_Account"
								},
								"operand2": {
									"values": aEngagementListErpNumbers
								},
								"operator": "EQ"
							}, {
								"operand1": {
									"elementIdentifier": "SNAPSHOT_DATE"
								},
								"operand2": {
									"values": [yesterday]
								},
								"operator": "EQ"
							}],
							"conjunctionOperator": "AND"
						}],
						"skip": 0
					}]),
					contentType: "application/json"
				}).always(function (data, stextStatus, errorThrown) {
					if (data.queryResults && data.queryResults.CL_MCCI_V2_CURRENT && data.queryResults.CL_MCCI_V2_CURRENT.rows.length > 0) {
						aData[sEntitySetName].forEach(function (oDataElement) {
							var oCase = data.queryResults.CL_MCCI_V2_CURRENT.rows.filter(function (val) {
								return val.ERP_Account.key === that.pad(oDataElement.CustomerErpNo, 10);
							});
							// we should get the first entry only, if it is from today, otherwise it would be older data, because we are reading the last 14 days
							//therefore it could also be, that there is no data for specific customers, because they have no ongoing cases in the relevant timeframes for Mission Control values
							if (oCase && oCase.length >= 1 && (oCase[0].SNAPSHOT_DATE.key === today || oCase[0].SNAPSHOT_DATE.key === yesterday)) {
								oDataElement.MCCi = Math.round(oCase[0].MCCI.value).toString();
								oDataElement.Trend = Math.round(oCase[0].TREND_28_DAYS.value).toString();
							}
						});
						oModel.refresh();
					} else {
						console.log("No MCCI Data for today or yesterday.")
						// that.getView().byId("c4sErrorTest").setText("Response received: \n\nHTTP Status Code: " + n.status + "\n\n" + "Response Text: \n" +
						// 	JSON.stringify(e));
					}
				});
			}
			//}
		},

		//Used for Mission Radar View
		readMissionRadarCriticalCustomers: function (oModel, callback, bNoData) {

			//we need submit todays date in format "2022-09-23" to get the current values
			var today = new Date(); //("2022-10-28");
			var yesterday = new Date(today);
			yesterday.setDate(today.getDate() - 1); // Subtract 1 day from today's date
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd" // we need a format like 2022-12-24
			});
			today = oFormat.format(today);
			yesterday = oFormat.format(yesterday);

			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var aFilter = oFilterModel.getProperty("/oFilterForMissionRadarCC");
			var sRegion = oFilterModel.getProperty("/regionText");
			var filterCondition;
			var that = this;

			// General Filter, always used
			// Needed since CURRENT includes values for today and yesterday
			// If bNoData is true, then use yesterday as filter
			if (bNoData === true) {
				filterCondition = {
					operand1: { elementIdentifier: "SNAPSHOT_DATE" },
					operand2: { values: [yesterday] },
					operator: "EQ"
				};
			} else {
				filterCondition = {
					operand1: { elementIdentifier: "SNAPSHOT_DATE" },
					operand2: { values: [today] },
					operator: "EQ"
				};
			}

			var combinedFilter = {
				filters: [filterCondition]
			};

			//var combinedFilter;

			// Check if there is Global Filters set
			if (aFilter) {
				var additionalFilters = [];

				aFilter.forEach(function (filterString) {
					var orFilters = filterString.split("^OR");

					var combinedValues = [];

					orFilters.forEach(function (orFilterString) {
						var filterExpression = orFilterString.split("=");
						var values = filterExpression[1].split(",");
						combinedValues = combinedValues.concat(values);
					});

					additionalFilters.push({
						operator: "EQ",
						operand1: { elementIdentifier: orFilters[0].split("=")[0] },
						operand2: { values: combinedValues }
					});
				});

				if (combinedFilter.filters) {
					// Füge die zusätzlichen Filter zu den bestehenden Filtern hinzu, wenn sie vorhanden sind
					combinedFilter.filters.push.apply(combinedFilter.filters, additionalFilters);
				} else {
					// Wenn es keine bestehenden Filter gibt, weise die zusätzlichen Filter zu
					combinedFilter.filters = additionalFilters;
				}
			}

			//if (typeof sRegion !== "undefined" && sRegion !== "" && !aFilter.some(filter => filter.includes("Country"))) {
			if (typeof sRegion !== "undefined" && sRegion !== "") {

				var aRegionHelp = this.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];
				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.countryCode;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var regionFilter = {
					operator: "EQ",
					operand1: { elementIdentifier: "Country_Code" },
					operand2: { values: regionCountryValues }
				};

				// Combine the regionFilter with filterCondition using AND conjunction
				combinedFilter.filters.push(regionFilter);

			}



			if (DebugMode == true) {

				//DEVELOPMENT
				$.ajax({
					url: "./json/MissionRadar/missionRadarCCNewTest.json",
					type: "GET",
					dataType: "json",
					success: function (data) {
						var items = data.queryResults.CL_MCCI_V2_CURRENT.rows;
						oModel.setData({ items: items });
						oModel.refresh();

						if (callback && typeof callback === "function") {
							callback();
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						console.log("Can't read JSON");

						if (callback && typeof callback === "function") {
							callback();
						}
					}
				});

			} else {

				//PROD
				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([
						{
							"queryIdentifier": "CL_MCCI_V2_CURRENT",
							"elementList": [
								"SNAPSHOT_DATE", "Base_Maintenance_GU_", "CUSTOMER_ID", "ERP_Account", "Global_Ultimate", "Maintenance_Revenue_Segment_GU_",
								"Master_Code", "Internal_Account_Classification", "Market_Unit", "Internal_Sales_Segment", "Global_Ultimate_Name", "Internal_Market_Segment",
								"MCCI", "TREND_28_DAYS", "TREND_3_DAYS", "Country", "Business_Partner_Accounts", "Country_Code",
								"CCM_CASES", "CPC_CASES", "TF_CASES", "TC2_CASES", "GEM_CASES", "OPEN_NOW_P1", "OPEN_NOW_P2", "MCC_SOL_AREA", "MCC_SOL_AREA_RANK"
							],
							"sortSteps": [{ "elementIdentifier": "MCCI", "direction": "DESC" }],
							"filters": [combinedFilter],
							"top": 700,
							"skip": 0
						}]),
					contentType: "application/json",
					success: function (data) {
						var items = data.queryResults.CL_MCCI_V2_CURRENT.rows;

						//If there are items for today, use those
						if (items && items.length > 0) {

							// Check if all rows in MCCI field have value 0
							var allMCCIValuesZero = items.every(function (row) {
								return row.MCCI.value === 0;
							});

							if (allMCCIValuesZero && (!bNoData || bNoData === false)) {
								//If there are no MCCI values in the items, recall the function with new parameter bNoData = true
								that.readMissionRadarCriticalCustomers(oModel, callback, true);
							} else {
								oModel.setData({ items: items });
								oModel.refresh();
								if (callback && typeof callback === "function") {
									callback();
								}
							}

						} else if (!bNoData || bNoData === false) {
							// If there are no items, recall the function with new parameter bNoData = true
							console.log("There is no data MCCI Data for today, trying to find data for yesterday..")
							that.readMissionRadarCriticalCustomers(oModel, callback, true);
						} else {
							//There is no data for today or yesterday. Callback.
							oModel.setData({ items: items });
							oModel.refresh();
							console.log("There is no data MCCI Data for today or yesterday.")
							if (callback && typeof callback === "function") {
								callback();
							}
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						console.log("Error while fetching data from API");
						var sMsg = xhr.responseJSON.message;
						sap.m.MessageBox.error(sMsg);

						if (callback && typeof callback === "function") {
							callback();
						}
					}
				});

			}


		},


		readMissionRadarGoLiveTrendData: function (oModel, aCustomerIDs, callback, bNoData) {
			//we need submit todays date in format "2022-09-23" to get the current values
			var today = new Date(); //("2022-10-28");
			var yesterday = new Date(today);
			yesterday.setDate(today.getDate() - 1); // Subtract 1 day from today's date
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd" // we need a format like 2022-12-24
			});
			today = oFormat.format(today);
			yesterday = oFormat.format(yesterday);


			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var aFilter = oFilterModel.getProperty("/oFilterForMissionRadarCC");
			var sRegion = oFilterModel.getProperty("/regionText");
			var filterCondition;
			var that = this;

			// General Filter, always used
			// Needed since CURRENT includes values for today and yesterday
			// If bNoData is true, then use yesterday as filter
			if (bNoData === true) {
				filterCondition = {
					operand1: { elementIdentifier: "SNAPSHOT_DATE" },
					operand2: { values: [yesterday] },
					operator: "EQ"
				};
			} else {
				filterCondition = {
					operand1: { elementIdentifier: "SNAPSHOT_DATE" },
					operand2: { values: [today] },
					operator: "EQ"
				};
			}

			var combinedFilter = {
				filters: [filterCondition]
			};

			var customerFilterCondition = {
				operand1: { elementIdentifier: "CUSTOMER_ID" },
				operand2: { values: aCustomerIDs },
				operator: "EQ"
			};

			combinedFilter.filters.push(customerFilterCondition);

			// Check if there are Global Filters set
			if (aFilter) {
				var additionalFilters = [];

				aFilter.forEach(function (filterString) {
					var orFilters = filterString.split("^OR");

					var combinedValues = [];

					orFilters.forEach(function (orFilterString) {
						var filterExpression = orFilterString.split("=");
						var values = filterExpression[1].split(",");
						combinedValues = combinedValues.concat(values);
					});

					additionalFilters.push({
						operator: "EQ",
						operand1: { elementIdentifier: orFilters[0].split("=")[0] },
						operand2: { values: combinedValues }
					});
				});

				if (combinedFilter.filters) {
					// Füge die zusätzlichen Filter zu den bestehenden Filtern hinzu, wenn sie vorhanden sind
					combinedFilter.filters.push.apply(combinedFilter.filters, additionalFilters);
				} else {
					// Wenn es keine bestehenden Filter gibt, weise die zusätzlichen Filter zu
					combinedFilter.filters = additionalFilters;
				}
			}

			//if (typeof sRegion !== "undefined" && sRegion !== "" && !aFilter.some(filter => filter.includes("Country"))) {
			if (typeof sRegion !== "undefined" && sRegion !== "") {

				var aRegionHelp = this.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.countryCode;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var regionFilter = {
					operator: "EQ",
					operand1: { elementIdentifier: "Country_Code" },
					operand2: { values: regionCountryValues }
				};

				// Combine the regionFilter with filterCondition using AND conjunction
				combinedFilter.filters.push(regionFilter);

			}

			if (combinedFilter.filters.length === 0) {
				combinedFilter = undefined; // Clear combined Filters if there is no filters to apply
			}


			if (DebugMode == true) {

				//DEVELOPMENT
				$.ajax({
					url: "./json/MissionRadar/missionRadarGoLiveTrendsNew.json",
					type: "GET",
					dataType: "json",
					success: function (data) {
						var items = data.queryResults.CL_MCCI_V2_CURRENT.rows;
						oModel.setData({ items: items });
						oModel.refresh();

						if (callback && typeof callback === "function") {
							callback();
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						console.log("Can't read missionRadarGoLiveTrendsNew.json");

						if (callback && typeof callback === "function") {
							callback();
						}
					}
				});

			} else {

				//PROD
				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([
						{
							"queryIdentifier": "CL_MCCI_V2_CURRENT",
							"elementList": [
								"SNAPSHOT_DATE", "Base_Maintenance_GU_", "CUSTOMER_ID", "ERP_Account", "Global_Ultimate", "Maintenance_Revenue_Segment_GU_",
								"Master_Code", "Internal_Account_Classification", "Market_Unit", "Internal_Sales_Segment", "Global_Ultimate_Name", "Internal_Market_Segment",
								"MCCI", "TREND_28_DAYS", "TREND_3_DAYS", "Country", "Business_Partner_Accounts", "Country_Code",
								"CCM_CASES", "CPC_CASES", "TF_CASES", "TC2_CASES", "GEM_CASES", "OPEN_NOW_P1", "OPEN_NOW_P2", "MCC_SOL_AREA", "MCC_SOL_AREA_RANK"
							],
							"filters": [combinedFilter],
							"top": 9999,
							"skip": 0
						}]),
					contentType: "application/json",
					success: function (data) {
						var items = data.queryResults.CL_MCCI_V2_CURRENT.rows;

						//If there are items for today, use those
						if (items && items.length > 0) {

							// Check if all rows in MCCI field have value 0
							var allMCCIValuesZero = items.every(function (row) {
								return row.MCCI.value === 0;
							});

							if (allMCCIValuesZero && (!bNoData || bNoData === false)) {
								//If there are no MCCI values in the items, recall the function with new parameter bNoData = true
								that.readMissionRadarGoLiveTrendData(oModel, aCustomerIDs, callback, true);
							} else {
								oModel.setData({ items: items });
								oModel.refresh();
								if (callback && typeof callback === "function") {
									callback();
								}
							}

						} else if (!bNoData || bNoData === false) {
							// If there are no items, recall the function with new parameter bNoData = true
							console.log("There is no data MCCI Data for today, trying to find data for yesterday..")
							that.readMissionRadarGoLiveTrendData(oModel, aCustomerIDs, callback, true);
						} else {
							//There is no data for today or yesterday. Callback.
							oModel.setData({ items: items });
							oModel.refresh();
							console.log("There is no data MCCI Data for today or yesterday.")
							if (callback && typeof callback === "function") {
								callback();
							}
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						Logger.error("Error retrieving Mission Radar Data", "", "", errorThrown);

						if (callback && typeof callback === "function") {
							callback();
						}
					}
				});
			}

		},

		readMissionRadarGoLives: function (oModel, callback) {

			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var aFilter = oFilterModel.getProperty("/oFilterForMissionRadarGoLives");
			var sRegion = oFilterModel.getProperty("/regionText");

			// General Filter, always used

			//we need submit todays date in format "2022-09-23" and add 90 days
			var goLiveDate = new Date();
			goLiveDate.setDate(goLiveDate.getDate() + 90);
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			goLiveDate = oFormat.format(goLiveDate);

			var today = new Date(); //("2022-10-28");
			today = oFormat.format(today);

			var pastDate = new Date();
			pastDate.setDate(pastDate.getDate() - 14);
			pastDate = oFormat.format(pastDate);




			var filterConditionGE = {
				operand1: { elementIdentifier: "Calculated_Go_Live_Date" },
				operand2: { values: [pastDate] },
				operator: "GE"
			};

			var filterConditionLE = {
				operand1: { elementIdentifier: "Calculated_Go_Live_Date" },
				operand2: { values: [goLiveDate] },
				operator: "LE"
			};

			var combinedFilterDate = {
				filters: [filterConditionGE, filterConditionLE],
				conjunctionOperator: "AND"
			};

			var combinedFilter = {
				filters: [combinedFilterDate]
			};



			// General Filter, always used
			/*	var filterCondition = {
					operand1: { elementIdentifier: "Wave_Go_Live_Next_90_Days_Flag" },
					operand2: { values: ["Yes"] },
					operator: "EQ"
				};
		
				var combinedFilter = {
					filters: [filterCondition]
				}; */


			// Check if there is Global Filters set
			if (aFilter) {
				var additionalFilters = [];

				aFilter.forEach(function (filterString) {
					var orFilters = filterString.split("^OR");

					var combinedValues = [];

					orFilters.forEach(function (orFilterString) {
						var filterExpression = orFilterString.split("=");
						var values = filterExpression[1].split(",");
						combinedValues = combinedValues.concat(values);
					});

					additionalFilters.push({
						operator: "EQ",
						operand1: { elementIdentifier: orFilters[0].split("=")[0] },
						operand2: { values: combinedValues }
					});
				});

				if (combinedFilter.filters) {
					// Füge die zusätzlichen Filter zu den bestehenden Filtern hinzu, wenn sie vorhanden sind
					combinedFilter.filters.push.apply(combinedFilter.filters, additionalFilters);
				} else {
					// Wenn es keine bestehenden Filter gibt, weise die zusätzlichen Filter zu
					combinedFilter.filters = additionalFilters;
				}
			}

			if (sRegion) {
				var regionValues = sRegion.split(",");
				// Mapping
				regionValues = regionValues.map(function (region) {
					var trimmedRegion = region.trim();
					switch (trimmedRegion) {
						//We need to return "EME" for EMEA North and EMEA South since the query only allows to filter for "EME" (EMEA)
						case "EMEA North":
							return "EMEA";
						case "EMEA South":
							return "EMEA";
						case "MEE":
							return "Middle and Eastern Europe"
						case "GTC":
							return "Greater China";
						case "LAC":
							return "Latin America";
						case "APJ":
							return "Asia Pacific Japan";
						case "NA":
							return "North America";
						default:
							return trimmedRegion;
					}
				});

				var regionFilter = {
					operator: "EQ",
					operand1: { elementIdentifier: "Customer_Region" },
					operand2: { values: regionValues }
				};

				combinedFilter.filters.push(regionFilter);
			}


			if (DebugMode == true) {

				//DEVELOPMENT
				$.ajax({
					url: "./json/MissionRadar/missionRadarGoLives.json",
					type: "GET",
					dataType: "json",
					success: function (data) {
						var items = data.queryResults.API_Call_Only_Wave_for_MCC.rows;
						oModel.setData({ items: items });
						oModel.refresh();

						if (callback && typeof callback === "function") {
							callback();
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						console.log("Can't read JSON");

						if (callback && typeof callback === "function") {
							callback();
						}
					}
				});

			} else {

				//PROD
				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([
						{
							"queryIdentifier": "API_Call_Only_Wave_for_MCC",
							"elementList": [
								"Calculated_Go_Live_Date",
								"Next_Renewal_Date",
								"Customer_CRM_ID",
								"Customer_ERP_ID",
								"Customer",
								"Customer_Global_Ultimate",
								"Customer_Country",
								"Solution_Area",
								"Sub_Solution_Area",
								"Customer_Region",
								"Customer_Market_Unit",
								"Wave_Go_Live_Next_90_Days_Flag",
								"Project_ID",
								"Customer_Global_Ultimate_CRM_ID",
								"Customer_Global_Ultimate",
								"Country_Code"
							],
							"filters": [combinedFilter],
							//"top": 100,
							//"skip": 0
						}]),
					contentType: "application/json",
					success: function (data) {
						var items = data.queryResults.API_Call_Only_Wave_for_MCC.rows;
						oModel.setData({ items: items });
						oModel.refresh();

						if (callback && typeof callback === "function") {
							callback();
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						console.log("Error while fetching data from API");

						if (callback && typeof callback === "function") {
							callback();
						}
					}
				});

			}

		},

		readMissionRadarGoLivesFromMCC: function (oModel, callback) {
			//we need submit todays date in format "2022-09-23" and add 90 days
			var goLiveDate = new Date();
			goLiveDate.setDate(goLiveDate.getDate() + 90);
			var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			goLiveDate = oFormat.format(goLiveDate);

			var today = new Date(); //("2022-10-28");
			today = oFormat.format(today);

			var pastDate = new Date();
			pastDate.setDate(pastDate.getDate() - 14);
			pastDate = oFormat.format(pastDate);

			var filterConditionGE = {
				operand1: { elementIdentifier: "Overview_Go_Live_Date" },
				operand2: { values: [pastDate] },
				operator: "GE"
			};

			var filterConditionLE = {
				operand1: { elementIdentifier: "Overview_Go_Live_Date" },
				operand2: { values: [goLiveDate] },
				operator: "LE"
			};

			var filterConditionNE = {
				operand1: { elementIdentifier: "Case_Status" },
				operand2: { values: ["90"] },
				operator: "NE"
			}


			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var aFilter = oFilterModel.getProperty("/oFilterForMissionRadarGoLivesFromMCC");
			var sRegion = oFilterModel.getProperty("/regionText");

			var combinedFilter = {
				filters: [filterConditionGE, filterConditionLE, filterConditionNE]
			};


			// Check if there is Global Filters set
			if (aFilter) {
				var additionalFilters = [];

				aFilter.forEach(function (filterString) {
					var orFilters = filterString.split("^OR");

					var combinedValues = [];

					orFilters.forEach(function (orFilterString) {
						var filterExpression = orFilterString.split("=");
						var values = filterExpression[1].split(",");
						combinedValues = combinedValues.concat(values);
					});

					additionalFilters.push({
						operator: "EQ",
						operand1: { elementIdentifier: orFilters[0].split("=")[0] },
						operand2: { values: combinedValues }
					});
				});

				if (combinedFilter.filters) {
					// Füge die zusätzlichen Filter zu den bestehenden Filtern hinzu, wenn sie vorhanden sind
					combinedFilter.filters.push.apply(combinedFilter.filters, additionalFilters);
				} else {
					// Wenn es keine bestehenden Filter gibt, weise die zusätzlichen Filter zu
					combinedFilter.filters = additionalFilters;
				}
			}


			//if (typeof sRegion !== "undefined" && sRegion !== "" && !aFilter.some(filter => filter.includes("Country"))) {
			if (typeof sRegion !== "undefined" && sRegion !== "") {


				var aRegionHelp = this.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.countryCode;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var regionFilter = {
					operator: "EQ",
					operand1: { elementIdentifier: "Country_Code" },
					operand2: { values: regionCountryValues }
				};

				// Combine the regionFilter with filterCondition using AND conjunction
				combinedFilter.filters.push(regionFilter);

			}

			if (DebugMode == true) {

				//DEVELOPMENT
				$.ajax({
					url: "./json/MissionRadar/missionRadarGoLivesFromMCC.json",
					type: "GET",
					dataType: "json",
					success: function (data) {
						var items = data.queryResults.CL_ENG_CASES_ONEDASHBOARD.rows;
						oModel.setData({ items: items });
						oModel.refresh();

						if (callback && typeof callback === "function") {
							callback();
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						console.log("Can't read JSON");

						if (callback && typeof callback === "function") {
							callback();
						}
					}
				});

			} else {

				//PROD
				$.ajax({
					method: "POST",
					headers: {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					},
					url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
					data: JSON.stringify([
						{
							"queryIdentifier": "CL_ENG_CASES_ONEDASHBOARD",
							"filters": [combinedFilter],
							//"top": 100,
							//"skip": 0
						}]),
					contentType: "application/json",
					success: function (data) {
						var items = data.queryResults.CL_ENG_CASES_ONEDASHBOARD.rows;
						oModel.setData({ items: items });
						oModel.refresh();

						if (callback && typeof callback === "function") {
							callback();
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						console.log("Error while fetching data from API");

						if (callback && typeof callback === "function") {
							callback();
						}
					}
				});

			}
		},




	});
});