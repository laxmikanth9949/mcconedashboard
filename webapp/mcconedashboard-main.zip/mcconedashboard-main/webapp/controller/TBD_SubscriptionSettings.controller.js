sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"sap/ui/model/json/JSONModel",
	'sap/base/util/deepExtend',
	'sap/m/ColumnListItem',
	'sap/m/MultiInput',
	'sap/m/Select',
	'sap/m/MessageBox',
	'sap/m/MultiComboBox',
	'sap/m/Token',
	'sap/ui/model/Filter',
	"sap/ui/model/Sorter",
	'sap/ui/model/FilterOperator',
	"com/sap/mcconedashboard/control/CustomMultiInput"
], function (BaseController, JSONModel, deepExtend, ColumnListItem, MultiInput, Select, MessageBox, MultiComboBox, Token, Filter, Sorter,
	FilterOperator, CustomMultiInput) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.SubscriptionSettings", {
		iacValues: ["X", "Y", "9", "V", "I", "Z"],
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.mcconedashboard.view.SubscriptionSettings
		 */
		onInit: function () {
			var oSettings = this.getOwnerComponent().getModel("settings").getData();
			this._initBasicFeatures(oSettings);
		},
		_initBasicFeatures: function (oSettings) {
			//if authoritySet is not yet loadrd, call method until it is
			if (!oSettings.dataLoaded) {
				var that = this;
				setTimeout(function () {
					that._initBasicFeatures(oSettings);
				}, 200);
				return null;
			}
			var dfdFiltersModelLoaded = this.getFiltersValueSet();
			this.oTable = this.byId("idSettingsTable");
			this.debounceTimer = null;
			this.oFilters = {
				"Customer": "Customer",
				"GlobalUltimate": "Global Ultimate",
				"country": "Country",
				"subregion": "Region",
				"ProductCategory": "Product Category",
				"ProductLine": "Product Line",
				"Product": "Product",
				"caseID": "MCC Engagement ID",
				// "SupportEngagement":"Support Engagement",
				"SolutionArea": "MCC Solution"
			};
			this.oUpperFilters = {
				"CUSTOMER": this.oFilters["Customer"],
				"GLOBALULTIMATE": this.oFilters["GlobalUltimate"],
				"COUNTRY": this.oFilters["country"],
				"SUBREGION": this.oFilters["subregion"],
				"PRODUCTCATEGORY": this.oFilters["ProductCategory"],
				"PRODUCTLINE": this.oFilters["ProductLine"],
				"PRODUCT": this.oFilters["Product"],
				"CASEID": this.oFilters["caseID"],
				// "SupportEngagement":"Support Engagement",
				"SOLUTIONAREA": this.oFilters["SolutionArea"]
			};

			// this.oCustomerEngagement = {
			// 	"GEM": "Global Escalations",
			// 	"CCM": "Critical Customer Management"
			// };
			this.removedItems = [];
			this.aCustomerEngagement = [];
			//the GEM selection should only be available if user has access via profile to global Escalations
			// sales org specific AUTH should be handled by the additional auth check in the workbench app
			if (oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations) {
				this.aCustomerEngagement.push({
					ValueKey: "GEM",
					ValueText: "Global Escalations"
				});
			}
			this.aCustomerEngagement.push({
				ValueKey: "CCM",
				ValueText: "Critical Customer Management"
			});

			this.aCustomerEngagement.push({
				ValueKey: "CPC",
				ValueText: "Critical Period Coverage"
			});

			// [{ValueKey:"GEM",ValueText:"Global Escalations"},{ValueKey:"CCM",ValueText:"Critical Customer Management"}];
			this.oRegions = [{
				ValueKey: "WORLD",
				ValueText: "World"
			}, {
				ValueKey: "APJ",
				ValueText: "APJ"
			}, {
				ValueKey: "EMEA",
				ValueText: "EMEA"
			}, {
				// 	ValueKey: "EMEA_NORTH",
				// 	ValueText: "EMEA North"
				// }, {
				// 	ValueKey: "EMEA_SOUTH",
				// 	ValueText: "EMEA South"
				// }, {
				ValueKey: "GTC",
				ValueText: "GTC"
			}, {
				ValueKey: "LAC",
				ValueText: "LAC"
			}, {
				ValueKey: "MEE",
				ValueText: "MEE"
			}, {
				ValueKey: "NA",
				ValueText: "NA"
			}];
			this.aCustomers = [];
			var aFilters = [];
			for (var key in this.oFilters) {
				aFilters.push({
					ValueKey: key,
					ValueText: this.oFilters[key],
					enabled: key !== 'caseID'
				});
			}
			// var aObjectTypes = [];
			// for(var key in this.oCustomerEngagement){
			// 	aObjectTypes.push({key:key, text:this.oCustomerEngagement[key]});
			// }
			this.oViewModel = new JSONModel({
				editing: false,
				valueHelpDialogTitle: "",
				filters: aFilters,
				CustomerEngagement: this.aCustomerEngagement,
				regions: this.oRegions,
				country: [],
				productCategories: [],
				MCCSolution: [],
				productLines: [],
				products: [],
				customers: [],
				globalUltimates: []
			});
			this.oViewModel.setSizeLimit(500);
			this.oModel = new JSONModel({
				"settings": []
			});
			this.subModel = this.getModel("subModel");
			// this.subModel.attachRequestCompleted(function(){

			// },this);
			this.getView().setModel(this.oViewModel, "viewModel");
			this.getView().setModel(this.oModel);
			var suggestionModel = new JSONModel({
				"items": []
			});
			this.getView().setModel(suggestionModel, "suggestionModel");
			this.customerModel = new JSONModel({
				"customers": []
			});
			this.getView().setModel(this.customerModel, "customerModel");

			this.oReadOnlyTemplate = this.oTable.removeItem(0);
			this.rebindTable(this.oReadOnlyTemplate, "Navigation");
			var oItemTemplate = new sap.ui.core.Item({
				key: "{viewModel>ValueKey}",
				text: "{viewModel>ValueText}",
				enabled: "{viewModel>enabled}"
			});
			this.oEditableTemplate = new ColumnListItem({
				cells: [
					new Select({
						forceSelection: false,
						selectedKey: "{filterName}",
						enabled: "{= ${filterName} !== 'caseID' }",
						items: {
							path: "viewModel>/filters",
							template: oItemTemplate,
							templateShareable: true
						},
						change: function (oEv) {
							oEv.getSource().getParent().getCells()[1].getBindingContext().getObject().filterValue = []
							oEv.getSource().getParent().getCells()[1].getBindingContext().getModel().refresh()
						}.bind(this)
					}),
					new CustomMultiInput({
						value: "{filterValue}",
						type: "{filterName}",
						enabled: "{= ${filterName} !== 'caseID' }",
						valueHelpRequest: this.valueHelpRequest.bind(this),
						suggest: this.onSuggest.bind(this),
						suggestionItemSelected: this.onSuggestionItemSelected.bind(this)
					}),
					new MultiComboBox({
						selectedKeys: "{path:'CustomerEngagement'}",
						enabled: "{= ${filterName} !== 'caseID' }",
						items: {
							path: "viewModel>/CustomerEngagement",
							template: oItemTemplate,
							templateShareable: true,
						},
					})
				]
			});

			$.when(dfdFiltersModelLoaded).done(function () {
				this.loadRoles();
			}.bind(this));
		},
		getFilterTexts: function (settings) {
			var selectedFilters = settings;
			var oModel = this.getOwnerComponent().getModel();
			var aCustomerIDs = [];
			var aCustomerFilters = [];
			var aProducts = [];
			var aProductLines = [];
			var aCustomerFilters = [];
			var aProductFilters = [];
			var aProductLineFilters = [];
			selectedFilters.forEach(function (item) {
				if ((item.filterName === "Customer" || item.filterName === "GlobalUltimate") && item.filterValue.length) {
					item.filterValue.forEach(function (customer) {
						if (aCustomerIDs.indexOf(customer) === -1) {
							aCustomerFilters.push(new sap.ui.model.Filter("ErpCustNo", sap.ui.model.FilterOperator.EQ, customer));
							aCustomerIDs.push(customer);
						}
					});
				}
				if (item.filterName === "Product" && item.filterValue.length) {
					item.filterValue.forEach(function (product) {
						if (aProducts.indexOf(product) === -1) {
							aProductFilters.push(new sap.ui.model.Filter("ValueText", sap.ui.model.FilterOperator.EQ, product));
							aProducts.push(product);
						}
					});
				}
				if (item.filterName === "ProductLine" && item.filterValue.length) {
					item.filterValue.forEach(function (productLine) {
						if (aProductLines.indexOf(productLine) === -1) {
							aProductLineFilters.push(new sap.ui.model.Filter("ValueText", sap.ui.model.FilterOperator.EQ, productLine));
							aProductLines.push(productLine);
						}
					});
				}
			});
			if (aCustomerFilters.length) {
				var oCustomerFilter = new Array(
					new sap.ui.model.Filter(aCustomerFilters,
						false
					)
				);
				oModel.read("/CustomerSet", {
					urlParameters: {
						"$top": 999,
						"$select": "CustomerName,Name1,ErpCustNo,Iac,CountryT,GuErpNo"
					},
					filters: oCustomerFilter,
					success: function (data, response) {
						console.log(data);
						var that = this;
						this.aCustomers = [];
						data.results.forEach(function (customer) {
							that.aCustomers.push({
								ValueKey: customer.ErpCustNo,
								ValueText: customer.CustomerName + " - " + customer.CountryT
							});
							// this.aCustomers[customer.ErpCustNo] = customer;
						});
						this.customerModel.setProperty("/customers", this.aCustomers);
						this.oModel.refresh(true);
					}.bind(this)
				});
			}
			if (aProductFilters.length) {
				this.aProducts = [];
				for (var j = 0; j < aProductFilters.length; j++) {
					this.getOwnerComponent().getModel("mainModelNoBatch").read("/GenericFilterSet", {
						urlParameters: {},
						filters: [new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, "PRODUCT_FLT"), aProductFilters[j]],
						success: function (data) {
							console.log(data);
							var that = this;
							data.results.forEach(function (product) {
								that.aProducts.push({
									ValueKey: product.ValueKey,
									ValueText: product.ValueText
								});
							});
							this.oViewModel.setProperty("/products", this.aProducts);
							this.oModel.refresh(true);
						}.bind(this),
						error: function (data) {

						}.bind(this)
					});
				}

			}
			if (aProductLineFilters.length) {
				this.aProductLines = [];
				for (var j = 0; j < aProductLineFilters.length; j++) {
					this.getOwnerComponent().getModel("mainModelNoBatch").read("/GenericFilterSet", {
						urlParameters: {},
						filters: [new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, "PRODUCT_LINE_FLT"), aProductLineFilters[j]],
						success: function (data) {
							console.log(data);
							var that = this;
							data.results.forEach(function (productLine) {
								that.aProductLines.push({
									ValueKey: productLine.ValueKey,
									ValueText: productLine.ValueText
								});
							});
							this.oViewModel.setProperty("/productLines", this.aProductLines);
							this.oModel.refresh(true);
						}.bind(this),
						error: function (data) {

						}.bind(this)
					});
				}
			}
		},
		loadRoles: function () {
			sap.ui.core.BusyIndicator.show(1000);
			this.subModel.read("/MailRoles", {
				filters: [new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, this.getModel("userapi").getProperty("/name"))],
				sorters: [new sap.ui.model.Sorter("createdAt")],
				success: function (response) {
					var settings = [];
					this.oModel.setProperty("/settings", settings);
					for (var i = 0; i < response.results.length; i++) {
						var item = response.results[i];
						var filterItem = {};
						for (var filter in this.oFilters) {
							if (item[filter]) {
								filterItem.filterName = filter;
								// filterItem.filterValue = item[filter].split(",").map(function(v){
								// 	return {key:v}
								// });
								if (filter === "caseID") {
									filterItem.filterValue = item[filter]
								} else {
									filterItem.filterValue = item[filter].split(",");
								}
								break;
							}
						}
						if (item.CustomerEngagement) {
							filterItem.CustomerEngagement = item.CustomerEngagement.split(",");
						}

						filterItem.RoleID = item.RoleID;
						settings.push(filterItem);
					}
					//Busy indicator also must be hidden in case there are no subscriptions available
					sap.ui.core.BusyIndicator.hide();
					this.getFilterTexts(settings);
					this.oModel.setProperty("/settings", settings);
					this.oModel.refresh(true);
					this.aSettings = deepExtend([], settings);
					console.log(settings);
				}.bind(this),
				error: function (err) {
					console.log(err);
					//Busy indicator also must be hidden in case there is an error
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		getFiltersValueSet: function () {
			sap.ui.core.BusyIndicator.show(0);
			var dfd = jQuery.Deferred();
			var dfd1 = jQuery.Deferred();
			// var dfd2 = jQuery.Deferred();
			// var dfd3 = jQuery.Deferred();
			// var dfd4 = jQuery.Deferred();
			var dfd5 = jQuery.Deferred();
			var dfd6 = jQuery.Deferred();
			$.when(dfd1, dfd5, dfd6).done(function () {
				dfd.resolve();
				sap.ui.core.BusyIndicator.hide();
				// this.oModel.updateBindings(true);
			}.bind(this));
			var oModel = this.getModel();
			var oAppDepModel = this.getModel("appDepModelNoBatch");
			this.getOwnerComponent().getModel("mainModelNoBatch").read("/GenericFilterSet", {
				urlParameters: {
					"$top": 999
				},
				filters: [new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, "PRODUCT_CATEGORY_FLT"), new sap.ui.model.Filter(
					"ValueText", sap.ui.model.FilterOperator.EQ, "")],
				success: function (data) {
					console.log(data);
					this.oViewModel.setProperty("/productCategories", data.results);
					dfd1.resolve();
				}.bind(this),
				error: function (data) {

				}.bind(this)
			});
			this.getOwnerComponent().getModel("mainModelNoBatch").read("/GenericFilterSet", {
				urlParameters: {
					"$top": 300
				},
				filters: [new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, "COUNTRY_FLT")],
				success: function (data) {
					console.log("country", data);
					this.oViewModel.setProperty("/country", data.results);
					dfd5.resolve();
				}.bind(this),
				error: function (data) {

				}.bind(this)
			});
			oAppDepModel.read("/SolutionSet", {

				success: function (data) {
					console.log(data);
					this.oViewModel.setProperty("/MCCSolution", data.results);
					dfd6.resolve();
				}.bind(this),
				error: function (data) {

				}.bind(this)
			});
			return dfd;
		},
		rebindTable: function (oTemplate, sKeyboardMode) {
			var that = this;
			var sorter1 = new Sorter("filterName");
			sorter1.fnCompare = function (a, b) {
				var nameA = that.oUpperFilters[a];
				var nameB = that.oUpperFilters[b];
				if (!nameA || !nameB) {
					return 1;
				}
				var res = nameA.localeCompare(nameB);
				// console.log(a,that.oUpperFilters[a],b,that.oUpperFilters[b]);
				return res;
			};
			this.oTable.bindItems({
				path: "/settings",
				sorter: sorter1,
				template: oTemplate,
				templateShareable: true,
				key: "ProductId"
			}).setKeyboardMode(sKeyboardMode);
		},
		onEdit: function () {
			this.oViewModel.setProperty("/editing", true);
			this.rebindTable(this.oEditableTemplate, "Edit");
		},
		onCancel: function () {
			this.oViewModel.setProperty("/editing", false);
			this.oModel.setProperty("/settings", this.aSettings);
			this.rebindTable(this.oReadOnlyTemplate, "Navigation");
			this.removedItems = [];
		},
		valueHelpRequest: function (oEvent) {
			this._oMultiInput = oEvent.getSource();
			var sFilter = this._oMultiInput.getName();
			this.oViewModel.setProperty("/valueHelpDialogTitle", this.oFilters[sFilter]);
			var sPath = "";
			if (sFilter === "ProductLine") {
				sPath = "productLines";
			}
			if (sFilter === "Product") {
				sPath = "products";
			}
			if (sFilter === "Customer") {
				sPath = "customers";
			}
			if (sFilter === "GlobalUltimate") {
				sPath = "globalUltimates";
			}
			var aCols = [{
				"label": "Description",
				"template": "viewModel>ValueText"
			}];
			var oColModel = new JSONModel({
				cols: aCols
			});
			this._oBasicSearchField = new sap.m.SearchField({
				search: this.onFilterBarSearch.bind(this)
			});
			this._oValueHelpDialog = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.SubscriptionSettingValueHelpDialog", this);
			this.getView().addDependent(this._oValueHelpDialog);
			var oFilterBar = this._oValueHelpDialog.getFilterBar();
			oFilterBar.setFilterBarExpanded(false);
			oFilterBar.setBasicSearch(this._oBasicSearchField);
			this._oValueHelpDialog.getTableAsync().then(function (oTable) {
				oTable.setModel(oColModel, "columns");

				if (oTable.bindRows) {
					oTable.bindAggregation("rows", "viewModel>/" + sPath);
				}

				if (oTable.bindItems) {
					oTable.bindAggregation("items", "viewModel>/" + sPath, function () {
						return new ColumnListItem({
							cells: aCols.map(function (column) {
								return new sap.m.Label({
									text: "{" + column.template + "}"
								});
							})
						});
					});
				}
				this._oValueHelpDialog.update();
			}.bind(this));

			this._oValueHelpDialog.setTokens(this._oMultiInput.getTokens());
			this._oValueHelpDialog.open();
		},
		filterChange: function (oEvent) {
			var oSelectedItem = oEvent.getParameters().selectedItem;
			var bindingPath = oSelectedItem.getBindingContext().getPath();
			// var selectedFilters = this.oModel.getData().settings;
			// var aFilters = this.oViewModel.getData().filters;
			// var aSelectedFiftersName = selectedFilters.map(function(filterItem){
			// 	return filterItem.filterName;
			// });
			// aFilters.forEach(function(item){
			// 	if(aSelectedFiftersName.indexOf(item.key) !== -1){
			// 		item.enabled = false;
			// 	}else{
			// 		item.enabled = true;
			// 	}
			// });
			this.oModel.setProperty(bindingPath + "/filterValue", []);
			this.oModel.setProperty(bindingPath + "/CustomerEngagement", []);
			this.oViewModel.refresh();
		},
		formatFilter: function (filterKey) {
			if (this.oFilters) {
				return this.oFilters[filterKey];
			}
		},
		formatObjectTypes: function (objectType) {
			return this.formatFilterValue("CustomerEngagement", objectType);
			// var aValues = [];
			// if(Array.isArray(objectType)){
			// 	aValues = objectType.map(function(v){
			// 		return this.oCustomerEngagement[v];
			// 	}.bind(this));
			// }

			// return aValues.join(", ");
		},
		// formatSelectedKeys: function(keyObjects){
		// 	return keyObjects.map(function(obj){
		// 		return obj.key;
		// 	});
		// },
		formatFilterValue: function (filterName, filterValue) {
			var aFilterValue = [];
			var oSetData;
			var oViewData = null;
			if (this.oViewModel) {
				oViewData = this.oViewModel.getData();
			}
			if (oViewData && filterValue) {
				if (Array.isArray(filterValue)) {
					aFilterValue = filterValue.map(function (v) {
						if (typeof v == "string") {
							var keyName = "ValueKey";
							var textName = "ValueText";

							if (filterName === "CustomerEngagement") {
								oSetData = this.aCustomerEngagement;
							}
							if (filterName === "SolutionArea") {
								oSetData = oViewData.MCCSolution;
								keyName = "SolKey";
								textName = "Description";
							}
							if (filterName === "ProductCategory") {
								oSetData = oViewData.productCategories;
							}
							if (filterName === "subregion") {
								oSetData = oViewData.regions;
							}

							if (filterName === "country") {
								oSetData = oViewData.country;
							}
							if (filterName === "ProductLine") {
								oSetData = oViewData.productLines;
							}
							if (filterName === "Product") {
								oSetData = oViewData.products;
							}
							if (filterName === "Customer" || filterName === "GlobalUltimate") {
								oSetData = this.customerModel.getProperty("/customers");
							}
							for (var i = 0; i < oSetData.length; i++) {
								if (oSetData[i][keyName] === v) {
									return oSetData[i][textName];
								}
							}
						}
						// if(typeof v == "object"){
						// 	if(filterName === "Product"){
						// 		oSetData = oViewData.products;
						// 	}

						// 	for(var i=0;i<oSetData.length;i++){
						// 		if(oSetData[i].ValueKey === v.key){
						// 			return oSetData[i].ValueText;
						// 		}
						// 	}
						// }
						return "";
					}.bind(this));
					return aFilterValue.join(", ");
				} else if (typeof filterValue == "string" || typeof filterValue == "number") {
					return filterValue;
				}
			}
			return "";
		},
		onFilterBarSearch: function (oEvent) {
			var sSearchQuery = this._oBasicSearchField.getValue();

			this._filterTable(new Filter({
				path: "ValueText",
				operator: FilterOperator.Contains,
				value1: sSearchQuery
			}));
		},
		_filterTable: function (oFilter) {
			var oValueHelpDialog = this._oValueHelpDialog;

			oValueHelpDialog.getTableAsync().then(function (oTable) {
				if (oTable.bindRows) {
					oTable.getBinding("rows").filter(oFilter);
				}

				if (oTable.bindItems) {
					oTable.getBinding("items").filter(oFilter);
				}

				oValueHelpDialog.update();
			});
		},
		onValueHelpOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var sFilterName = this._oMultiInput.getName();
			var sPath = this._oMultiInput.getBindingContext().getPath();
			// this._oMultiInput.setTokens(aTokens);
			if (aTokens && aTokens.length) {
				var aFilterValue = aTokens.map(function (tk) {
					return tk.getKey();
				});
				this.oModel.setProperty(sPath + "/filterValue", aFilterValue);
			}

			this._oValueHelpDialog.close();
		},

		onValueHelpCancelPress: function () {
			this._oValueHelpDialog.close();
		},

		onValueHelpAfterClose: function () {
			this._oValueHelpDialog.destroy();
		},
		onSuggest: function (oEvent) {
			var oInput = oEvent.getSource();
			this._oMultiInput = oInput;
			var sValue = oEvent.getParameter("suggestValue");
			var sType = oEvent.getParameter("type");
			var oModel = this.getOwnerComponent().getModel();
			// reset suggestionItems list
			if (this.getView().getModel("suggestionModel")) {
				this.getView().getModel("suggestionModel").setProperty("/items", []);
			}
			if (sValue === "") {
				return null;
			}
			//show busy indicator
			oInput.setBusyIndicatorDelay(0);
			oInput.setBusy(true);

			if (sType === "Customer" || sType === "GlobalUltimate") {
				var oFilter = new Array(
					new sap.ui.model.Filter([
							new sap.ui.model.Filter("CustomerName", sap.ui.model.FilterOperator.Contains, sValue),
							new sap.ui.model.Filter("ErpCustNo", sap.ui.model.FilterOperator.EQ, sValue),
							new sap.ui.model.Filter("Partner", sap.ui.model.FilterOperator.EQ, sValue)
						],
						false
					)
				);
				oModel.read("/CustomerSet", {
					urlParameters: {
						"$top": 999,
						"$select": "CustomerName,ErpCustNo,Iac,CountryT,GuErpNo,IsGlobalUltimate"
					},
					filters: oFilter,
					success: function (data, response) {
						oInput.setBusy(false);
						var aCustomerData = [];
						//push data to array
						data.results.forEach(function (customer) {
							var visible = sType === "Customer" ? true : customer.IsGlobalUltimate === "X";
							if (visible) {
								aCustomerData.push({
									text: customer.CustomerName,
									key: customer.ErpCustNo,
									filterProp: customer.IsGlobalUltimate === "X" ? "Global Ultimate" : "Customer",
									iac: this.iacValues.indexOf(customer.Iac) > -1 ? customer.Iac : "ZZZZZ",
									description: " - " + customer.CountryT //"(" + customer.CountryT + ")"
								});
							}

						}.bind(this));

						this.iacValues.push("ZZZZZ");

						//sort array by filterProp and iac
						aCustomerData = aCustomerData.sort(function (a, b) {
							if (this.iacValues.indexOf(a.iac) < this.iacValues.indexOf(b.iac)) {
								return -1;
							} else if (this.iacValues.indexOf(a.iac) > this.iacValues.indexOf(b.iac)) {
								return 1;
							} else if (b.filterProp < a.filterProp) {
								return -1;
							} else if (b.filterProp > a.filterProp) {
								return 1;
							} else if (b.text > a.text) {
								return -1;
							} else if (b.text < a.text) {
								return 1;
							} else if (b.description > a.description) {
								return -1;
							} else if (b.description < a.description) {
								return 1;
							}
							return 0;
						}.bind(this));

						for (var i = 0; i < aCustomerData.length; i++) {
							if (i === 0) {
								aCustomerData[i].isTopMatch = true;
							} else if ((i === 1 || i === 2) && aCustomerData[i].iac !== "ZZZZZ") {
								aCustomerData[i].isTopMatch = true;
							} else if (i > 2 && i < 5 && aCustomerData[i].iac !== "ZZZZZ" && aCustomerData[i].iac === aCustomerData[(i - 1)].iac) {
								aCustomerData[i].isTopMatch = true;
							} else {
								aCustomerData[i].isTopMatch = false;
							}
						}

						this.getView().getModel("suggestionModel").setProperty("/items", aCustomerData);
						// oInput.suggest();
					}.bind(this)
				});
			} else if (sType === "Product") {
				this.getOwnerComponent().getModel("mainModelNoBatch").read("/GenericFilterSet", {
					urlParameters: {
						"$top": 999
					},
					filters: [new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, "PRODUCT_FLT"), new sap.ui.model.Filter(
						"ValueText", sap.ui.model.FilterOperator.Contains, sValue)],
					success: function (data) {
						oInput.setBusy(false);
						console.log(data);
						var aProductData = [];
						//push data to array
						data.results.forEach(function (product) {
							aProductData.push({
								text: product.ValueText,
								key: product.ValueKey
							});
						}.bind(this));
						this.getView().getModel("suggestionModel").setProperty("/items", aProductData);
					}.bind(this),
					error: function (data) {

					}.bind(this)
				});
			} else if (sType === "ProductLine") {
				this.getOwnerComponent().getModel("mainModelNoBatch").read("/GenericFilterSet", {
					urlParameters: {
						"$top": 999
					},
					filters: [new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, "PRODUCT_LINE_FLT"), new sap.ui.model.Filter(
						"ValueText", sap.ui.model.FilterOperator.Contains, sValue)],
					success: function (data) {
						oInput.setBusy(false);
						console.log(data);
						var aProductLineData = [];
						//push data to array
						data.results.forEach(function (productLine) {
							aProductLineData.push({
								text: productLine.ValueText,
								key: productLine.ValueKey
							});
						}.bind(this));
						this.getView().getModel("suggestionModel").setProperty("/items", aProductLineData);
					}.bind(this),
					error: function (data) {

					}.bind(this)
				});
			}
		},
		onSuggestionItemSelected: function (e) {
			this.getView().getModel("suggestionModel").setProperty("/items", []);
			var sFilterName = this._oMultiInput.getName();
			var sPath = this._oMultiInput.getBindingContext().getPath();
			var aTokens = this._oMultiInput.getTokens();
			var that = this;
			if (aTokens && aTokens.length) {
				var aFilterValue = aTokens.map(function (tk) {
					if (sFilterName === "Customer" || sFilterName === "GlobalUltimate") {
						var aCustomers = that.customerModel.getProperty("/customers");
						aCustomers.push({
							ValueKey: tk.getKey(),
							ValueText: tk.getText()
						});
						that.customerModel.setProperty("/customers", aCustomers);
					} else if (sFilterName === "ProductLine") {
						var aProductLines = that.oViewModel.getProperty("/productLines");
						aProductLines.push({
							ValueKey: tk.getKey(),
							ValueText: tk.getText()
						});
						that.oViewModel.setProperty("/productLines", aProductLines);
					} else if (sFilterName === "Product") {
						var aProducts = that.oViewModel.getProperty("/products");
						aProducts.push({
							ValueKey: tk.getKey(),
							ValueText: tk.getText()
						});
						that.oViewModel.setProperty("/products", aProducts);
					}

					return tk.getKey();
				});
				this.oModel.setProperty(sPath + "/filterValue", aFilterValue);
			}
		},
		onAdd: function () {
			var newItem = {
				"filterName": "",
				"CustomerEngagement": [],
				"filterValue": []
			};
			var settings = this.oModel.getProperty("/settings");
			this.oModel.setProperty("/settings", settings.concat(newItem));
		},
		onDelete: function (oEvent) {
			var item = oEvent.getParameters().listItem;
			var bindingPath = item.getBindingContextPath();
			var idx = bindingPath.split("/")[2];
			var settings = this.oModel.getProperty("/settings");
			if (settings[idx].RoleID) {
				this.removedItems.push(settings[idx].RoleID);
			}
			settings.splice(idx, 1);
			this.oModel.setProperty("/settings", settings);
		},
		_afterSave: function () {
			var that = this;
			if (this.debounceTimer) {
				clearTimeout(this.debounceTimer);
			}

			this.debounceTimer = setTimeout(function () {
				var settings = that.oModel.oData.settings;
				var oSubModel = that.getModel("subModel");
				that.aSettings = deepExtend([], settings);
				sap.ui.core.BusyIndicator.hide();
				that.removedItems = [];
				MessageBox.success(
					"Changes have been successfully saved.", {
						styleClass: "sapUiSizeCompact",
						onClose: function (oAction) {
							that.onCancel();
							that.loadRoles();
						}
					}
				);
			}, 100);

		},
		onSave: function () {
			this.trackEvent("Subscription: Settings view - Add");
			var settings = this.oModel.oData.settings;
			var oSubModel = this.getModel("subModel");
			this.removedItems.forEach(function (RoleID) {
				oSubModel.remove("/MailRoles(guid'" + RoleID + "')", {
					success: function (response) {
						this._afterSave();
					}.bind(this),
					error: function (err) {
						console.log(err)
					}
				});
			}.bind(this));
			for (var i = 0; i < settings.length; i++) {
				var item = settings[i];
				var hasFilterValue = Array.isArray(item.filterValue) && item.filterValue.length || typeof item.filterValue == "string" && item.filterValue ||
					typeof item.filterValue == "number";
				var hasCE = false;
				if (item.CustomerEngagement) {
					hasCE = item.CustomerEngagement.length > 0;
				}
				if (!hasFilterValue || !hasCE) {
					MessageBox.warning(
						"All fields are mandatory, please check.", {
							styleClass: "sapUiSizeCompact"
						}
					);
					return false;
				}
			}
			settings.forEach(function (item) {
				sap.ui.core.BusyIndicator.show(0);
				var filterValue = "";
				if (Array.isArray(item.filterValue)) {
					filterValue = item.filterValue.join(",");
				} else {
					filterValue = item.filterValue;
				}
				if (!item.RoleID) {
					oSubModel.create("/MailRoles", {
						RoleType: "SUB",
						Recipients: this.getModel("userapi").getProperty("/email"),
						UserID: this.getModel("userapi").getProperty("/name"),
						CustomerEngagement: item.CustomerEngagement.join(","),
						[item.filterName]: filterValue
					}, {
						success: function (response) {
							this._afterSave();
						}.bind(this),
						error: function (err) {
							console.log(err)
						}
					});
				}
				if (item.RoleID) {
					var oRole = {
						RoleID: item.RoleID,
						CustomerEngagement: item.CustomerEngagement.join(","),
						[item.filterName]: filterValue
					};
					for (var key in this.oFilters) {
						if (key !== item.filterName) {
							oRole[key] = null;
						}
					}
					oSubModel.update("/MailRoles(guid'" + item.RoleID + "')", oRole, {
						success: function (response) {
							this._afterSave();
						}.bind(this),
						error: function (err) {
							console.log(err)
						}
					});
				}
			}.bind(this));

			// this.getModel("subModel").create("/MailRoles", oRole, {
			// 	success: function (response) {
			// 		console.log(response)
			// 	},
			// 	error: function (err) {
			// 		console.log(err)
			// 	}
			// });
		},
		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.sap.mcconedashboard.view.Global
		 */
		onAfterRendering: function () {
			//	this.loadRoles();
		},

		onBeforeRendering: function () {
			this.loadRoles();
		}

	});

});