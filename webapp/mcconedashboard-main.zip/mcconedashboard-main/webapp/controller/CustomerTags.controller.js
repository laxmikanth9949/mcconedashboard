sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"./../connector/TranslationConnector",
	"sap/m/MessageBox",
	"sap/base/Log",

], function (BaseController, formatter, Filter, FilterOperator, MessageToast,TranslationConnector, MessageBox, Logger) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.CustomerTags", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				bLoadingState: false,
				bLoadingStateAISummary: false,
			}), "viewModel");

			this.DebugMode = false;

		},

		onAfterRendering: function () {
			if (this.getRouter().getRoute("CustomerTags")) {
				this.getRouter().getRoute("CustomerTags").attachPatternMatched(this._onObjectMatched, this);
			}

		},

		_onObjectMatched: function (oEvent) {
			var oArgs = oEvent.getParameter("arguments");
			var sTagsParam = oArgs["?query"].tags;
			var that = this;

			if (sTagsParam !== undefined && sTagsParam !== null) {
				// Der Parameter "tags" ist vorhanden und nicht null oder undefined
				var aTags = sTagsParam.split(",").map(tag => tag.trim().toLowerCase());
				this._readCustomersWithTags(aTags);
				this._handleMissionRadarAndAnonymizedMode(oArgs);
				this._handleFeatureFlags(oArgs, function (flags) {
					if (flags.showAiSummary !== true) {
						var oTable = that.byId("tagsTable");
						var oColumn = that.byId("customerTagsAiSummaryColumn");
						oTable.removeColumn(oColumn);
					}
				});

			} else {
				console.log("No 'tags' parameter set.");
			}
			this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "tagData");
		},

		_readCustomersWithTags: function (aTags) {
			var oSubModel = this.getOwnerComponent().getModel("subModel");
			var aMCCTagsFilters = [];
			var that = this;

			// Immer nach Type "Customer" filtern
			aMCCTagsFilters.push(new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "Customer"));

			// Nach Einträgen mit den gesetzten Tags suchen
			if (aTags && Array.isArray(aTags) && aTags.length > 0) {
				var aNameFilters = aTags.map(function (tag) {
					return new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.EQ, tag);
				});
				aMCCTagsFilters.push(new sap.ui.model.Filter(aNameFilters, false));
			}

			oSubModel.read("/MCCTags", {
				filters: aMCCTagsFilters,
				success: function (data) {
					that.updateCriticalCustomers(data);
				},
				error: function (error) {

				}
			});
		},

		updateCriticalCustomers: function (aTags) {
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = new sap.ui.model.json.JSONModel();
			this.getOwnerComponent().setModel(oModel, "tagData");

			var that = this;

			// Read Customer Data Based on Tags
			this.readCustomerData(oModel, aTags, function (customerData) {
				// Fusion von Kundeninformationen mit aTags-Daten
				if (aTags && aTags.results && aTags.results.length > 0) {
					customerData.forEach(function (customer) {
						var customerID = customer.ErpCustNo;
						var matchedTags = aTags.results.filter(function (tag) {
							return tag.CustomerID === customerID;
						});
						if (matchedTags.length > 0) {
							customer.Tags = matchedTags;
							customer.AllTags = matchedTags.map(function (tag) {
								return tag.Title;
							}).join(", ");
						}
					});
				}

				that.readMissionRadarCriticalCustomers(oModel, aTags, function (data) {
					if (data && data.length > 0) {
						var mergedData = customerData.slice(); // Clone customerData array

						data.forEach(function (item) {
							// Remove leading zeros from ERP_Account key
							var erpAccountKey = item.ERP_Account.key.replace(/^0+/, '');

							// Find the matching customer in customerData array
							var matchedCustomerIndex = mergedData.findIndex(function (customer) {
								return customer.ErpCustNo === erpAccountKey;
							});

							if (matchedCustomerIndex !== -1) {
								var matchedCustomer = mergedData[matchedCustomerIndex];

								// Check if the new item's SNAPSHOT_DATE is newer
								if (!matchedCustomer.MissionRadar || item.SNAPSHOT_DATE.key > matchedCustomer.MissionRadar.SNAPSHOT_DATE.key) {
									// Update the customer with the new item's data
									matchedCustomer.MissionRadar = {
										MCCiRounded: Math.round(item.MCCI.value),
										TrendRounded: Math.round(item.TREND_28_DAYS.value),
										SNAPSHOT_DATE: item.SNAPSHOT_DATE,
										preventionScore: item.preventionScore,
										preventionScoreColor: item.preventionScoreColor,
										preventionScoreDesc: item.preventionScoreDesc,
										preventionScoreIcon: item.preventionScoreIcon

									};
									that.addTrendCalculations(matchedCustomer.MissionRadar, that);
								}
							}
						});
					} else {
						var mergedData = customerData;
					}

					oModel.setData({ items: mergedData });
					oModel.refresh();
					that.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				});
			});
		},


		readCustomerData: function (oModel, aTags, callback) {
			if (aTags.results.length > 0) {
				var customerIDs = this.extractCustomerIDs(aTags);
				var aCustomerFilters = [];

				customerIDs.forEach(function (customerID) {
					aCustomerFilters.push(new sap.ui.model.Filter("ErpCustNo", sap.ui.model.FilterOperator.EQ, customerID));
				});

				var oCustomerFilter;
				if (aCustomerFilters.length) {
					oCustomerFilter = new sap.ui.model.Filter({
						filters: aCustomerFilters,
						and: false
					});
				}

				var oCCModel = this.getOwnerComponent().getModel("mainModelNoBatch");
				oCCModel.read("/CustomerSet", {
					urlParameters: {
						"$select": "CustomerName,Name1,ErpCustNo,CountryT,Gu,GuErpNo,GuName,GuName1,IsGlobalUltimate,MasterCodeT,RegionT"
					},
					filters: aCustomerFilters,
					success: function (data) {
						var items = data.results;
						if (callback && typeof callback === "function") {
							callback(items);
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						sap.m.MessageToast.show("Error while fetching MCCI data from API");
						if (callback && typeof callback === "function") {
							callback();
						}
					}
				});
			} else {

				if (callback && typeof callback === "function") {
					callback();
				}
			}
		},


		addTrendCalculations: function (item, that) {
			var sTempHighestMCCi = parseFloat("0");
			var aTempHighestTrend;
			var sTempLowestPreventionScore = parseFloat("100");

			if (item.MCCiRounded > parseFloat(sTempHighestMCCi)) {
				sTempHighestMCCi = item.MCCiRounded;
			}
			if (!aTempHighestTrend || item.TrendRounded > parseFloat(aTempHighestTrend)) {
				aTempHighestTrend = item.TrendRounded;
			}
			if (item.PreventionScoreRounded < parseFloat(sTempLowestPreventionScore)) {
				sTempLowestPreventionScore = item.PreventionScoreRounded;
			}

			item.preventionScore = Math.round(aTempHighestTrend);
			item.preventionScoreDesc = that.formatter._formatTrendDesc(Math.round(aTempHighestTrend));
			item.preventionScoreColor = that.formatter._formatTrendColor(Math.round(aTempHighestTrend));
			item.preventionScoreIcon = that.formatter._formatTrendIcon(Math.round(aTempHighestTrend));
		},

		readMissionRadarCriticalCustomers: function (oModel, aTags, callback, bNoData) {
			var that = this;
			if (aTags.results.length > 0) {
				var customerIDs = this.extractCustomerIDsWithZeros(aTags);


				if (this.DebugMode == true) {

					//DEVELOPMENT
					$.ajax({
						url: "./json/CustomerView/CustomerTagsListExample.json",
						type: "GET",
						dataType: "json",
						success: function (data) {
							var items = data.queryResults.CL_MCCI_V2_CURRENT.rows;

							if (callback && typeof callback === "function") {
								callback(items);
							}
						},
						error: function (xhr, textStatus, errorThrown) {
							console.log("Can't read JSON");

							if (callback && typeof callback === "function") {
								callback();
							}
						}
					});

				} else {

					//we need submit todays date in format "2022-09-23" to get the current values
					var today = new Date(); //("2022-10-28");
					var yesterday = new Date(today);
					yesterday.setDate(today.getDate() - 1); // Subtract 1 day from today's date
					var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
						pattern: "yyyy-MM-dd" // we need a format like 2022-12-24
					});
					today = oFormat.format(today);
					yesterday = oFormat.format(yesterday);
					var filterCondition;

					if (bNoData === true) {
						filterCondition = {
							operand1: { elementIdentifier: "SNAPSHOT_DATE" },
							operand2: { values: [yesterday] },
							operator: "EQ"
						};
					} else {
						filterCondition = {
							operand1: { elementIdentifier: "SNAPSHOT_DATE" },
							operand2: { values: [today] },
							operator: "EQ"
						};
					}

					var combinedFilter = {
						filters: [filterCondition]
					};

					var customerFilter = {
						operator: "EQ",
						operand1: { elementIdentifier: "ERP_Account" },
						operand2: { values: customerIDs }
					};

					combinedFilter.filters.push(customerFilter);

					$.ajax({
						method: "POST",
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3",
						data: JSON.stringify([
							{
								"queryIdentifier": "CL_MCCI_V2_CURRENT",
								"elementList": [
									"SNAPSHOT_DATE", "CUSTOMER_ID", "ERP_Account", "Global_Ultimate", "Internal_Sales_Segment", "Global_Ultimate_Name", "MCCI", "TREND_28_DAYS", "TREND_3_DAYS", "CCM_CASES", "CPC_CASES", "TF_CASES", "TC2_CASES", "GEM_CASES", "OPEN_NOW_P1", "OPEN_NOW_P2", "MCC_SOL_AREA", "MCC_SOL_AREA_RANK"
								],
								"filters": [combinedFilter],
								"skip": 0
							}]),
						contentType: "application/json",
						success: function (data) {
							if (data.queryResults.CL_MCCI_V2_CURRENT && data.queryResults.CL_MCCI_V2_CURRENT.rows.length > 0) {
								var items = data.queryResults.CL_MCCI_V2_CURRENT.rows;

								//If there are items for today, use those
								if (items && items.length > 0) {

									// Check if all rows in MCCI field have value 0
									var allMCCIValuesZero = items.every(function (row) {
										return row.MCCI.value === 0;
									});

									if (allMCCIValuesZero && (!bNoData || bNoData === false)) {
										//If there are no MCCI values in the items, recall the function with new parameter bNoData = true
										that.readMissionRadarCriticalCustomers(oModel, aTags, callback, true);
									} else {
										if (callback && typeof callback === "function") {
											callback(items);
										}
									}
								}

							} else if (!bNoData || bNoData === false) {
								//Try finding MCCI Values from yesterday if there is no entries for today
								that.readMissionRadarCriticalCustomers(oModel, aTags, callback, true);
							} else {
								console.log("No MCCI Data for today and yesterday");
								if (callback && typeof callback === "function") {
									callback();
								}
							}
						},
						error: function (xhr, textStatus, errorThrown) {
							console.log("Error while fetching data from API");

							if (callback && typeof callback === "function") {
								callback();
							}
						}
					});

				}
			} else {
				if (callback && typeof callback === "function") {
					callback();
				}
			}

		},



		onCustomer: function (oEv) {
			var sCustomerErpNo = oEv.getSource().getBindingContext("tagData").getObject().ErpCustNo;
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("Customer", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		onOpenUser: function (oEv) {
			if (oEv.getSource().data("userid")) {
				this.formatter.openUser(oEv, oEv.getSource().data("userid"));
			}
		},

		extractCustomerIDs: function (aTags) {
			if (aTags && aTags.results && Array.isArray(aTags.results)) {
				var customerIDsMap = {};
				aTags.results.forEach(function (tag) {
					//var formattedCustomerID = this._addLeadingZeros(tag.CustomerID);
					var formattedCustomerID = tag.CustomerID;
					customerIDsMap[formattedCustomerID] = true;
				}, this);
				return Object.keys(customerIDsMap);
			} else {
				return [];
			}
		},

		extractCustomerIDsWithZeros: function (aTags) {
			if (aTags && aTags.results && Array.isArray(aTags.results)) {
				var customerIDsMap = {};
				aTags.results.forEach(function (tag) {
					var formattedCustomerID = this._addLeadingZeros(tag.CustomerID);
					customerIDsMap[formattedCustomerID] = true;
				}, this);
				return Object.keys(customerIDsMap);
			} else {
				return [];
			}
		},

		loadAiSummaryForCustomer: function (oEv) {
			this.getView().getModel("viewModel").setProperty("/bLoadingStateAISummary", true);
			var oData = oEv.getSource().getBindingContext("tagData").getObject();
			var sErpCustNo = oData.ErpCustNo;
			var oFeatureFlagsModel = this.getModel("featureFlags");
			if (!this.getView().getModel("oLanguageModel")) {
				var oLanguageModel = TranslationConnector.createLanguageModel(this.getView().getModel("userProfile"));
				this.getView().setModel(oLanguageModel, "oLanguageModel");
			}

			// Check if there is already an AISummary
			if (oData && !oData.AISummary) {
				// Use the ScenarioID from the ccsPreview FeatureFlag
				if (oFeatureFlagsModel && oFeatureFlagsModel.getProperty("/ccsPreview") && (oFeatureFlagsModel.getProperty("/ccsPreview") !== true) ) {
					var requestData = {
						//"inputID": sErpCustNo, OLD APPROACH
						"ScenarioID": oFeatureFlagsModel.getProperty("/ccsPreview"),
						"CustomBody": {
							"jsonEncoded": "{\"customerID\":\""+sErpCustNo+"\"}"
						}
					};
					var mcccacheKey = oFeatureFlagsModel.getProperty("/ccsPreview") + "_" + sErpCustNo;
				} else {
					var requestData = {
						//"inputID": sErpCustNo,
						"ScenarioID": "9649ee30-0204-4e9c-aaf8-04a96ff0cc07",
						"CustomBody": {
							"jsonEncoded": "{\"customerID\":\""+sErpCustNo+"\"}"
						}
					};
					var mcccacheKey = "9649ee30-0204-4e9c-aaf8-04a96ff0cc07_" + sErpCustNo;
				}

				sap.m.MessageToast.show(this.getView().getModel("i18n").getProperty("customerIntelligentSummaryFetchingAI"));
				var ajaxPromise = new Promise(function (resolve, reject) {
					$.ajax({
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/mcc-aimanager/odata/v4/MCCAIManager/processScenario", //"/apimcf/mcc-aiservice/odata/v4/MCCAIManagerService/getAISummary",
						method: "POST",
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU" //,
							//"mcccachekey": mcccacheKey
						},

						contentType: "application/json",
						data: JSON.stringify(requestData),
						success: function (data, textStatus, jqXHR) {
							resolve(data);
						},
						error: function (oError) {
							Logger.error("Error while retrieving AI Summary", "", "", oError);
							sap.m.MessageBox.error(oError.responseJSON.error.message + "Can't reach AI-Service currently. Please try again later.", {
								title: "Error " + oError.status
							});
							reject(oError);
						}
					});
				});

				// Wait for Response
				ajaxPromise.then(function (data) {
					oData.AISummary = data;
					this.openStatusReportPopover(oEv);
					this.getView().getModel("viewModel").setProperty("/bLoadingStateAISummary", false);
				}.bind(this)).catch(function (error) {
					console.error("Can't load GPT Response:", error);
					this.getView().getModel("viewModel").setProperty("/bLoadingStateAISummary", false);
				}.bind(this));
			} else if ((oData && oData.AISummary)) {
				this.openStatusReportPopover(oEv);
				this.getView().getModel("viewModel").setProperty("/bLoadingStateAISummary", false);
			}
		},

		openStatusReportPopover: function (oEv) {
			var oData = oEv.getSource().getBindingContext("tagData").getObject();
			var sMessage;
			var oAISummary;
			if (oData.AISummary) {
				sMessage = oData.AISummary.responseText;
				oAISummary = oData.AISummary;
			} else {
				sMessage = "Can't load AI Summary for this customer"
			}

			if (!oData.AISummary.responseID) {
				this.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", true);
				this.getView().getModel("viewModel").setProperty("/AISummaryFeedbackValue", 0);
			} else {
				this.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", false);
				this.getView().getModel("viewModel").setProperty("/AISummaryFeedbackValue", 0);
			}

			if (!this.openGPTReportPopover) {
				this.openGPTReportPopover = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.GPTReport", this);
				this.getView().addDependent(this.openGPTReportPopover);
			}
			oData.sMessage = sMessage;
			oData.sOriginalMessage = sMessage;
			oData.bIsTranslated = false;
			oData.oAISummary = oAISummary;
			this.openGPTReportPopover.setModel(new sap.ui.model.json.JSONModel(
				oData
			), "data");
			this.openGPTReportPopover.openBy(oEv.getSource());
			this.trackEvent("AI Summary: show Popover");
		},

		handleFeedbackChange: function (oEv) {
			this.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", true);
			var iRating = oEv.getParameter("value");
			var oModel = oEv.getSource().getModel("data");
			var oFeatureFlagsModel = this.getModel("featureFlags");
			var that = this;
			if (oModel.getProperty("/oAISummary")) {
				var sResponseID = oModel.getProperty("/oAISummary/responseID");

				if (sResponseID) {
					this.trackEvent("AI Summary: Feedback");
					// Use the ScenarioID from the ccsPreview FeatureFlag
					if (oFeatureFlagsModel && oFeatureFlagsModel.getProperty("/ccsPreview") && (oFeatureFlagsModel.getProperty("/ccsPreview") !== true)) {
						var requestData = {
							"Body": {
								"scenarioID": oFeatureFlagsModel.getProperty("/ccsPreview"),
								"xPlainID": sResponseID,
								"rating": iRating,
								"comment": ""
							}
						};
					} else {
						var requestData = {
							"Body": {
								"scenarioID": "9649ee30-0204-4e9c-aaf8-04a96ff0cc07",
								"xPlainID": sResponseID,
								"rating": iRating,
								"comment": ""
							}
						};
					}

					$.ajax({
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/mcc-aimanager/odata/v4/MCCAIManager/postFeedback",
						method: "POST",
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						contentType: "application/json",
						data: JSON.stringify(requestData),
						success: function (textStatus, jqXHR) {
							that.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", true);
							sap.m.MessageToast.show("Feedback submitted successfully");
						},
						error: function (jqXHR, textStatus, errorThrown) {
							that.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", false);
							console.error("Can't load GPT Response:", textStatus, errorThrown);
							sap.m.MessageToast.show("Feedback could not be submitted");
						}
					});
				}

			} else {
				that.getView().getModel("viewModel").setProperty("/bAISummaryDisplayOnly", true);
			}
		},
		handleTranslationPress: async function(oEv) {
			let translation;
			let oDataModel = this.openGPTReportPopover.getModel("data");
			let oLanguageModel = this.getView().getModel("oLanguageModel");
			let sSelectedKey = oLanguageModel.getProperty("/preselectedOption");
			if(oDataModel.oData.bIsTranslated){
			   oDataModel.oData.sMessage = oDataModel.oData.sOriginalMessage;
			   oDataModel.oData.bIsTranslated = false;
			}else{
			   	try {
				  	translation = await TranslationConnector.translateText(oDataModel.oData.sOriginalMessage, sSelectedKey);
				  	oDataModel.oData.sMessage = translation;
				  	oDataModel.oData.bIsTranslated = true;
				} catch (error) {
					var errorMessage = "An unknown error occurred.";
					if (!!error.responseJSON && !!error.responseJSON.error && !!error.responseJSON.error.code) {
						errorMessage = error.responseJSON.error.message;							
					} else {
						if (typeof error === 'object' && error.message) {
							errorMessage = "An unknown error occurred: " + error.message;
						} 
					}
					MessageBox.error(errorMessage);
				}
			}
			oDataModel.refresh(true)
		},

	});
});