sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/viz/ui5/format/ChartFormatter",
	"com/sap/mcconedashboard/model/mcs/ChartCustomFormat",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/model/models",
	"com/sap/mcconedashboard/utils/FilterComponent"
], function (BaseController, JSONModel, History, Filter, FilterOperator, ChartFormatter, ChartCustomFormat, formatter, models,
	FilterComponent) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.MCSOperationalInformation", {

		formatter: formatter,
		models: models,
		oPopover: null,

		//array of corresponding chartIds in view for iteration
		aCharts: [
			"vizFrameEscalationByRootCause",
			"vizFrameEscalationBySupportModel",
			"vizFrameEscalationBySupportModelTotalCostRelative",
			"vizFrameEscalationBySupportModelTotalCostAbsolute"
		],

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {

			ChartCustomFormat.registerCustomFormat();
			if (!this.getOwnerComponent().getModel("variantManagement")) {
				this._loadVariants("MCSOPERATIONAL");
			}
			//	this.initFilterBase();
			//===========================================================
			// Load model and Resources
			//===========================================================
			//check if data has been read
			var operationalInformationModel = null;
			if (!this.getModel("OperationalInformationModel")) {
				operationalInformationModel = this.getOperationalInformation();
				this.setModel(operationalInformationModel, "OperationalInformationModel");
			}

			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			this.getRouter().getRoute("MCSOperationalInformation").attachPatternMatched(this.onOperationalInformationMatched, this);

			var modelEscaRequestsUserStatus = new JSONModel({
				"UserStatus": [{
					key: "ALL",
					text: this._oResourceBundle.getText("zs31UserStatusALL")
				}, {
					key: "E0010",
					text: this._oResourceBundle.getText("zs31UserStatusNew")
				}, {
					key: "E0011",
					text: this._oResourceBundle.getText("zs31UserStatusInProcess")
				}, {
					key: "E0012",
					text: this._oResourceBundle.getText("zs31UserStatusAccepted")
				}, {
					key: "E0013",
					text: this._oResourceBundle.getText("zs31UserStatusRejected")
				}, {
					//	key: "E0014",
					//	text: this._oResourceBundle.getText("zs31UserStatusRestricted")
					//	}, {
					key: "E0015",
					text: this._oResourceBundle.getText("zs31UserStatusDraft")
				}, {
					key: "E0016",
					text: this._oResourceBundle.getText("zs31UserStatusObsolete")
				}]
			});
			this.setModel(modelEscaRequestsUserStatus, "escalationRequestUserStatus");

			//===========================================================
			// init Controls (Charts)
			//===========================================================

			//init: pie charts
			this._initPieCharts();

			//init: EscalationBySupportModelTotalCostAbsolute
			this._initEscalationBySupportModelTotalCost();

			//init: EscalationBySupportModelAndRootCause
			this._initEscalationBySupportModelAndRootCause();

			//init: CaseChecker
			this._initCaseChecker();

			//init: Escalation Requests
			this._initEscalationRequests();
			this._initEscalationRequestsRegion();

			//init: Escalation Requests
			this._initEscalationActivities();

			//initialize filter component
			this.oFilterComponent = new FilterComponent(this);
		},

		onOperationalInformationMatched: function (event) {
			this.getModel("settings").setProperty("/isInOperationalKPITile", true);

			var oArgs = event.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);

			var oFaceFilterSelection = this.getOwnerComponent().getModel("filterModel").getProperty("/facetFilterSelection");
			if (!this.getOwnerComponent().getModel("settings").getProperty("/initialReadOfVariantManagement")) {
				this.oFilterComponent.syncFacetFilters(oFaceFilterSelection, false);
			} else {
				this.oFilterComponent.syncFacetFilters(oFaceFilterSelection, true);
			}
			//hide facetFilter and variant management on OperationalInformation View
			this.getModel("settings").setProperty("/facetFilterVisible", Boolean(false));
			//	this.getModel("settings").setProperty("/variantManagementVisible", Boolean(false));

			var iconTabBar = this.getView().byId("firstLevelTabBar");

			var oArgs = event.getParameter("arguments");

			if (oArgs["?query"] && oArgs["?query"].tabBar) {
				var oSection = iconTabBar.getItems().find(function (section) {
					return section.getId().indexOf(oArgs["?query"].tabBar) > -1;
				});
			} else if (jQuery.sap.getUriParameters() && jQuery.sap.getUriParameters()._get("tabBar") && jQuery.sap.getUriParameters()._get("tabBar") !== "") {
				var oSection = iconTabBar.getItems().find(function (section) {
					return section.getId().indexOf(jQuery.sap.getUriParameters()._get("tabBar")) > -1;
				});
			} else {
				var oSection = iconTabBar.getItems()[0];
			}

			if (oSection && oSection.getVisible()) {
				iconTabBar.setSelectedItem(oSection);
			} else {
				iconTabBar.setSelectedItem(iconTabBar.getItems()[0]);
			}

			//navigation to specific charts
			var sSelectedChart = "";
			if (oArgs["?query"] && oArgs["?query"].chartselection) {
				sSelectedChart = oArgs["?query"].chartselection;
			} else if (jQuery.sap.getUriParameters() && jQuery.sap.getUriParameters()._get("chartselection") && jQuery.sap.getUriParameters()._get("chartselection") !== "") {
				sSelectedChart = jQuery.sap.getUriParameters()._get("chartselection");
			}
			//just for testing			sSelectedChart = "escabysupportmodelcount";
			var oPage = this.getView().byId("mcsOperationalInformationScrollContainer");
			var oPanel = this.getView().byId("vizFrameEscalationBySupportModelTotalCostAbsolute");

			if (sSelectedChart !== "") {
				switch (sSelectedChart) {
				case "escabysupportmodelcount":
					oPage = this.getView().byId("mcsOperationalInformationScrollContainer");
					oPanel = this.getView().byId("vizFrameEscalationBySupportModel");
					iconTabBar.setSelectedItem(iconTabBar.getItems()[0]);
					break;
				case "escabysupportmodelandrootcause":
					oPage = this.getView().byId("mcsOperationalInformationScrollContainer");
					oPanel = this.getView().byId("vizframeSupportModelAndRootCause");
					iconTabBar.setSelectedItem(iconTabBar.getItems()[0]);
					break;
				default:
					oPage = this.getView().byId("mcsOperationalInformationScrollContainer");
					oPanel = this.getView().byId("vizFrameEscalationBySupportModelTotalCostAbsolute");
					iconTabBar.setSelectedItem(iconTabBar.getItems()[0]);
					break;
				}
				oPage.scrollToElement(oPanel);
			}

			this.trackEvent("Display Operational Statistics");
		},

		onAfterRendering: function (event) {

		},

		onNavBack: function () {
			//this.getRouter().navTo("mcsdashboard", {}, true);
			this.getModel("settings").setProperty("/isInOperationalKPITile", false);
			//show facetFilter and variant management on other Views
			this.getModel("settings").setProperty("/facetFilterVisible", Boolean(true));
			//this.getModel("settings").setProperty("/variantManagementVisible", Boolean(true));
			var sPreviousHash = History.getInstance().getPreviousHash();
			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("Global", {
					"?query": this._getQueryParameter(),
				}, true);
			}
		},
		onTabChanged: function (oEvent) {
			var bIsVisible = false;
			switch (oEvent.getParameter("item").getProperty("text")) {
			case this.getModel("i18n").getProperty("caseCheckerTab"):
				bIsVisible = true;
				break;
			default:
				bIsVisible = false;
			}
			this.getModel("settings").setProperty("/isVisibleOpenCaseCheckerButton", Boolean(bIsVisible));
		},

		onOpenCaseChecker: function (oEvent) {
			sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), "opened CaseChecker");
			var that = this;
			setTimeout(function () {
				sap.m.URLHelper.redirect(that._oResourceBundle.getText("hrefCaseChecker"), "_self");
			}, 1000);
		},

		//===========================================================
		// init Pie Charts
		//===========================================================
		_initPieCharts: function () {

			//init all charts defind in the aCharts array
			this.aCharts.forEach(function (vizFrameId) {

				var oVizFrameChart = this.getView().byId(vizFrameId);
				if (!oVizFrameChart) {
					return;
				}

				//define and apply general chartProperties
				oVizFrameChart.setVizProperties({
					legendGroup: {
						linesOfWrap: 2,
						layout: {
							width: "250px"
						}
					},
					title: {
						visible: false
					},
					plotArea: {
						dataLabel: {
							visible: true,
							type: "value",
							formatString: ChartCustomFormat.FIORI_VALUE_INT_ROUND
						}
					},
					interaction: {
						selectability: {
							mode: "single"
						}
					}
				});

				//define and apply special chartProperties
				switch (vizFrameId) {
				case "vizFrameEscalationByRootCause":
				case "vizFrameEscalationBySupportModel":
				case "vizFrameEscalationBySupportModelTotalCostAbsolute":
					oVizFrameChart.setVizProperties({
						legend: {
							visible: true
						}
					});
					break;
				default:
					oVizFrameChart.setVizProperties({
						legend: {
							visible: false
						}
					});
				}

				// workaround to prevent rendering problems after changing filters on other views
				oVizFrameChart.setVisible(false);
				oVizFrameChart.setVisible(true);
			}, this);
		},

		//===========================================================
		// init EscalationBySupportModelTotalCostAbsolute Pie Chart
		//===========================================================
		_initEscalationBySupportModelTotalCost: function () {

			var oVizFrame = this.byId("vizFrameEscalationBySupportModelTotalCostAbsolute");
			if (!oVizFrame) {
				return;
			}

			//define and apply chartProperties
			oVizFrame.setVizProperties({
				plotArea: {
					legend: {
						visible: true
					},
					dataLabel: {
						visible: true,
						type: "value",
						formatString: ChartCustomFormat.VALUE_DEFAULT_EUR_K_TO_K, //FIORI_PERCENTAGE_FORMAT_2_PERCENTAGE_SIGN_ONLY,
						// style: {
						// 	width: "50"
						// },
						hideWhenOverlap: true,
						//define custom render function to combine absolute and percentage value
						//formatting for the datalabels of the specific chart is done here
						renderer: function (oEvent) {}
					}
				}
			});

			oVizFrame.attachSelectData(function (oEvent) {
				var sCostsForSelectedElement = oEvent.getSource().getModel("OperationalInformationModel").getProperty(oEvent.getSource().getDataset()
					.getBinding(
						"data").getPath())[oEvent.getParameter("data")[0].data._context_row_number].A00O2TFCW5W1NDKQCKZB6ZW1U0; //A00O2TFCW5W1NDKQA1Y5ZL0248;
				var mData = {
					'customDataControl': function (data) {
						if (data.data.val) {
							var oLabelBold = new sap.m.Label({
								text: data.data.val[0].value,
								design: "Bold"
							});
							var oLabelA = new sap.m.Label({
								text: "Costs:",
								width: "5rem"
							});
							var oTextA = new sap.m.Text({
								text: ChartCustomFormat.chartFormatter.format(data.data.val[1].value, ChartCustomFormat.VALUE_DEFAULT_EUR_K_TO_K)
							});
							var oLabelB = new sap.m.Label({
								text: "Percentage:",
								width: "5rem"
							});
							var oTextB = new sap.m.Text({
								text: ChartCustomFormat.chartFormatter.format(sCostsForSelectedElement, ChartCustomFormat.FIORI_PERCENTAGE_FORMAT_2_PERCENTAGE_SIGN_ONLY)
							});
							var oHbox1 = new sap.m.HBox({
								width: "100%"
							});
							var oHbox2 = new sap.m.HBox({
								width: "100%"
							});

							oTextA.addStyleClass("sapUiMediumMarginBegin");
							oTextB.addStyleClass("sapUiMediumMarginBegin");
							oHbox1.addItem(oLabelA);
							oHbox1.addItem(oTextA);
							oHbox2.addItem(oLabelB);
							oHbox2.addItem(oTextB);
							var oVbox1 = new sap.m.VBox({
								width: "100%"
							});
							oVbox1.addItem(oLabelBold);
							oVbox1.addItem(oHbox1);
							oVbox1.addItem(oHbox2);

							return oVbox1;
						}
					}
				};
				var oPopOver = new sap.viz.ui5.controls.Popover(mData);
				oPopOver.connect(oVizFrame.getVizUid());
			});

		},

		//===========================================================
		// init EscalationBySupportModelAndRootCause Stacked Column Chart
		//===========================================================
		_initEscalationBySupportModelAndRootCause: function () {

			var oVizFrame = this.byId("vizframeSupportModelAndRootCause");
			if (!oVizFrame) {
				return;
			}

			//define and apply chartProperties
			oVizFrame.setVizProperties({
				legend: {
					visible: true
				},
				legendGroup: {
					layout: {
						position: 'bottom'
					}
				},
				title: {
					visible: false,
					text: 'Escalation by Support Model and Root Cause'
				},
				categoryAxis: {
					title: {
						visible: false
					},
					label: {
						angle: 0,
						overlapBehavior: 'auto',
						rotation: 'auto',
						truncatedLabelRatio: 0.2,
						linesOfWrap: 3
					}
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				dataLabel: {
					showTotal: true
				}, //only single select
				interaction: {
					selectability: {
						mode: "single"
					},
					behaviorType: null
				},
				tooltip: {
					visible: true
				}

			});

			var that = this;
			this.getOwnerComponent().getModel("mcsModel").attachRequestCompleted(function (oEvent) {

				if (oEvent.getParameter("url").toLocaleString().indexOf("KPICategoryReasonSet") < 0) {
					return;
				}

				oVizFrame.destroyDataset();
				oVizFrame.destroyFeeds();

				var oEntry = {};
				var aData = that.getModel("OperationalInformationModel").oData.escalationBySupportModelAndRootCause.data;
				var sPath = "OperationalInformationModel>/escalationBySupportModelAndRootCause/data";
				if (aData === null) {
					return;
				}
				oEntry = aData[0];

				var aMeasures = that._createMeasuresFromEntry(oEntry);

				if (aMeasures.length > 0) {
					that._addFeedsFromEntry(oVizFrame, aMeasures, "valueAxis", "Measure");
				} else {
					sPath = null;
					aMeasures = [{
						name: 'test_counter',
						value: 0
					}];
					that._addFeedsFromEntry(oVizFrame, aMeasures, "valueAxis", "Measure");
				}

				var aDimensions = [{
					name: "support model",
					value: "{category_text}"
				}];

				oVizFrame.addFeed(new sap.viz.ui5.controls.common.feeds.FeedItem({
					uid: "categoryAxis",
					type: "Dimension",
					values: ["support model"]
				}));

				//define dataset dynamically
				oVizFrame.setDataset(new sap.viz.ui5.data.FlattenedDataset({
					dimensions: aDimensions,
					measures: aMeasures,
					data: {
						path: sPath
					}
				}));
			});

		},

		_createMeasuresFromEntry: function (oEntry) {

			var sIndexString = "_counter";
			var aMeasures = [];

			for (var oItem in oEntry) {
				var iIndex = oItem.toLocaleString().indexOf(sIndexString);
				if (iIndex === -1) {
					continue;
				}

				if (oEntry.hasOwnProperty(oItem)) {

					var oMeasureDefinition = {
						name: oEntry[oItem.substring(0, iIndex) + "_reason_text"],
						value: '{' + oItem.toLocaleString() + '}'
					};
					aMeasures.push(oMeasureDefinition);
				}
			}

			return aMeasures;
		},

		_addFeedsFromEntry: function (oVizFrame, aMeasures, sUid, sType) {

			for (var i = 0; i < aMeasures.length; i++) {
				var oFeedItem = new sap.viz.ui5.controls.common.feeds.FeedItem({
					uid: sUid,
					type: sType,
					values: [aMeasures[i].name]
				});
				oVizFrame.addFeed(oFeedItem);
			}
		},

		//===========================================================
		// init CaseChecker Stacked Column Chart
		//===========================================================
		_initCaseChecker: function () {

			var oVizFrame = this.byId("vizFrameCaseChecker");
			if (!oVizFrame) {
				return;
			}

			//define and apply chartProperties
			oVizFrame.setVizProperties({
				legend: {
					visible: true
				},
				legendGroup: {
					layout: {
						position: "bottom"
					}
				},
				title: {
					visible: false,
					text: 'Case Checker'
				},
				categoryAxis: {
					title: {
						visible: false

					},
					label: {
						angle: 0,
						overlapBehavior: 'auto',
						rotation: 'auto',
						truncatedLabelRatio: 0.2,
						linesOfWrap: 3
					}
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataPointStyle: {
						rules: [{
							dataContext: [{
								not_ok: {
									'min': 0
								}
							}],
							properties: {
								color: 'sapUiChartPaletteSemanticBad'
							},
							displayName: 'not ok'
						}],
						others: {
							properties: {
								color: 'sapUiChartPaletteSemanticGood'
							},
							displayName: 'ok'
						}
					}
				},
				dataLabel: {
					showTotal: true
				}, //only single select
				interaction: {
					selectability: {
						mode: "single"
					},
					behaviorType: null
				},
				tooltip: {
					visible: true
				}
			});

			//sort oData
			var oBinding = oVizFrame.getDataset().getBinding("data");
			var aSorter = [];
			aSorter.push(new sap.ui.model.Sorter("rating", true, false));
			oBinding.sort(aSorter);

		},

		//===========================================================
		// init EscalationRequests Line Chart
		//===========================================================
		_initEscalationRequests: function () {

			var oVizFrame = this.byId("vizFrameEscalationRequests");
			if (!oVizFrame) {
				return;
			}

			//define and apply chartProperties
			oVizFrame.setVizProperties({
				legend: {
					visible: true
				},
				legendGroup: {
					layout: {
						position: "bottom"
					}
				},
				title: {
					visible: false,
					text: "Escalation Requests"
				},
				categoryAxis: {
					title: {
						visible: false
					},
					label: {
						angle: 0,
						overlapBehavior: "auto",
						rotation: "auto",
						truncatedLabelRatio: 0.2,
						linesOfWrap: 3
					}
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataShape: {
						primaryAxis: ["line", "line", "line", "line", "line", "line", "line"]
					}
				}, //only single select
				interaction: {
					selectability: {
						mode: "single"
					},
					behaviorType: null
				},
				tooltip: {
					visible: true
				}
			});

			/*
			oVizFrame.attachSelectData(function (oEvent) {
				var oVizPopover = new sap.viz.ui5.controls.Popover({});
				oVizPopover.connect(oVizFrame.getVizUid());
			});
			*/
		},
		_initEscalationRequestsRegion: function () {

			var oVizFrame = this.byId("vizFrameEscalationRequestsRegion");
			if (!oVizFrame) {
				return;
			}

			//define and apply chartProperties
			oVizFrame.setVizProperties({
				legend: {
					visible: true
				},
				legendGroup: {
					layout: {
						position: "bottom"
					}
				},
				title: {
					visible: false,
					text: "Escalation Requests"
				},
				categoryAxis: {
					title: {
						visible: false
					},
					label: {
						angle: 0,
						overlapBehavior: "auto",
						rotation: "auto",
						truncatedLabelRatio: 0.2,
						linesOfWrap: 3
					}
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataShape: {
						primaryAxis: ["line"]
					}
				}, //only single select
				interaction: {
					selectability: {
						mode: "single"
					},
					behaviorType: null
				},
				tooltip: {
					visible: true
				}
			});
			//set ID of VizFeed into internal json model in order to have access to it from within other js files - we need to update the label in case of region filter selection
			//this is a special case handling,because normally you don't have to change the legend label afterwards
			//var oSettingsModel = this.getOwnerComponent().getModel("settings");
			//oSettingsModel.setProperty("/valueAxisEscalationRequestFeed", this.getView().byId("valueAxisEscalationRequestFeed").getId());
			//oSettingsModel.setProperty("/vizFrameEscalationRequestsRegion", oVizFrame.getId());
		},

		//===========================================================
		// init EscalationActivities Line Chart
		//===========================================================
		_initEscalationActivities: function () {

			var oVizFrame = this.byId("vizFrameEscalationActivities");
			if (!oVizFrame) {
				return;
			}

			//define and apply chartProperties
			oVizFrame.setVizProperties({
				legend: {
					visible: true
				},
				legendGroup: {
					layout: {
						position: "bottom"
					}
				},
				title: {
					visible: false,
					text: "Escalation Activities"
				},
				categoryAxis: {
					title: {
						visible: false
					},
					label: {
						angle: 0,
						overlapBehavior: "auto",
						rotation: "auto",
						truncatedLabelRatio: 0.2,
						linesOfWrap: 3
					}
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				//only single select
				interaction: {
					selectability: {
						mode: "single"
					},
					behaviorType: null
				},
				tooltip: {
					visible: true
				}
			});
		},
		/**
		 * Event Hanlder if Escalation Type selection changes in order to get the needed data from the backend
		 */
		onEscaRequestUserStatusChange: function (selectedItem) {
			var escalationFilters = []; //filtersModel.buildRegionOnlyODataFilter("CRM").aFilters;
			var sRegion = this.getRegionFilterModel();

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("region", sap.ui.model.FilterOperator.EQ, region));
				});
				escalationFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}
			var finalFilter = escalationFilters;
			//add drop Down specific filtering
			if (selectedItem.getSource().getSelectedKey() !== "ALL") {
				this.getOwnerComponent().getModel("settings").setProperty("/kpiEscalationRequestsUserStatusFilter", selectedItem.getSource().getSelectedKey());
				var kpiSpecificFilters = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, selectedItem.getSource().getSelectedKey());
				finalFilter = new sap.ui.model.Filter([kpiSpecificFilters].filter(Boolean), true);
				if (escalationFilters.length > 0) {
					finalFilter = new sap.ui.model.Filter([escalationFilters[0], finalFilter].filter(Boolean),
						true
					);
				}
			} else {
				this.getOwnerComponent().getModel("settings").setProperty("/kpiEscalationRequestsUserStatusFilter", "ALL");
				finalFilter = new sap.ui.model.Filter([escalationFilters[0]].filter(Boolean),
					true
				);
			}

			var mainModel = this.getModel("mcsModel");
			var operationalInformationModel = this.getModel("OperationalInformationModel");
			//var settingsModel = this.getOwnerComponent().getModel("settings");
			operationalInformationModel.setProperty("/escalationRequests/data", null);
			operationalInformationModel.setProperty("/escalationRequests/info/hasData", false);
			operationalInformationModel.setProperty("/escalationRequests/info/isBusy", true);

			//	var that = this;
			mainModel.read(
				"/KPIEscalationRequestsSet", {
					filters: finalFilter.aFilters.slice(0),
					success: function (data) {
						//13.04.2022 START remove the current month from the result
						var now = new Date();
						// Fill model with month names
						var monthNames = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
						var sCurrentMonth = monthNames[now.getMonth()] + " " + now.getFullYear();
						var result = data.results;
						if (data.results.length > 0) {
							result.forEach(function (item, index) {
								if (sCurrentMonth === item.month) {
									result.splice(index, 1);
								}
							});
						}
						//13.04.2022 END remove the current month from the result
						operationalInformationModel.setProperty("/escalationRequests/data", result);
						operationalInformationModel.setProperty("/escalationRequests/info/hasData", Boolean(result !== null && result.length >
							0));
						operationalInformationModel.setProperty("/escalationRequests/info/isBusy", Boolean(false));
					},
					error: function (oError) {
						operationalInformationModel.setProperty("/escalationRequests/data", null);
						operationalInformationModel.setProperty("/escalationRequests/info/hasData", Boolean(false));
						operationalInformationModel.setProperty("/escalationRequests/info/isBusy", Boolean(true));
						models._showODataError(oError);
					}
				});
		},
		getOperationalInformation: function () {
			var model = new JSONModel({
				escalationBySupportModel: {
					info: {
						hasData: false,
						isBusy: false
					},
					data: null
				},
				escalationByRootCause: {
					info: {
						hasData: false,
						isBusy: false
					},
					data: null
				},
				escalationBySupportModelAndRootCause: {
					info: {
						hasData: false,
						isBusy: false,
						unassignedValues: 0
					},
					data: null
				},
				escalationBySupportModelTotalCost: {
					info: {
						hasData: false,
						isBusy: false
					},
					data: null
				},
				escalationRequests: {
					info: {
						hasData: false,
						isBusy: false
					},
					data: null
				},
				escalationActivities: {
					info: {
						hasData: false,
						isBusy: false
					},
					data: null
				},
				caseChecker: {
					info: {
						hasData: false,
						isBusy: false
					},
					data: null
				}
			});

			// Bind to changes of the filter model
			//var binding = new sap.ui.model.Binding(filtersModel, "/");
			//binding.attachChange(debounce(readCases, 10));

			setTimeout(this.readCases(model), 0);

			return model;
		},
		readCases: function (model) {
			var dashboardModel = this.getOwnerComponent().getModel("mcsModel");
			//var bwp010EscalationBySupportModelTotalCostBWModel = this.getOwnerComponent().getModel("bwp010EscalationBySupportModelTotalCostBWModel");
			var bwp010EscalationBySupportModelTotalCostBWModel = new sap.ui.model.odata.v2.ODataModel(
				sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCASE_COST_ODA_010N_SRV", {
				"metadataUrlParams": {
					"sap-documentation": "heading"
				},
				"defaultCountMode": true,
				"useBatch": false,
				"headers": {
					"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
				}
			});
			//var bwpCatsModel = this.getOwnerComponent().getModel("bwpCatsActivityOnsiteRemoteBWModel");
			var bwpCatsModel = new sap.ui.model.odata.v2.ODataModel(
				sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCATS0003_CRA_01_OD2_SRV", {
				"metadataUrlParams": {
					"sap-documentation": "heading"
				},
				"defaultCountMode": true,
				"useBatch": false,
				"headers": {
					"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
				}
			});
			var settingsModel = this.getOwnerComponent().getModel("settings");

			var onlyRegionFilter = []; //filtersModel.buildRegionOnlyODataFilter("CRM").aFilters;
			var sRegion = this.getRegionFilterModel();
			var oBWFilterModel = this.getOwnerComponent().getModel("bwFilterModel");

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("region", sap.ui.model.FilterOperator.EQ, region));
				});
				onlyRegionFilter.push(new sap.ui.model.Filter(aRegionFilter, false));
			}
			var sRegionBW = "WORLD";
			if (sRegion && sRegion !== "") {
				sRegionBW = sRegion;
			}

			// var aOnlyRegionFilterBWP = oBWFilterModel.buildRegionOnlyODataFilter("BWP",sRegion).aFilters;
			// var sBWPFilter = oBWFilterModel.buildURLVariableFilterForBWP(aOnlyRegionFilterBWP, "");
			//BWP CATS Activities
			// var aOnlyRegionFilterBWPCATS = oBWFilterModel.buildRegionOnlyODataFilter("BWPCATS").aFilters;
			// var sBWPCATSFilter = oBWFilterModel.buildURLVariableFilterForBWPCATS(aOnlyRegionFilterBWPCATS);
			var that = this;

			//--------------------------------
			//EscalationBySupportModel
			//--------------------------------
			this._onBeginLoadingDataToModel(model, "/escalationBySupportModel");
			dashboardModel.read("/KPITopCategoriesSet", {
				filters: onlyRegionFilter.slice(0),
				success: function (data, response) {
					//prepareModelForDisplay.call(data.results, "category_text", aRefLegendCategoryText);
					//ignore unassigned values
					that._onFinishLoadingDataToModel(model, "/escalationBySupportModel", data.results);
				},
				error: function (oError, response) {
					that._onFinishLoadingDataToModel(model, "/escalationBySupportModel", null);
				}
			});

			var nRegionCallCounter = 0,
				nRegionCounter = 0,
				aoDataResultSupportModelTotalCost = [],
				dSumOfAllCosts = 0,
				bNotAddedYet = true;

			//function needed, because for BW oData calls we cannot submit several Region filters in one call. We need to call it separately and the merge it.
			//only after all calls have been successful, we can update the data model for the ui
			function mergeBWSupportModelTotalCost() {
				if (nRegionCallCounter !== nRegionCounter) {
					setTimeout(function () {
						jQuery.proxy(mergeBWSupportModelTotalCost(), this);
					}, 200);
					return null;
				} else {
					//percentage needs to be calculated after all Regions have been returned
					aoDataResultSupportModelTotalCost.forEach(function (val, i) {
						bNotAddedYet = false;
						aoDataResultSupportModelTotalCost[i].A00O2TFCW5W1NDKQCKZB6ZW1U0 = parseFloat((100 / dSumOfAllCosts) *
							aoDataResultSupportModelTotalCost[i].A00O2TFCW5W1NDKQA1Y5ZL0248).toFixed(2); //percentage
					});
					that._onFinishLoadingDataToModel(model, "/escalationBySupportModelTotalCost", aoDataResultSupportModelTotalCost);
				}
			}

			//--------------------------------
			//EscalationBySupportModelTotalCost
			//--------------------------------
			var oCostDescSorter = new sap.ui.model.Sorter("A00O2TFCW5W1NDKQA1Y5ZL0248", true);
			if (settingsModel.oData.show_cost_data) {
				that._onBeginLoadingDataToModel(model, "/escalationBySupportModelTotalCost");

				//for BW we need to read the data for each Region separately
				if (sRegionBW) {
					sRegionBW.split(",").forEach(function (region) {
						nRegionCounter++;
						var regionOnlyFilterForBWP = oBWFilterModel.buildRegionOnlyODataFilter("BWP", region).aFilters;
						var sBWPFilter = oBWFilterModel.buildURLVariableFilterForBWP(regionOnlyFilterForBWP, "");

						bwp010EscalationBySupportModelTotalCostBWModel.read("/MCASE_COST_ODA_010N(" + sBWPFilter + ")/Results", {
							//	jQuery.ajax("./json/escalationsTotalCostModel.json", { // load the data from a relative URL (the Data.json file in the same directory)
							dataType: "json",
							sorters: [oCostDescSorter],
							//filters: onlyRegionFilter.slice(0),
							success: function (oData) {
								oData.results.forEach(function (result) {
									bNotAddedYet = true;
									dSumOfAllCosts += parseFloat(result.A00O2TFCW5W1NDKQA1Y5ZL0248);
									aoDataResultSupportModelTotalCost.forEach(function (val, i) {
										if (aoDataResultSupportModelTotalCost[i].A4MCASEX017CSM_CATE_T === result.A4MCASEX017CSM_CATE_T) {
											bNotAddedYet = false;
											aoDataResultSupportModelTotalCost[i].A00O2TFCW5W1NDKQA1Y5ZL0248 += parseFloat(result.A00O2TFCW5W1NDKQA1Y5ZL0248); //costs
										}
									});
									if (bNotAddedYet) {
										var oNewEntry = {};
										oNewEntry.A4MCASEX017CSM_CATE_T = result.A4MCASEX017CSM_CATE_T;
										oNewEntry.A00O2TFCW5W1NDKQA1Y5ZL0248 = parseFloat(result.A00O2TFCW5W1NDKQA1Y5ZL0248);
										//append new entry to the structuredDataSet
										aoDataResultSupportModelTotalCost.push(oNewEntry);
									}

								}, this);
								nRegionCallCounter++;
							},
							error: function (oError, response) {
								//that._onFinishLoadingDataToModel(model, "/escalationBySupportModelTotalCost", null);
								nRegionCallCounter++;
							}
						});
					});
					mergeBWSupportModelTotalCost();
				}

			}

			//--------------------------------
			//EscalationRequests
			//--------------------------------

			//because of multiselect of Regions we need to add feed items manually
			var oVizFrame = this.byId("vizFrameEscalationRequests");

			oVizFrame.removeFeed(this.getView().byId("valueAxisMEE"));
			oVizFrame.removeFeed(this.getView().byId("valueAxisEMEA"));
			oVizFrame.removeFeed(this.getView().byId("valueAxisNA"));
			oVizFrame.removeFeed(this.getView().byId("valueAxisLAC"));
			oVizFrame.removeFeed(this.getView().byId("valueAxisAPJ"));
			oVizFrame.removeFeed(this.getView().byId("valueAxisGTC"));
			oVizFrame.removeFeed(this.getView().byId("valueAxisWORLD"));

			if (sRegion === "") {
				oVizFrame.addFeed(this.getView().byId("valueAxisMEE"));
				oVizFrame.addFeed(this.getView().byId("valueAxisEMEA"));
				oVizFrame.addFeed(this.getView().byId("valueAxisNA"));
				oVizFrame.addFeed(this.getView().byId("valueAxisLAC"));
				oVizFrame.addFeed(this.getView().byId("valueAxisAPJ"));
				oVizFrame.addFeed(this.getView().byId("valueAxisGTC"));
				oVizFrame.addFeed(this.getView().byId("valueAxisWORLD"));
			} else {
				sRegion.split(",").forEach(function (region) {
					if (region === "EMEA_NORTH" || region === "EMEA_SOUTH") {
						region = "EMEA";
					}
					oVizFrame.addFeed(this.getView().byId("valueAxis" + region));
				}, this);
			}

			this._onBeginLoadingDataToModel(model, "/escalationRequests");
			var finalFilter = onlyRegionFilter;
			if (settingsModel.getProperty("/kpiEscalationRequestsUserStatusFilter") !== "ALL") {
				var kpiSpecificFilters = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, settingsModel.getProperty(
					"/kpiEscalationRequestsUserStatusFilter"));
				finalFilter = new sap.ui.model.Filter([kpiSpecificFilters].filter(Boolean), true);
				if (onlyRegionFilter.length > 0) {
					finalFilter = new sap.ui.model.Filter([onlyRegionFilter[0], finalFilter].filter(Boolean),
						true
					);
				}
			} else {
				this.getOwnerComponent().getModel("settings").setProperty("/kpiEscalationRequestsUserStatusFilter", "ALL");
				finalFilter = new sap.ui.model.Filter([onlyRegionFilter[0]].filter(Boolean),
					true
				);
			}

			dashboardModel.read("/KPIEscalationRequestsSet", {
				filters: finalFilter.aFilters.slice(0),
				success: function (data) {
					//13.04.2022 START remove the current month from the result
					var now = new Date();
					// Fill model with month names
					var monthNames = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
					var sCurrentMonth = monthNames[now.getMonth()] + " " + now.getFullYear();
					var result = data.results;
					if (data.results.length > 0) {
						result.forEach(function (item, index) {
							if (sCurrentMonth === item.month) {
								result.splice(index, 1);
							}
						});
					}
					//13.04.2022 END remove the current month from the result
					that._onFinishLoadingDataToModel(model, "/escalationRequests", result);
				},
				error: function (oError, response) {
					that._onFinishLoadingDataToModel(model, "/escalationRequests", null);
				}
			});

			//--------------------------------
			//EscalationActivities
			//--------------------------------
			//if (settingsModel.oData.show_Element_In_Development) {
			var nRegionCallCounterCATS = 0,
				nRegionCounterCATS = 0,
				aoDataResultBWCATS = [],
				bNotAddedYetCATS = true;

			//function needed, because for BW oData calls we cannot submit several Region filters in one call. We need to call it separately and the merge it.
			//only after all calls have been successful, we can update the data model for the ui
			function mergeBWCATS() {
				if (nRegionCallCounterCATS !== nRegionCounterCATS) {
					setTimeout(function () {
						jQuery.proxy(mergeBWCATS(), this);
					}, 200);
					return null;
				} else {
					that._onFinishLoadingDataToModel(model, "/escalationActivities", aoDataResultBWCATS);
				}
			}

			//for BW we need to read the data for each Region separately
			if (sRegionBW) {
				sRegionBW.split(",").forEach(function (region) {
					nRegionCounterCATS++;
					var aOnlyRegionFilterBWPCATS = oBWFilterModel.buildRegionOnlyODataFilter("BWPCATS", region).aFilters;
					var sBWPCATSFilter = oBWFilterModel.buildURLVariableFilterForBWPCATS(aOnlyRegionFilterBWPCATS);

					that._onBeginLoadingDataToModel(model, "/escalationActivities");
					//BWP CATS Activities
					//workaround needed for EMEA North and EMEA South -->  need to be Merged to EMEA
					if (region.toUpperCase() === "EMEA") {
						//EMEA NORTH		17	'0HIER_NODE:M017'  0HIER_NODE%3AM017		
						//EMEA SOUTH		12	'0HIER_NODE:M018' 0HIER_NODE%3AM018	

						var sBWPCATSFilterEmeaNorth = "MCASE_NAM_ON_00_0COMP_CODE='0HIER_NODE%3AM017'";
						var sBWPCATSFilterEmeaSouth = "MCASE_NAM_ON_00_0COMP_CODE='0HIER_NODE%3AM018'";
						var fnGetEmeaNorthCatsData, fnGetEmeaSouthCatsData;

						// define Promises to wait for the two requests to finish
						var aPromises = [];

						fnGetEmeaNorthCatsData = function fGetEmeaNorthCatsData() {
							return new Promise(function (resolve, reject) {
								//EMEA NORTH
								bwpCatsModel.read("/MCATS0003_CRA_01_OD2(" + sBWPCATSFilterEmeaNorth + ")/Results", {
									urlParameters: "$select=A0CALMONTH_T,PCALOCAT_T,A00O2TFB0LT47SJW5AL692UW00&$inlinecount=allpages",
									success: function (data) {
										resolve({
											data: data,
											origin: "EMEANorth"
										});
									},
									error: function (oError, response) {
										resolve(null);
									}
								});
							});
						};

						aPromises.push(fnGetEmeaNorthCatsData());

						fnGetEmeaSouthCatsData = function fGetEmeaSouthCatsData() {
							return new Promise(function (resolve, reject) {
								//EMEA SOUTH
								bwpCatsModel.read("/MCATS0003_CRA_01_OD2(" + sBWPCATSFilterEmeaSouth + ")/Results", {
									urlParameters: "$select=A0CALMONTH_T,PCALOCAT_T,A00O2TFB0LT47SJW5AL692UW00&$inlinecount=allpages",
									success: function (data) {
										resolve({
											data: data,
											origin: "EMEASouth"
										});
									},
									error: function (oError, response) {
										resolve(null);
									}
								});
							});
						};

						aPromises.push(fnGetEmeaSouthCatsData());

						// on finish of all requests merge the data before handing it over to the standard function for putting the data into the model
						Promise.all(aPromises).then(function (aResults) {
							// promise results will be stored within aResults in order of Promises in aPromises
							// merge data if exists (response might be null on request error)
							if (aResults[0] && aResults[1]) {
								aResults.forEach(function (oData) {
									oData.data.results.forEach(function (result) {
										bNotAddedYetCATS = true;
										aoDataResultBWCATS.forEach(function (val, i) {
											if ((aoDataResultBWCATS[i].A0CALMONTH_T === result.A0CALMONTH_T) && (aoDataResultBWCATS[i].PCALOCAT_T === result.PCALOCAT_T)) {
												bNotAddedYetCATS = false;
												aoDataResultBWCATS[i].A00O2TFB0LT47SJW5AL692UW00 += parseFloat(result.A00O2TFB0LT47SJW5AL692UW00); //activties
											}
										});
										if (bNotAddedYetCATS) {
											var oNewEntry = {};
											oNewEntry.A0CALMONTH_T = result.A0CALMONTH_T;
											oNewEntry.PCALOCAT_T = result.PCALOCAT_T;
											oNewEntry.A00O2TFB0LT47SJW5AL692UW00 = parseFloat(result.A00O2TFB0LT47SJW5AL692UW00);
											//append new entry to the structuredDataSet
											aoDataResultBWCATS.push(oNewEntry);
										}
									}, this);
								}, this);
								nRegionCallCounterCATS++;
							} else {
								nRegionCallCounterCATS++;
							}
						}, function (err) {
							nRegionCallCounterCATS++;
						});
					} else {
						bwpCatsModel.read("/MCATS0003_CRA_01_OD2(" + sBWPCATSFilter + ")/Results", {
							urlParameters: "$select=A0CALMONTH_T,PCALOCAT_T,A00O2TFB0LT47SJW5AL692UW00&$inlinecount=allpages",
							success: function (oData) {
								oData.results.forEach(function (result) {
									bNotAddedYetCATS = true;
									aoDataResultBWCATS.forEach(function (val, i) {
										if ((aoDataResultBWCATS[i].A0CALMONTH_T === result.A0CALMONTH_T) && (aoDataResultBWCATS[i].PCALOCAT_T === result.PCALOCAT_T)) {
											bNotAddedYetCATS = false;
											aoDataResultBWCATS[i].A00O2TFB0LT47SJW5AL692UW00 += parseFloat(result.A00O2TFB0LT47SJW5AL692UW00); //activties
										}
									});
									if (bNotAddedYetCATS) {
										var oNewEntry = {};
										oNewEntry.A0CALMONTH_T = result.A0CALMONTH_T;
										oNewEntry.PCALOCAT_T = result.PCALOCAT_T;
										oNewEntry.A00O2TFB0LT47SJW5AL692UW00 = parseFloat(result.A00O2TFB0LT47SJW5AL692UW00);
										//append new entry to the structuredDataSet
										aoDataResultBWCATS.push(oNewEntry);
									}

								}, this);
								nRegionCallCounterCATS++;
								//that._onFinishLoadingDataToModel(model, "/escalationActivities", data.results);
							},
							error: function (oError, response) {
								//that._onFinishLoadingDataToModel(model, "/escalationActivities", null);
								nRegionCallCounterCATS++;
							}
						});
					}
				});
				mergeBWCATS();
			}

			//--------------------------------
			//Case Maintenance
			//--------------------------------
			this._onBeginLoadingDataToModel(model, "/caseChecker");
			dashboardModel.read("/KPIUpdateStatSet", {
				filters: onlyRegionFilter.slice(0),
				success: function (data, response) {
					that._onFinishLoadingDataToModel(model, "/caseChecker", data.results);
				},
				error: function (oError, response) {
					that._onFinishLoadingDataToModel(model, "/caseChecker", null);
				}
			});

			//-----------------------------
			//EscalationByRootCause
			//-----------------------------
			this._onBeginLoadingDataToModel(model, "/escalationByRootCause");
			dashboardModel.read("/KPITopReasonsSet", {
				filters: onlyRegionFilter.slice(0),
				success: function (data, response) {
					//prepareModelForDisplay.call(data.results, "reason_text", aRefLegendReasonText, "reason_code");
					that._onFinishLoadingDataToModel(model, "/escalationByRootCause", data.results);
				},
				error: function (oError, response) {
					that._onFinishLoadingDataToModel(model, "/escalationByRootCause", null);
				}
			});

			//-----------------------------
			//EscalationBySupportModelAndRootCause
			//-----------------------------
			this._onBeginLoadingDataToModel(model, "/escalationBySupportModelAndRootCause");
			dashboardModel.read("/KPICategoryReasonSet", {
				filters: onlyRegionFilter.slice(0),
				success: function (data, response) {
					//helper function for searching a specific value for a specific key (property) within a dataSet (array)
					var fSetContainsPropertyValue = function (sPropertyKey, sPropertyValue, aSet) {
						var i2 = aSet.length;
						while (i2--) {
							var element = aSet[i2];
							if (element[sPropertyKey].localeCompare(sPropertyValue) === 0) {
								return i2;
							}
						}
						return -1;
					};

					//convert data from oDataService for the stacked_column vizFrame control
					data.results.mergeToModel = function () {
						var i = this.length;
						var sProperty = "";
						var oStructuredDataSet = [];

						//method returns index of element if element with category found (true). Else returns -1 (false)
						oStructuredDataSet.containsCategory = function (category) {
							var i2 = this.length;
							while (i2--) {
								var element = this[i2];
								if (element.category.localeCompare(category) === 0) {
									return i2;
								}
							}
							return -1;
						};

						var aReasonInfo = {};

						// for each entry in the dataSet...
						while (i--) {
							var oElement = this[i];
							//if category already defined as new entry in stuctured dataset...
							//increment escX_count of the defined entry by the escX_count of the current element

							//dynamically define property name for counting aggregation
							// -> "escX_counter"
							sProperty = oElement.reason.toLowerCase() + "_counter";

							var index = fSetContainsPropertyValue("category", oElement.category, oStructuredDataSet);
							if (index >= 0) {
								if (typeof oStructuredDataSet[index][sProperty] === "undefined") {
									oStructuredDataSet[index][sProperty] = oElement.counter;
								} else {
									oStructuredDataSet[index][sProperty] = oStructuredDataSet[index][sProperty] + oElement.counter;
								}
							}
							//else create new category entry in structuredDataSet and apply data of current element
							else {
								var oNewEntry = {};
								oNewEntry.category = oElement.category;
								oNewEntry.category_text = oElement.category_text;

								//dynamically define property name for counting aggregation
								// -> "escX_counter"
								sProperty = oElement.reason.toLowerCase() + "_counter";
								oNewEntry[sProperty] = oElement.counter;

								var sRegionFilter = "WORLD";
								if (oElement.region) {
									sRegionFilter = oElement.region;
								}
								oNewEntry.region = sRegionFilter;

								//append new entry to the structuredDataSet
								oStructuredDataSet.push(oNewEntry);
							}

							if (!aReasonInfo.hasOwnProperty(oElement.reason.toLowerCase() + "_reason_text")) {
								aReasonInfo[oElement.reason.toLowerCase() + "_counter"] = 0;
								aReasonInfo[oElement.reason.toLowerCase() + "_reason"] = oElement.reason;
								aReasonInfo[oElement.reason.toLowerCase() + "_reason_text"] = oElement.reason_text;
							}
						}

						var aFinal = [];
						for (var k = 0; k < oStructuredDataSet.length; k++) {
							aFinal[k] = $.extend({}, aReasonInfo, oStructuredDataSet[k]);

							//Object.assign(aFinal[k], aReasonInfo, oStructuredDataSet[k]);
						}

						//model.setProperty("/escalationBySupportModelAndRootCause/info", oNewInfo);
						return aFinal;
					};

					//structure data
					var oStructuredDataSet = data.results.mergeToModel();
					//use data of the structuredDataSet
					oStructuredDataSet.sort(function (a, b) {
						return a.category_text.toString().localeCompare((b.category_text.toString()));
					});

					that._onFinishLoadingDataToModel(model, "/escalationBySupportModelAndRootCause", oStructuredDataSet);
				},
				error: function (oError, response) {
					that._onFinishLoadingDataToModel(model, "/escalationBySupportModelAndRootCause", null);
				}
			});
		},

		//helper function to be executed before data is retrieved from oData service
		_onBeginLoadingDataToModel: function (oModel, sPropertyPath) {
			oModel.setProperty(sPropertyPath + "/data", null);
			oModel.setProperty(sPropertyPath + "/info/isBusy", Boolean(true));
		},
		//helper function to be executed after data is retrieved from oData service and placed inside of success: or error:
		_onFinishLoadingDataToModel: function (oModel, sPropertyPath, aData, iCostReturnedOdataCount, aDataCATSEMEANorth, aDataCATSEMEASouth) {
			var bAllDataRetrieved = true;
			if (iCostReturnedOdataCount && iCostReturnedOdataCount < 7) {
				bAllDataRetrieved = false;
			}
			if (bAllDataRetrieved) {
				if (sPropertyPath === "/escalationActivities") {
					//BWP CATS Activities
					var oData = this.initializeBWPChartArrays("operationalEscalationActivitiesChart");
					//in case if EMEA North & EMEA South we need to merge the data
					// if (aDataCATSEMEANorth && aDataCATSEMEASouth) {
					// 	for (var i = 0; i < aDataCATSEMEANorth.length; i++) {
					// 		oData.forEach(
					// 			function (innerObject) {
					// 				if (innerObject["MonthTEMPNumber"] === aDataCATSEMEANorth[i].A0CALMONTH_T) {
					// 					if (aDataCATSEMEANorth[i].PCALOCAT_T === "O") {
					// 						innerObject.Onsite = aDataCATSEMEANorth[i].A00O2TFB0LT47SJW5AL692UW00;
					// 					} else if (aDataCATSEMEANorth[i].PCALOCAT_T === "R") {
					// 						innerObject.Remote = aDataCATSEMEANorth[i].A00O2TFB0LT47SJW5AL692UW00;
					// 					} else {
					// 						innerObject.Unassigned = aDataCATSEMEANorth[i].A00O2TFB0LT47SJW5AL692UW00;
					// 					}
					// 					return;
					// 				}
					// 			}
					// 		);
					// 	}
					// 	for (var i = 0; i < aDataCATSEMEASouth.length; i++) {
					// 		oData.forEach(
					// 			function (innerObject) {
					// 				if (innerObject["MonthTEMPNumber"] === aDataCATSEMEASouth[i].A0CALMONTH_T) {
					// 					if (aDataCATSEMEASouth[i].PCALOCAT_T === "O") {
					// 						innerObject.Onsite = Number(innerObject.Onsite) + Number(aDataCATSEMEASouth[i].A00O2TFB0LT47SJW5AL692UW00);
					// 					} else if (aDataCATSEMEASouth[i].PCALOCAT_T === "R") {
					// 						innerObject.Remote = Number(innerObject.Remote) + Number(aDataCATSEMEASouth[i].A00O2TFB0LT47SJW5AL692UW00);
					// 					} else {
					// 						innerObject.Unassigned = Number(innerObject.Unassigned) + Number(aDataCATSEMEASouth[i].A00O2TFB0LT47SJW5AL692UW00);
					// 					}
					// 					return;
					// 				}
					// 			}
					// 		);
					// 	}
					// } else {
					if (aData) {
						for (var i = 0; i < aData.length; i++) {
							oData.forEach(
								function (innerObject) {
									if (innerObject["MonthTEMPNumber"] === aData[i].A0CALMONTH_T) {
										innerObject.days = aData[i].A00O2TFB0LT47SJW5AL692UW00;
										if (aData[i].PCALOCAT_T === "O") {
											innerObject.Onsite = aData[i].A00O2TFB0LT47SJW5AL692UW00;
										} else if (aData[i].PCALOCAT_T === "R") {
											innerObject.Remote = aData[i].A00O2TFB0LT47SJW5AL692UW00;
										} else {
											innerObject.Unassigned = aData[i].A00O2TFB0LT47SJW5AL692UW00;
										}
										return;
									}
								}
							);
						}
					}
					//}
					oModel.setProperty(sPropertyPath + "/data", oData);
				} else {
					oModel.setProperty(sPropertyPath + "/data", aData);
				}
				oModel.setProperty(sPropertyPath + "/info/hasData", Boolean(aData !== null && aData.length > 0));
				oModel.setProperty(sPropertyPath + "/info/isBusy", Boolean(false));
			}
		},
		initializeBWPChartArrays: function (sArrayType, settingsModel) {
			var monthNames = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
			var aResult = [];
			if (sArrayType === "operationalEscalationActivitiesChart") {
				//BWP CATS Activities
				var aTypes = ["O", "R", ""];
				for (var i = 12; i >= 1; i--) {
					var oDate = new Date();
					oDate.setDate(1);
					oDate.setMonth(oDate.getMonth() - i);
					var oJsonDataElement = {};
					oJsonDataElement.month = monthNames[oDate.getMonth()] + " " + oDate.getFullYear();
					oJsonDataElement.MonthTEMPNumber = ("0" + (oDate.getMonth() + 1)).slice(-2) + "." + oDate.getFullYear();
					oJsonDataElement.days = "0.00";
					oJsonDataElement.Onsite = "0.00";
					oJsonDataElement.Remote = "0.00";
					oJsonDataElement.Unassigned = "0.00";
					aResult.push(oJsonDataElement);
				}
				return aResult;
			}
		},
		/**
		 * event handler for selection of specific region
		 */
		onSelectRegion: function (event) {
			if (event.getParameter("selected")) {
				this.trackEvent("Region Filter: Select");
			}
			//var oButton = oParam.getSource().getSelectedButton();
			var sText = event.getSource().getText();
			var oFilterModel = this.getModel("filterModel");
			var oRegionContainer = this.getView().byId("regionContainer");
			var aRegions = [],
				aRegionsT = [];
			var that = this;
			oRegionContainer.getItems().forEach(function (region) {
				if (region.getSelected() && sText !== "World" && region.getText() !== "World") {
					aRegionsT.push(region.getText());
					aRegions.push(that.formatter.formatRegionNameToRegionCode(region.getText()));
				} else if (sText === "World" && region.getText() !== "World") {
					region.setSelected(false);
				} else if (sText !== "World" && region.getText() === "World") {
					region.setSelected(false);
				}
			});
			var sRegion = aRegions.join();

			if (sRegion === "") {
				oRegionContainer.getItems()[0].setSelected(true);
			}

			oFilterModel.setProperty("/region", sRegion);
			oFilterModel.setProperty("/regionText", aRegionsT.join());

			setTimeout(this.readCases(this.getModel("OperationalInformationModel")), 0);

			if (this.oFilterComponent.oFacetFilter._variantInitiallyLoaded === true) {
				this.oFilterComponent.oFacetFilter._variantInitiallyLoaded = false;
			}
			// set current filter variant to modified /dirty flag 
			if (!this.oFilterComponent.oFacetFilter._variantInitiallyLoaded) {
				this.getView().byId("filterVariantManagement").currentVariantSetModified(true);
			}

			// var selectedIndex = event.getParameter("selectedIndex");
			// var radioButtonSrc = event.getSource().getAggregation("buttons");
			// var selectedId = (selectedIndex > 0) ? radioButtonSrc[selectedIndex].getId().split("--").slice(-1)[0] : null;

			// Create filter based on selected radio button
			//this.getModel("filters").setProperty("/region", selectedId);

			//in case if region != WORLD show column chart for specific region in cost KPI TAB
			//check also, if table view is currently selected, if this is the case we do not have to take care of chart switching
			var oSettingsModel = this.getModel("settings");
			if (sRegion === "" || sRegion === "World") {

				if (oSettingsModel.getProperty("/kpiTotalEscalationCostsTableVisible") === false) {
					oSettingsModel.setProperty("/kpiTotalEscalationCostsChartVisible", true);
					oSettingsModel.setProperty("/kpiTotalEscalationCostsChartRegionVisible", false);
				}
				if (oSettingsModel.getProperty("/kpiAverageEscalationCostsTableVisible") === false) {
					oSettingsModel.setProperty("/kpiAverageEscalationCostsChartVisible", true);
					oSettingsModel.setProperty("/kpiAverageEscalationCostsChartRegionVisible", false);
				}
				//EscalationRequests
				//	oSettingsModel.setProperty("/kpiEscalRequestsVisible", true);
				//oSettingsModel.setProperty("/kpiEscalRequestsRegionVisible", false);
			} else {
				if (oSettingsModel.getProperty("/kpiTotalEscalationCostsTableVisible") === false) {
					oSettingsModel.setProperty("/kpiTotalEscalationCostsChartRegionVisible", true);
					oSettingsModel.setProperty("/kpiTotalEscalationCostsChartVisible", false);
				}
				if (oSettingsModel.getProperty("/kpiAverageEscalationCostsTableVisible") === false) {
					oSettingsModel.setProperty(
						"/kpiAverageEscalationCostsChartRegionVisible", true);
					oSettingsModel
						.setProperty("/kpiAverageEscalationCostsChartVisible", false);
				}
				//EscalationRequests
				//oSettingsModel.setProperty("/kpiEscalRequestsVisible", false);
				//oSettingsModel.setProperty("/kpiEscalRequestsRegionVisible", true);
			}
			//enable setDirty after initial load of variant  -->  region is directly set in function onSelectVariant
			// if (this.facetFilter._variantInitiallyLoaded === true) {
			// 	this.facetFilter._variantInitiallyLoaded = false;
			// }
			// // set current filter variant to modified /dirty flag 
			// if (!this.facetFilter._variantInitiallyLoaded) {
			// 	this.getView().byId("filterVariantManagement").currentVariantSetModified(true);
			// }

			//reset the piechart table information and hide
			//if (this.getModel("KPICasesTable")) {
			//	this.setModel("KPICasesTable", null);
			oSettingsModel.setProperty("/kpi_Top5Products_TableVisibility", false);
			oSettingsModel.setProperty("/kpi_StrategicProducts_TableVisibility", false);
			oSettingsModel.setProperty("/isVisible_Top5ProductsWithHighEscCostsTable", false);
			oSettingsModel.setProperty("/isVisible_EscCostsOfStrategicProductsTable", false);
			oSettingsModel.setProperty("/isVisible_EscCostsPerProdCategoryTable", false);
			//}

		},
	});
});