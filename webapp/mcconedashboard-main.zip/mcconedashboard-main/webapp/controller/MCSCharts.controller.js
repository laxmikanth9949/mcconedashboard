sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"com/sap/mcconedashboard/model/mcs/ChartCustomFormat",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/model/models",
	"com/sap/mcconedashboard/utils/FilterComponent",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/viz/ui5/api/env/Format"
], function (BaseController, JSONModel, History, Filter, FilterOperator, ChartCustomFormat, formatter, models, FilterComponent,
	ChartFormatter, Format) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.MCSCharts", {
		//Colors based on Fiori Qualitative Palette
		//set in AnalyticalMapRegions.json
		//https://experience.sap.com/fiori-design-web/ui-components/color-palettes/
		// color1_blue: "sapUiChartPaletteQualitativeHue1",  #5cbae6   rgba(92, 186, 230, 1)
		// color2_green: "sapUiChartPaletteQualitativeHue2", #b6d957    rgba(182, 217, 87, 1)
		// color3_orange: "sapUiChartPaletteQualitativeHue3", #fac364  rgba(250, 195, 100, 1)
		// color4_lightBlue: "sapUiChartPaletteQualitativeHue4",  #8cd3ff  rgba(140, 211, 255, 1)
		// color5_violet: "sapUiChartPaletteQualitativeHue5", #d998cb   rgba(217, 152, 203, 1)
		// color6_yellow: "sapUiChartPaletteQualitativeHue6", #f2d249  rgba(242, 210, 73, 1)
		// color7_darkerBlue: "sapUiChartPaletteQualitativeHue7",  #93b9c6  rgba(147, 185, 198, 1)
		// color8_lightGrey: "sapUiChartPaletteQualitativeHue8", #ccc5a8  rgba(204, 197, 168, 1)
		// color9_turquoisBlue: "sapUiChartPaletteQualitativeHue9", #52bacc  rgba(82, 186, 204, 1)
		// color10_lightGreen: "sapUiChartPaletteQualitativeHue10", #dbdb46  rgba(219, 219, 70, 1)
		// color11_lila: "sapUiChartPaletteQualitativeHue11"   	#98aafb  rgba(152, 170, 251, 1)

		formatter: formatter,
		models: models,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {

			ChartCustomFormat.registerCustomFormat();

			//this.initFilterBase();
			//initialize filter component
			this.oFilterComponent = new FilterComponent(this);
			if (!this.getOwnerComponent().getModel("variantManagement")) {
				this._loadVariants("MCSCHARTS");
			}
			

			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

			//===========================================================
			//Escalation Overview 
			//===========================================================
			//Number of Escalations currently ongoing per region - Global Escalations (Production Downs)
			//===========================================================
			this.addNumberOfEscalationsOngoingKPI();

			//===========================================================
			//Escalation Overview Details
			//===========================================================
			//Number of closed / new / ongoing Escalations
			//===========================================================
			this.addNumberOfClosedNewOngoingKPI();

			//===========================================================
			//Average Duration of closed Escalations (in days)
			//===========================================================
			this.addAverageDurationOfEscalationKPI();

			//===========================================================
			//Top 5 Products (based on product lines) with High Number of Escalations
			//===========================================================
			this.addTop5ProductsNumberKPI();

			//===========================================================
			//Number of Escalations of Strategic Products (based on product lines) 
			//===========================================================
			this.addStrategicProductsNumberKPI();
			//this.addTest();

			//===========================================================
			//Escalation Costs Allocation
			//===========================================================
			//Total Escalation Costs 
			//===========================================================
			this.addTotalEscalationCostsKPI();

			//===========================================================
			//Average Escalation Costs  
			//===========================================================
			this.addAverageEscalationCostsKPI();

			//===========================================================
			//Escalation Costs per Product Category
			//===========================================================
			this.addEscCostsPerProductCategory();

			//===========================================================
			//Top 5 Products with High Escalation Costs  
			//===========================================================
			this.addTop5ProductsWithHighEscCosts();

			//===========================================================
			//Top 5 Products with High Escalation Costs  
			//===========================================================
			this.addEscCostsOfStrategicProducts();

			//===========================================================
			//KPIs Production Downs
			//===========================================================
			//New Production Downs by Creation Month 
			//===========================================================
			//	this.addNewProdDownByCreationMonthKPI();

			this.getRouter().getRoute("MCSCharts").attachPatternMatched(this.onChartsMatched, this);

			//Drop Down for "Number of closed / new / ongoing Escalations" Chart
			// var model = new JSONModel({
			// 	"EscalationTypes": [{
			// 		key: "ZSPRCTYP01",
			// 		text: this._oResourceBundle.getText("escalationTypeGlobal") //"Global Escalations"
			// 	}, {
			// 		key: "ZSPRCTYP02",
			// 		text: this._oResourceBundle.getText("escalationTypeProdDown") //"Production Downs"
			// 	}, {
			// 		key: "ALL",
			// 		text: this._oResourceBundle.getText("escalationTypeAll") //"Global Escalations and Production Downs"
			// 	}]
			// });
			// this.setModel(model, "escalationTypes");

			//Drop down for cost charts in order to select Global customer or Product escalations
			var modelEscaTypeCostCharts = new JSONModel({
				"EscalationTypes": [{
					key: "ALL",
					text: this._oResourceBundle.getText("escalationTypeAllCostCharts") //"Global Escalations and Product Escalations"
				}, {
					key: "ZSPRCTYP01",
					text: this._oResourceBundle.getText("escalationTypeGlobal") //"Global Escalations"
				}, {
					key: "ZSPRCTYP06",
					text: this._oResourceBundle.getText("escalationTypeProductEscalations") //"Product Escalations"
				}]
			});
			this.setModel(modelEscaTypeCostCharts, "escalationTypesCostCharts");

			//hide table view of chart on initial load
			this.getView().byId("sKPIClosedNewOngoingEscalationsTable").setVisible(false);

			//analytical map: title with current month and year
			var date = new Date();
			var year = new Date().getFullYear();

			var locale = "en-us",
				month = date.toLocaleString(locale, {
					month: "long"
				});

			var sdate = month + " " + year;

			var myBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var stext = myBundle.getText("escalationOverviewTitleNumberOfEscalations", [sdate]);
			this.getView().byId("mapTitle").setText(stext);
			//just a test if the focus works:
			// jQuery.sap.delayedCall(500, this, function () {
			// 	this.getView().byId("vizFrameTop5NumberTitle").focus();
			// });
		},
		onChartsMatched: function (event) {
			this.getOwnerComponent().getModel("settings").setProperty("/isInChartsTile", true);
			var oFaceFilterSelection = this.getOwnerComponent().getModel("filterModel").getProperty("/facetFilterSelection");

			var oArgs = event.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);

			//	if (oFaceFilterSelection) {
			//	}
			//check if data has been read
			//CRM Model
			if (!this.getModel("KPICases")) {
				var kpiCasesModel = new JSONModel({
					casesKPIOngoingEscalationsRegion: null,
					casesKPIClosedNewOngoingEscalations: null,
					casesKPIClosedNewOngoingEscalationsTable: null,
					casesKPIAverageDurationClosedEscalations: null,
					//	casesKPINewProdDownByCreationMonth: null,
					casesKPITop5Products: null,
					casesKPIStrategicProducts: null
				});
				//if (!this.getModel("KPICases")) {
				// moved to _loadVariants
				//kpiCasesModel = this.getCasesFromCRMforKPI(this.getOwnerComponent().getModel("mcsModel"), this.getOwnerComponent()
				//	.getModel("filterModel"), this.getOwnerComponent().getModel("settings"), this.getResourceBundle());
				this.getOwnerComponent().setModel(kpiCasesModel, "KPICases");
			}

			//BW Model
			if (!this.getModel("KPICasesBW")) {
				var kpiCasesBWModel = new JSONModel({
					casesKPITotalEscalationCosts: {
						info: {
							hasData: false,
							isBusy: false
						},
						data: null
					},
					casesKPITotalEscalationCostsTable: null,
					casesKPIAverageEscalationCosts: {
						info: {
							hasData: false,
							isBusy: false
						},
						data: null
					},
					casesKPIAverageEscalationCostsTable: null,
					casesKPIEscalationOverviewCostsTable: {
						info: {
							hasData: false,
							isBusy: false
						},
						data: null
					},
					escCostsPerProductCategory: {
						info: {
							hasData: false,
							isBusy: false
						},
						data: null
					},
					escCostsPerProductCategoryTable: {
						info: {
							hasData: false,
							isBusy: false
						},
						data: null
					},
					top5ProductsWithHighEscCosts: {
						info: {
							hasData: false,
							isBusy: false
						},
						data: null
					},
					top5ProductsWithHighEscCostsTable: {
						info: {
							hasData: false,
							isBusy: false
						},
						data: null
					},
					escCostsOfStrategicProducts: {
						info: {
							hasData: false,
							isBusy: false
						},
						data: null
					},
					escCostsOfStrategicProductsTable: {
						info: {
							hasData: false,
							isBusy: false
						},
						data: null
					}
				});

				
				this.getOwnerComponent().setModel(kpiCasesBWModel, "KPICasesBW");
			}

			if (!this.getOwnerComponent().getModel("settings").getProperty("/initialReadOfVariantManagement")) {
				this.oFilterComponent.syncFacetFilters(oFaceFilterSelection, false);
			} else {
				this.oFilterComponent.syncFacetFilters(oFaceFilterSelection, true);
			}
			//////////////////
			//Escalation Cost Overview -->  only needs to be read once, because no filters can be applied
			/////////////////
			//readEscalationCostsOverviewFromBWP
			//if (bInitialCall) {
			this.oFilterComponent.readCases();
			this.oFilterComponent.readCasesBWKPI();
			this.oFilterComponent.readEscalationCostsOverviewFromBWP();
			//	}

			var iconTabBar = this.getView().byId("idIconTabBarKPICharts");
			var iconTabBarSub = this.getView().byId("analyticalMapEscalationOverviewMainIconTabBar");

			var oArgs = event.getParameter("arguments");

			if (oArgs["?query"] && oArgs["?query"].firstTabBar) {
				var oSection = iconTabBar.getItems().find(function (section) {
					return section.getId().indexOf(oArgs["?query"].firstTabBar) > -1;
				});
			} else if (jQuery.sap.getUriParameters() && jQuery.sap.getUriParameters()._get("firstTabBar") && jQuery.sap.getUriParameters()._get(
					"firstTabBar") !== "") {
				var oSection = iconTabBar.getItems().find(function (section) {
					return section.getId().indexOf(jQuery.sap.getUriParameters()._get("firstTabBar")) > -1;
				});
			} else {
				var oSection = iconTabBar.getItems()[0];
			}

			if (oSection && oSection.getVisible()) {
				iconTabBar.setSelectedItem(oSection);
			} else {
				iconTabBar.setSelectedItem(iconTabBar.getItems()[0]);
			}

			if (oArgs["?query"] && oArgs["?query"].secondTabBar) {
				var oSection = iconTabBarSub.getItems().find(function (section) {
					return section.getId().indexOf(oArgs["?query"].secondTabBar) > -1;
				});
			} else if (jQuery.sap.getUriParameters() && jQuery.sap.getUriParameters()._get("secondTabBar") && jQuery.sap.getUriParameters()._get(
					"secondTabBar") !== "") {
				var oSection = iconTabBarSub.getItems().find(function (section) {
					return section.getId().indexOf(jQuery.sap.getUriParameters()._get("secondTabBar")) > -1;
				});
			} else {
				var oSection = iconTabBarSub.getItems()[0];
			}

			if (oSection && oSection.getVisible()) {
				iconTabBarSub.setSelectedItem(oSection);
			} else {
				iconTabBarSub.setSelectedItem(iconTabBarSub.getItems()[0]);
			}

			//navigation to specific charts
			var sSelectedChart = "";
			if (oArgs["?query"] && oArgs["?query"].chartselection) {
				sSelectedChart = oArgs["?query"].chartselection;
			} else if (jQuery.sap.getUriParameters() && jQuery.sap.getUriParameters()._get("chartselection") && jQuery.sap.getUriParameters()._get(
					"chartselection") !== "") {
				sSelectedChart = jQuery.sap.getUriParameters()._get("chartselection");
			}
			//just for testing sSelectedChart = "top5cost";
			var oPage = this.getView().byId("chartsEscalationOverviewScrollContainer");
			var oPanel = this.getView().byId("vizFrameNumberOfEscalations");

			if (sSelectedChart !== "") {
				switch (sSelectedChart) {
				case "newEscalationCases":
					oPage = this.getView().byId("chartsEscalationOverviewScrollContainer");
					oPanel = this.getView().byId("vizFrameNewEscalationCases");
					iconTabBar.setSelectedItem(iconTabBar.getItems()[0]);
					break;
				case "rootCauses":
					oPage = this.getView().byId("chartsEscalationOverviewScrollContainer");
					oPanel = this.getView().byId("vizFrameRootCauses");
					iconTabBar.setSelectedItem(iconTabBar.getItems()[0]);
					break;
				case "top5":
					oPage = this.getView().byId("chartsEscalationOverviewScrollContainer");
					oPanel = this.getView().byId("vizFrameTop5Number");
					iconTabBar.setSelectedItem(iconTabBar.getItems()[0]);
					break;
				case "averageduration":
					oPage = this.getView().byId("chartsEscalationOverviewScrollContainer");
					oPanel = this.getView().byId("vizFrameAverageDurationOfEscalation");
					iconTabBar.setSelectedItem(iconTabBar.getItems()[0]);
					break;
				case "totalescacosts":
					oPage = this.getView().byId("chartsEscalationCostOverviewScrollContainer");
					oPanel = this.getView().byId("vizFrameTotalEscalationCosts");
					iconTabBar.setSelectedItem(iconTabBar.getItems()[1]);
					break;
				case "averageescacosts":
					oPage = this.getView().byId("chartsEscalationCostOverviewScrollContainer");
					oPanel = this.getView().byId("vizFrameAverageEscalationCosts");
					iconTabBar.setSelectedItem(iconTabBar.getItems()[1]);
					break;
				case "escacostsperprodcat":
					oPage = this.getView().byId("chartsEscalationCostOverviewScrollContainer");
					oPanel = this.getView().byId("vizFrameEscCostsPerProductCategory");
					iconTabBar.setSelectedItem(iconTabBar.getItems()[1]);
					break;
				case "top5cost":
					oPage = this.getView().byId("chartsEscalationCostOverviewScrollContainer");
					oPanel = this.getView().byId("vizFrameTop5ProductsWithHighEscCosts");
					iconTabBar.setSelectedItem(iconTabBar.getItems()[1]);
					break;
				default:
					oPage = this.getView().byId("chartsEscalationOverviewScrollContainer");
					oPanel = this.getView().byId("vizFrameNumberOfEscalations");
					iconTabBar.setSelectedItem(iconTabBar.getItems()[0]);
					break;
				}
				oPage.scrollToElement(oPanel);
			}

			this.readNewEscalationCases();
			this.readRootCauses();
			this.trackEvent("Display Escalation Statistics");

			// moved to respecitve calls ins FilterComponent this._setCostChartandTableVisibility();

		},

		onAfterRendering: function (event) {
			// this.getView().byId("vizFrameTop5Number").setVisible(false);
			// this.getView().byId("vizFrameTop5Number").setVisible(true);
			// this.getView().byId("vizFrameTop5Number").rerender();
			// this.getView().byId("vizFrameStrategicNumber").rerender();

			// if (this.getView().byId("vizFrameTop5Number")) {
			// 	this.getView().byId("vizFrameTop5Number").setVizProperties({
			// 		plotArea: {
			// 			dataLabel: {
			// 				visible: true
			// 			}
			// 		}
			// 	});
			// }
			//just a test if the focus works:
			// jQuery.sap.delayedCall(5000, this, function () {
			// 	var s =this.getView().byId("vizFrameTop5NumberTitle").getFocusInfo();
			// 	this.getView().byId("vizFrameTop5NumberTitle").focus();
			// });


			//006	//check, which quarter is currently ongoing. needed for visual highlighting of current quarter in cost overview table
			var myBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var today = new Date(); //"01.02.2019"
			var quarter = Math.floor((today.getMonth() + 3) / 3);
			switch (quarter) {
			case 2:
				this.getView().byId("escaCostOverviewTreeTableQ2Label").setText(myBundle.getText("notFinalText", [myBundle.getText("quarter2")]));
				this.getView().byId("escaCostOverviewTreeTableQ2Label").addStyleClass("MCSDashboardQuarterOngoingClass");
				return;
			case 3:
				this.getView().byId("escaCostOverviewTreeTableQ3Label").setText(myBundle.getText("notFinalText", [myBundle.getText("quarter3")]));
				this.getView().byId("escaCostOverviewTreeTableQ3Label").addStyleClass("MCSDashboardQuarterOngoingClass");
				return;
			case 4:
				this.getView().byId("escaCostOverviewTreeTableQ4Label").setText(myBundle.getText("notFinalText", [myBundle.getText("quarter4")]));
				this.getView().byId("escaCostOverviewTreeTableQ4Label").addStyleClass("MCSDashboardQuarterOngoingClass");
				return;
			default:
				this.getView().byId("escaCostOverviewTreeTableQ1Label").setText(myBundle.getText("notFinalText", [myBundle.getText("quarter1")]));
				this.getView().byId("escaCostOverviewTreeTableQ1Label").addStyleClass("MCSDashboardQuarterOngoingClass");
				return;
			}



		},

		readRootCauses: function () {
			var oChart = this.getView().byId("vizFrameRootCauses");
			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;

			var oPopOver = new sap.viz.ui5.controls.Popover({
				'customDataControl': function (data) {
					if (data.data.val) {
						var values = data.data.val,
							divStr = "",
							idx = values[1].value;

						divStr = divStr + "<div style = 'margin: 15px 30px 0 10px'>Product: <b style='margin-left:10px'>" + values[0].value +
							"</b></div>";
						divStr = divStr + "<div style = 'margin: 5px 30px 0 10px'>Rootcause: <b style='margin-left:10px'>" + values[2].name +
							"</b></div>";
						divStr = divStr + "<div style = 'margin: 5px 30px 10px 10px'>Cases: <b style='margin-left:10px'>" + values[2].value +
							"</span></div>";
						return new sap.ui.core.HTML({
							content: divStr
						});
					}
				}
			});
			oPopOver.connect(oChart.getVizUid());

			oChart.setVizProperties({
				plotArea: {
					isFixedDataPointSize: false, //used in order to show all columns on the screen - column width set based on vavailable space
					dataLabel: {
						visible: false
					},
					dataShape: {
						primaryAxis: ["column"]
					},
					window: {
						start: "firstDataPoint",
						end: "lastDataPoint"
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.LONGFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: false
				}
			});
			var iThisYear = new Date().getFullYear();

			var aRequest = [{
				"queryIdentifier": "CL_MCC_TOOLS_MCS_CASE",
				"elementList": [
					"Case_Counter", "Case_Reason__rootcause_", "PPMS_Product_Line"
				],
				"sortSteps": [{
					"elementIdentifier": "Creation_Date_Year_YYYY",
					"direction": "DESC"
				}],
				"filters": [{
					"filters": [{
						"filters": [{
							"operand1": {
								"elementIdentifier": "Case_Process_Type"
							},
							"operand2": {
								"values": [
									"ZSPRCTYP01"
								]
							},
							"operator": "EQ"
						}, {
							"operand1": {
								"elementIdentifier": "Case_Status"
							},
							"operand2": {
								"values": [
									"20", "30", "40"
								]
							},
							"operator": "EQ"
						}, {
							"operand1": {
								"elementIdentifier": "Creation_Date_Year_YYYY"
							},
							"operand2": {
								"values": [iThisYear]
							},
							"operator": "LE"
						}],
						"conjunctionOperator": "AND"
					}, {
						"filters": [{
							"operand1": {
								"elementIdentifier": "Closing_Date_Day_YYYYMMDD"
							},
							"operand2": {
								"values": [
									iThisYear + "0101"
								]
							},
							"operator": "GE"
						}, {
							"operand1": {
								"elementIdentifier": "Closure_Date_Null"
							},
							"operand2": {
								"values": [
									"yes"
								]
							},
							"operator": "EQ"
						}],
						"conjunctionOperator": "OR"
					}],
					"conjunctionOperator": "AND"
				}]
			}];

			var aProductLines = [];
			for (var tmp in this.getModel("filterModel").getProperty("/facetFilterSelection/productLine")) {
				aProductLines.push(tmp.toString());
			}

			//set product line filter
			if (aProductLines.length > 0) {
				var oProductLineFilter = {
					conjunctionOperator: "OR",
					filters: []
				}

				oProductLineFilter.filters.push({
					operator: "EQ",
					operand1: {
						elementIdentifier: "PPMS_Product_Line"
					},
					operand2: {
						values: aProductLines
					}
				})
				aRequest[0].filters[0].filters.push(oProductLineFilter);
			}

			oChart.setBusy(true);
			$.ajax({
				method: "POST",
				headers: {
					"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
				},
				url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3?user-propagation=true",
				data: JSON.stringify(aRequest),
				contentType: "application/json"
			}).always(function (data, stextStatus, errorThrown) {
				//$.ajax("./json/ExampleRootCause.json", {}).always(function (data, stextStatus, errorThrown) {
				oChart.setBusy(false);
				if (data.queryResults && data.queryResults.CL_MCC_TOOLS_MCS_CASE && data.queryResults.CL_MCC_TOOLS_MCS_CASE.rows) {
					var aProducts = [];
					var aRootcauses = [];
					data.queryResults.CL_MCC_TOOLS_MCS_CASE.rows.forEach(function (row) {
						if (row.PPMS_Product_Line.key) {
							//check if product is already added
							var oProduct = aProducts.find(function (product) {
								return product.id === row.PPMS_Product_Line.key;
							});
							if (!oProduct) {
								var obj = {};
								obj[row.Case_Reason__rootcause_.key] = row.Case_Counter.value;
								obj.name = row.PPMS_Product_Line.title;
								obj.id = row.PPMS_Product_Line.key;
								obj.value = row.Case_Counter.value;
								aProducts.push(obj);
							} else {
								oProduct.value += row.Case_Counter.value;
								if (oProduct[row.Case_Reason__rootcause_.key]) {
									oProduct[row.Case_Reason__rootcause_.key] += row.Case_Counter.value;
								} else {
									oProduct[row.Case_Reason__rootcause_.key] = row.Case_Counter.value;
								}
							}

							var oTmp = aRootcauses.find(function (c) {
								return c.key === row.Case_Reason__rootcause_.key;
							});
							if (row.Case_Reason__rootcause_.key && !oTmp) {
								aRootcauses.push({
									name: row.Case_Reason__rootcause_.title,
									key: row.Case_Reason__rootcause_.key
								});
							}
						}
					}.bind(this));
					//take only top 10 product lines
					aProducts = aProducts.sort(function (a, b) {
						return b.value - a.value;
					});
					aProducts = aProducts.slice(0, 10);

					oChart.setModel(new JSONModel(aProducts), "data");
					oChart.getDataset().removeAllMeasures();
					oChart.removeAllFeeds();

					var oValueFeed = new sap.viz.ui5.controls.common.feeds.FeedItem({
						uid: "categoryAxis",
						type: "Dimension",
						values: ["name"]
					});
					oChart.addFeed(oValueFeed);

					var aMeasures = [];

					//sort
					aRootcauses = aRootcauses.sort(function (a, b) {
						return a.name < b.name ? -1 : a.name > b.name ? 1 : 0;
					});

					aRootcauses.forEach(function (cause) {
						oChart.getDataset().addMeasure(new sap.viz.ui5.data.MeasureDefinition({
							name: cause.name,
							value: "{data>" + cause.key + "}"
						}));
						var oValueFeed = new sap.viz.ui5.controls.common.feeds.FeedItem({
							uid: "valueAxis",
							type: "Measure",
							values: [cause.name]
						});
						oChart.addFeed(oValueFeed);
					}.bind(this))
				}

			}.bind(this));
		},

		readNewEscalationCases: function () {
			var oChart = this.getView().byId("vizFrameNewEscalationCases");
			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;

			var oPopOver = new sap.viz.ui5.controls.Popover({
				'customDataControl': function (data) {
					if (data.data.val) {
						var values = data.data.val,
							divStr = "",
							idx = values[1].value;

						divStr = divStr + "<div style = 'margin: 15px 30px 0 10px'>Month: <b style='margin-left:10px'>" + values[0].value + " " +
							values[2].name.split(" ")[2] +
							"</b></div>";
						divStr = divStr + "<div style = 'margin: 5px 30px 10px 10px'>Escalation Cases: <b style='margin-left:10px'>" + values[2].value +
							"</span></div>";
						return new sap.ui.core.HTML({
							content: divStr
						});
					}
				}
			});
			oPopOver.connect(oChart.getVizUid());

			oChart.setVizProperties({
				plotArea: {
					isFixedDataPointSize: false, //used in order to show all columns on the screen - column width set based on vavailable space
					dataLabel: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_2,
						visible: false
					},
					dataShape: {
						primaryAxis: ["line", "line", "line", "line"]
					},
					//Colors based on Fiori Qualitative Palette
					colorPalette: ["sapUiChartPaletteQualitativeHue8", "sapUiChartPaletteQualitativeHue5", "sapUiChartPaletteQualitativeHue1",
						"sapUiChartPaletteQualitativeHue3"
					],
					line: {
						marker: {
							size: 12
						}
					},
					window: {
						start: "firstDataPoint",
						end: "lastDataPoint"
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: false
				}
			});
			var aYears = [];
			var aConfigData = [{
				month: 0,
				desc: "Jan"
			}, {
				month: 1,
				desc: "Feb"
			}, {
				month: 2,
				desc: "Mar"
			}, {
				month: 3,
				desc: "Apr"
			}, {
				month: 4,
				desc: "May"
			}, {
				month: 5,
				desc: "Jun"
			}, {
				month: 6,
				desc: "Jul"
			}, {
				month: 7,
				desc: "Aug"
			}, {
				month: 8,
				desc: "Sep"
			}, {
				month: 9,
				desc: "Oct"
			}, {
				month: 10,
				desc: "Nov"
			}, {
				month: 11,
				desc: "Dec"
			}, ]
			var iThisYear = new Date().getFullYear();
			for (var i = 0; i <= 3; i++) {
				aYears.push((iThisYear - i).toString());
			}
			oChart.setBusy(true);
			$.ajax({
				method: "POST",
				headers: {
					"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
				},
				url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3?user-propagation=true",
				data: JSON.stringify([{
					"queryIdentifier": "CL_MCC_TOOLS_MCS_CASE",
					"elementList": [
						"Case_Counter", "Creation_Date_Year_YYYY", "Creation_Month"
					],
					"sortSteps": [{
						"elementIdentifier": "Creation_Date_Year_YYYY",
						"direction": "DESC"
					}],
					"filters": [{
						"filters": [{
							"filters": [{
								"operand1": {
									"elementIdentifier": "Case_Process_Type"
								},
								"operand2": {
									"values": [
										"ZSPRCTYP01"
									]
								},
								"operator": "EQ"
							}, {
								"operand1": {
									"elementIdentifier": "Case_Status"
								},
								"operand2": {
									"values": [
										"20", "30", "40"
									]
								},
								"operator": "EQ"
							}, {
								"operand1": {
									"elementIdentifier": "Creation_Date_Year_YYYY"
								},
								"operand2": {
									"values": aYears.reverse()
								},
								"operator": "EQ"
							}],
							"conjunctionOperator": "AND"
						}, {
							"filters": [{
								"operand1": {
									"elementIdentifier": "Case_Process_Type"
								},
								"operand2": {
									"values": [
										"ZSPRCTYP01"
									]
								},
								"operator": "EQ"
							}, {
								"operand1": {
									"elementIdentifier": "Case_Status"
								},
								"operand2": {
									"values": [
										"98"
									]
								},
								"operator": "EQ"
							}, {
								"operand1": {
									"elementIdentifier": "Creation_Date_Year_YYYY"
								},
								"operand2": {
									"values": aYears.reverse()
								},
								"operator": "EQ"
							}, {
								"operand1": {
									"elementIdentifier": "Closure_Date_Null"
								},
								"operand2": {
									"values": [
										"no"
									]
								},
								"operator": "EQ"
							}],
							"conjunctionOperator": "AND"
						}],
						"conjunctionOperator": "OR"
					}]
				}]),
				contentType: "application/json"
			}).always(function (data, stextStatus, errorThrown) {
				//$.ajax("./json/ExampleNewEscalationCases.json", {}).always(function (data, stextStatus, errorThrown) {
				oChart.setBusy(false);
				if (data.queryResults && data.queryResults.CL_MCC_TOOLS_MCS_CASE && data.queryResults.CL_MCC_TOOLS_MCS_CASE.rows.length > 0) {
					var aRows = data.queryResults.CL_MCC_TOOLS_MCS_CASE.rows;
					var aData = [];
					var aMeasures = [];
					var aCurrentMonth = new Date().getMonth() - 1;

					for (var i = 0; i < 12; i++) {
						var oTmp = aConfigData.find(function (conf) {
							return conf.month === aCurrentMonth;
						});
						aCurrentMonth--;
						if (aCurrentMonth === -1) {
							aCurrentMonth = 11;
						}
					}

					aRows.forEach(function (row) {
						//check if month already added
						var oMonth = aData.find(function (data) {
							return data.month === row.Creation_Month.key;
						});
						var sKey = row.Creation_Date_Year_YYYY.key;
						var oConfig = aConfigData.find(function (conf) {
							return conf.desc === row.Creation_Month.key;
						});
						if (!oMonth) {
							var object = {};
							object.month = row.Creation_Month.key;
							object[sKey] = row.Case_Counter.value;
							object.order = oConfig.month;
							aData.push(object);
						} else {
							oMonth[sKey] = row.Case_Counter.value;
						}
					});
					aData.sort(function (a, b) {
						return a.order - b.order;
					});

					aYears.forEach(function (year) {
						for (var i = 0; i < aData.length; i++) {
							if (i !== 0 && aData[i][year]) {
								aData[i][year] = aData[i][year] + aData[(i - 1)][year];
							}
						}

						var sNameAsString = "Escalation Cases " + year;
						oChart.getDataset().addMeasure(new sap.viz.ui5.data.MeasureDefinition({
							name: sNameAsString,
							value: "{data>" + year + "}"
						}));

						var oValueFeed = new sap.viz.ui5.controls.common.feeds.FeedItem({
							uid: "valueAxis",
							type: "Measure",
							values: [sNameAsString]
						});
						oChart.addFeed(oValueFeed);
					})

					oChart.setModel(new JSONModel(aData), "data");
				}
			});
		},

		_setCostChartandTableVisibility: function () {
			//in case if region != WORLD show column chart for specific region in cost KPI TAB
			//check also, if table view is currently selected, if this is the case we do not have to take care of chart switching
			var sRegion = this.getModel("filterModel").getProperty("/region");
			var oSettingsModel = this.getModel("settings");
			if (sRegion === "" || sRegion === "World") {
				if (oSettingsModel.getProperty("/kpiTotalEscalationCostsTableVisible") === false) {
					oSettingsModel.setProperty("/kpiTotalEscalationCostsChartVisible", true);
					oSettingsModel.setProperty("/kpiTotalEscalationCostsChartRegionVisible", false);
				}
				if (oSettingsModel.getProperty("/kpiAverageEscalationCostsTableVisible") === false) {
					oSettingsModel.setProperty("/kpiAverageEscalationCostsChartVisible", true);
					oSettingsModel.setProperty("/kpiAverageEscalationCostsChartRegionVisible", false);
				}
				//EscalationRequests
				//	oSettingsModel.setProperty("/kpiEscalRequestsVisible", true);
				//	oSettingsModel.setProperty("/kpiEscalRequestsRegionVisible", false);
			} else {
				if (oSettingsModel.getProperty("/kpiTotalEscalationCostsTableVisible") === false) {
					oSettingsModel.setProperty("/kpiTotalEscalationCostsChartRegionVisible", true);
					oSettingsModel.setProperty("/kpiTotalEscalationCostsChartVisible", false);
				}
				if (oSettingsModel.getProperty("/kpiAverageEscalationCostsTableVisible") === false) {
					oSettingsModel.setProperty(
						"/kpiAverageEscalationCostsChartRegionVisible", true);
					oSettingsModel
						.setProperty("/kpiAverageEscalationCostsChartVisible", false);
				}
				//EscalationRequests
				//	oSettingsModel.setProperty("/kpiEscalRequestsVisible", false);
				//	oSettingsModel.setProperty("/kpiEscalRequestsRegionVisible", true);
			}
		},
		/**
		 * event handler for selection of specific region
		 */
		onSelectRegion: function (event) {
			if (event.getParameter("selected")) {
				this.trackEvent("Region Filter: Select");
			}
			//var oButton = oParam.getSource().getSelectedButton();
			var sText = event.getSource().getText();
			var oFilterModel = this.getModel("filterModel");
			var oRegionContainer = this.getView().byId("regionContainer");
			var aRegions = [],
				aRegionsT = [];
			var oSettingsModel = this.getModel("settings");
			var that = this;
			oRegionContainer.getItems().forEach(function (region) {
				if (region.getSelected() && sText !== "World" && region.getText() !== "World") {
					aRegionsT.push(region.getText());
					aRegions.push(that.formatter.formatRegionNameToRegionCode(region.getText()));
				} else if (sText === "World" && region.getText() !== "World") {
					region.setSelected(false);
				} else if (sText !== "World" && region.getText() === "World") {
					region.setSelected(false);
				}
			});
			var sRegion = aRegions.join();

			if (sRegion === "") {
				oRegionContainer.getItems()[0].setSelected(true);
			}

			oFilterModel.setProperty("/region", sRegion);
			oFilterModel.setProperty("/regionText", aRegionsT.join());

			//Update MCS Charts
			this.oFilterComponent.readCases(); //this.getModel("KPICases"), this.getOwnerComponent().getModel("mcsModel"), this.getOwnerComponent().getModel("filterModel"), this.getOwnerComponent().getModel("settings")
			//this.oFilterComponent.readCasesNoFiltersApply(); //this.getModel("KPICases"), this.getOwnerComponent().getModel("mcsModel"), this.getOwnerComponent().getModel("filterModel")
			this.oFilterComponent.readCasesBWKPI(false); 
			if (this.oFilterComponent.oFacetFilter._variantInitiallyLoaded === true) {
				this.oFilterComponent.oFacetFilter._variantInitiallyLoaded = false;
			}
			// set current filter variant to modified /dirty flag 
			if (!this.oFilterComponent.oFacetFilter._variantInitiallyLoaded) {
				this.getView().byId("filterVariantManagement").currentVariantSetModified(true);
			}

			// var selectedIndex = event.getParameter("selectedIndex");
			// var radioButtonSrc = event.getSource().getAggregation("buttons");
			// var selectedId = (selectedIndex > 0) ? radioButtonSrc[selectedIndex].getId().split("--").slice(-1)[0] : null;

			// Create filter based on selected radio button
			//this.getModel("filters").setProperty("/region", selectedId);

			//moved to respective calls in FilterComponent - readCasesBWKPI	this._setCostChartandTableVisibility();
			//enable setDirty after initial load of variant  -->  region is directly set in function onSelectVariant
			// if (this.facetFilter._variantInitiallyLoaded === true) {
			// 	this.facetFilter._variantInitiallyLoaded = false;
			// }
			// // set current filter variant to modified /dirty flag 
			// if (!this.facetFilter._variantInitiallyLoaded) {
			// 	this.getView().byId("filterVariantManagement").currentVariantSetModified(true);
			// }

			//reset the piechart table information and hide
			//if (this.getModel("KPICasesTable")) {
			//	this.setModel("KPICasesTable", null);
			oSettingsModel.setProperty("/kpi_Top5Products_TableVisibility", false);
			oSettingsModel.setProperty("/kpi_StrategicProducts_TableVisibility", false);
			oSettingsModel.setProperty("/isVisible_Top5ProductsWithHighEscCostsTable", false);
			oSettingsModel.setProperty("/isVisible_EscCostsOfStrategicProductsTable", false);
			oSettingsModel.setProperty("/isVisible_EscCostsPerProdCategoryTable", false);
			//}
		},

		/**
		 * Event Hanlder if Escalation Type selection changes for TotalEscaCosts chart in order to get the needed data from the BW backend
		 */
		onEscalationTypesChangeTotalEscaCosts: function (selectedItem) {
			//var escalationFilters = this.getOwnerComponent().getModel("bwFilterModel").buildODataFilter("BWP").aFilters;
			var escalationFilters = [];
			var oFilterForBWP = this.getOwnerComponent().getModel("bwFilterModel").getProperty("/oFilterForBWCosts");
			if (oFilterForBWP && oFilterForBWP.aFilters.length > 0) {
				escalationFilters.push(oFilterForBWP);
			}

			var finalFilter = escalationFilters;

			//add drop Down specific filtering
			if (selectedItem.getSource().getSelectedKey() !== "ALL") {
				this.getOwnerComponent().getModel("settings").setProperty("/kpiTotalEscalationCostsFilter", selectedItem.getSource().getSelectedKey());
				var kpiSpecificFilters = new sap.ui.model.Filter([new sap.ui.model.Filter("A4MCASEX017CSM_STYP", sap.ui.model.FilterOperator.EQ,
					selectedItem.getSource().getSelectedKey())].filter(Boolean), true);
				//finalFilter = this.getOwnerComponent().getModel("bwFilterModel").buildODataFilter("BWP", kpiSpecificFilters).aFilters;
				finalFilter.push(kpiSpecificFilters);
			} else {
				this.getOwnerComponent().getModel("settings").setProperty("/kpiTotalEscalationCostsFilter", "ALL");
			}

			var kpiCasesModel = this.getModel("KPICasesBW");
			var settingsModel = this.getOwnerComponent().getModel("settings");
			//check if region filter has been selected, because different chart is shown for BW KPI charts and only one row in the table view for the specific region
			//because we need the inner filter array- we can always be sure, that there is at least one filter, because we have to set GSS initially in createFiltersModel function
			// if (finalFilter[0]) {
			// 	finalFilter = finalFilter[0].aFilters;
			// }

			var sRegion = this.getRegionFilterModel();
			//var region = sRegion;
			var kpiCasesChart = this.oFilterComponent.initializeBWPChartArrays("kpiCasesChart", this.getOwnerComponent().getModel(
				"filterModel"));
			var kpiCasesTable = this.oFilterComponent.initializeBWPChartArrays("kpiCasesTableChart", this.getOwnerComponent().getModel(
				"filterModel"), settingsModel);
			var kpiCasesTableIDs = [];
			// var regionOnlyFilterForBWP = this.getOwnerComponent().getModel("bwFilterModel").buildRegionOnlyODataFilter("BWP", region).aFilters;
			// var sFilter = this.getOwnerComponent().getModel("bwFilterModel").buildURLVariableFilterForBWP(regionOnlyFilterForBWP,
			// 	"CostStandardStructure");


			var bwp004TotalEscaCost13BWModel = new sap.ui.model.odata.v2.ODataModel(
				sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCASE_COST_ODA_004N_SRV", {
				"metadataUrlParams": {
					"sap-documentation": "heading"
				},
				"defaultCountMode": true,
				"useBatch": false,
				"headers": {
					"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
				}
			});
			this.oFilterComponent.readTotalEscalationCostsFromBWP(kpiCasesModel, this.getOwnerComponent().getModel("bwFilterModel"),
				sRegion, bwp004TotalEscaCost13BWModel,
				finalFilter, settingsModel, 0, kpiCasesChart, kpiCasesTable, kpiCasesTableIDs);

		},

		/**
		 * Event Hanlder if Escalation Type selection changes for TotalEscaCosts chart in order to get the needed data from the BW backend
		 */
		onEscalationTypesChangeAverageEscaCosts: function (selectedItem) {
			//var escalationFilters = this.getOwnerComponent().getModel("bwFilterModel").buildODataFilter("BWP").aFilters;
			var escalationFilters = [];
			var oFilterForBWP = this.getOwnerComponent().getModel("bwFilterModel").getProperty("/oFilterForBWCosts");
			if (oFilterForBWP && oFilterForBWP.aFilters.length > 0) {
				escalationFilters.push(oFilterForBWP);
			}
			var finalFilter = escalationFilters;
			//add drop Down specific filtering
			if (selectedItem.getSource().getSelectedKey() !== "ALL") {
				this.getOwnerComponent().getModel("settings").setProperty("/kpiAverageEscaltaionCostsFilter", selectedItem.getSource().getSelectedKey());
				var kpiSpecificFilters = new sap.ui.model.Filter([new sap.ui.model.Filter("A4MCASEX017CSM_STYP", sap.ui.model.FilterOperator.EQ,
					selectedItem.getSource().getSelectedKey())].filter(Boolean), true);
				//	finalFilter = this.getOwnerComponent().getModel("bwFilterModel").buildODataFilter("BWP", kpiSpecificFilters).aFilters;
				finalFilter.push(kpiSpecificFilters);
			} else {
				this.getOwnerComponent().getModel("settings").setProperty("/kpiAverageEscaltaionCostsFilter", "ALL");
			}

			var kpiCasesModel = this.getModel("KPICasesBW");
			var settingsModel = this.getOwnerComponent().getModel("settings");
			//check if region filter has been selected, because different chart is shown for BW KPI charts and only one row in the table view for the specific region
			//because we need the inner filter array- we can always be sure, that there is at least one filter, because we have to set GSS initially in createFiltersModel function
			// if (finalFilter[0]) {
			// 	finalFilter = finalFilter[0].aFilters;
			// }

			var sRegion = this.getRegionFilterModel();
			//var region = sRegion;
			var kpiCasesChartAvg = this.oFilterComponent.initializeBWPChartArrays("kpiCasesChart", this.getOwnerComponent().getModel(
				"filterModel"));
			var kpiCasesTableAvg = this.oFilterComponent.initializeBWPChartArrays("kpiCasesTableChart", this.getOwnerComponent().getModel(
				"filterModel"), settingsModel);
			var kpiCasesTableIDsAvg = [];
			// var regionOnlyFilterForBWP = this.getOwnerComponent().getModel("bwFilterModel").buildRegionOnlyODataFilter("BWP", region).aFilters;
			// var sFilter = this.getOwnerComponent().getModel("bwFilterModel").buildURLVariableFilterForBWP(regionOnlyFilterForBWP,
			// 	"CostStandardStructure");
			var bwp005AverageEscaCost13BWModel = new sap.ui.model.odata.v2.ODataModel(
				sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCASE_COST_ODA_005N_SRV", {
				"metadataUrlParams": {
					"sap-documentation": "heading"
				},
				"defaultCountMode": true,
				"useBatch": false,
				"headers": {
					"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
				}
			});
			this.oFilterComponent.readAverageEscalationCostsFromBWP(kpiCasesModel, this.getOwnerComponent().getModel("bwFilterModel"),
				sRegion, bwp005AverageEscaCost13BWModel,
				finalFilter, settingsModel, 0, kpiCasesChartAvg, kpiCasesTableAvg, kpiCasesTableIDsAvg);
		},
		/**
		 * Switch between table and chart view in KPI view
		 */
		onEscalationDetailTableChartSwitch: function (event) {
			if (event.getSource().getText() === this._oResourceBundle.getText("btnTextTable")) {
				this.getView().byId("vizFrameNumberOfEscalations").setVisible(false);
				this.getView().byId("sKPIClosedNewOngoingEscalationsTable").setVisible(true);
				this.getView().byId("btnTableChartSwitch").setText(this._oResourceBundle.getText("btnTextChart"));
			} else {
				this.getView().byId("vizFrameNumberOfEscalations").setVisible(true);
				this.getView().byId("sKPIClosedNewOngoingEscalationsTable").setVisible(false);
				this.getView().byId("btnTableChartSwitch").setText(this._oResourceBundle.getText("btnTextTable"));
			}
		},
		/**
		 * Switch between table and chart view in KPI view
		 */
		onTotalEscalationCostsTableChartSwitch: function (event) {
			var sRegionFilter = this.getModel("filterModel").getProperty("/region"),
				oSettingsModel = this.getModel("settings");
			if (event.getSource().getText() === this._oResourceBundle.getText("btnTextTable")) {
				oSettingsModel.setProperty("/kpiTotalEscalationCostsChartVisible", false);
				oSettingsModel.setProperty("/kpiTotalEscalationCostsChartRegionVisible", false);
				oSettingsModel.setProperty("/kpiTotalEscalationCostsTableVisible", true);
				this.getView().byId("btnTotalEscalationCostsTableChartSwitch").setText(this._oResourceBundle.getText("btnTextChart"));
			} else {
				//in case if region != WORLD show column chart for specific region
				if (sRegionFilter === "WORLD" || sRegionFilter === "") {
					oSettingsModel.setProperty("/kpiTotalEscalationCostsChartVisible", true);
				} else {
					oSettingsModel.setProperty("/kpiTotalEscalationCostsChartRegionVisible", true);
				}
				oSettingsModel.setProperty("/kpiTotalEscalationCostsTableVisible", false);
				this.getView().byId("btnTotalEscalationCostsTableChartSwitch").setText(this._oResourceBundle.getText("btnTextTable"));
			}
		},
		/**
		 * Switch between table and chart view in KPI view
		 */
		onAverageEscalationCostsTableChartSwitch: function (event) {
			var sRegionFilter = this.getModel("filterModel").getProperty("/region"),
				oSettingsModel = this.getModel("settings");
			if (event.getSource().getText() === this._oResourceBundle.getText("btnTextTable")) {
				oSettingsModel.setProperty("/kpiAverageEscalationCostsChartVisible", false);
				oSettingsModel.setProperty("/kpiAverageEscalationCostsChartRegionVisible", false);
				oSettingsModel.setProperty("/kpiAverageEscalationCostsTableVisible", true);
				this.getView().byId("btnAverageEscalationCostsTableChartSwitch").setText(this._oResourceBundle.getText("btnTextChart"));
			} else {
				//in case if region != WORLD show column chart for specific region
				if (sRegionFilter === "WORLD" || sRegionFilter === "") {
					oSettingsModel.setProperty("/kpiAverageEscalationCostsChartVisible", true);
				} else {
					oSettingsModel.setProperty("/kpiAverageEscalationCostsChartRegionVisible", true);
				}
				oSettingsModel.setProperty("/kpiAverageEscalationCostsTableVisible", false);
				this.getView().byId("btnAverageEscalationCostsTableChartSwitch").setText(this._oResourceBundle.getText("btnTextTable"));
			}
		},

		//===========================================================
		//Number of Escalations currently ongoing per region - Global Escalations (Production Downs)
		//===========================================================
		addNumberOfEscalationsOngoingKPI: function () {
			var rootPath = jQuery.sap.getModulePath("com.sap.mcconedashboard");
			var dataModelEscalationOverview = new sap.ui.model.json.JSONModel([rootPath, "json/AnalyticalMapRegions.json"].join("/")); //new JSONModel("./json/AnalyticalMapRegions.json");

			// set the geojson location to the data provided in a json file
			jQuery.sap.require("sap.ui.vbm.AnalyticMap");
			sap.ui.vbm.AnalyticMap.GeoJSONURL = [rootPath, "json/AnalyticalMapContinents.json"].join("/"); // "./json/AnalyticalMapContinents.json";

			var oSpots = new sap.ui.vbm.Spots("Spots", {
				items: [new sap.ui.vbm.Spot({
					id: "NASpotId",
					position: "-100.74017333984375;45.553080288955805;0",
					tooltip: "NA",
					type: "Hidden",
					labelPos: "5",
					labelType: "Default",
					labelBorderColor: "rgb(212, 215, 219)",
					labelText: "{KPICases>/casesKPIOngoingEscalationsRegion/0/escalationsNA}",
					// {
					// 	parts: [{
					// 		path: "KPICases>/casesKPIOngoingEscalationsRegion/0/escalationsNA"
					// 	// }, {
					// 	// 	path: "KPICases>/casesKPIOngoingEscalationsRegion/0/prodDownNA"
					// 	}],
					// 	formatter: this.formatter.concatenateKpiEscalationOverviewLabels
					// },
					labelArrow: false
				}), new sap.ui.vbm.Spot({
					position: "-64.67376708984375;-4.214943141390639;0",
					tooltip: "LAC",
					type: "Hidden",
					labelPos: "5",
					labelType: "Default",
					labelBorderColor: "rgb(212, 215, 219)",
					labelText: "{KPICases>/casesKPIOngoingEscalationsRegion/0/escalationsLAC}",
					// {
					// 	parts: [{
					// 		path: "KPICases>/casesKPIOngoingEscalationsRegion/0/escalationsLAC"
					// 	// }, {
					// 	// 	path: "KPICases>/casesKPIOngoingEscalationsRegion/0/prodDownLAC"
					// 	}],
					// 	formatter: this.formatter.concatenateKpiEscalationOverviewLabels
					// },
					labelArrow: false
				}), new sap.ui.vbm.Spot({
					position: "96.69342041015625;12.382928338487396;0",
					tooltip: "APJ",
					type: "Hidden",
					labelPos: "5",
					labelType: "Default",
					labelBorderColor: "rgb(212, 215, 219)",
					labelText: "{KPICases>/casesKPIOngoingEscalationsRegion/0/escalationsAPJ}",
					// {
					// 	parts: [{
					// 		path: "KPICases>/casesKPIOngoingEscalationsRegion/0/escalationsAPJ"
					// 	// }, {
					// 	// 	path: "KPICases>/casesKPIOngoingEscalationsRegion/0/prodDownAPJ"
					// 	}],
					// 	formatter: this.formatter.concatenateKpiEscalationOverviewLabels
					// },
					labelArrow: false
				}), new sap.ui.vbm.Spot({
					position: "93.70513916015625;40.44694705960048;0",
					tooltip: "GRC",
					type: "Hidden",
					labelPos: "5",
					labelType: "Default",
					labelBorderColor: "rgb(212, 215, 219)",
					labelText: "{KPICases>/casesKPIOngoingEscalationsRegion/0/escalationsGTC}",
					// {
					// 	parts: [{
					// 		path: "KPICases>/casesKPIOngoingEscalationsRegion/0/escalationsGTC"
					// 	// }, {
					// 	// 	path: "KPICases>/casesKPIOngoingEscalationsRegion/0/prodDownGTC"
					// 	}],
					// 	formatter: this.formatter.concatenateKpiEscalationOverviewLabels
					// },
					labelArrow: false
				}), new sap.ui.vbm.Spot({
					position: "10.86517333984375;30.17380831799959;0",
					tooltip: "EMEA",
					type: "Hidden",
					labelPos: "5",
					labelType: "Default",
					labelBorderColor: "rgb(212, 215, 219)",
					labelText: "{KPICases>/casesKPIOngoingEscalationsRegion/0/escalationsEMEA}",
					// {
					// 	parts: [{
					// 		path: "KPICases>/casesKPIOngoingEscalationsRegion/0/escalationsEMEA"
					// 	// }, {
					// 	// 	path: "KPICases>/casesKPIOngoingEscalationsRegion/0/prodDownEMEA"
					// 	}],
					// 	formatter: this.formatter.concatenateKpiEscalationOverviewLabels
					// },
					labelArrow: false
				}), new sap.ui.vbm.Spot({
					position: "38.66607666015625;51.36525013685606;0",
					tooltip: "MEE",
					type: "Hidden",
					labelPos: "5",
					labelType: "Default",
					labelBorderColor: "rgb(212, 215, 219)",
					labelText: "{KPICases>/casesKPIOngoingEscalationsRegion/0/escalationsMEE}",
					// {
					// 	parts: [{
					// 		path: "KPICases>/casesKPIOngoingEscalationsRegion/0/escalationsMEE"
					// 	// }, {
					// 	// 	path: "KPICases>/casesKPIOngoingEscalationsRegion/0/prodDownMEE"
					// 	}],
					// 	formatter: this.formatter.concatenateKpiEscalationOverviewLabels
					// },
					labelArrow: false
				})]
			});

			// create analytic map and bind to model
			var oVBI1 = new sap.ui.vbm.AnalyticMap('analyticalMapEscalationOverview', {
				width: "95%",
				height: "95%",
				plugin: false,
				initialPosition: "0;20;0",
				disableZoom: true,
				disablePan: true,
				enableAnimation: false,
				regions: {
					path: "regions>/Regions",
					template: new sap.ui.vbm.Region({
						code: "{regions>code}",
						color: "{regions>color}",
						tooltip: "{regions>tooltip}" //,
							//enabled: false,
							//editable: false
					})
				},
				legend: new sap.ui.vbm.Legend({
					caption: "Regions",
					items: {
						path: "regions>/Regions",
						template: new sap.ui.vbm.LegendItem({
							text: "{regions>legend}",
							color: "{regions>color}",
							tooltip: "{regions>tooltip}"
						})
					}
				}),
				vos: oSpots,
				busy: {
					path: "KPICases>/casesKPIOngoingEscalationsRegion/0/escalationsMEE",
					formatter: this.formatter.numberOrBusy
				},
				busyIndicatorDelay: 0

			});

			oVBI1.setModel(dataModelEscalationOverview, "regions");
			oVBI1.setLassoSelection(false);
			oVBI1.setRectangularSelection(false);
			oVBI1.addStyleClass("OverviewRegion");

			oVBI1.placeAt(this.getView().byId("analyticalMapEscalationOverviewTab"));
		},

		//===========================================================
		//Number of closed / new / ongoing Escalations
		//===========================================================

		addNumberOfClosedNewOngoingKPI: function () {
			var oVizFrameNumberOfEscalations = this.getView().byId("vizFrameNumberOfEscalations");
			oVizFrameNumberOfEscalations.setVizProperties({
				plotArea: {
					isFixedDataPointSize: false, //used in order to show all columns on the screen - column width set based on vavailable space
					dataLabel: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_2,
						visible: false
					},
					dataShape: {
						primaryAxis: ["bar", "bar", "bar"]
					},
					//Colors based on Fiori Qualitative Palette
					colorPalette: ["sapUiChartPaletteQualitativeHue8", "sapUiChartPaletteQualitativeHue5", "sapUiChartPaletteQualitativeHue1"],
					line: {
						marker: {
							size: 12
						}
					},
					window: {
						start: "firstDataPoint",
						end: "lastDataPoint"
					} //,
					// gap: {
					// 	innerGroupSpacing: 0.125
					// },
					// dataPointSize: {
					// 	max: 36
					// } //,
					// window: {
					// 	start: end:
					// }
				},
				valueAxis: {
					label: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_10
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					},
					axisTick: {
						visible: true,
						shortTickVisible: true
					}
				},
				title: {
					visible: false
				}, //only single select
				interaction: {
					selectability: {
						mode: "single"
					},
					behaviorType: null
				},
				tooltip: {
					visible: true,
					formatString: ChartCustomFormat.FIORI_LABEL_FORMAT_2
				}
			});
			// oVizFrameNumberOfEscalations.setVizScales({
			// 	color: ["sapUiChartPaletteQualitativeHue8", "sapUiChartPaletteQualitativeHue5", "sapUiChartPaletteQualitativeHue1"],
			// 	dataFrame:[]
			// });
			//oVizFrameNumberOfEscalations.zoom();
			//oVizFrameNumberOfEscalations.zoom();

		},
		//===========================================================
		//Average Duration of closed Escalations (in days)
		//===========================================================
		addAverageDurationOfEscalationKPI: function () {
			var oVizFrameAverageDurationOfEscalation = this.getView().byId("vizFrameAverageDurationOfEscalation");
			oVizFrameAverageDurationOfEscalation.setVizProperties({
				plotArea: {
					isFixedDataPointSize: false, //used in order to show all columns on the screen - column width set based on vavailable space
					dataLabel: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_2,
						visible: false
					},
					dataShape: {
						primaryAxis: ["line"]
					},
					//Colors based on Fiori Qualitative Palette
					colorPalette: ["sapUiChartPaletteQualitativeHue1"],
					line: {
						marker: {
							size: 12
						}
					}
				},
				valueAxis: {
					label: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_10
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					},
					axisTick: {
						visible: true,
						shortTickVisible: true
					}
				},
				title: {
					visible: false
				}, //only single select
				interaction: {
					selectability: {
						mode: "single"
					},
					behaviorType: null
				},
				tooltip: {
					visible: true,
					formatString: ChartCustomFormat.FIORI_LABEL_FORMAT_2
				}
			});
		},
		//===========================================================
		//Top 5 Products (based on product lines) with High Number of Escalations
		//===========================================================
		addTop5ProductsNumberKPI: function () {
			//	var dataModel = new JSONModel("../webapp/json/pieChartTableExampleData1.json"); //pieChartExampleData
			var oVizFrameTop5ProductsNumber = this.getView().byId("vizFrameTop5Number");
			oVizFrameTop5ProductsNumber.setVizProperties({
				legend: {
					title: {
						visible: false
					},
					showFullLabel: true
				},
				legendGroup: {
					linesOfWrap: 2,
					layout: {
						width: "50%"
					}
				},
				title: {
					visible: false //,
						//text: this._oResourceBundle.getText("productEscalationsTop5Number"),
						//alignment: "left"
				},
				plotArea: {
					dataLabel: {
						visible: true,
						type: "value",
						formatString: ChartCustomFormat.FIORI_VALUE_INT_ROUND //FIORI_VALUE_LOCALE_EURO_K //,//"Euro 0k",
							//	unitFormatType: "FinancialUnits"
					}
				}, //only single select
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});

			var that = this;
			var fSelectionChanged = function (oEvent) {

				var sSelectedElementNumber,
					sRegion = that.getRegionFilterModel(),
					sSelectedElementName = oEvent.getParameter("data")[0].data.productLineName;

				var aModelData = oEvent.getSource().getModel("KPICases").getProperty(oEvent.getSource().getDataset().getBinding("data").getPath());
				//.k[0].pl_name

				//get elementNumber as identifierer to execute request for corresponding data to the backend
				aModelData.forEach(function (item) {
					if (sSelectedElementName === item.sol_name) {
						sSelectedElementNumber = item.sol_key;
					}
				});
				// if (!sRegion) {
				// 	sRegion = "WORLD";
				// }
				//read the data from the backend and set model for table
				that.setModel(that.readCasesForProductChartsTable(that.getModel("mcsModel"), that.getModel("KPICasesTable"), sRegion,
					sSelectedElementNumber, "/casesKPITop5ProductsTable"), "KPICasesTable");
				// 	dataModel = new JSONModel("../webapp/json/pieChartTableExampleData2.json");
				// 	that.getView().byId("vizFrameTop5NumberTable").setModel(dataModel, "myData");
				//update the table header with the selected elements text
				that.getView().byId("vizFrameTop5NumberTableToolbarText").setText(sSelectedElementName);
				var binding = that.getView().byId("vizFrameTop5NumberTable").getBinding("items");
				//sort ascending
				var aSorters = [];
				aSorters.push(new sap.ui.model.Sorter("case_id", false));
				binding.sort(aSorters);
				that.getModel("settings").setProperty("/kpi_Top5Products_TableVisibility", true);
				that.getView().byId("vizFrameTop5NumberTable").setVisible(true);
			};

			//var renderComplete = function(oEvent) {
			//	var x = "";

			//}

			oVizFrameTop5ProductsNumber.attachSelectData(fSelectionChanged);
			//oVizFrameTop5ProductsNumber.attachRenderComplete(renderComplete);
			//this.getView().byId("vizFrameTop5NumberTable").setModel(dataModel, "myData");
			this.getView().byId("vizFrameTop5NumberTableToolbarText").setText("");
			//var oPopOver = this.getView().byId("idPopOverTop5Number");
			//oPopOver.connect(oVizFrameTop5ProductsNumber.getVizUid());
			//oPopOver.setFormatString(ChartCustomFormat.FIORI_VALUE_INT_ROUND); //FIORI_VALUE_LOCALE_EURO_K);
		},
		//===========================================================
		//Number of Escalations of Strategic Products (based on product lines)
		//===========================================================
		addStrategicProductsNumberKPI: function () {
			//var dataModel = new JSONModel("../webapp/json/pieChartTableExampleData1.json"); //pieChartExampleData
			var oVizFrameStrategicNumber = this.getView().byId("vizFrameStrategicNumber");
			oVizFrameStrategicNumber.setVizProperties({
				legend: {
					title: {
						visible: false
					},
					showFullLabel: true
				},
				legendGroup: {
					linesOfWrap: 2,
					layout: {
						width: "50%"
					}
				},
				title: {
					visible: false
				},
				plotArea: {
					dataLabel: {
						visible: true,
						type: "value",
						formatString: ChartCustomFormat.FIORI_VALUE_INT_ROUND
							// formatString: [
							// 	['#'],
							// 	['##0']
							// ]
					}
				}, //only single select
				interaction: {
					selectability: {
						mode: "single"
					}
				}

			});

			var that = this;

			var fSelectionChanged = function (oEvent) {
				var sSelectedElementNumber, sRegion = that.getRegionFilterModel(),
					sSelectedElementName = oEvent.getParameter("data")[0].data.productLineName;
				var aModelData = oEvent.getSource().getModel("KPICases").getProperty(oEvent.getSource().getDataset().getBinding("data").getPath());
				//.k[0].pl_name
				aModelData.forEach(function (item) {
					if (sSelectedElementName === item.pl_name) {
						sSelectedElementNumber = item.pl_number;
					}
				});
				// if (!sRegion) {
				// 	sRegion = "WORLD";
				// }
				//read the data from the backend and set model for table
				that.setModel(that.readCasesForProductChartsTable(that.getModel("mcsModel"), that.getModel("KPICasesTable"), sRegion,
					sSelectedElementNumber, "/casesKPIStrategicProductsTable"), "KPICasesTable");
				// 	dataModel = new JSONModel("../webapp/json/pieChartTableExampleData2.json");
				// 	that.getView().byId("vizFrameTop5NumberTable").setModel(dataModel, "myData");
				//update the table header with the selected elements text
				that.getView().byId("vizFrameStrategicNumberTableText").setText(sSelectedElementName);
				var binding = that.getView().byId("vizFrameStrategicNumberTable").getBinding("items");
				//sort ascending
				var aSorters = [];
				aSorters.push(new sap.ui.model.Sorter("case_id", false));
				binding.sort(aSorters);
				that.getModel("settings").setProperty("/kpi_StrategicProducts_TableVisibility", true);
			};

			oVizFrameStrategicNumber.attachSelectData(fSelectionChanged);
			//	oVizFrameTop5ProductsNumber.attachDeselectData(fSelectionChanged);
			//this.getView().byId("vizFrameStrategicNumberTable").setModel(dataModel, "myData");
			this.getView().byId("vizFrameStrategicNumberTableText").setText("");
			//oVizFrameTop5ProductsNumber.setModel(dataModel, "myData");
			//var oPopOver = this.getView().byId("idPopOverStrategicNumber");
			//oPopOver.connect(oVizFrameTop5ProductsNumber.getVizUid());
			//oPopOver.setFormatString(ChartCustomFormat.FIORI_VALUE_INT_ROUND);
		},
		//===========================================================
		//COSTS: top5ProductsWithHighEscCosts
		//===========================================================
		addTop5ProductsWithHighEscCosts: function () {
			var oVizFrame = this.getView().byId("vizFrameTop5ProductsWithHighEscCosts");
			oVizFrame.setVizProperties({
				legend: {
					title: {
						visible: false
					},
					showFullLabel: true
				},
				legendGroup: {
					linesOfWrap: 2,
					layout: {
						width: "200px"
					}
				},
				title: {
					visible: false //
				},
				plotArea: {
					dataLabel: {
						visible: true,
						type: "value",
						formatString: ChartCustomFormat.VALUE_DEFAULT_EUR_BASE_TO_K
					}
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});

			var that = this;
			var fSelectionChanged = function (oEvent) {

				var sSelectedElementName = oEvent.getParameter("data")[0].data.product;
				//var aModelData = oEvent.getSource().getModel("KPICasesBW").getProperty(oEvent.getSource().getDataset().getBinding("data").getPath());
				//read Case IDs from oData https://mcsdashboard-sapitcloudt.dispatcher.hana.ondemand.com/webapp/destinations/int_bw/sap/MCASE_COST_ODA_008N_SRV/MCASE_COST_ODA_008N(MCASE_NMM_OY_003='0HIER_NODE%3ASUP_EMEA%20W%2FO%20MEE',MCASE_HCS_MY_01_0SALESORG='',MCASE_NAM_ON_01_0SALESORG='')/Results?$select=A4MCASEX017PPMSPRLN_T,A4MCASEX017CSM_EXID
				//get elementNumber as identifierer to execute request for corresponding data to the backend
				// aModelData.forEach(function (item) {
				// 	if (sSelectedElementName === item.product_name) {
				// 		sSelectedElementNumber = item.pl_number;
				// 	}
				// });
				// if (!sRegion) {
				// 	sRegion = "WORLD";
				// }
				// //read the data from the backend and set model for table
				// that.setModel(that.models.readCasesForProductChartsTable(that.getModel(), that.getModel("KPICasesBW"), sRegion,
				// 	sSelectedElementNumber, "/top5ProductsWithHighEscCostsTable"), "KPICasesBWTable");

				//update the table header with the selected elements text
				that.getView().byId("vizFrameTop5ProductsWithHighEscCostsTableToolbarText").setText(sSelectedElementName);
				var binding = that.getView().byId("vizFrameTop5ProductsWithHighEscCostsTable").getBinding("items");
				//sort ascending
				var aSorters = [];
				aSorters.push(new sap.ui.model.Sorter("case_id", false));
				binding.sort(aSorters);

				var oFilter = new sap.ui.model.Filter("product_line", sap.ui.model.FilterOperator.EQ, sSelectedElementName);
				var oFinalFilter = new sap.ui.model.Filter([oFilter], true);
				binding.filter(oFinalFilter, sap.ui.model.FilterType.Control);

				that.getModel("settings").setProperty("/isVisible_Top5ProductsWithHighEscCostsTable", Boolean(true));
			};

			oVizFrame.attachSelectData(fSelectionChanged);

			this.getView().byId("vizFrameTop5ProductsWithHighEscCostsTableToolbarText").setText("");
		},

		//===========================================================
		//COSTS: EscCostsOfStrategicProducts
		//===========================================================
		addEscCostsOfStrategicProducts: function () {
			var oVizFrame = this.getView().byId("vizFrameEscCostsOfStrategicProducts");
			oVizFrame.setVizProperties({
				legend: {
					title: {
						visible: false
					},
					showFullLabe00l: true
				},
				legendGroup: {
					linesOfWrap: 2,
					layout: {
						width: "200px"
					}
				},
				title: {
					visible: false //
				},
				plotArea: {
					dataLabel: {
						visible: true,
						type: "value",
						formatString: ChartCustomFormat.VALUE_DEFAULT_EUR_BASE_TO_K
					}
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				},
				dataLabel: {
					hideWhenOverlap: false
				}
			});

			var that = this;
			var fSelectionChanged = function (oEvent) {
				var //sSelectedElementNumber,
				//sRegion = that.getModel("filters").getProperty("/region"),
					sSelectedElementName = oEvent.getParameter("data")[0].data.product;

				//update the table header with the selected elements text
				that.getView().byId("vizFrameEscCostsOfStrategicProductsTableToolbarText").setText(sSelectedElementName);
				var binding = that.getView().byId("vizFrameEscCostsOfStrategicProductsTable").getBinding("items");
				//sort ascending
				var aSorters = [];
				aSorters.push(new sap.ui.model.Sorter("case_id", false));
				binding.sort(aSorters);

				var oFilter = new sap.ui.model.Filter("product_line", sap.ui.model.FilterOperator.EQ, sSelectedElementName);
				var oFinalFilter = new sap.ui.model.Filter([oFilter], true);
				binding.filter(oFinalFilter, sap.ui.model.FilterType.Control);

				that.getModel("settings").setProperty("/isVisible_EscCostsOfStrategicProductsTable", Boolean(true));
			};

			oVizFrame.attachSelectData(fSelectionChanged);

			this.getView().byId("vizFrameEscCostsOfStrategicProductsTableToolbarText").setText("");
		},

		//===========================================================
		//COSTS: EscCostsPerProductCategory
		//===========================================================
		addEscCostsPerProductCategory: function () {
			var oVizFrame = this.byId("vizFrameEscCostsPerProductCategory");
			if (!oVizFrame) {
				return;
			}

			//define and apply chartProperties
			oVizFrame.setVizProperties({
				legend: {
					visible: true
				},
				legendGroup: {
					layout: {
						position: 'bottom'
					}
				},
				title: {
					visible: false,
					text: '{i18n>escCostsPerProductCategory_title}'
				},
				categoryAxis: {
					title: {
						visible: false
					},
					label: {
						angle: 0,
						overlapBehavior: 'auto',
						rotation: 'auto',
						truncatedLabelRatio: 0.2,
						linesOfWrap: 3
					}
				},
				valueAxis: {
					title: {
						visible: false
					},
					label: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_10 //VALUE_CONVERT_BASE_TO_K
					}
				},
				dataLabel: {
					formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_2, //VALUE_CONVERT_BASE_TO_K,
					visible: false
				}, //only single select
				interaction: {
					selectability: {
						mode: "single"
					},
					behaviorType: null
				},
				tooltip: {
					visible: true,
					formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_2 //VALUE_CONVERT_BASE_TO_K
				}
			});
			var that = this;
			var fSelectionChanged = function (oEvent) {
				var //sSelectedElementNumber,
				//sRegion = that.getModel("filters").getProperty("/region"),
					sSelectedElementName = oEvent.getParameter("data")[0].data.Category;

				//update the table header with the selected elements text
				that.getView().byId("vizFrameEscCostsPerProductCategoryTableToolbarText").setText(sSelectedElementName + " " + oEvent.getParameter(
					"data")[0].data.Year);
				var binding = that.getView().byId("vizFrameEscCostsPerProductCategoryTable").getBinding("rows");
				//sort ascending
				var aSorters = [];
				aSorters.push(new sap.ui.model.Sorter("case_id", false));
				binding.sort(aSorters);

				var oFilter = new sap.ui.model.Filter("product_category", sap.ui.model.FilterOperator.EQ, sSelectedElementName);
				var oFilter2 = new sap.ui.model.Filter("year", sap.ui.model.FilterOperator.EQ, oEvent.getParameter("data")[0].data.Year);
				var oFinalFilter = new sap.ui.model.Filter([oFilter, oFilter2], true);
				binding.filter(oFinalFilter, sap.ui.model.FilterType.Control);

				that.getModel("settings").setProperty("/isVisible_EscCostsPerProdCategoryTable", Boolean(true));
			};

			oVizFrame.attachSelectData(fSelectionChanged);

			this.getView().byId("vizFrameEscCostsPerProductCategoryTableToolbarText").setText("");

			/*
			oVizFrame.attachSelectData(function (oEvent) {
				var oVizPopover = new sap.viz.ui5.controls.Popover({});
				oVizPopover.setFormatString(ChartCustomFormat.FIORI_VALUE_LOCALE_EURO_K);
				oVizPopover.connect(oVizFrame.getVizUid());
			});
			*/
		},

		//===========================================================
		//Total Escalation Costs
		//===========================================================
		addTotalEscalationCostsKPI: function () {
			//var dataModelTotalEscalationCosts = new JSONModel("../json/TotalEscalationCosts13Months.json");
			//Chart for WORLd Region Filter - multi Column
			var oVizFrameTotalEscalationCosts = this.getView().byId("vizFrameTotalEscalationCosts");
			oVizFrameTotalEscalationCosts.setVizProperties({
				plotArea: {
					isFixedDataPointSize: false, //used in order to show all columns on the screen - column width set based on vavailable space
					dataLabel: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_2,
						visible: false
					},
					dataShape: {
						primaryAxis: ["bar", "bar", "bar", "bar", "bar", "bar", "line"]
					},
					//Colors based on Fiori Qualitative Palette
					colorPalette: ["sapUiChartPaletteQualitativeHue1", "sapUiChartPaletteQualitativeHue2", "sapUiChartPaletteQualitativeHue3",
						"sapUiChartPaletteQualitativeHue4", "sapUiChartPaletteQualitativeHue5", "sapUiChartPaletteQualitativeHue6",
						"sapUiChartPaletteQualitativeHue7"
					],
					line: {
						marker: {
							size: 12
						}
					},
					window: {
						start: "firstDataPoint",
						end: "lastDataPoint"
					},
					scrollbar: {
						thumb: {
							fill: "transparent",
							hoverFill: "transparent"
						}
					}
				},
				valueAxis: {
					label: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_10
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					},
					axisTick: {
						visible: true,
						shortTickVisible: true
					},
					isScrollable: false
				},
				title: {
					visible: false
				}, //only single select
				interaction: {
					selectability: {
						mode: "single"
					},
					behaviorType: null
				},
				tooltip: {
					visible: true,
					formatString: ChartCustomFormat.FIORI_LABEL_FORMAT_2
				}
			});
			//Chart for specific Region Filter - simple Column
			var oVizFrameTotalEscalationCostsRegion = this.getView().byId("vizFrameTotalEscalationCostsRegion");
			oVizFrameTotalEscalationCostsRegion.setVizProperties({
				plotArea: {
					isFixedDataPointSize: false, //used in order to show all columns on the screen - column width set based on vavailable space
					dataLabel: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_2,
						visible: false
					},
					dataShape: {
						primaryAxis: ["bar", "bar", "bar", "bar", "bar", "bar"]
					},
					//Colors based on Fiori Qualitative Palette
					colorPalette: ["sapUiChartPaletteQualitativeHue1", "sapUiChartPaletteQualitativeHue2", "sapUiChartPaletteQualitativeHue3",
						"sapUiChartPaletteQualitativeHue4", "sapUiChartPaletteQualitativeHue5", "sapUiChartPaletteQualitativeHue6",
					],
					line: {
						marker: {
							size: 12
						}
					},
					window: {
						start: "firstDataPoint",
						end: "lastDataPoint"
					},
					scrollbar: {
						thumb: {
							fill: "transparent",
							hoverFill: "transparent"
						}
					}
				},
				valueAxis: {
					label: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_10
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					},
					axisTick: {
						visible: true,
						shortTickVisible: true
					},
					isScrollable: false
				},
				title: {
					visible: false
				}, //only single select
				interaction: {
					selectability: {
						mode: "single"
					},
					behaviorType: null
				},
				tooltip: {
					visible: true,
					formatString: ChartCustomFormat.FIORI_LABEL_FORMAT_2
				}
			});

			//	set ID of VizFeed into internal json model in order to have access to it from within other js files - we need to update the label in case of region filter selection
			//	this is a special case handling,because normally you don't have to change the legend label afterwards
			//	var oSettingsModel = this.getOwnerComponent().getModel("settings");
			//	var sValueAxisTotalEscalationCostsFeed = this.getView().byId("valueAxisTotalEscalationCostsFeed").getId();
			//	oSettingsModel.setProperty("/valueAxisTotalEscalationCostsFeed", sValueAxisTotalEscalationCostsFeed);
			//oSettingsModel.setProperty("/vizFrameTotalEscalationCostsRegion", oVizFrameTotalEscalationCostsRegion.getId());

		},
		//===========================================================
		//Average Escalation Costs
		//===========================================================
		addAverageEscalationCostsKPI: function () {
			//var dataModelAverageEscalationCosts = new JSONModel("../json/TotalEscalationCosts13Months.json");
			//Chart for WORLd Region Filter - multi Column
			var oVizFrameAverageEscalationCosts = this.getView().byId("vizFrameAverageEscalationCosts");
			oVizFrameAverageEscalationCosts.setVizProperties({
				plotArea: {
					isFixedDataPointSize: false, //used in order to show all columns on the screen - column width set based on vavailable space
					dataLabel: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_2,
						visible: false
					},
					dataShape: {
						primaryAxis: ["bar", "bar", "bar", "bar", "bar", "bar", "line"]
					},
					//Colors based on Fiori Qualitative Palette
					colorPalette: ["sapUiChartPaletteQualitativeHue1", "sapUiChartPaletteQualitativeHue2", "sapUiChartPaletteQualitativeHue3",
						"sapUiChartPaletteQualitativeHue4", "sapUiChartPaletteQualitativeHue5", "sapUiChartPaletteQualitativeHue6",
						"sapUiChartPaletteQualitativeHue7"
					],
					line: {
						marker: {
							size: 12
						}
					},
					window: {
						start: "firstDataPoint",
						end: "lastDataPoint"
					},
					scrollbar: {
						thumb: {
							fill: "transparent",
							hoverFill: "transparent"
						}
					}
				},
				valueAxis: {
					label: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_10
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					},
					axisTick: {
						visible: true,
						shortTickVisible: true
					},
					isScrollable: false
				},
				title: {
					visible: false
				}, //only single select
				interaction: {
					selectability: {
						mode: "single"
					},
					behaviorType: null
				},
				tooltip: {
					visible: true,
					formatString: ChartCustomFormat.FIORI_LABEL_FORMAT_2
				}
			});
			//Chart for specific Region Filter - single Column
			var oVizFrameAverageEscalationCostsRegion = this.getView().byId("vizFrameAverageEscalationCostsRegion");
			oVizFrameAverageEscalationCostsRegion.setVizProperties({
				plotArea: {
					isFixedDataPointSize: false, //used in order to show all columns on the screen - column width set based on vavailable space
					dataLabel: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_2,
						visible: false
					},
					dataShape: {
						primaryAxis: ["bar", "bar", "bar", "bar", "bar", "bar"]
					},
					//Colors based on Fiori Qualitative Palette
					colorPalette: ["sapUiChartPaletteQualitativeHue1", "sapUiChartPaletteQualitativeHue2", "sapUiChartPaletteQualitativeHue3",
						"sapUiChartPaletteQualitativeHue4", "sapUiChartPaletteQualitativeHue5", "sapUiChartPaletteQualitativeHue6",
					],
					line: {
						marker: {
							size: 12
						}
					},
					window: {
						start: "firstDataPoint",
						end: "lastDataPoint"
					},
					scrollbar: {
						thumb: {
							fill: "transparent",
							hoverFill: "transparent"
						}
					}
				},
				valueAxis: {
					label: {
						formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_10
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					},
					axisTick: {
						visible: true,
						shortTickVisible: true
					},
					isScrollable: false
				},
				title: {
					visible: false
				}, //only single select
				interaction: {
					selectability: {
						mode: "single"
					},
					behaviorType: null
				},
				tooltip: {
					visible: true,
					formatString: ChartCustomFormat.FIORI_LABEL_FORMAT_2
				}
			});

			//	set ID of VizFeed into internal json model in order to have access to it from within other js files - we need to update the label in case of region selection
			//	this is a special case handling,because normally you don't have to change the legend label afterwards
			var oSettingsModel = this.getOwnerComponent().getModel("settings");
			//	var sValueAxisAverageEscalationCostsFeed = this.getView().byId("valueAxisAverageEscalationCostsFeed").getId();
			//	oSettingsModel.setProperty("/valueAxisAverageEscalationCostsFeed", sValueAxisAverageEscalationCostsFeed);
			oSettingsModel.setProperty("/vizFrameAverageEscalationCostsRegion", oVizFrameAverageEscalationCostsRegion.getId());
		},
		//===========================================================
		//KPIs Production Downs
		//===========================================================
		//New Production Downs by Creation Month 
		//===========================================================
		// TBD_addNewProdDownByCreationMonthKPI: function () {
		// 	var oVizFrameNewProdDownByCreationMonth = this.getView().byId("vizFrameNewProdDownByCreationMonth");
		// 	oVizFrameNewProdDownByCreationMonth.setVizProperties({
		// 		plotArea: {
		// 			isFixedDataPointSize: false, //used in order to show all columns on the screen - column width set based on vavailable space
		// 			dataLabel: {
		// 				formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_2,
		// 				visible: false
		// 			},
		// 			dataShape: {
		// 				primaryAxis: ["bar", "bar", "line"]
		// 			},
		// 			colorPalette: ["sapUiChartPaletteQualitativeHue8", "sapUiChartPaletteQualitativeHue5", "sapUiChartPaletteQualitativeHue1"],
		// 			line: {
		// 				marker: {
		// 					size: 12
		// 				}
		// 			}
		// 		},
		// 		valueAxis: {
		// 			label: {
		// 				formatString: ChartCustomFormat.FIORI_LABEL_SHORTFORMAT_10
		// 			},
		// 			title: {
		// 				visible: false
		// 			}
		// 		},
		// 		categoryAxis: {
		// 			title: {
		// 				visible: false
		// 			},
		// 			axisTick: {
		// 				visible: true,
		// 				shortTickVisible: true
		// 			}
		// 		},
		// 		title: {
		// 			visible: false
		// 		}, //only single select
		// 		interaction: {
		// 			selectability: {
		// 				mode: "single"
		// 			},
		// 			behaviorType: null
		// 		},
		// 		tooltip: {
		// 			visible: true,
		// 			formatString: ChartCustomFormat.FIORI_LABEL_FORMAT_2
		// 		},
		// 		legendGroup: {
		// 			layout: {
		// 				position: "bottom"
		// 			}
		// 		}
		// 	});
		// },

		caseIdBWClicked: function (oEvent) {
			var sFinalNavString = "/Case/" + oEvent.getSource().getTitle();
			//get the binding context of the selected element and read the status
			//in case status === 40 it should be redirected to the closed escalation view, otherwise the standard one -->  the all ongoing one
			// var sStatus = this.getView().getModel("KPICasesBW").getProperty(oEvent.getSource().getBindingContext("KPICasesBW").getPath())
			// 	.status;
			// if (sStatus === "40") {
			// 	sFinalNavString = "/escalations/closed12MonthsEscalations/" + oEvent.getSource().getTitle();
			// }
			//replace /charts with /escalations/allEscalations/10014925  or closed12MonthsEscalations
			var sUrlPath = window.location.href.replace("/MCSCharts", sFinalNavString);
			var win = window.open(sUrlPath, "_blank");
			win.opener = null;
		},

		caseIdClicked: function (oEvent) {
			var sFinalNavString = "/Case/" + oEvent.getSource().getTitle();
			//get the binding context of the selected element and read the status
			//in case status === 40 it should be redirected to the closed escalation view, otherwise the standard one -->  the all ongoing one
			// var sStatus = this.getView().getModel("KPICasesTable").getProperty(oEvent.getSource().getBindingContext("KPICasesTable").getPath())
			// 	.status;
			// if (sStatus === "40") {
			// 	sFinalNavString = "/Case/" + oEvent.getSource().getTitle();
			// }
			//replace /charts with /escalations/allEscalations/10014925  or closed12MonthsEscalations
			var sUrlPath = window.location.href.replace("/MCSCharts", sFinalNavString);
			var win = window.open(sUrlPath, "_blank");
			win.opener = null;
		},

		//helper function to be executed before data is retrieved from oData service
		_onBeginLoadingDataToModel: function (oModel, sPropertyPath) {
			oModel.setProperty(sPropertyPath + "/data", null);
			oModel.setProperty(sPropertyPath + "/info/isBusy", Boolean(true));
		},
		//helper function to be executed after data is retrieved from oData service and placed inside of success: or error:
		_onFinishLoadingDataToModel: function (oModel, sPropertyPath, aData, iCostReturnedOdataCount, aDataCATSEMEANorth,
			aDataCATSEMEASouth) {
			if (sPropertyPath === "/casesKPITop5ProductsTable" || sPropertyPath === "/casesKPIStrategicProductsTable") {
				//for AGGR Profile -->  in this case case_title might be empty and therefore do not show cases, where case title is empty
				var tableData = [];
				for (var i = 0; i < aData.length; i++) {
					if (aData[i].case_title !== "") {
						tableData.push(aData[i]);
					}
				}
				oModel.setProperty(sPropertyPath + "/data", tableData);
				oModel.setProperty(sPropertyPath + "/info/hasData", Boolean(tableData !== null && tableData.length > 0));
				oModel.setProperty(sPropertyPath + "/info/isBusy", Boolean(false));
			} else {
				oModel.setProperty(sPropertyPath + "/data", aData);
				oModel.setProperty(sPropertyPath + "/info/hasData", Boolean(aData !== null && aData.length > 0));
				oModel.setProperty(sPropertyPath + "/info/isBusy", Boolean(false));
			}
		},

		readCasesForProductChartsTable: function (dashboardModel, model, region, refObjectLine, sChartPropertyName) {
			if (!model) {
				model = new JSONModel({
					casesKPITop5ProductsTable: {
						info: {
							hasData: false,
							isBusy: false
						},
						data: null
					},
					casesKPIStrategicProductsTable: {
						info: {
							hasData: false,
							isBusy: false
						},
						data: null
					}
				});
			}
			//MCSDashboardSet?sap-language=EN&$filter=(
			//product_line%20eq%20%2773554900100700001081%27%20and%20
			//process_type%20eq%20%27ZSPRCTYP01%27%20and%20
			//region%20eq%20%27WORLD%27%20and%20
			//create_time%20le%20%2720180613235959%27and%20
			//(closing_time%20ge%20%2720180101000000%27or%20closing_time%20eq%20%27%27)and%20
			//product_rel_type%20eq%20%27ZSCASEPROM%27)&$select=case_id,customer_name,create_time,closing_time
			var sProcessType = "process_type";
			var sRegion = "region"; //based on selected Filter
			var sRefObjectLine = "product_line"; // based on selected area of pie chart
			var sMainProductSearch = "product_rel_type"; // always true -->  main product only
			var sStatus = "status"; // ignore 50 and 98
			var sCreationTime = "create_time"; //<= today
			var sClosingTime = "closing_time"; //>= first of year or empty

			//in case of Top5 Products, we need to use solution key
			if (sChartPropertyName === "/casesKPITop5ProductsTable") {
				sRefObjectLine = "solution";
			}

			//dates
			var dateToday = new Date(); //today
			var sDateToday = "" + dateToday.getFullYear() + ("0" + (dateToday.getMonth() + 1)).slice(-2) + ("0" + dateToday.getDate())
				.slice(-2) + "235959";
			//first of the year
			var dateFirstOfYear = new Date();
			dateFirstOfYear.setUTCDate(1);
			dateFirstOfYear.setUTCMonth(0);
			dateFirstOfYear.setUTCFullYear(dateToday.getUTCFullYear());
			var sDateFirstOfYear = "" + dateFirstOfYear.getFullYear() + ("0" + (dateFirstOfYear.getMonth() + 1)).slice(-2) + ("0" +
					dateFirstOfYear.getDate())
				.slice(-2) + "000000";
			var aFinalFilters = [];
			var aFilters1 = [];
			var aFilters2 = [];

			if (region) {
				var aRegionFilter = [];
				region.split(",").forEach(function (tempRegion) {
					aRegionFilter.push(new sap.ui.model.Filter("region", sap.ui.model.FilterOperator.EQ, tempRegion));
				});
				aFinalFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			aFinalFilters.push(
				new sap.ui.model.Filter([
						//new sap.ui.model.Filter(sRegion, sap.ui.model.FilterOperator.EQ, region),
						new sap.ui.model.Filter(sProcessType, sap.ui.model.FilterOperator.EQ, "ZSPRCTYP01"),
						new sap.ui.model.Filter(sRefObjectLine, sap.ui.model.FilterOperator.EQ, refObjectLine + ""),
						new sap.ui.model.Filter(sMainProductSearch, sap.ui.model.FilterOperator.EQ, "ZSCASEPROM"),
						new sap.ui.model.Filter(sCreationTime, sap.ui.model.FilterOperator.LE, sDateToday),
						new sap.ui.model.Filter([
							new sap.ui.model.Filter(sStatus, sap.ui.model.FilterOperator.EQ, "20"),
							new sap.ui.model.Filter(sStatus, sap.ui.model.FilterOperator.EQ, "30"),
							new sap.ui.model.Filter(sStatus, sap.ui.model.FilterOperator.EQ, "40"),
							new sap.ui.model.Filter(sStatus, sap.ui.model.FilterOperator.EQ, "60")
						], false)
					],
					true
				)
			);

			aFinalFilters.push(
				new sap.ui.model.Filter([new sap.ui.model.Filter(sClosingTime, sap.ui.model.FilterOperator.GE, sDateFirstOfYear),
						new sap.ui.model.Filter(sClosingTime, sap.ui.model.FilterOperator.EQ, "")
					],
					false
				)
			);

			//casesKPITop5ProductsTable

			var that = this;
			that._onBeginLoadingDataToModel(model, sChartPropertyName);

			dashboardModel.read("/MCSDashboardSet", {
				urlParameters: {
					"$select": "case_id,customer_name,status,case_title"
				},
				filters: [new sap.ui.model.Filter({ //filters.slice(0),
					filters: aFinalFilters,
					and: true
				})], //aFilters,
				success: function (data, response) {
					that._onFinishLoadingDataToModel(model, sChartPropertyName, data.results);
				},
				error: function (oError, response) {
					that._onFinishLoadingDataToModel(model, sChartPropertyName, []);
				}
			});

			return model;

		},

		handleConfirm: function () {
			this.readRootCauses();
		},

		handleFacetFilterReset: function (oEvent) {
			//moved to BaseController because of MCS Dashboard integration and use in Charts and Operational View
			this.handleFacetFilterResetBase(oEvent);
			this.oFilterComponent._updateTileNumbers();
			//Update MCS Charts
			this.oFilterComponent.readCases();
			//this.oFilterComponent.readCasesNoFiltersApply();
			this.oFilterComponent.readCasesBWKPI(false);

			if (this.oFilterComponent.oFacetFilter._variantInitiallyLoaded === true) {
				this.oFilterComponent.oFacetFilter._variantInitiallyLoaded = false;
			}
			// set current filter variant to modified /dirty flag 
			if (!this.oFilterComponent.oFacetFilter._variantInitiallyLoaded) {
				this.getView().byId("filterVariantManagement").currentVariantSetModified(true);
			}
			var oSettingsModel = this.getModel("settings");
			oSettingsModel.setProperty("/kpi_Top5Products_TableVisibility", false);
			oSettingsModel.setProperty("/kpi_StrategicProducts_TableVisibility", false);
			oSettingsModel.setProperty("/isVisible_Top5ProductsWithHighEscCostsTable", false);
			oSettingsModel.setProperty("/isVisible_EscCostsOfStrategicProductsTable", false);
			oSettingsModel.setProperty("/isVisible_EscCostsPerProdCategoryTable", false);
			this.getView().byId("filterVariantManagement").currentVariantSetModified(true);

			this.readRootCauses();
		},
	});
});