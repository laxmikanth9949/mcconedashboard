sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter"
], function (BaseController, formatter) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.GlobalEscalationRequest", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0
			}), "viewModel");
			//create local model to read customer related data, should be this name, cause fragment reused
			var oCustomerData = {
				reload: true
			};
			var oCustomerModel = new sap.ui.model.json.JSONModel(oCustomerData);
			this.getOwnerComponent().setModel(oCustomerModel, "globalEscalationRequests");

			this._oGlobalFilter = null;
			this._oPriceFilter = null;
			this._tblRendered = false;
			this.getRouter().getRoute("GlobalEscalationRequest").attachPatternMatched(this._onObjectMatched, this);

		},

		onAfterRendering: function () {
			/*this.getView().byId("tabInc").setVisibleRowCount(8);
			this.getView().byId("tabInc").setVisibleRowCountMode("Auto");*/
			this.getView().byId("tabInc").addEventDelegate({
				"onAfterRendering": function (oEv) {
					if (!this._tblRendered) {
						setTimeout(function () {
							oEv.srcControl.invalidate();
						}, 300);

						this._tblRendered = true;
					}
				}.bind(this)
			});
		},

		_onObjectMatched: function (oEvent) {
			if (this.getModel("globalEscalationRequests") && this.getModel("globalEscalationRequests").getData() && this.getModel(
					"globalEscalationRequests").getProperty("/reload")) {
				this.getModel("globalEscalationRequests").setProperty("/reload", false);
				this._updateTable();
				this.getModel("globalEscalationRequests").setProperty("/GlobalEscalationRequestsSetBusy", true);
			}
			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);

		},

		_updateTable: function () {
			var aFilters = [];
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();

			this.getView().byId("dataIconTabBar").setSelectedKey("All");

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICPGER");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				});
				aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			//ALL ongoing 
			var tileSpecificFilters = new sap.ui.model.Filter([ 
					//new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ,	"ZSPRCTYP01"),
					new sap.ui.model.Filter([new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0010"), new sap.ui.model.Filter(
						"Status", sap.ui.model.FilterOperator.EQ, "E0011")], false)
				],
				true
			);

			aFilters.push(tileSpecificFilters);

			//	var oPrioritySorter = new sap.ui.model.Sorter("Priority", false);
			var oChangedAtSorter = new sap.ui.model.Sorter("ChangeTime", true);

			var oICModel = this.getModel();
			var oRatingSorter = new sap.ui.model.Sorter("Rating", true);

			oICModel.read("/GlobalEscalationRequestSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				sorters: [oRatingSorter, oChangedAtSorter],
				success: function (data) {
					this._calculateRating(data);
					data.results.forEach(function (request) {
						if (request.Rating === "") {
							request.Rating = "unrated";
						}
					}.bind(this));

					this.getModel("globalEscalationRequests").setProperty("/GlobalEscalationRequestSet", data.results);
					this.getModel("globalEscalationRequests").setProperty("/GlobalEscalationRequestsSetBusy", false);
				}.bind(this),
				error: function (data) {
					this.getModel("globalEscalationRequests").setProperty("/GlobalEscalationRequestsSetBusy", false);
				}.bind(this)
			});

		},

		loadNotes: function (oControl, id) {
			var oICModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oICModel.read("/GlobalEscalationRequestSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		handleRatingIconTabBarSelect: function (oEv) {
			var oTable = this.getView().byId("tabInc");
			var sRatingKey = oEv.getSource().getSelectedKey();
			var aFilter = [];
			if (sRatingKey !== "All") {
				aFilter.push(new sap.ui.model.Filter("Rating", "EQ", sRatingKey));
			}
			oTable.getBinding("rows").filter(aFilter);
		},

		_calculateRating: function (data) {
			var oViewModel = this.getView().getModel("viewModel");
			var iGreen = 0;
			var iYellow = 0;
			var iRed = 0;
			var iUnrated = 0;
			data.results.forEach(function (oCase) {
				switch (oCase.Rating) {
				case "A":
					iGreen++;
					break;
				case "B":
					iYellow++;
					break;
				case "C":
					iRed++;
					break;
				default:
					iUnrated++;
				}
			});
			oViewModel.setProperty("/iTabAll", data.results.length);
			oViewModel.setProperty("/iTabGreen", iGreen);
			oViewModel.setProperty("/iTabYellow", iYellow);
			oViewModel.setProperty("/iTabRed", iRed);
			oViewModel.setProperty("/iTabUnrated", iUnrated);
		},

		handleCustomerPress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("globalEscalationRequests").getPath();
			var oProperty = this.getModel("globalEscalationRequests").getProperty(sPath);
			var sErpCustNo = oProperty.CustomerErpNo || oProperty.ErpCustNo || oProperty.CustomerNo;
			var oRouter = this.getRouter();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		/*
		 *Event handler when Global Ulitmate is press in any table
		 * Set Routing parameter 'ErpCustNo' and navigate to customer fact sheet
		 **/
		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("globalEscalationRequests").getPath();
			var oProperty = this.getModel("globalEscalationRequests").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("globalEscalationRequests").getObject();
			var sId = oData.ObjectId;
			this.loadNotes(oEv.getSource(), sId);
			this.trackEvent("Status Report: show Popover");
		},

		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("globalEscalationRequests").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		}

	});

});