sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"sap/ui/core/routing/History",
	"com/sap/mcconedashboard/model/formatter",
	"sap/ui/model/json/JSONModel"
], function (BaseController, History, formatter, JSONModel) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.Case", {

		formatter: formatter,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.mcconedashboard.view.Customer
		 */
		onInit: function () {
			if (this.getRouter().getRoute("CrossIssueDetails")) {
				this.getRouter().getRoute("CrossIssueDetails").attachPatternMatched(this._onObjectMatched, this);
			}
		},

		_onObjectMatched: function (oEvent) {
			//in case of anonymized mode, no Cross Issues should be retunrned
			if (this.getOwnerComponent().getModel("settings").getProperty("/isAnonymizedMode") === true) {
				return null;
			}

			this.getView().setModel(new JSONModel({
				caseType: "",
				showNotesLatestStatus: false,
				showNotesManagementSummary: false,
				showNotesAdditionalInformation: false,
				showNotesNextSteps: false,
				showNotesCurrentSituation: false,
				showNotesIssueImpact: false,
				showSubscriptionButton: false,
				subscriptionAction: "ADD",
				subscriptionID: ""
			}), "viewModel");

			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);

			//set 1st section selected
			this.getView().byId("ObjectPageLayout").setSelectedSection(this.getView().byId("ObjectPageLayout").getSections()[0].getId());

			var sObjectId = oEvent.getParameter("arguments").objectId;
			sap.ui.core.BusyIndicator.show(0);
			var oModel = this.getOwnerComponent().getModel();
			this._readLinkesObjects(sObjectId);
			oModel.read("/CrossIssueSet", {
				filters: [new sap.ui.model.Filter("ObjectId", sap.ui.model.FilterOperator.EQ, sObjectId)],
				urlParameters: {
					"$expand": "toProducts,toAffCustomers,toLastNotes"
				},
				success: function (data) {
					if (data.results.length === 0) {
						return null;
					}
					data = data.results[0];
					//get Engagement Reason and Executive Summary
					var executiveSummary = data.toLastNotes.results.find(function (value) {
						return value.NoteTypeT === "Executive Summary";
					});
					if (executiveSummary) {
						data.executiveSummary = executiveSummary.Text;
					}

					var engagementReason = data.toLastNotes.results.find(function (value) {
						return value.NoteTypeT === "Engagement Reason";
					});
					if (engagementReason) {
						data.engagementReason = engagementReason.Text;
					}

					var oModel = new JSONModel(data);
					this.getView().setModel(oModel, "crossIssue");
					this._loadCustomerLogo(data.CustomerCrmNo);
					this.parseNotes(data);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function (data) {
					sap.ui.core.BusyIndicator.hide();
				}.bind(this)
			});

		},

		_loadCustomerLogo: function (sErpCustNo) {
			var oSettings = this.getOwnerComponent().getModel("settings");
			var oHeader = this.getView().byId("crossIssueObjectPageHeader");
			sErpCustNo = oSettings.getProperty("/isAnonymizedMode") ? "" : sErpCustNo;
			if (sErpCustNo && sErpCustNo !== "" && sErpCustNo !== null) {

				var sPath = sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/ic/sap/opu/odata/sap/";
				var sUrl = sPath + "ZS_APP_DEP_SRV/CustomerSet('" + sErpCustNo + "')/$value";

				function waitForObjectImageAndSetProperty() {
					return new Promise(function (resolve) {
						function checkObjectImage() {
							var oObjectImage = oHeader.getAggregation("_objectImage");
							if (oObjectImage) {
								resolve(oObjectImage);
							} else {
								setTimeout(checkObjectImage, 100);
							}
						}

						checkObjectImage();
					});
				}

				this._getImageStream(sUrl).then(function (sBase64) {
					oHeader.setObjectImageURI(sBase64);
					return waitForObjectImageAndSetProperty();
				}).then(function (oObjectImage) {
					oObjectImage.setProperty("backgroundSize", "contain");
				});
			}
		},


		parseNotes: function (data) {
			var oModel = new JSONModel();

			if (data.toLastNotes) {
				//sort by date
				data.toLastNotes.results = data.toLastNotes.results.sort(function (a, b) {
					//format time, which comes in format <d:created_at>PT15H46M10S</d:created_at> to be shown as 15:46:10
					var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
					var aTMPTime = new Date(a.CreatedAt.ms + TZOffsetMs);
					var bTMPTime = new Date(b.CreatedAt.ms + TZOffsetMs);
					b.CreatedOn.setHours(bTMPTime.getHours());
					a.CreatedOn.setHours(aTMPTime.getHours());
					b.CreatedOn.setMinutes(bTMPTime.getMinutes());
					a.CreatedOn.setMinutes(aTMPTime.getMinutes());
					b.CreatedOn.setSeconds(bTMPTime.getSeconds());
					a.CreatedOn.setSeconds(aTMPTime.getSeconds());
					return b.CreatedOn.getTime() - a.CreatedOn.getTime();
				});
			}
			oModel.setData(data.toLastNotes.results);
			this.getView().setModel(oModel, "notes");
		},

		onNavBack: function (oEvent) {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", false);

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = this.getRouter();
				oRouter.navTo("Global", {
					"?query": this._getQueryParameter()
				});
			}
		},

		onNavHome: function (oEvent) {
			//nav back to start page of the MCC One Dashboard
			var oRouter = this.getRouter();
			oRouter.navTo("Global", {
				"?query": this._getQueryParameter(),
			});
		},

		navToCustomer: function (oEv) {
			var oCustomer = oEv.getSource().getBindingContext("crossIssue").getObject();
			var oRouter = this.getRouter();
			if (this.getOwnerComponent().getModel("customerModel")) {
				this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			}

			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: oCustomer.ErpCustNo
			});
		},

		navToGlobalUltimate: function () {
			var oCase = this.getOwnerComponent().getModel("crossIssue").getData();
			var oRouter = this.getRouter();
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: oCase.GlobalUltimateR3No
			});
		},

		navToParentCase: function () {
			var oCase = this.getOwnerComponent().getModel("crossIssue").getData();
			var oRouter = this.getRouter();
			this.getOwnerComponent().getModel("crossIssue").setProperty("/reload", true);
			oRouter.navTo("CaseDetails", {
				"?query": this._getQueryParameter(),
				CaseId: oCase.ParentCaseId
			});
		},

		onParentCaseNewTab: function (oEv) {
			var sCaseId = this.getOwnerComponent().getModel("crossIssue").getData().ParentCaseId;
			this._openCaseInNewTab(sCaseId);
		},

		_openCaseInWebDynpro: function () {
			var oCase = this.getView().getModel("crossIssue").getData();
			this._openWindow(oCase.LinkToCroi);
		},

		onOpenUser: function (oEv) {
			if (oEv.getSource().data("useridGEM")) {
				this.formatter.openUser(oEv, oEv.getSource().data("useridGEM"));
			} else if (oEv.getSource().data("userid")) {
				this.formatter.openUser(oEv, oEv.getSource().data("userid"));
			} else {
				this.formatter.openUser(oEv, oEv.getSource().data("useridBDM"));
			}
		},

		handleQuickViewtPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("crossIssue").getObject();
			var oDescription = oData.toNote.results.filter(function (note) {
				return note.NoteType === "A001";
			});
			var oInitialInformation = oData.toNote.results.filter(function (note) {
				return note.NoteType === "ZMM2";
			});
			//NoteTypeDesc.Description
			//NoteTypeDesc.InitialInformation
			if (!this.quickInfoDialog) {
				this.quickInfoDialog = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.QuickInfoNotes", this);
				this.getView().addDependent(this.quickInfoDialog);
			}
			this.quickInfoDialog.setModel(new JSONModel({
				description: oDescription.length > 0 ? oDescription[0].Text : "-",
				initialInformation: oInitialInformation.length > 0 ? oInitialInformation[0].Text : "-"
			}), "notes");

			this.quickInfoDialog.openBy(oEv.getSource());
		},

		openTicketURL: function (oEv) {
			var oData = oEv.getSource().getBindingContext("crossIssue").getObject();
			var currentUrl = window.location.href;
			var url = "";
			var id = "";
			var type = "";
			if (oData.BCPIncident !== "") {
				id = oData.BCPIncident;
				type = "BCP";
			} else if (oData.SNOWIncident !== "") {
				id = oData.SNOWIncident;
				type = "SNOW";
			}

			if (id !== "") {
				if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard")) {
					//we are in dev envrionment
					if (type === "BCP") {
						url = "https://bcdmain.wdf.sap.corp/sap/support/message/" + id;
					} else if (type === "SNOW") {
						url = "https://dev.itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + id;
					}
				} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
					//we are in test envrionment
					if (type === "BCP") {
						url = "https://qa-support.wdf.sap.corp/sap/support/message/" + id;
					} else if (type === "SNOW") {
						url = "https://test.itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + id;
					}
				} else {
					if (type === "BCP") {
						url = "https://support.wdf.sap.corp/sap/support/message/" + id;
					} else if (type === "SNOW") {
						url = "https://itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + id;
					}
				}
				this._openWindow(url);
			}

		},
		_showSubscriptionButtonForSpecificCaseTypes: function (oCase) {
			//check if user has general access to at least the aggregation view
			var oSettings = this.getOwnerComponent().getModel("settings").getData();
			if (oSettings.ShowGlobalAggregation) {
				//GEM  Case Type = ZS01 ,Process Type = ZSPRCTYP01, 
				if (oCase.CaseType === "ZS01" && oCase.ProcessTypeId === "ZSPRCTYP01") {
					if (oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations) {
						return true;
					} else {
						return false;
					}
				} else
					// CCM Case Type = ZS02  CustomerType = “MCC Critical Customer Management” with id “ZSCUSTYP05
					if (oCase.CaseType === "ZS02" && oCase.CustomerTypeID === "ZSCUSTYP05") {
						return true;
					} else if (oCase.CaseType === "ZS02" && oCase.CustomerTypeID === "ZSCUSTYP04") { //CPC
						return true;
					} else {
						return false;
					}
			} else {
				return false;
			}

		},
		_readLinkesObjects: function (sId) {
			this.getModel("subModel").read("/LinkedObjects", {
				filters: [new sap.ui.model.Filter("TopIssueID", sap.ui.model.FilterOperator.EQ, sId)],
				success: function (oData) {
					var oModel = new JSONModel(oData);
					this.getView().setModel(oModel, "linkedObjects");
				}.bind(this),
				error: function (err) {
					this.getView().getModel("viewModel").setProperty("/subscriptionID", "");
					this.getView().getModel("viewModel").setProperty("/subscriptionAction", "ERROR");
				}
			});
		},

		navToObject: function (oEv) {
			var oData = oEv.getSource().getBindingContext("linkedObjects").getObject();
			var URL = oData.URL;
			var type = oData.ObjectType;
			var ID = oData.ObjectID;
			if (type === "1") {
				URL = this.formatCRMUrl(ID);
			} else if (type === "2") {
				URL = this.formatCRMUrl(ID, true);
			} else if (type === "3") { //BCP ID
				URL = this.formatter.formatBcpIncidentUrl(ID);
				var win = window.open(URL, "_blank");
				win.opener = null;
				win.focus();
			} else if (type === "4") { //ServiceNow
				URL = this.formatter.formatBcpIncidentUrl(ID);
				var win = window.open(URL, "_blank");
				win.opener = null;
				win.focus();
			}
			if (URL !== null && URL !== "") {
				var win = window.open(URL, "_blank");
				win.opener = null;
				win.focus();
			}
		},

		// loadBCPIncident: function (ID) {
		// 	return new Promise(function (resolve, reject) {
		// 		if (!ID) {
		// 			resolve();
		// 			return;
		// 		}
		// 		var oBCModel = this.getModel("bcModel");
		// 		var oFilter = new sap.ui.model.Filter("IncidentId", sap.ui.model.FilterOperator.EQ, ID);
		// 		oBCModel.read("/Critical_IncidentsSet", {
		// 			filters: [oFilter],
		// 			success: function (oData) {
		// 				if (oData.results.length > 0) {
		// 					var ticket = {
		// 						IncidentID: ID,
		// 						EstatusTxt: oData.results[0].EstatusTxt,
		// 						IncidentLink: oData.results[0].IncidentLink,
		// 						ComponentName: oData.results[0].ComponentName
		// 					};
		// 					resolve(ticket);
		// 				} else {
		// 					resolve();
		// 				}
		// 			},
		// 			error: function (err) {
		// 				resolve();
		// 			}
		// 		});
		// 	}.bind(this));
		// },

		formatCRMUrl: function (caseId, bCrossIssue) {
			var currentUrl = window.location.href;
			var relativeUrl =
				"/sap/bc/bsp/sap/crm_ui_start/default.htm?sap-language=EN&saprole=ZSU_DEFAULT&crm-object-type=CRM_CMG&crm-object-action=B&crm-object-keyname=EXT_KEY&crm-object-value=" +
				caseId;
			if (caseId !== undefined && bCrossIssue === true) {
				var relativeUrl =
					"/sap/bc/bsp/sap/crm_ui_start/default.htm?saprole=ZSU_DEFAULT&crm-object-type=BT116_SRVO&crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-value=" +
					caseId + "&SAP-Language=EN";
				//		https://ict.wdf.sap.corp/sap(bD1lbiZjPTAwMSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?saprole=ZSU_DEFAULT&crm-object-type=BT116_SRVO&crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-value=10222514
			}
			var CRMurl = "https://icp.wdf.sap.corp" + relativeUrl;

			if (currentUrl.includes("a44f228ad") || currentUrl.includes("fiorilaunchpad-sapitcloudt") || currentUrl.includes("test-kinkajou")) {
				//we are in test envrionment
				CRMurl = "https://ict.wdf.sap.corp" + relativeUrl;
			} else if (currentUrl.includes("ssn8r5sjsj")) {
				CRMurl = "https://icd.wdf.sap.corp" + relativeUrl;
			}

			return CRMurl;
		},

		_checkSubscriptionStatusForCase: function (oCase) {
			this.getModel("subModel").read("/MailRoles", {
				filters: [new sap.ui.model.Filter("caseID", sap.ui.model.FilterOperator.EQ, oCase.CaseID)],
				sorters: [new sap.ui.model.Sorter("createdAt")],
				success: function (response) {
					if (response.results.length > 0) {
						this.getView().getModel("viewModel").setProperty("/subscriptionID", response.results[0].RoleID);
						this.getView().getModel("viewModel").setProperty("/subscriptionAction", "DELETE");
					} else {
						this.getView().getModel("viewModel").setProperty("/subscriptionID", "");
						this.getView().getModel("viewModel").setProperty("/subscriptionAction", "ADD");
					}
				}.bind(this),
				error: function (err) {
					this.getView().getModel("viewModel").setProperty("/subscriptionID", "");
					this.getView().getModel("viewModel").setProperty("/subscriptionAction", "ERROR");
				}
			});

		},
		triggerSubscription: function () {
			var oSubModel = this.getModel("subModel");
			var sCustomerEngagement = "";
			var oCase = this.getView().getModel("crossIssue").getData();
			if (oCase.CaseType === "ZS01" && oCase.ProcessTypeId === "ZSPRCTYP01") {
				sCustomerEngagement = "GEM";
			} else
				// CCM Case Type = ZS02  CustomerType = “MCC Critical Customer Management” with id “ZSCUSTYP05
				if (oCase.CaseType === "ZS02" && oCase.CustomerTypeID === "ZSCUSTYP05") {
					sCustomerEngagement = "CCM";
				} else
					// CCM Case Type = ZS02  CustomerType = “MCC Critical Period Coverage” with id “ZSCUSTYP04”
					if (oCase.CaseType === "ZS02" && oCase.CustomerTypeID === "ZSCUSTYP04") {
						sCustomerEngagement = "CPC";
					} else
						// CCM Case Type = ZS02  CustomerType = “Top Critical Customer” with id “ZSCUSTYP06”
						if (oCase.CaseType === "ZS02" && oCase.CustomerTypeID === "ZSCUSTYP06") {
							sCustomerEngagement = "TC2";
						}
			var that = this;
			if (this.getView().getModel("viewModel").getProperty("/subscriptionAction") === "ADD") {
				oSubModel.create("/MailRoles", {
					RoleType: "SUB",
					Recipients: this.getModel("userapi").getProperty("/email"),
					UserID: this.getModel("userapi").getProperty("/name"),
					CustomerEngagement: sCustomerEngagement,
					caseID: parseInt(oCase.CaseID, 10)
				}, {
					success: function (response) {
						if (response) {
							that.getView().getModel("viewModel").setProperty("/subscriptionID", response.RoleID);
						}
						that.getView().getModel("viewModel").setProperty("/subscriptionAction", "DELETE");
					},
					error: function (err) {
						that.getView().getModel("viewModel").setProperty("/subscriptionID", "");
					}
				});
				this.trackEvent("Subscription: Case Add");
			} else if (this.getView().getModel("viewModel").getProperty("/subscriptionAction") === "DELETE") {
				oSubModel.remove("/MailRoles(guid'" + this.getView().getModel("viewModel").getProperty("/subscriptionID") + "')", {
					success: function (response) {
						that.getView().getModel("viewModel").setProperty("/subscriptionAction", "ADD");
						that.getView().getModel("viewModel").setProperty("/subscriptionID", "");
					},
					error: function (err) {
						that.getView().getModel("viewModel").setProperty("/subscriptionID", "");
					}
				});
			}

		}

	});

});