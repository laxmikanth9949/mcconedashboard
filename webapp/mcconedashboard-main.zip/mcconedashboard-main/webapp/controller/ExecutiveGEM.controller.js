sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"com/sap/mcconedashboard/model/Constants",
	"sap/ui/model/json/JSONModel"
], function (BaseController, formatter, Constants, JSONModel) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.ExecutiveGEM", {

		formatter: formatter,

		onInit: function () {

			//create local model to read customer related data, should be this name, cause fragment reused
			var oCustomerData = {
				reload: true
			};
			var oCustomerModel = new sap.ui.model.json.JSONModel(oCustomerData);
			this.getOwnerComponent().setModel(oCustomerModel, "globalEscalations");

			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				iTabFiltered: 0,
				bLoadingState: false,
				title: ""
			}), "viewModel");

			this._oGlobalFilter = null;
			this._oPriceFilter = null;
			this._tblRendered = false;
			this.getRouter().getRoute("ExecutiveGEM").attachPatternMatched(this._onObjectMatched, this);

			//Attach Listener in case a Filter is applied
			var oTable = this.getView().byId("tabInc");
			oTable.attachFilter(function (oEvent) {
				this._updateFilteredCount();
			}, this);

			//Attach Listener in case a global Filter is applied
			var oSearchField = this.getSearchField(oTable);
			oSearchField.attachSearch(function (oEvent) {
				this._updateFilteredCount();
			}, this);
		},

		onAfterRendering: function () {
			this.getView().byId("tabInc").addEventDelegate({
				"onAfterRendering": function (oEv) {
					if (!this._tblRendered) {
						setTimeout(function () {
							oEv.srcControl.invalidate();
						}, 300);

						this._tblRendered = true;
					}
				}.bind(this)
			});

		},

		_onObjectMatched: function (oEvent) {
			if (this.getModel("globalEscalations") && this.getModel("globalEscalations").getData() && this.getModel("globalEscalations").getProperty(
					"/reload")) {
				this.getModel("globalEscalations").setProperty("/reload", false);

				var oArgs = oEvent.getParameter("arguments");
				var sSelectedTab = "All";
				var bCaseState = "open";

			
				this._handleMissionRadarAndAnonymizedMode(oArgs);
				this._handleFeatureFlags(oArgs);

				//var sSelectedTab = this.getOwnerComponent().getModel("data").getProperty("/executiveGEMCaseSelectedTabBarKey");

				if (oArgs["?query"] && oArgs["?query"].selectedTab) {
					sSelectedTab = oArgs["?query"].selectedTab;
				} else if (jQuery.sap.getUriParameters() && jQuery.sap.getUriParameters()._get("selectedTab") && jQuery.sap.getUriParameters()._get(
						"selectedTab") !== "") {
					sSelectedTab = jQuery.sap.getUriParameters()._get("selectedTab");
				}

				if (oArgs["?query"] && oArgs["?query"].caseState) {
					bCaseState = oArgs["?query"].caseState;
				} else if (jQuery.sap.getUriParameters() && jQuery.sap.getUriParameters()._get("caseState") && jQuery.sap.getUriParameters()._get(
						"caseState") !== "") {
					bCaseState = jQuery.sap.getUriParameters()._get("caseState");
				}

				this.getOwnerComponent().getModel("data").setProperty("/executiveGEMCaseSelectedTabBarKey", sSelectedTab);
				this.getOwnerComponent().getModel("data").setProperty("/executiveGEMCaseState", bCaseState);

				this._updateTable();

				this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

				if (bCaseState === "open") {
					if (sSelectedTab === "C") {
						this.getView().getModel("viewModel").setProperty("/title", this._oResourceBundle.getText("redEscalationsTitle") + " - " + this._oResourceBundle
							.getText("redEscalationsSubTitle"));

					} else {
						this.getView().getModel("viewModel").setProperty("/title", this._oResourceBundle.getText("allEscalationsTitle") + " - " + this._oResourceBundle
							.getText("allEscalationSubTitle"));
					}
				} else
				if (bCaseState === "closed") {
					this.getView().getModel("viewModel").setProperty("/title", this._oResourceBundle.getText("closed12MonthsEscalationsTitle"));
				} else if (bCaseState === "all") {
					//
				} else if (bCaseState === "longRunning") {
					this.getView().getModel("viewModel").setProperty("/title", this._oResourceBundle.getText("topLongRunningTitle"));
				} else if (bCaseState === "topTenHighCost") {
					this.getView().getModel("viewModel").setProperty("/title", this._oResourceBundle.getText("topHighCostsTitle"));
				} else if (bCaseState === "boardandexec") {
					this.getView().getModel("viewModel").setProperty("/title", this._oResourceBundle.getText("boardAndExecEscalationsTitle"));
				}

			}
		},
		_readCostDataforTable: function () {
			// //when the view is called directly, it can happen, that the cost oData metadata has not been loaded yet. Therefore we need to check
			// //and call function until it is loaded - successfully or not

			// const pending = {
			// 	state: 'pending',
			// };

			// function getPromiseState(promise) {
			// 	// We put `pending` promise after the promise to test, 
			// 	// which forces .race to test `promise` first
			// 	return Promise.race([promise, pending]).then(
			// 		(value) => {
			// 			if (value === pending) {
			// 				return value;
			// 			}
			// 			return {
			// 				state: 'resolved',
			// 				value
			// 			};
			// 		},
			// 		(reason) => ({
			// 			state: 'rejected',
			// 			reason
			// 		})
			// 	);
			// }

			// if (getPromiseState(this.getOwnerComponent().getModel("bwp003DetailCostBWModel").metadataLoaded(true)) === "pending") {
			// 	var that = this;
			// 	setTimeout(function () {
			// 		that._readCostDataforTable();
			// 	}, 200);
			// 	return null;
			// }
			/*
			 * Read cost data for a list of cases from BW Backend
			 * https://fiorilaunchpad.sap.com/sap/fiori/mcsdashboard/webapp/destinations/int_bw/sap/opu/odata/sap/MCASE_COST_ODA_003N_SRV/
			 * MCASE_COST_ODA_003N(MCASE_CMM_YO_001='',MCASE_HCS_MY_01_0SALESORG='',MCASE_NAM_ON_01_0SALESORG='')/Results?$select=A4MCASEX017CSM_EXID,A4MCASEX017CSM_DURA,A00O2TFCW5W1LNCK7YZ0OT6YGA,A00O2TFCW5W1LNCK7YZ0OT7NQI
			 * &$filter=A4MCASEX017CSM_EXID%20eq%20%2710004472%27%20or%20A4MCASEX017CSM_EXID%20eq%20%2710023955%27
			 */
			if (this.getOwnerComponent().getModel("settings").getProperty("/show_cost_data")) {
				//loop through caseIDs to build the Url Parameters for the case filter

				//we need to split the array in several parts, because otherwise the Cloud Connector is blocking the call
				var aCases = this.getModel("settings").getProperty("/caseIdsForExport");
				if (aCases) {
					aCases = this.getModel("settings").getProperty("/caseIdsForExport").slice();
					var aArrayOfCaseFilters = [];

					var i, j, temporary, chunk = 100;
					for (i = 0, j = aCases.length; i < j; i += chunk) {
						var sCaseIdFilters = "&$filter=";
						temporary = aCases.slice(i, i + chunk);
						temporary.forEach(function (item, index) {
							if (index > 0) {
								sCaseIdFilters += "%20or%20";
							}
							sCaseIdFilters += "A4MCASEX017CSM_EXID%20eq%20%27" + item + "%27";
						});
						aArrayOfCaseFilters.push(sCaseIdFilters);
					}

					var that = this;
					aArrayOfCaseFilters.forEach(function (item) {
						that.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", true);
						var mParamsMap = [
							"$select=A4MCASEX017CSM_EXID,A4MCASEX017CSM_DURA,A00O2TFCW5W1LNCK7YZ0OT6YGA,A00O2TFCW5W1LNCK7YZ0OT7NQI" + item,
						];

						var bwp003DetailCostBWModel = new sap.ui.model.odata.v2.ODataModel(
							sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCASE_COST_ODA_003N_SRV", {
							"metadataUrlParams": {
								"sap-documentation": "heading"
							},
							"defaultCountMode": true,
							"useBatch": false,
							"headers": {
								"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
							}
						});
						bwp003DetailCostBWModel.read(
							"/MCASE_COST_ODA_003N(MCASE_CMM_YO_001='',MCASE_HCS_MY_01_0SALESORG='',MCASE_NAM_ON_01_0SALESORG='')/Results", {
								urlParameters: mParamsMap,
								success: function (data) {
									that.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
									var aAlreadyAdded = that.getModel("globalEscalations").getProperty("/GlobalEscalationsSet");
									data.results.forEach(function (oCase) {
										var aTmp = aAlreadyAdded.filter(function (val) {
											return val.CaseId === oCase.A4MCASEX017CSM_EXID;
										});
										if (aTmp.length > 0) {
											aTmp.forEach(function (item) {
												item.TotalForecastCost = parseInt(oCase.A00O2TFCW5W1LNCK7YZ0OT7NQI, 10);
												item.TotalActualCost = parseInt(oCase.A00O2TFCW5W1LNCK7YZ0OT6YGA, 10);
											});
										}
									});
									that.getModel("globalEscalations").refresh();
								},
								error: function (oError) {
									that.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
								}
							});
					});
				}
			}
		},

		_updateTable: function () {
			var aFilters = [];
			var aBWCaseIdFiltersContainer = [];
			var that = this;
			var aCosts = [],
				aTotalActualCosts = [];
			var oICModel = this.getModel();
			var oFilterModel = this.getModel("filterModel");
			var oSettings = this.getOwnerComponent().getModel("settings").getData();
			var oPromiseReadExecutiveGEM = null; //promise needed to handledifferent checks 
			oFilterModel.refresh(true);
			var sRegion = this.getRegionFilterModel();
			//reset caseIds for PDF or XLS Export
			this.getModel("settings").setProperty("/caseIdsForExport", null);
			var bCaseState = this.getOwnerComponent().getModel("data").getProperty("/executiveGEMCaseState");
			if (!bCaseState) {
				bCaseState = "open";
			}
			var sSelectedTab = this.getOwnerComponent().getModel("data").getProperty("/executiveGEMCaseSelectedTabBarKey");
			this.getView().byId("dataIconTabBar").setSelectedKey(sSelectedTab);
			// reset Model
			this.getModel("globalEscalations").setProperty("/GlobalEscalationsSet", null);

			var nRegionCallCounter = 0,
				nRegionCounter = 0;
			//function needed, because for BW oData calls we cannot submit several Region filters in one call. We need to call it separately and the merge it.
			//Then get the top ten for all regions and call CRM oData with the relevant case ids
			function mergeBWTopTenHighCost() {
				if (nRegionCallCounter !== nRegionCounter) {
					setTimeout(function () {
						jQuery.proxy(mergeBWTopTenHighCost(), this);
					}, 200);
					return null;
				} else {
					//get the top ten out of all Region calls
					aCosts.sort(function (a, b) {
						return parseInt(b.costforecast.replace(/,/g, ""), 10) - parseInt(a.costforecast.replace(/,/g, ""), 10);
					});
					aCosts.length = 10;
					var aCaseIdFilters = [];
					aCosts.forEach(function (item, index) {
						// if (index < (maxCount * iMultiplier)) {
						// 	aCaseIdFilters.push(new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.EQ, item.A4MCASEX017CSM_EXID));
						// } else {
						// 	aBWCaseIdFiltersContainer.push(aCaseIdFilters);
						// 	iMultiplier += 1;
						// 	aCaseIdFilters = [];
						//	aCaseIdFilters.push(new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.EQ, index));
						aCaseIdFilters.push(new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.EQ, item.id));
						//for PDF/XLS Generation we need to store the case IDs
						if (that.getModel("settings").getProperty("/caseIdsForExport") === null) {
							that.getModel("settings").setProperty("/caseIdsForExport", [item.id]);
						} else {
							that.getModel("settings").getProperty("/caseIdsForExport").push(item.id);
						}
						// }
					});
					if (aCaseIdFilters.length > 0) {
						aBWCaseIdFiltersContainer.push(aCaseIdFilters);
					} else {
						that.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
						that.getModel("globalEscalations").setProperty("/GlobalEscalationsSet", null);
					}
					//call CRM Odata Service in order to get further details for the case from CRM System
					aBWCaseIdFiltersContainer.forEach(function (item) {
						oICModel.read("/GlobalEscalationsSet", {
							filters: [new sap.ui.model.Filter(item, false)],
							success: function (data) {
								that._calculateRating(data);

								function getRelevantCostData(value, index, array) {
									return value.id === this.id;
								}

								for (var i = 0; i < data.results.length; i++) {
									var oCaseForecastCosts = aCosts.find(getRelevantCostData, {
										id: data.results[i].CaseId
									});
									var oCaseActialCosts = aTotalActualCosts.find(getRelevantCostData, {
										id: data.results[i].CaseId
									});
									data.results[i].TotalForecastCost = parseInt(oCaseForecastCosts.costforecast, 10);
									data.results[i].TotalActualCost = parseInt(oCaseActialCosts.costactuals, 10);

									//calculate and add duration
									var dateToday = new Date();
									var dCreationDate = new Date(data.results[i].CreateDate); //new Date(data.results[i].create_time.substring(0, 4), data.results[i].create_time.substring(4, 6) -	1,data.results[i].create_time.substring(6, 8));
									var iDuration = that.dateDiffInDays(dCreationDate, dateToday, data.results[i].CaseTitle);
									data.results[i].Duration = iDuration;

									//data.results[i].totalForecastCost = parseInt(aCosts.find(x => x.id === data.results[i].CaseId).costforecast);//parseInt(aCosts[data.results[i].CaseId]);
									//data.results[i].totalActualCost = parseInt(aTotalActualCosts.find(x => x.id === data.results[i].CaseId).costactuals);//parseInt(aTotalActualCosts[data.results[i].CaseId]);
								}
								data.results.sort(function (a, b) {
									return b.TotalForecastCost - a.TotalForecastCost;
								});
								that.getModel("globalEscalations").setProperty("/GlobalEscalationsSet", data.results);
								that.loadProducts(aFilters);
								//MISSIONRADAR 2211	
								that.readMissionRadarValues(that.getModel("globalEscalations"), "GlobalEscalationsSet");
								//in order to also apply the select tab filters to the data in the table, we need to fire the select of the tab
								that.getView().byId("dataIconTabBar").fireSelect();
							},
							error: function (oError) {
								that.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
							}
						});
					});
					return null;
				}
			}

			if (bCaseState !== "topTenHighCost") {

				var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
				if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
					aFilters.push(oFilterForICP);
				}

				if (sRegion) {
					var aRegionFilter = [];
					sRegion.split(",").forEach(function (region) {
						aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
					});
					aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
				}
				var dateInPast = new Date(),
					aCaseIdsRequestingUnitFromHana = null;
				dateInPast.setFullYear(dateInPast.getFullYear() - 1);
				dateInPast.setDate(1);
				dateInPast.setUTCHours(0, [0], [0], [0]);
				this.getOwnerComponent().getModel("data").setProperty("/executiveGEMClosedDate", this.formatter.dateFormatOneDate(dateInPast));

				if (bCaseState === "closed" || bCaseState === "all") {

					var tileSpecificFilters1 = new sap.ui.model.Filter([
							new sap.ui.model.Filter([
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "40")
								],
								false),
							new sap.ui.model.Filter({
								path: "ClosingDate",
								operator: sap.ui.model.FilterOperator.GE,
								value1: dateInPast
							})
						],
						true
					);

				}
				if (bCaseState === "open" || bCaseState === "all") {
					//ALL ongoing 
					var tileSpecificFilters2 = new sap.ui.model.Filter([
							new sap.ui.model.Filter([new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20"), new sap.ui.model.Filter(
								"Status", sap.ui.model.FilterOperator.EQ, "30")], false)
						],
						true
					);
				}

				//Top Long Running
				//Duration >= 180 Tage  -->  CREATE_TIME < (today-180 days)
				//Rating =  "C Red and B Yellow" -->  rating eq "C"  or rating eq "B"
				//Case Status = "30 - in Process"   -->  status eq '30'
				//	process_type Global Escalations(ZSPRCTYP01)
				if (bCaseState === "longRunning") {
					//var tilesModel = this.getModel("tiles");
					//Calculate date
					var dTemp = new Date();
					dTemp.setDate(dTemp.getDate() - 180);

					//dMinus6.getMonth()+1 because the service delivers the date string with months from 01-12, but javascript uses 00-11
					//var todayMinus180Date = "" + dTemp.getFullYear() + ("0" + (dTemp.getMonth() + 1)).slice(-2) + ("0" + dTemp.getDate()).slice(-2) +
					//	("0" + dTemp.getHours()).slice(-2) + ("0" + dTemp.getMinutes()).slice(-2) + ("0" + dTemp.getSeconds()).slice(-2);

					var tileSpecificFilters3 = new sap.ui.model.Filter(
						[new sap.ui.model.Filter("CreateDate", sap.ui.model.FilterOperator.LE, dTemp),
							// new sap.ui.model.Filter(
							// 		"process_type", sap.ui.model.FilterOperator
							// 		.EQ,
							// 		"ZSPRCTYP01"),
							new sap.ui.model.Filter(
								[new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"), new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator
									.EQ, "B")].filter(Boolean), false),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30")
						].filter(Boolean),
						true
					);
					//	tilesModel.setProperty("/topLongRunning/date", dTemp);
				}

				if (bCaseState === "boardandexec") {

					//Board & Executive Requested Global Customer Escalations ongoing escalations
					//Case Status = status eq '20' or status eq '30'
					//process_type  Global Escalations (ZSPRCTYP01)  -->  should be predefined in Backend
					// in addition we need to read the data from the MCC HANA DB --> all ongoing escalations with requesting unit "RU_Board" and "RU_Exec" 
					//-->  the returned case IDs we need to add the the ICP call
					var tileSpecificFilters4 = null;
					//read relevant case Ids form Hana DB
					//int_mcshana/odata/v2/MCCOnedashboard/Cases?
					//$filter=(RequestingUnit%20eq%20%27RU_BOARD%27%20or%20RequestingUnit%20eq%20%27RU_EXEC%27)%20and%20UseCaseType%20eq%20%27mcs-gem%27

					oPromiseReadExecutiveGEM = new Promise(function (resolve) {
						this.getModel("subModel").read("/Cases", {
							filters: [new sap.ui.model.Filter(
								[new sap.ui.model.Filter(
										[new sap.ui.model.Filter("RequestingUnit", sap.ui.model.FilterOperator.StartsWith, "RU_BOARD"), new sap.ui.model.Filter(
											"RequestingUnit", sap.ui.model.FilterOperator
											.StartsWith, "RU_EXEC")].filter(Boolean), false),
									new sap.ui.model.Filter("UseCaseType", sap.ui.model.FilterOperator.EQ, "mcs-gem")
								].filter(Boolean),
								true
							)],
							urlParameters: {
								"$select": "CaseID,RequestingUnit,RequestingUnitName"
							},
							success: function (oData) {
								if (oData.results) {
									aCaseIdsRequestingUnitFromHana = oData.results;
								}
								var aCaseIdFilters = [];
								oData.results.forEach(function (element) {
									aCaseIdFilters.push(new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.EQ, element.CaseID));
								});
								// tileSpecificFilters4.push(new sap.ui.model.Filter(aCaseIdFilters, false));
								// var tileSpecificFilters = new sap.ui.model.Filter([
								// 		new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30"),
								// 		new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20")
								// 	],
								// 	false);
								// tileSpecificFilters4.push(new sap.ui.model.Filter(tileSpecificFilters, false));

								tileSpecificFilters4 = new sap.ui.model.Filter(
									[new sap.ui.model.Filter(aCaseIdFilters, false),
										new sap.ui.model.Filter(
											[new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30"), new sap.ui.model.Filter("Status", sap.ui.model
												.FilterOperator.EQ, "20")].filter(Boolean), false)
									].filter(Boolean),
									true
								);

								resolve();
							},
							error: function () {
								resolve();
							}
						});
					}.bind(this));
				} else {
					//in this case just read all Requestîng Units from the HANA DB for GEM
					this.getModel("subModel").read("/Cases", {
						filters: [new sap.ui.model.Filter(
							[new sap.ui.model.Filter("UseCaseType", sap.ui.model.FilterOperator.EQ, "mcs-gem")].filter(Boolean),
							true
						)],
						urlParameters: {
							"$select": "CaseID,RequestingUnit,RequestingUnitName"
						},
						success: function (oData) {
							if (oData.results) {
								aCaseIdsRequestingUnitFromHana = oData.results;
							}
						},
						error: function () {}
					});

				}

				if (bCaseState === "open") {
					aFilters.push(tileSpecificFilters2);
				} else if (bCaseState === "closed") {
					aFilters.push(tileSpecificFilters1);
				} else if (bCaseState === "all") {
					aFilters.push(new sap.ui.model.Filter([
							tileSpecificFilters1,
							tileSpecificFilters2
						],
						false
					));
				} else if (bCaseState === "longRunning") {
					aFilters.push(tileSpecificFilters3);
				} else if (bCaseState === "boardandexec") {
					Promise.all([oPromiseReadExecutiveGEM]).then(function () {
						aFilters.push(tileSpecificFilters4);
					}.bind(this));

				}

				this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", true);
				//check the state context of the view and in case it is NOT the Executive and Board Requested context, then we can set the oPromiseReadExecutiveGEM right away to resolved
				//we only need to wait for the Executive and Board oData call to HANA to finish first in order to built up the correct filter with the needed case ids from the HANA DB
				if (bCaseState !== "boardandexec") {
					oPromiseReadExecutiveGEM = new Promise(function (resolve) {
						resolve();
					}.bind(this));
				}
				Promise.all([oPromiseReadExecutiveGEM]).then(function () {

					oICModel.read("/GlobalEscalationsSet", {
						filters: [new sap.ui.model.Filter(aFilters, true)],
						success: function (data) {
							//sort client at side
							data = this._sortByRanking(data);

							this._calculateRating(data);
							data.results.forEach(function (oCase) {
								if (oCase.Rating === "") {
									oCase.Rating = "unrated";
								}
								if (oCase.DbsMaintenanceRanking === "0") {
									oCase.DbsMaintenanceRanking = "";
								}
								oCase.priorityMatched = this.formatter.sortPriorities(oCase.PriorityT);
								//in case the user has only AGGR AUTH we need to assure, that the action-Icon for showing the notes, is not visible in the UI
								//RD05.22 this is not valid anymore, because the HasNotes is now covered by AUTH checks in the Backend
								// if (oSettings.ShowGlobalAggregation) {
								// 	if (!oSettings.ShowGlobalEscalations && !oSettings.ShowRegionalGlobalEscalations) {
								// 		oCase.HasNotes = "";
								// 	}
								// }
								//for PDF/XLS Generation we need to store the case IDs
								if (this.getModel("settings").getProperty("/caseIdsForExport") === null) {
									this.getModel("settings").setProperty("/caseIdsForExport", [oCase.CaseId]);
								} else {
									this.getModel("settings").getProperty("/caseIdsForExport").push(oCase.CaseId);
								}
								//calculate and add duration
								var dateToday = new Date();
								var dCreationDate = new Date(oCase.CreateDate); //new Date(data.results[i].create_time.substring(0, 4), data.results[i].create_time.substring(4, 6) -	1,data.results[i].create_time.substring(6, 8));
								if (oCase.Status === "40") {
									dateToday = new Date(oCase.ClosingDate);
								}
								var iDuration = this.dateDiffInDays(dCreationDate, dateToday, oCase.CaseTitle);
								oCase.Duration = iDuration;
								oCase.DurationString = iDuration.toString();

								//add data for requesting unit to result list
								if (aCaseIdsRequestingUnitFromHana) {
									var index = aCaseIdsRequestingUnitFromHana.findIndex(item => item.CaseID.toString() === oCase.CaseId);
									if (index > -1) {
										oCase.ReqestingUnit = aCaseIdsRequestingUnitFromHana[index].RequestingUnit;
										oCase.RequestingUnitT = aCaseIdsRequestingUnitFromHana[index].RequestingUnitName; //this.formatter.getRequestingUnitText(oCase.ReqestingUnit, this._oResourceBundle);
									}
								}

							}.bind(this));
							//sort array by filterProp and iac
							data.results = data.results.sort(function (a, b) {
								if (b.Duration > a.Duration) {
									return 1;
								} else if (b.Duration < a.Duration) {
									return -1;
								}
								return 0;
							}.bind(this));
							this.getModel("globalEscalations").setProperty("/GlobalEscalationsSet", data.results);
							this._readCostDataforTable();
							this.loadProducts(aFilters);
							//MISSIONRADAR 2211	
							this.readMissionRadarValues(this.getModel("globalEscalations"), "GlobalEscalationsSet");
							//in order to also apply the select tab filters to the data in the table, we need to fire the select of the tab
							this.getView().byId("dataIconTabBar").fireSelect();

						}.bind(this),
						error: function (data) {
							this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
						}.bind(this)
					});
				}.bind(this));
			} else {
				//-----------------------------
				//High Cost Global Customer escalations 
				//-----------------------------
				this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", true);
				//BW specific filter model for URL specific filter
				var oBWFilterModel = this.oView.getModel("bwFilterModel");
				//BW filters from Facet Filter selection
				var oFilterForBWCost = oFilterModel.getProperty("/oFilterForBWCosts");
				//var bwp001HighCostBWModel = this.getOwnerComponent().getModel("bwp001HighCostBWModel");
				var bwp001HighCostBWModel = new sap.ui.model.odata.v2.ODataModel(
					sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCASE_COST_ODA_001N_SRV", {
					"metadataUrlParams": {
						"sap-documentation": "heading"
					},
					"defaultCountMode": true,
					"useBatch": false,
					"headers": {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					}
				});

				//reset current count on ui in order to enable the busy indicator
				//tilesModel.setProperty("/topHighCosts/number", null);
				var sRegionBW = "WORLD";
				if (sRegion && sRegion !== "") {
					sRegionBW = sRegion;
				}
				var model = new JSONModel({
					cases: null //,
						//totalEscalationCosts: null
				});
				//for BW we need to read the data for each Region separately
				if (sRegionBW) {
					sRegionBW.split(",").forEach(function (region) {
						nRegionCounter++;
						var aBWFilters = [];
						var regionOnlyFilterForBWP = oBWFilterModel.buildRegionOnlyODataFilter("BWP", region).aFilters;
						var sFilter = oBWFilterModel.buildURLVariableFilterForBWP(regionOnlyFilterForBWP, "TopTenHighCostStructure");

						if (oFilterForBWCost && oFilterForBWCost.aFilters && oFilterForBWCost.aFilters.length > 0) {
							aBWFilters.push(oFilterForBWCost);
						}
						bwp001HighCostBWModel.read("/MCASE_COST_ODA_001N(" + sFilter + ")/Results", {
							filters: [new sap.ui.model.Filter(aBWFilters, true)],
							urlParameters: "$select=A4MCASEX017CSM_EXID,A00O2TFCW5W1LNCK5HR2HNY6F3,A00O2TFCW5W1LNCK711GBMXFV8&$inlinecount=allpages", //A4MCASEX017MP_0COUNTRY_T_L
							dataType: "json",
							success: function (data, response) {
								if (data.results.length > 0) {
									var result = data.results;
									result.forEach(function (item, index) {
										aCosts.push({
											id: item.A4MCASEX017CSM_EXID,
											costforecast: item.A00O2TFCW5W1LNCK5HR2HNY6F3
										});
										aTotalActualCosts.push({
											id: item.A4MCASEX017CSM_EXID,
											costactuals: item.A00O2TFCW5W1LNCK711GBMXFV8
										});
									});
								} else {
									model.setProperty("/cases", data.results);
								}
								nRegionCallCounter++;
							},
							error: function (oError, response) {
								model.setProperty("/cases", null);
								nRegionCallCounter++;
							}
						});
					}.bind(this));
					mergeBWTopTenHighCost();
				}
			}
		},

		loadProducts: function (aFilters) {
			this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", true);

			var oICModel = this.getModel();
			oICModel.read("/GlobalEscalationsSet", {
				urlParameters: {
					"$expand": "toProducts"
				},
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					var oModel = this.getModel("globalEscalations");
					var aAlreadyAdded = oModel.getProperty("/GlobalEscalationsSet");
					//concat toProducts properties
					data.results.forEach(function (result) {
						result.Product = this.formatter.concatProducts(result.toProducts.results, "ProductT");
						result.ProductCategory = this.formatter.concatProducts(result.toProducts.results, "ProductCatT");
						result.ProductLine = this.formatter.concatProducts(result.toProducts.results, "ProductLineT");
						result.ProductVersion = this.formatter.concatProducts(result.toProducts.results, "ProductVersionT");

						var aTmp = aAlreadyAdded.filter(function (val) {
							return val.CaseId === result.CaseId;
						});
						if (aTmp.length > 0) {
							aTmp.forEach(function (val, i) {
								aTmp[i].toProducts = result.toProducts;
								aTmp[i].toLastNotes = result.toLastNotes;
								aTmp[i].Product = result.Product;
								aTmp[i].ProductCategory = result.ProductCategory;
								aTmp[i].ProductLine = result.ProductLine;
								aTmp[i].ProductVersion = result.ProductVersion;
							});
						}

					}, this);
					oModel.refresh();
					this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
				}.bind(this),
				error: function (data) {
					this.getModel("globalEscalations").setProperty("/GlobalEscalationsSetBusy", false);
				}.bind(this)
			});
		},

		loadNotes: function (oControl, id) {
			var oICModel = this.getModel();
			oControl.setBusyIndicatorDelay(0);
			oControl.setBusy(true);
			oICModel.read("/GlobalEscalationsSet('" + id + "')/toLastNotes", {
				success: function (data) {
					this.openQuickInfoPopover(oControl, data.results);
				}.bind(this),
				error: function (data) {
					oControl.setBusy(false);
				}.bind(this)
			});
		},

		handleCustomerPress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("globalEscalations").getPath();
			var oProperty = this.getModel("globalEscalations").getProperty(sPath);
			var sErpCustNo = oProperty.CustomerErpNo || oProperty.ErpCustNo || oProperty.CustomerNo;
			var oRouter = this.getRouter();
			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		handleGlobalUltimatePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("globalEscalations").getPath();
			var oProperty = this.getModel("globalEscalations").getProperty(sPath);
			var sErpCustNo = oProperty.GuErpNo;
			var oRouter = this.getRouter();

			this.getModel("settings").setProperty("/flagCustomerFactSheet", true);
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			oRouter.navTo("Customer", {
				"?query": this._getQueryParameter(),
				ErpCustNo: sErpCustNo
			});
		},

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("globalEscalations").getObject();
			var sObjectType = "";
			var sId = oData.CaseId;
			this.loadNotes(oEv.getSource(), sId, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},

		handleCasePress: function (evt) {
			var sPath = evt.getSource().getParent().getBindingContext("globalEscalations").getPath();
			var oProperty = this.getModel("globalEscalations").getProperty(sPath);
			var sCaseId = oProperty.CaseId;
			var oRouter = this.getRouter();
			this.getOwnerComponent().getModel("case").setProperty("/reload", true);
			oRouter.navTo("CaseDetails", {
				"?query": this._getQueryParameter(),
				CaseId: sCaseId
			});
		},

		onCaseNewTab: function (oEv) {
			var sPath = oEv.getSource().getParent().getBindingContext("globalEscalations").getPath();
			var oProperty = this.getModel("globalEscalations").getProperty(sPath);
			var sCaseId = oProperty.CaseId;
			this._openCaseInNewTab(sCaseId);
		},

		changeCaseState: function () {
			this.getOwnerComponent().getModel("data").setProperty("/executiveGEMCaseSelectedTabBarKey", "All");
			this._updateTable();
		},

		_calculateRating: function (data) {
			var oViewModel = this.getView().getModel("viewModel");
			var iGreen = 0;
			var iYellow = 0;
			var iRed = 0;
			var iUnrated = 0;
			data.results.forEach(function (oCase) {
				switch (oCase.Rating) {
				case "A":
					iGreen++;
					break;
				case "B":
					iYellow++;
					break;
				case "C":
					iRed++;
					break;
				default:
					iUnrated++;
				}
			});
			oViewModel.setProperty("/iTabAll", data.results.length);
			oViewModel.setProperty("/iTabGreen", iGreen);
			oViewModel.setProperty("/iTabYellow", iYellow);
			oViewModel.setProperty("/iTabRed", iRed);
			oViewModel.setProperty("/iTabUnrated", iUnrated);
			this._updateFilteredCount();
		},

		_updateFilteredCount: function () {
			var oTable = this.getView().byId("tabInc");
			var iFilteredCount = oTable.getBinding("rows").getLength();
			var aFilters = oTable.getBinding("rows").aFilters;
			if (aFilters && aFilters.length > 0) {
				var iLengths = oTable.getBinding("rows").iLengths;
				if (iLengths) {
					iFilteredCount = oTable.getBinding("rows").iLength - iLengths.sum();
				} else {
					iFilteredCount = oTable.getBinding("rows").iLength;
				}
			}
			this.getView().getModel("viewModel").setProperty("/iTabFiltered", iFilteredCount);
		},

		handleRatingIconTabBarSelect: function (oEv) {
			var oTable = this.getView().byId("tabInc");
			var sRatingKey = oEv.getSource().getSelectedKey();
			var aFilter = [];

			// Reset all table filters
			oTable.getColumns().forEach(function (oColumn) {
				oColumn.filter(null);
				oColumn.setFilterValue("");
			});
			this.clearSearchField(oTable);

			if (sRatingKey !== "All") {
				aFilter.push(new sap.ui.model.Filter("Rating", "EQ", sRatingKey));
			}
			//this.getOwnerComponent().getModel("data").setProperty("/executiveGEMCaseSelectedTabBarKey", sRatingKey);

			//reset caseIds for PDF or XLS Export
			this.getModel("settings").setProperty("/caseIdsForExport", null);
			var oBinding = oTable.getBinding("rows"); //Get hold of binding aggregation "row"
			if (oBinding) {
				oBinding.filter(aFilter);
				oBinding.aIndices.forEach(function (c) {
					//for PDF/XLS Generation we need to store the case IDs
					if (this.getModel("settings").getProperty("/caseIdsForExport") === null) {
						this.getModel("settings").setProperty("/caseIdsForExport", [oBinding.oList[c].CaseId]);
					} else {
						this.getModel("settings").getProperty("/caseIdsForExport").push(oBinding.oList[c].CaseId);
					}
				}.bind(this));
			}
			this._updateFilteredCount();
		},

		onTopIssuesCount: function (oEv) {
			var oProperty = oEv.getSource().getParent().getBindingContext("globalEscalations").getObject();
			var sCaseId = oProperty.CaseId;
			this._shopTopIssuesCountPopover(sCaseId, oEv.getSource());
		},
		customSorting: function (oEvent) {
			var oGUMaintenanceRankingColumn = this.byId("dbsMaintenanceRankingColumn");
			var oMCCiColumn = this.byId("mcci");
			var oPreventionScoreColumn = this.byId("preventionScore");
			var oCurrentColumn = oEvent.getParameter("column");
			if (oCurrentColumn !== oGUMaintenanceRankingColumn && oCurrentColumn !== oMCCiColumn && oCurrentColumn !== oPreventionScoreColumn) {
				//oGUMaintenanceRankingColumn.setSorted(false); //No multi-column sorting
				return;
			}
			oEvent.preventDefault();
			var sOrder = oEvent.getParameter("sortOrder");
			if (oCurrentColumn == oMCCiColumn || oCurrentColumn == oPreventionScoreColumn) {
				this.customSortingBaseFloat(oCurrentColumn, sOrder, "tabInc");
			} else {
				this.customSortingBase(oCurrentColumn, sOrder, oGUMaintenanceRankingColumn, "tabInc");
			}
		},

		readCasesFromICPinJSONforCostBasedXLSGeneration: function (filteredCaseList) {
			var dashboardModel = this.getModel("mcsModel");

			return new Promise(function (resolve, reject) {
				var oJsonModel = new JSONModel({
					cases: null
				});
				var oFilters = [];
				for (var i = 0; i < filteredCaseList.length; i++) {
					var oCaseIdFilter = new sap.ui.model.Filter([new sap.ui.model.Filter(
						"CaseID",
						sap.ui.model.FilterOperator.EQ,
						filteredCaseList[i])].filter(Boolean), true);
					oFilters.push(oCaseIdFilter);
				}

				//this._onBeginLoadingDataToModel(model, "/escalationBySupportModel");
				var oFinalFilter = [new sap.ui.model.Filter({
					filters: oFilters, //[finalFilter[0], finalFilter[1]],
					and: false
				})];
				dashboardModel.read("/XLSDownloadSet", {
					filters: [oFinalFilter], // [oCaseIdFilter],
					urlParameters: {
						"$expand": "ToExt",
						"$format": "json"
					},
					success: function (data, response) {
						oJsonModel.setProperty("/cases", data.results);
						resolve(oJsonModel);
					},
					error: function (oError, response) {
						oJsonModel.setProperty("/cases", null);
						reject(oJsonModel);
					}
				});

			});
		},
		createXLSColumnConfig: function () {
			var aXLSConfig = [{
				label: this._oResourceBundle.getText("xlsConfidential"),
				property: this._oResourceBundle.getText("xlsConfidential"),
				type: "string",
				width: "25"
			}, {
				label: this._oResourceBundle.getText("xlsCaseId"),
				property: "CaseID",
				type: "string",
				scale: 0
			}, {
				label: this._oResourceBundle.getText("xlsProcessType"),
				property: "ProcessTypeText",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsCustomer"),
				property: "CustomerName",
				type: "string",
				width: "50"
			}, {
				label: this._oResourceBundle.getText("xlsForecastCosts"),
				property: "forecastCost",
				type: "string",
				width: "50"
			}, {
				label: this._oResourceBundle.getText("xlsCosts"),
				property: "actualCost",
				type: "string",
				width: "50"
			}, {
				label: this._oResourceBundle.getText("xlsCustomerNumber"),
				property: "CustomerNoErp",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsCustomerNumberCRM"),
				property: "CustomerNoCrm",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsRating"),
				property: "RatingText",
				type: "string",
				width: "15"
			}, {
				label: this._oResourceBundle.getText("xlsStatus"),
				property: "StatusText",
				type: "string",
				width: "15"
			}, {
				label: this._oResourceBundle.getText("xlsDescription"),
				property: "CaseTitle",
				type: "string",
				width: "60"
			}, {
				label: this._oResourceBundle.getText("xlsMainProducts"),
				property: "MainProducts",
				type: "string",
				width: "60"
			}, {
				label: this._oResourceBundle.getText("xlsAffectedProducts"),
				property: "AffectedProducts",
				type: "string",
				width: "60"
			}, {
				label: this._oResourceBundle.getText("xlsRegion"),
				property: "Region",
				type: "string",
				width: "15"
			}, {
				label: this._oResourceBundle.getText("xlsCountry"),
				property: "CountryText",
				type: "string",
				width: "15"
			}, {
				label: this._oResourceBundle.getText("xlsDeliveryUnit"),
				property: "DeliveryUnitText",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsCustomerSegment"),
				property: "MasterCodeText",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsSalesOrg"),
				property: "SalesOrgName",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsServiceOrg"),
				property: "ServiceOrgName",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsCustomerEngagement"),
				property: "CategoryText",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsImplementationPartner"),
				property: "ImplementationPartnerText",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsEscalationManager"),
				property: "EscalationManagerText",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsDeEscalationArchitect"),
				property: "DeescalationArchitectText",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsRequestor"),
				property: "RequestorName",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsCreated"),
				property: "CaseDate",
				type: "string",
				width: "15"
			}, {
				label: this._oResourceBundle.getText("xlsPlanned"),
				property: "PlanEndDate",
				type: "string",
				width: "15"
			}, {
				label: this._oResourceBundle.getText("xlsClosing"),
				property: "ClosingDate",
				type: "string",
				width: "15"
			}, {
				label: this._oResourceBundle.getText("xlsDuration"),
				property: "Duration",
				type: "string",
				width: "15"
			}, {
				label: this._oResourceBundle.getText("xlsLatestStatus"),
				property: "LatestStatus",
				type: "string",
				width: "30"
			}, {
				label: this._oResourceBundle.getText("xlsManagementSummary"),
				property: "ManagementSummary",
				type: "string",
				width: "30"
			}, {
				label: this._oResourceBundle.getText("xlsAdditionalInformation"),
				property: "AdditionalInformation",
				type: "string",
				width: "30"
			}, {
				label: this._oResourceBundle.getText("xlsIssueImpact"),
				property: "IssueImpact",
				type: "string",
				width: "30"
			}, {
				label: this._oResourceBundle.getText("xlsCurrentSituation"),
				property: "CurrentSituation",
				type: "string",
				width: "30"
			}, {
				label: this._oResourceBundle.getText("xlsNextSteps"),
				property: "NextSteps",
				type: "string",
				width: "30"
			}, {
				label: this._oResourceBundle.getText("xlsActionPlanTotalOfTopIssues"),
				property: "TETotOfTopI",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsActionPlanOnsiteE2EAssessment"),
				property: "TEOnsE2EAss",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsActionPlanEscalationManager"),
				property: "TEEscMan",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsActionPlanDeEscalataionArchitect"),
				property: "TEDeEscArch",
				type: "string",
				width: "20"
			}, {
				label: this._oResourceBundle.getText("xlsActionPlanTotals"),
				property: "TETotals",
				type: "string",
				width: "20"
			}];
			return aXLSConfig;
		},
		_getConfidentialTexts: function (iTextCounter) {
			var sText;
			switch (iTextCounter) {
			case 1:
				sText = this._oResourceBundle.getText("xlsAnnotationDivider");
				break;
			case 3:
				sText = this._oResourceBundle.getText("xlsAnnotation01");
				break;
			case 4:
				sText = this._oResourceBundle.getText("xlsAnnotation02");
				break;
			case 6:
				sText = this._oResourceBundle.getText("xlsAnnotationDivider");
				break;
			case 8:
				sText = this._oResourceBundle.getText("xlsAnnotation03");
				break;
			case 9:
				sText = this._oResourceBundle.getText("xlsAnnotation04");
				break;
			case 11:
				sText = this._oResourceBundle.getText("xlsAnnotationDivider");
				break;
			default:
				sText = "";
			}
			return sText;
		},
		dateDiffInDays: function (a, b, sCaseTitle) {
			if (sCaseTitle && a) {
				//Previous MCS Dashboard implementation -->  keep for reference
				// var _MS_PER_DAY = 1000 * 60 * 60 * 24;
				// // Discard the time and time-zone information.
				// var utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
				// var utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
				// return Math.floor((utc2 - utc1) / _MS_PER_DAY);

				var dDate = new Date(a);
				// get total seconds between the times
				var delta = Math.abs(new Date(b) - (dDate)) / 1000;
				// calculate (and subtract) whole days
				return Math.floor(delta / 86400);

			} else {
				return "";
			}
		},
		onRatingPress: function (oEv) {
			var sObjectType = oEv.getSource().getBindingContext("globalEscalations").getObject().RatingT;
			var sMsg = this._getRatingInfoByType(sObjectType);
			this.openInfoPopup(oEv.getSource(), sMsg);
		},

	});

});