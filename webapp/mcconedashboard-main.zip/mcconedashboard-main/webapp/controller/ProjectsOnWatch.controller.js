sap.ui.define([
	"com/sap/mcconedashboard/controller/BaseController.controller",
	"com/sap/mcconedashboard/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast"
], function (BaseController, formatter, Filter, FilterOperator, MessageToast) {
	"use strict";

	return BaseController.extend("com.sap.mcconedashboard.controller.ProjectsOnWatch", {

		formatter: formatter,

		onInit: function () {
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				iTabAll: 0,
				iTabGreen: 0,
				iTabYellow: 0,
				iTabRed: 0,
				iTabUnrated: 0,
				bLoadingState: false,
				// iTabAllPA: 0,
				// iTabGreenPA: 0,
				// iTabYellowPA: 0,
				// iTabRedPA: 0,
				// iTabUnratedPA: 0,
				iTabFiltered: 0,
				bLoadingStatePA: false,
				showObjectType: false,
				bIsMCCInternal: false
			}), "viewModel");



		},

		onAfterRendering: function () {
			if (this.getRouter().getRoute("ProjectsOnWatch")) {
				if (!this._tabBarInitialized) {
					var oTabBar = this.getView().byId("projectsOnWatchTabBar");
					if (oTabBar) {
						this._tabBarInitialized = true;
						this.getRouter().getRoute("ProjectsOnWatch").attachPatternMatched(this._onObjectMatched, this);
					}
				}
			}

			if (this.getRouter().getRoute("ProjectsOnWatchDetails")) {
				if (!this._fragmentInitialized) {
					var oTable = this.getView().byId("PoWActionPlanTable");
					if (oTable) {
						this.getRouter().getRoute("ProjectsOnWatchDetails").attachPatternMatched(this._onObjectMatchedDetails, this);
					}
				}
			}

		},

		_onObjectMatched: function (oEvent) {
			this.showInternal = false;
			this.showMCCInternal = false;
			var oTabBar = this.getView().byId("projectsOnWatchTabBar");
			var oArgs = oEvent.getParameter("arguments");
			if (oArgs["?query"] && oArgs["?query"].showInternal === "true") {
				this.showInternal = true;
				this.getView().getModel("viewModel").setProperty("/powType", "INTERNAL");
			} else if (oArgs["?query"] && oArgs["?query"].showMCCInternal === "true") {
				this.showMCCInternal = true;
				this.getView().getModel("viewModel").setProperty("/powType", "MCCINTERNAL");
				this.getView().getModel("viewModel").setProperty("/bIsMCCInternal", true);
			} else {
				this.getView().getModel("viewModel").setProperty("/powType", "EXTERNAL");
			}
				this._handleMissionRadarAndAnonymizedMode(oArgs);
				this._handleFeatureFlags(oArgs);


			//Check if data was already loaded. If yes, use this data
			if (this.getOwnerComponent().getModel("data").getProperty("/reloadProjectsOnWatch")) {
				this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(), "tableData");
				this.getOwnerComponent().getModel("data").setProperty("/reloadProjectsOnWatch", false);
				var sState = "ongoing"
				if (this.getOwnerComponent().getModel("data").getProperty("/projectsOnWatchState") === "closed") {
					sState = "closed"
					oTabBar.setSelectedKey("closed")
				} else {
					oTabBar.setSelectedKey("ongoing")
				}

				this._updateTable(sState);
			}

		},

		_updateTable: function (sState) {
			var aFilters = [];
			var oTable = this.getView().byId("table");
			var oFilterModel = this.getModel("filterModel");
			oFilterModel.refresh(true);
			var sRegion = oFilterModel.getProperty("/regionText");

			var oFilterForICP = oFilterModel.getProperty("/oFilterForProjectsOnWatch");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				aFilters.push(oFilterForICP);
			}

			/* Only apply Region Filter if there is no Country Filter set
			if (typeof sRegion !== "undefined" && sRegion !== "" && !oFilterForICP.aFilters.some(filterGroup => {
				return filterGroup.aFilters.some(subFilter => subFilter.sPath.includes("Country"));
			})) { */

			if (typeof sRegion !== "undefined" && sRegion !== "") {

				var aRegionHelp = this.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.country;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var eqFilters = regionCountryValues.map(function (country) {
					return new sap.ui.model.Filter("CustomerCountry", sap.ui.model.FilterOperator.EQ, country);
				});

				var regionFilter = new sap.ui.model.Filter({
					filters: eqFilters,
					and: false //OR
				});


				// Combine the regionFilter with filterCondition using AND conjunction
				aFilters.push(regionFilter);

			}



			if (sState === "ongoing") {
				var tileSpecificFilters = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "POWSTAT01"),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "POWSTAT02")

					], false)
				],
					true
				);
			} else {
				var tileSpecificFilters = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "POWSTAT03")
					], false)
				],
					true
				);

				//Only Showing Closed Entries for the past 4 weeks
				var pastDate = new Date();
				pastDate.setDate(pastDate.getDate() - 28);

				var closedDateFilter = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("ClosureDate", sap.ui.model.FilterOperator.GE, pastDate)
					], false)
				],
					true
				);

				aFilters.push(closedDateFilter);
			}

			aFilters.push(tileSpecificFilters);
			aFilters.push(new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "POW"));

			if (this.showInternal === true) {
				aFilters.push(new sap.ui.model.Filter("TriggeredBy", sap.ui.model.FilterOperator.EQ, "INTERNAL"));
			} else if (this.showMCCInternal === true) {
				aFilters.push(new sap.ui.model.Filter("TriggeredBy", sap.ui.model.FilterOperator.EQ, "MCCINTERNAL"));
			} else {
				aFilters.push(new sap.ui.model.Filter("TriggeredBy", sap.ui.model.FilterOperator.EQ, "EXTERNAL"));
			}

			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			oTable.setBusy(true);
			var that = this;

			oModel.read("/MCCObject", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				urlParameters: {
					"$expand": "toNotes"
				},
				success: function (data) {
					data.results.forEach(function (item) {
						item.RatingT = formatter.formatRatingToColor(item.Rating);
						item.Region = that.getRegionByCountry(item.CustomerCountry);
						item.CustomerErpNo = item.CustomerID; // Needed for Mission Radar Function

						if (item.toNotes.results.length > 0) {
							item.bHasNotes = true;
						} else {
							item.bHasNotes = false;
						}

					});
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "tableData");
					this.readMissionRadarValues(oModel, "results");
					oTable.setBusy(false);
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this),
				error: function (data) {
					oTable.setBusy(false);
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this)
			});
		},

		getRegionByCountry: function (sCountry) {
			var sRegion;
			var aRegionHelp = this.getModel("countryRegionModel").getData();
			// Find Entry in the Array, which fits the Country
			const countryEntry = aRegionHelp.RegionHelp.find(entry => entry.country === sCountry);

			if (countryEntry) {
				switch (countryEntry.region) {
					case "EMEA":
						if (countryEntry.subsubregion == "EMEA South") {
							sRegion = "EMEA South";
							break;
						}
						if (countryEntry.subsubregion == "EMEA North") {
							sRegion = "EMEA North"
							break;
						}
						if (countryEntry.subregion == "MEE") {
							sRegion = "MEE"
							break;
						}
					case "NA":
						sRegion = "NA";
						break;
					case "APJ":
						if (countryEntry.subregion == "GTC") {
							sRegion = "GTC"
							break;
						} else {
							sRegion = "APJ";
							break;
						}
					case "LAC":
						sRegion = "LAC";
						break;
					default:
						break;
				}
			}

			return sRegion;
		},

		handleProjectsOnWatchState: function (oEv) {
			var sState = oEv.getParameter("selectedKey");
			var oTable = this.getView().byId("table");

			this.getOwnerComponent().getModel("data").setProperty("/projectsOnWatchState", sState);

			// Reset all table filters
			oTable.getColumns().forEach(function (oColumn) {
				oColumn.filter(null);
				oColumn.setFilterValue("");
			});
			this.clearSearchField(oTable);

			this._updateTable(sState);
		},

		clearAllFilters: function (oEvent) {
			var oTable = oEvent.getSource().getParent().getParent();
			var aColumns = oTable.getColumns();
			oTable.getBinding().aSorters = null;

			//reset filter value for each column 

			for (var i = 0; i < aColumns.length; i++) {
				oTable.filter(aColumns[i], null);
				if (aColumns[i].getSorted()) {
					aColumns[i].setSorted(false);
				}
				aColumns[i].setFilterValue("");
				aColumns[i].setFiltered(false);
			}
			
			this.clearSearchField(oTable);

		},

		clearSearchField: function (oTable) {
			var oControl = this.getSearchField(oTable);
			if (oControl !== null) {
				oControl.setValue("");
				oControl.fireSearch();
			}
			return;
		},

		onCase: function (oEv) {
			var sProjectId = oEv.getSource().getBindingContext("tableData").getObject().ObjectID;
			this.getOwnerComponent().getModel("data").setProperty("/reload", true);
			this.getRouter().navTo("ProjectsOnWatchDetails", {
				"?query": this._getQueryParameter(),
				"ProjectId": sProjectId
			});
		},

		/*onCaseNewTab: function (oEv) {
			var sCaseId = oEv.getSource().getBindingContext("tableData").getObject().ObjectId;
			this._openCaseInNewTab(sCaseId);
		},*/

		handleStatusReportPressed: function (oEv) {
			var oData = oEv.getSource().getBindingContext("tableData").getObject();
			var sReason;
			var sWeeklyUpdates;
			var sDecisionNeeds;
			var sTarget;
			var bNoNotes = false;

			if (oData.TriggeredBy == "MCCINTERNAL") {

				for (let i = 0; i < oData.toNotes.results.length; i++) {
					const result = oData.toNotes.results[i];

					if (result.Type === "Reason for Overall Rating") {
						sReason = result;
					}
					if (result.Type === "Updates") {
						sWeeklyUpdates = result;
					}
					if (result.Type === "Decision Needs") {
						sDecisionNeeds = result;
					}
					if (result.Type === "To-Be/Target State/Objectives & expected Business Benefits") {
						sTarget = result;
					}
				}

				if (!sReason && !sWeeklyUpdates && !sDecisionNeeds && !sTarget) {
					bNoNotes = true;
				}

				this.statusReportDialog = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.StatusReportPoWInternal", this);
				this.getView().addDependent(this.statusReportDialog);
				this.statusReportDialog.setModel(new sap.ui.model.json.JSONModel({
					sReason: sReason,
					sWeeklyUpdates: sWeeklyUpdates,
					sDecisionNeeds: sDecisionNeeds,
					sTarget: sTarget,
					bNoNotes: bNoNotes
				}), "data");

			} else {

				var sLatestStatus = oData.LatestStatusText;
				var sDescription = oData.Description;

				this.statusReportDialog = sap.ui.xmlfragment("com.sap.mcconedashboard.view.fragment.StatusReportPOW", this);
				this.getView().addDependent(this.statusReportDialog);
				this.statusReportDialog.setModel(new sap.ui.model.json.JSONModel({
					sDescription: sDescription,
					sLatestStatus: sLatestStatus
				}), "data");

			}

			this.statusReportDialog.openBy(oEv.getSource());

			//this.readNotes(oEv.getSource(), sId, sObjectType);
			this.trackEvent("Status Report: show Popover");
		},

		onCustomer: function (oEv) {
			if (oEv.getSource().getBindingContext("tableData")) {
				var sCustomerErpNo = oEv.getSource().getBindingContext("tableData").getObject().CustomerID;
			} else {

				var sCustomerErpNo = this.getOwnerComponent().getModel("detailData").getData().CustomerID;
			}
			this.getOwnerComponent().getModel("customerModel").setProperty("/reloadCustomer", true);
			this.getRouter().navTo("Customer", {
				"?query": this._getQueryParameter(),
				"ErpCustNo": sCustomerErpNo
			});
		},

		onOpenUser: function (oEv) {
			if (oEv.getSource().data("userid")) {
				this.formatter.openUser(oEv, oEv.getSource().data("userid"));
			}
		},

		// Begin of Details Functions

		_onObjectMatchedDetails: function (oEvent) {
			var oArgs = oEvent.getParameter("arguments");
			this._handleMissionRadarAndAnonymizedMode(oArgs);
			this._handleFeatureFlags(oArgs);
			this.getView().byId("ObjectPageLayoutPoW").setSelectedSection(this.getView().byId("ObjectPageLayoutPoW").getSections()[0].getId());
			var sProjectId = oEvent.getParameter("arguments").ProjectId;
			this.projectId = sProjectId;
			this._checkIfPoW(sProjectId);


		},

		_checkIfPoW: function (sProjectId) {
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			var that = this;
			oModel.read("/MCCObject('" + sProjectId + "')", {
				success: function (data) {
					if (data.Type == "POW") {
						that._updateDetails(sProjectId);
						that._updateWatchItems(sProjectId);
						that._updateLinkedObjects(sProjectId);
					} else {
						MessageToast.show("Cannot find a Project on Watch under the specified ID");
					}
				},
				error: function (data) {
					MessageToast.show("Can't receive API response for this ProjectID ");

				}
			});
		},

		_updateDetails: function (sProjectId) {
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			oModel.read("/MCCObject('" + sProjectId + "')", {
				urlParameters: {
					"$expand": "toActionPlan, toAffectedProducts, toNotes"
				},
				success: function (data) {
					data.RatingT = this.formatter.formatRatingToColor(data.Rating);
					if (data.TriggeredBy == "MCCINTERNAL") {
						data.isMCCInternal = true;
					} else {
						data.isMCCInternal = false;
					}
					data.Notes = this.addCharterAndUpdates(data.toNotes.results);
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "detailData");
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this),
				error: function (data) {
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this)
			});
		},

		addCharterAndUpdates: function (aNotes) {
			var fixedHeadings = ["As-Is/Problem Statement", "To-Be/Target State/Objectives & expected Business Benefits", "Related Process(es) & targeted Improvements", "In Scope/Out of Scope", "Reason for Overall Rating", "Updates", "Decision Needs"];
			var addedHeadings = {};
			var updatedNotes = [];

			for (var i = 0; i < aNotes.length; i++) {
				var note = aNotes[i];
				// Check if Heading matches the fixedHeadings
				if (fixedHeadings.includes(note.Type) && !addedHeadings[note.Type]) {
					updatedNotes.push({
						Type: note.Type,
						Text: note.Text
					});
					addedHeadings[note.Type] = true;
				}
			}

			// Check if all fixed Headings are added
			var remainingHeadings = fixedHeadings.filter(function (heading) {
				return !addedHeadings[heading];
			});

			// Add Empty Entries for missing headings
			for (var j = 0; j < remainingHeadings.length; j++) {
				updatedNotes.push({
					Type: remainingHeadings[j],
					Text: ""
				});
			}

			// Sort based on fixed Headings
			updatedNotes.sort(function (a, b) {
				return fixedHeadings.indexOf(a.Type) - fixedHeadings.indexOf(b.Type);
			});

			return updatedNotes;
		},

		_updateWatchItems: function (sProjectId) {
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			var oFilter = new Filter("Type", FilterOperator.NE, "POWWORK");

			oModel.read("/MCCObject('" + sProjectId + "')/toIssues", {
				/*urlParameters: {
					"$expand": "toAffectedProducts"
				},*/
				filters: [oFilter],
				success: function (data) {
					/*data.results.forEach(function (issue) {
						if (issue.toAffectedProducts.results.length > 0) {
							issue.affectedProducts = issue.toAffectedProducts.results[0];
							issue.ProductText = issue.toAffectedProducts.results.map(function (product) {
								return product.ProductText;
							}).join('\n');
						} 
					}); */

					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "watchItemData");
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this),
				error: function (data) {
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "watchItemData");
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this)
			});
		},

		_updateLinkedObjects: function (sProjectId) {
			this.getView().getModel("viewModel").setProperty("/bLoadingState", true);
			var oModel = this.getOwnerComponent().getModel("subModel");
			var oFilter = new Filter("TopIssueID", FilterOperator.EQ, sProjectId);
			oModel.read("/LinkedObjects", {
				filters: [oFilter],
				success: function (data) {
					data.results.forEach(function (item) {
						if (item.ObjectType !== "5") {
							item.URL = item.ObjectID;
						}
					});
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "linkedObjects");
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this),
				error: function (data) {
					var oModel = new sap.ui.model.json.JSONModel(data);
					this.getOwnerComponent().setModel(oModel, "linkedObjects");
					this.getView().getModel("viewModel").setProperty("/bLoadingState", false);
				}.bind(this)
			});
		},

		onSectionChange: function (oEv) {
			if (oEv.getParameter("section").getTitle().includes("Action Plan")) {
				//this._updateDetails(this.projectId); Not needed since all data is initially loaded
			}
			if (oEv.getParameter("section").getTitle().includes("Watch Items")) {
				//this._updateWatchItems(this.projectId); Not needed since all data is initially loaded
			}
			if (oEv.getParameter("section").getTitle().includes("Project Details")) {

			}
		},

		handleURLPress: function (oEv) {
			if (oEv.getSource().getBindingContext("linkedObjects")) {
				var oBindingContext = oEv.getSource().getBindingContext("linkedObjects");
				var sObjectType = oBindingContext.getObject().ObjectType;
				var sUrl = oBindingContext.getObject().URL;
				var sObjectID = oBindingContext.getObject().ObjectID;
				var currentUrl = window.location.href;

				switch (sObjectType) {
					case "5": // Others
						if (!sUrl.startsWith("http")) {
							sUrl = "https://" + oBindingContext.getObject().URL + "/"
						}
						this._openWindow(sUrl);
						break;
					case "4": // ServiceNow ID
						if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") || currentUrl.includes("applicationstudio")) {
							//we are in dev envrionment
							sUrl = "https://bcdmain.wdf.sap.corp/sap/support/message/" + sObjectID;
							this._openWindow(sUrl);
						} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
							//we are in test envrionment
							sUrl = "https://qa-support.wdf.sap.corp/sap/support/message/" + sObjectID;
							this._openWindow(sUrl);
						} else {
							sUrl = "https://support.wdf.sap.corp/sap/support/message/" + sObjectID;
							this._openWindow(sUrl);
						}
						break;

					case "13": // Escalation Record ID
					case "12": // ServiceNow Incident ID
						if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") || currentUrl.includes("applicationstudio")) {
							//we are in dev envrionment
							sUrl = "https://dev.itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + sObjectID;
							this._openWindow(sUrl);
						} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
							//we are in test envrionment
							sUrl = "https://test.itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + sObjectID;
							this._openWindow(sUrl);
						} else {
							sUrl = "https://itsm.services.sap/now/nav/ui/search/97a574ea53c0130084acddeeff7b12a6/params/global-search-data-config-id/4961e3e7871033000929717936cb0ba7/search-context/now%2Fcwf%2Fagent/search-term/" + sObjectID;
							this._openWindow(sUrl);
						}
						break;

					case "1": // ICP Case
						this.getOwnerComponent().getModel("case").setProperty("/reload", true);
						this.getRouter().navTo("CaseDetails", {
							"?query": this._getQueryParameter(),
							"CaseId": sUrl
						});
						break;
					default:
						if (sUrl !== "") {
							this.getOwnerComponent().getModel("case").setProperty("/reload", true);
							this.getRouter().navTo("CaseDetails", {
								"?query": this._getQueryParameter(),
								"CaseId": sUrl
							});
						}
						break;
				}
			}
		},



	});
});