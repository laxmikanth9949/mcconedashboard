sap.ui.define([
	"sapit/controls/EmployeeDataInfoPopover",
	"sap/gantt/misc/Format"
], function (EmployeePopover, Format) {
	"use strict";

	var _globalDateFormatLong = sap.ui.core.format.DateFormat.getDateInstance({
		style: "long"
	}, new sap.ui.core.Locale("en_GB"));

	var _globalTimeFormatLong = sap.ui.core.format.DateFormat.getTimeInstance({
		pattern: "HH:mm:ss"
	});

	var _dateTimeFormatOneDateTime = function (sDateTime) {
		if (sDateTime) {
			return _globalDateFormatLong.format(sDateTime) + " " + _globalTimeFormatLong.format(sDateTime);
		}
		return "";
	};

	return {

		_formatMcciDesc: function (iVal) {
			var sDesc = "";
			if (iVal >= 0 && iVal < 20) {
				sDesc = iVal + " (low)";
			} else if (iVal >= 20 && iVal < 30) {
				sDesc = iVal + " (moderate)";
			} else if (iVal >= 30 && iVal < 40) {
				sDesc = iVal + " (increased)";
			} else if (iVal >= 40 && iVal < 50) {
				sDesc = iVal + " (high)";
			} else if (iVal >= 50 && iVal < 65) {
				sDesc = iVal + " (very high)";
			} else if (iVal >= 65 && iVal < 100) {
				sDesc = iVal + " (critical)";
			}
			return sDesc;
		},

		_roundToDecimal: function (value) {
			if (!isNaN(value)) {
				return parseFloat(value).toFixed(1); // Hier wird auf eine Nachkommastelle gerundet (1 Dezimalstelle).
			}
			return value;
		},

		_formatMcciColor: function (iVal) {
			var iVal = parseFloat(iVal);
			var sDesc = "None";
			if (iVal >= 0 && iVal < 20) {
				sDesc = "Success";
			} else if (iVal >= 20 && iVal < 30) {
				sDesc = "Warning";
			} else if (iVal >= 30 && iVal < 40) {
				sDesc = "Warning";
			} else if (iVal >= 40 && iVal < 50) {
				sDesc = "Error";
			} else if (iVal >= 50 && iVal < 65) {
				sDesc = "Error";
			} else if (iVal >= 65 && iVal < 100) {
				sDesc = "Error";
			}
			return sDesc;
		},

		_formatMcciColorCharts: function (iVal) {
			var iVal = parseFloat(iVal);
			var sDesc = "Neutral";
			if (iVal >= 0 && iVal < 20) {
				sDesc = "Good";
			} else if (iVal >= 20 && iVal < 30) {
				sDesc = "Critical";
			} else if (iVal >= 30 && iVal < 40) {
				sDesc = "Critical";
			} else if (iVal >= 40 && iVal < 50) {
				sDesc = "Critical";
			} else if (iVal >= 50 && iVal < 65) {
				sDesc = "Error";
			} else if (iVal >= 65 && iVal < 100) {
				sDesc = "Error";
			}
			return sDesc;
		},

		formatMCCINumber: function (value) {
			if (value !== -1) {
				return value;
			} else {
				return ""; // Oder null oder undefined, je nach gewünschtem Verhalten
			}
		},
		formatMCCIUnit: function (value) {
			if (value !== -1) {
				return "MCCI";
			} else {
				return "";
			}
		},

		_formatPreventionColorCharts: function (iVal) {
			var iVal = parseFloat(iVal);
			var sDesc = "Neutral";
			if (iVal >= 0 && iVal <= 100) {
				sDesc = "Good";
			} else if (iVal < 0 && iVal > -100) {
				sDesc = "Critical"; //Error
			}
			return sDesc;
		},

		_formatTrendIcon: function (iVal) {
			var iVal = parseFloat(iVal);
			var sColor = "";
			if (iVal >= -90 && iVal < -10) {
				sColor = "sap-icon://arrow-bottom";
			} else if (iVal >= -10 && iVal < -1) {
				sColor = "sap-icon://trend-down";
			} else if (iVal >= -1 && iVal < 1) {
				sColor = "sap-icon://arrow-right";
			} else if (iVal >= 1 && iVal < 10) {
				sColor = "sap-icon://trend-up";
			} else if (iVal >= 10 && iVal < 90) {
				sColor = "sap-icon://arrow-top";
			}
			return sColor;
		},

		_formatTrendColor: function (iVal) {
			var iVal = parseFloat(iVal);
			var sColor = "None";
			if (iVal >= -90 && iVal < -10) {
				sColor = "Indication04";
			} else if (iVal >= -10 && iVal < -1) {
				sColor = "Indication04";
			} else if (iVal >= -1 && iVal < 1) {
				sColor = "None";
			} else if (iVal >= 1 && iVal < 10) {
				sColor = "Warning";
			} else if (iVal >= 10 && iVal < 90) {
				sColor = "Indication02";
			}
			return sColor;
		},

		getBarColor: function (value) {
			var minValue = 0;
			var maxValue = 100;

			var colorScheme = [
				{ min: 0, max: 20, color: "#00FF00" },      // Grün
				{ min: 20, max: 30, color: "#FFFF00" },     // Helles Gelb
				{ min: 30, max: 40, color: "#FFD700" },     // Gelborange
				{ min: 40, max: 50, color: "#FFA500" },     // Orange
				{ min: 50, max: 65, color: "#FF4500" },     // Rotorange
				{ min: 65, max: 100, color: "#FF0000" }    // Rot
			];

			var defaultColor = "#00FF00";

			if (value !== undefined && value !== null) {
				for (var i = 0; i < colorScheme.length; i++) {
					if (value >= colorScheme[i].min && value <= colorScheme[i].max) {
						return colorScheme[i].color;
					}
				}
			}
			return defaultColor;
		},

		getBarColorForListItems: function (value) {

			if (value === -1) {
				return sap.ui.core.ValueState.None;
			} else {
				var colorScheme = [
					{ min: 0, max: 20, state: sap.ui.core.ValueState.Success },      // Grün
					{ min: 20, max: 30, state: sap.ui.core.ValueState.Information }, // Helles Gelb (entspricht Information)
					{ min: 30, max: 40, state: sap.ui.core.ValueState.Warning },     // Gelborange (entspricht Warning)
					{ min: 40, max: 50, state: sap.ui.core.ValueState.Warning },     // Orange (entspricht Warning)
					{ min: 50, max: 65, state: sap.ui.core.ValueState.Error },       // Rotorange (entspricht Error)
					{ min: 65, max: 100, state: sap.ui.core.ValueState.Error }       // Rot (entspricht Error)
				];

				var defaultState = sap.ui.core.ValueState.Success;

				if (value !== undefined && value !== null) {
					for (var i = 0; i < colorScheme.length; i++) {
						if (value >= colorScheme[i].min && value <= colorScheme[i].max) {
							return colorScheme[i].state;
						}
					}
				}
				return defaultState;
			}
		},

		isNotEmptyOrUndefined: function (value) {
			return value !== undefined && value !== null && value !== "";
		},

		_formatTrendDesc: function (iVal) {
			var iVal = parseFloat(iVal);
			var sDesc = "";
			if (iVal >= -90 && iVal < -10) {
				sDesc = "strong downtrend";
			} else if (iVal >= -10 && iVal < -1) {
				sDesc = "moderate downtrend";
			} else if (iVal >= -1 && iVal < 1) {
				sDesc = "neutral trend";
			} else if (iVal >= 1 && iVal < 10) {
				sDesc = "moderate uptrend";
			} else if (iVal >= 10 && iVal < 90) {
				sDesc = "strong uptrend";
			}
			return sDesc;
		},

		setNumberTableRows: function (aRows) {
			// get the width of the device screen
			var screenWidth = window.innerWidth ||
				document.documentElement.clientWidth ||
				document.body.clientWidth;

			if (screenWidth <= 768) {
				return 8;
			} else {
				return 15;
			}
		},

		formatLinkedObjectType: function (sType) {
			var sDescr = "";
			switch (sType) {
				case "1":
					sDescr = "ICP Case";
					break;
				case "2":
					sDescr = "ICP Top Issue";
					break;
				case "3":
					sDescr = "BCP ID";
					break;
				case "4":
					sDescr = "ServiceNow ID";
					break;
				case "5":
					sDescr = "Others";
					break;
				case "7":
					sDescr = "Feedback Loop Backlog";
					break;
			}
			return sDescr;
		},

		formatLinkedServiceNowObjectType: function (sID, sState, sReason) {
			var sDescr = "";
			switch (sID) {
				case "0":
					// Type 0 Status 101 / 103 ->  Reason 8 + 9 = BDM
					//					-> Reason 7 = PE
					// 					-> Reason 10 = xTec

					/*
					100 "Requested"
					101 "Escalated"
					102 "Declined"
					103 "Closed"
					104 "De-escalation Requested" */

					// Type 0 Status 100 (Requested), Reason kein Einfluss = TBE
					if (sState === "Requested") {
						sDescr = "Technical Backoffice Requests";
						break;
					} else if (sState === "Escalated" || sState === "Closed") {
						switch (sReason) {
							case "7":
								sDescr = "PE Critical Engagements";
								break;
							case "8":
								sDescr = "Business Down Situations";
								break;
							case "9":
								sDescr = "Business Down Situations";
								break;
							case "10":
								sDescr = "xTec Engagements";
								break;
						}
					}
					break;
				case "1":
					sDescr = "Unknown: " + sID;
					break;
				case "2":
					sDescr = "Critical Customer Situations";
					break;
				case "3":
					sDescr = "CIM Requests";
					break;
				case "4":
					sDescr = "Unknown: " + sID;
					break;
				case "5":
					if (sState === "Requested") {
						sDescr = "CCM Requests";
					} else if (sState === "Escalated") {
						sDescr = "CCM Engagements";
					} else if (sState === "Declined") {
						sDescr = "CCM Declined";
					} else if (sState === "Closed") {
						sDescr = "CCM Requests";
						break;
					}
				case "6":
					if (sState === "Requested") {
						sDescr = "CPC Requests";
					} else if (sState === "Escalated") {
						sDescr = "CPC Engagements";
					} else if (sState === "Declined") {
						sDescr = "CPC Declined";
					} else if (sState === "Closed") {
						sDescr = "CPC Requests";
					}
					break;
				case "7":
					sDescr = "MCC Support Requests";
					break;
				case "8":
					sDescr = "Executive Assistance";
					break;
				default:
					sDescr = "Unknown: " + sID;
			}
			return sDescr;
		},

		adaptSNRatingToGeneralRating: function (sSNRating) {
			var sGeneralRating = "";
			switch (sSNRating) {
				case "1":
					sGeneralRating = "C";
					break;
				case "2":
					sGeneralRating = "B"
					break;
				case "3":
					sGeneralRating = "A";
					break;
				default:
					sGeneralRating = "";
			}
			return sGeneralRating;
		},

		formatOutageStatus: function (value) {
			if (value || value === 0) {
				return value === 1 ? "On" : "Off";
			}
			return "";
		},

		formatOutageStatusState: function (value) {
			if (value || value === 0) {
				return value === 1 ? "Indication02" : "Indication04";
			}
			return sap.ui.core.ValueState.None;
		},

		formatOutageType: function (value) {
			if (value) {
				return value === 1 ? "Degradation" : "Disruption";
			}
			return "";
		},

		formatOutageTypeState: function (value) {
			if (value || value === 0) {
				return value === 1 ? "Indication03" : "Indication02";
			}
			return sap.ui.core.ValueState.None;
		},

		formatOutageDate: function (date) {
			if (date && date !== "0") {
				var df = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyyMMddHHmmss"
				});
				var dDate = df.parse(date);
				var sLocaleId = sap.ui.getCore().getConfiguration().getLanguage(); // "en-US" "en-GB";
				var oLocal = new sap.ui.core.Locale(sLocaleId);
				var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "MMM dd, yyyy HH:mm z",
					UTC: true
				}, oLocal);

				return dateFormat.format(dDate);
			}
			return "";

		},

		formatMaintenanceRanking: function (value) {
			if (value === "0") {
				return "";
			}
			return value;
		},

		formatEscalationState: function (state) {
			switch (state) {
				case "100":
					return "Requested";
				case "101":
					return "Escalated";
				case "102":
					return "Declined";
				case "103":
					return "Closed";
				case "104":
					return "De-escalation Requested";
			}
			return "";
		},

		getCimStatus: function (status) {
			var sStatusDesc = "";
			if (status === "1") {
				sStatusDesc = "New";
			} else if (status === "10") {
				sStatusDesc = "In progress";
			} else if (status === "18") {
				sStatusDesc = "Awaiting Info";
			} else if (status === "6") {
				sStatusDesc = "Resolved";
			} else if (status === "3") {
				sStatusDesc = "Closed";
			}
			return sStatusDesc;
		},

		getCimActionStatus: function (status) {
			var sStatusDesc = "";
			if (status === "-10") {
				sStatusDesc = "Awaiting Requester";
			} else if (status === "-20") {
				sStatusDesc = "Awaiting Incident";
			} else if (status === "-30") {
				sStatusDesc = "Awaiting Problem";
			} else if (status === "-40") {
				sStatusDesc = "Awaiting Change";
			} else if (status === "-50") {
				sStatusDesc = "In Progress by partner";
			} else if (status === "-55") {
				sStatusDesc = "In Progress by BCP";
			} else if (status === "-60") {
				sStatusDesc = "Awaiting requester by partner";
			} else if (status === "-70") {
				sStatusDesc = "Awaiting Partner";
			} else if (status === "-80") {
				sStatusDesc = "Awaiting Service Request";
			} else if (status === "-90") {
				sStatusDesc = "Pending release / hotfix";
			} else if (status === "-100") {
				sStatusDesc = "Pending Permanent Fix";
			} else if (status === "-110") {
				sStatusDesc = "Cancelled";
			} else if (status === "-120") {
				sStatusDesc = "Duplicate";
			} else if (status === "-130") {
				sStatusDesc = "Solution confirmed";
			} else if (status === "-140") {
				sStatusDesc = "Auto closure";
			}
			return sStatusDesc;
		},

		getCimPriority: function (prio) {
			var sPrioDesc = "";
			if (prio === "1") {
				sPrioDesc = "Very High";
			} else if (prio === "2") {
				sPrioDesc = "High";
			} else if (prio === "3") {
				sPrioDesc = "Medium";
			} else if (prio === "4") {
				sPrioDesc = "Low";
			}
			return sPrioDesc;
		},

		getCimEscalationStatus: function (state) {
			// 100 Requested
			// 101 Escalated
			// 102 Declined
			// 103 Closed

			var sStateDesc = "";
			if (state === "100") {
				sStateDesc = "Requested";
			} else if (state === "101") {
				sStateDesc = "Escalated";
			} else if (state === "102") {
				sStateDesc = "Declined";
			} else if (state === "103") {
				sStateDesc = "Closed";
			}
			return sStateDesc;
		},

		concatAffectedProducts: function (aProducts) {
			var sProducts = "";
			if (aProducts && aProducts.length > 0) {
				//first bring main to top
				aProducts.sort(function (x, y) {
					return x.IsMainProduct ? -1 : y.IsMainProduct ? 1 : 0;
				});
				//concat strings
				aProducts.forEach(function (product, idx) {
					sProducts += product["OfficialProductVersionName"];
					if (aProducts.length > (idx + 1)) {
						sProducts += ", ";
					}
				});
			}
			return sProducts;
		},

		parseIntToString: function (val) {
			if (val) {
				return String(val);
			}
			return "";
		},

		getTopIssueChangedText: function (changedBy, changedAt) {
			if (this.getModel("settings").getProperty("/isAnonymizedMode")) {
				changedBy = this.getModel("i18n").getResourceBundle().getText("anonymizedText");
			}
			var sDate = this.formatter.dateTimeFormatFullUTC(changedAt);
			return "Last updated by " + changedBy + " on " + sDate;
		},

		checkNote: function (aNotes) {
			if (aNotes && aNotes.results) {
				var oNotesInfo = this._getNotesInformation(aNotes.results);
				return oNotesInfo.escalationReason !== "-" || oNotesInfo.executiveSummary !== "-";
			}
			return false;
		},

		checkNoteForIssue: function (aNotes) {
			var bVisible = false;
			if (aNotes && aNotes.results) {
				aNotes.results.forEach(function (note) {
					if (note.NoteType === "A001" || note.NoteType === "ZMM2") {
						bVisible = true;
					}
				});
			}
			return bVisible;
		},

		formatTextWithoutTags: function (value) {
			var tempElement = document.createElement("div");
			tempElement.innerHTML = value;

			var paragraphs = tempElement.getElementsByTagName("p");
			var formattedText = "";

			for (var i = 0; i < paragraphs.length; i++) {
				var paragraph = paragraphs[i];
				var paragraphText = paragraph.innerHTML.replace(/<\/?[^>]+(>|$)/g, '').trim();
				formattedText += paragraphText;

				if (i < paragraphs.length - 1) {
					formattedText += "\n\n";
				}
			}

			return formattedText;
		},

		removeHTMLTags: function (value) {
			var tempElement = document.createElement("div");
			tempElement.innerHTML = value;

			// Extract pure text out of HTML Element
			var textContent = tempElement.textContent || tempElement.innerText || "";

			// Remove Spaces and line breaks
			textContent = textContent.trim().replace(/\s+/g, " ");

			return textContent;
		},

		formatHTML: function (html) {

			if (html) {
				return `<div>${html}</div>`;
			} else {
				return "";
			}
		},

		formatString: function (sValue) {
			var that = this;

			function replaceStr(str) {
				if (str.startsWith("\r\n\r\n")) {
					str = str.replaceAll("\r\n\r\n", "\n");
				}
				if (str.startsWith("\r\n***")) {
					str = str.replace("\r\n***", "\n***");
				}
				if (str.startsWith("\r\n+++")) {
					str = str.replace("\r\n+++", "\n+++");
				}
				if (str.startsWith("\r\n")) {
					str = str.replace("\r\n", "");
				}
				if (str.endsWith("\r\n\r\n")) {
					str = str.replace("\r\n\r\n", "\n");
				}
				var res = str.split(/\n\*\.\*\n|\*\.\*|\n\+\.\+\n|\+\.\+/);
				that.openTags = [];

				function myFunction(value, index, array) {
					var length = that.openTags.length;
					var li = "</li><li>";
					if (value.indexOf("<") > -1) {
						value = value.replace(/</g, "&lt;");
					}
					if (value.indexOf(">") > -1) {
						value = value.replace(/>/g, "&gt;");
					}
					if (value.indexOf("\n+++") > -1) {
						value = value.replace(/\n\+\.\+/g, "</li></ol>\n");
						if (value.indexOf("\n+++++") > -1) value = value.replace("\n+++++", "<ol><li>").replace(/\n\+\+\+\+\+/g, li);
						if (value.indexOf("\n++++") > -1 && length >= 2 && that.openTags[1][0] === "<ol") value = value.replace(/\n\+\+\+\+/g, li);
						else if (value.indexOf("\n++++") > -1) value = value.replace("\n++++", "<ol><li>").replace(/\n\+\+\+\+/g, li);
						if (value.indexOf("\n+++") > -1 && length >= 1 && that.openTags[0][0] === "<ol") value = value.replace(/\n\+\+\+/g, li);
						else if (value.indexOf("\n+++") > -1) value = value.replace("\n+++", "<ol><li>").replace(/\n\+\+\+/g, li);
					} else if (value.indexOf("+++") > -1) {
						value = value.replace(/\+\.\+/g, "</li></ol>\n");
						if (value.indexOf("+++++") > -1) value = value.replace("+++++", "<ol><li>").replace(/\+\+\+\+\+/g, li);
						if (value.indexOf("++++") > -1 && length >= 2 && that.openTags[1][0] === "<ol") value = value.replace(/\+\+\+\+/g, li);
						else if (value.indexOf("++++") > -1) value = value.replace("++++", "<ol><li>").replace(/\+\+\+\+/g, li);
						if (value.indexOf("+++") > -1 && length >= 1 && that.openTags[0][0] === "<ol") value = value.replace(/\+\+\+/g, li);
						else if (value.indexOf("+++") > -1) value = value.replace("+++", "<ol><li>").replace(/\+\+\+/g, li);
					}
					if (value.indexOf("\n***") > -1) {
						value = value.replace(/\n\*\.\*/g, "</li></ul>\n");
						if (value.indexOf("\n*****") > -1) value = value.replace("\n*****", "<ul><li>").replace(/\n\*\*\*\*\*/g, li);
						if (value.indexOf("\n****") > -1 && length >= 2 && that.openTags[1][0] === "<ul") value = value.replace(/\n\*\*\*\*/g, li);
						else if (value.indexOf("\n****") > -1) value = value.replace("\n****", "<ul><li>").replace(/\n\*\*\*\*/g, li);
						if (value.indexOf("\n***") > -1 && length >= 1 && that.openTags[0][0] === "<ul") value = value.replace(/\n\*\*\*/g, li);
						else if (value.indexOf("\n***") > -1) value = value.replace("\n***", "<ul><li>").replace(/\n\*\*\*/g, li);
					} else if (value.indexOf("***") > -1) {
						value = value.replace(/\*\.\*/g, "</li></ul>\n");
						if (value.indexOf("*****") > -1) value = value.replace("*****", "<ul><li>").replace(/\*\*\*\*\*/g, li);
						if (value.indexOf("****") > -1 && length >= 2 && that.openTags[1][0] === "<ul") value = value.replace(/\*\*\*\*/g, li);
						else if (value.indexOf("****") > -1) value = value.replace("****", "<ul><li>").replace(/\*\*\*\*/g, li);
						if (value.indexOf("***") > -1 && length >= 1 && that.openTags[0][0] === "<ul") value = value.replace(/\*\*\*/g, li);
						else if (value.indexOf("***") > -1) value = value.replace("***", "<ul><li>").replace(/\*\*\*/g, li);
					}

					var closeTag = "";
					var bFirstStr = false;
					if (length > 0) {
						if (that.openTags[length - 1][0] === "<ul") closeTag = "</li></ul>";
						if (that.openTags[length - 1][0] === "<ol") closeTag = "</li></ol>";
						that.openTags.splice(length - 1, 1); // cut the last one which will be closed by the close Tag
					} else bFirstStr = true;
					var regex = /<ol|<ul/g,
						current;
					while ((current = regex.exec(value)) != null) {
						that.openTags.push(current);
					}
					if (bFirstStr === true && that.openTags.length > 0) {
						if (that.openTags[that.openTags.length - 1][0] === "<ul") closeTag = "</li></ul>";
						if (that.openTags[that.openTags.length - 1][0] === "<ol") closeTag = "</li></ol>";
						that.openTags.splice(that.openTags.length - 1, 1); // cut the last one which will be closed by the close Tag
					}
					value = value.replace(/\r/g, "");
					return value.replace(/\n/g, "<br/>") + closeTag;
				}

				var formattedStringArray = res.map(myFunction);

				function addEndTags(value, index, array) {
					var changedValue = value;
					if (value.substring(value.length - 5, value.length) === "<br/>") {
						value = value.substring(0, value.length - 5);
					}
					return changedValue;
				}

				var finalStringArray = formattedStringArray.map(addEndTags);
				var note = finalStringArray.join("").replace(/<br\/><br\/><ul/g, "<br/><ul").replace(/<br\/><br\/><ol/g, "<br/><ol").replace(
					/<\/ul><br\/>/g, "</ul>").replace(/<\/ol><br\/>/g, "</ol>");

				return note;
			}
			if (sValue && sValue !== "") {
				return replaceStr(sValue);
			}
			return "";
		},

		openUser: function (oEv, userid) {
			var oPopover = new EmployeePopover({
				userId: userid,
				mode: "full"
			});
			oPopover.openBy(oEv.getSource());
		},

		openEmplRespUser: function (oEv) {
			var oData = oEv.getSource().getBindingContext("customerModel").getModel().getProperty(oEv.getSource().getBindingContext(
				"customerModel").getPath());
			var sEmployeeId = "";
			if (oData.ObjectId.startsWith("100")) {
				sEmployeeId = oData.ResponsibleId;
			} else if (oData.ObjectId.startsWith("20")) {
				sEmployeeId = oData.ResponsibleId;
			} else if (oData.objectType === "Cross Issue") {
				sEmployeeId = oData.ResponsibleId;
			} else if (oData.ObjectId.startsWith("ESC")) {
				sEmployeeId = oData["assigned_to.employee_number"]
			} else {
				sEmployeeId = oData.EmplRespUser;
			}
			var oPopover = new EmployeePopover({
				userId: sEmployeeId,
				mode: "full"
			});

			oPopover.openBy(oEv.getSource());
		},

		openEmplRespUserGE: function (oEv) {
			var oData = oEv.getSource().getBindingContext("globalEscalations").getModel().getProperty(oEv.getSource().getBindingContext(
				"globalEscalations").getPath());

			var sEmployeeId = oData.ResponsibleId;
			var oPopover = new EmployeePopover({
				userId: sEmployeeId,
				mode: "full"
			});

			oPopover.openBy(oEv.getSource());
		},
		openProcessorGE: function (oEv) {
			var oData = oEv.getSource().getBindingContext("globalEscalations").getModel().getProperty(oEv.getSource().getBindingContext(
				"globalEscalations").getPath());

			var sEmployeeId = oData.ProcessorId;
			var oPopover = new EmployeePopover({
				userId: sEmployeeId,
				mode: "full"
			});

			oPopover.openBy(oEv.getSource());
		},

		openEmplRespUserSolution: function (oEv) {
			var oData = oEv.getSource().getBindingContext("solutionModel").getModel().getProperty(oEv.getSource().getBindingContext(
				"solutionModel").getPath());
			var sEmployeeId = "";
			if (oData.ObjectId.startsWith("100")) {
				sEmployeeId = oData.ResponsibleId;
			} else if (oData.ObjectId.startsWith("20")) {
				sEmployeeId = oData.ResponsibleId;
			} else if (oData.objectType === "Cross Issue") {
				sEmployeeId = oData.ResponsibleId;
			} else if (oData.objectType === "Critical Event Coverages") {
				sEmployeeId = oData.ResponsibleID;
			} else {
				sEmployeeId = oData.EmplRespUser;
			}
			var oPopover = new EmployeePopover({
				userId: sEmployeeId,
				mode: "full"
			});

			oPopover.openBy(oEv.getSource());
		},

		openEmplRespUserCCM: function (oEv) {
			var oData = oEv.getSource().getBindingContext("data").getModel().getProperty(oEv.getSource().getBindingContext(
				"data").getPath());
			var sEmployeeId = oData.ResponsibleId;
			var oPopover = new EmployeePopover({
				endpoint: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/sapit-employee-data",
				userId: sEmployeeId,
				mode: "full"
			});

			oPopover.openBy(oEv.getSource());
		},

		openEmplRespUserTaskForces: function (oEv) {
			var oData = oEv.getSource().getBindingContext("tableData").getModel().getProperty(oEv.getSource().getBindingContext(
				"tableData").getPath());
			var sEmployeeId = oData.ResponsibleId;
			var oPopover = new EmployeePopover({
				userId: sEmployeeId,
				mode: "full"
			});

			oPopover.openBy(oEv.getSource());
		},

		openEmplRespUserCim: function (oEv) {
			var oData = oEv.getSource().getBindingContext("data").getObject();

			var sEmployeeId = oData["assigned_to.employee_number"];

			var oPopover = new EmployeePopover({
				userId: sEmployeeId,
				mode: "full"
			});

			oPopover.openBy(oEv.getSource());
		},

		formatDropdownValue: function (oValue, aValues, name) {
			/*for (var i = 0; i < aValues.length; i++) {
				if ((aValues[i].DropdownID === oValue || (aValues[i].DropdownKey === oValue && aValues[i].DropdownKey !== null)) && name === aValues[
					i].DropdownName) {
					value = aValues[i].DropdownValue;
				}
			}*/
			if (oValue) {
				var oStatus = aValues.find(function (val) {
					return val.DropdownKey === oValue;
				});
				if (oStatus) {
					return oStatus.DropdownValue;
				}

			}
			return "";

		},

		formatCECStatus: function (sStatus) {

			switch (sStatus) {
				case "CECSTAT01":
					return "Planned";
					break;
				case "CECSTAT02":
					return "New";
					break;
				case "CECSTAT03":
					return "In progress";
					break;
				case "CECSTAT04":
					return "Patch planned";
					break;
				case "CECSTAT05":
					return "Patch verified";
					break;
				case "CECSTAT06":
					return "Not relevant";
					break;
				case "CECSTAT07":
					return "Duplicate";
					break;
				case "CECSTAT08":
					return "Won't fix";
					break;
				case "CECSTAT09":
					return "Solution provided";
					break;
				case "CECSTAT10":
					return "Solution confirmed";
					break;
				case "CECSTAT11":
					return "Closed";
					break;
				case "CECSTAT12":
					return "In progress requestor";
					break;

			}
		},

		formatNoteToHTML: function (str) {
			var res = str.split(/\n\*\.\*\n|\*\.\*|\n\+\.\+\n|\+\.\+/);
			this.openTags = [];
			var that = this;

			function myFunction(value, index, array) {
				var length = that.openTags.length;
				var li = "</li><li>";
				if (value.indexOf("<") > -1) {
					value = value.replace(/</g, "&lt;");
				}
				if (value.indexOf(">") > -1) {
					value = value.replace(/>/g, "&gt;");
				}
				if (value.indexOf("\n+++") > -1) {
					value = value.replace(/\n\+\.\+/g, "</li></ol>\n");
					if (value.indexOf("\n+++++") > -1) value = value.replace("\n+++++", "<ol><li>").replace(/\n\+\+\+\+\+/g, li);
					if (value.indexOf("\n++++") > -1 && length >= 2 && that.openTags[1][0] === "<ol") value = value.replace(/\n\+\+\+\+/g, li);
					else if (value.indexOf("\n++++") > -1) value = value.replace("\n++++", "<ol><li>").replace(/\n\+\+\+\+/g, li);
					if (value.indexOf("\n+++") > -1 && length >= 1 && that.openTags[0][0] === "<ol") value = value.replace(/\n\+\+\+/g, li);
					else if (value.indexOf("\n+++") > -1) value = value.replace("\n+++", "<ol><li>").replace(/\n\+\+\+/g, li);
				} else if (value.indexOf("+++") > -1) {
					value = value.replace(/\+\.\+/g, "</li></ol>\n");
					if (value.indexOf("+++++") > -1) value = value.replace("+++++", "<ol><li>").replace(/\+\+\+\+\+/g, li);
					if (value.indexOf("++++") > -1 && length >= 2 && that.openTags[1][0] === "<ol") value = value.replace(/\+\+\+\+/g, li);
					else if (value.indexOf("++++") > -1) value = value.replace("++++", "<ol><li>").replace(/\+\+\+\+/g, li);
					if (value.indexOf("+++") > -1 && length >= 1 && that.openTags[0][0] === "<ol") value = value.replace(/\+\+\+/g, li);
					else if (value.indexOf("+++") > -1) value = value.replace("+++", "<ol><li>").replace(/\+\+\+/g, li);
				}
				if (value.indexOf("\n***") > -1) {
					value = value.replace(/\n\*\.\*/g, "</li></ul>\n");
					if (value.indexOf("\n*****") > -1) value = value.replace("\n*****", "<ul><li>").replace(/\n\*\*\*\*\*/g, li);
					if (value.indexOf("\n****") > -1 && length >= 2 && that.openTags[1][0] === "<ul") value = value.replace(/\n\*\*\*\*/g, li);
					else if (value.indexOf("\n****") > -1) value = value.replace("\n****", "<ul><li>").replace(/\n\*\*\*\*/g, li);
					if (value.indexOf("\n***") > -1 && length >= 1 && that.openTags[0][0] === "<ul") value = value.replace(/\n\*\*\*/g, li);
					else if (value.indexOf("\n***") > -1) value = value.replace("\n***", "<ul><li>").replace(/\n\*\*\*/g, li);
				} else if (value.indexOf("***") > -1) {
					value = value.replace(/\*\.\*/g, "</li></ul>\n");
					if (value.indexOf("*****") > -1) value = value.replace("*****", "<ul><li>").replace(/\*\*\*\*\*/g, li);
					if (value.indexOf("****") > -1 && length >= 2 && that.openTags[1][0] === "<ul") value = value.replace(/\*\*\*\*/g, li);
					else if (value.indexOf("****") > -1) value = value.replace("****", "<ul><li>").replace(/\*\*\*\*/g, li);
					if (value.indexOf("***") > -1 && length >= 1 && that.openTags[0][0] === "<ul") value = value.replace(/\*\*\*/g, li);
					else if (value.indexOf("***") > -1) value = value.replace("***", "<ul><li>").replace(/\*\*\*/g, li);
				}

				var closeTag = "";
				var bFirstStr = false;
				if (length > 0) {
					if (that.openTags[length - 1][0] === "<ul") closeTag = "</li></ul>";
					if (that.openTags[length - 1][0] === "<ol") closeTag = "</li></ol>";
					that.openTags.splice(length - 1, 1); // cut the last one which will be closed by the close Tag
				} else bFirstStr = true;
				var regex = /<ol|<ul/g,
					current;
				while ((current = regex.exec(value)) != null) {
					that.openTags.push(current);
				}
				if (bFirstStr === true && that.openTags.length > 0) {
					if (that.openTags[that.openTags.length - 1][0] === "<ul") closeTag = "</li></ul>";
					if (that.openTags[that.openTags.length - 1][0] === "<ol") closeTag = "</li></ol>";
					that.openTags.splice(that.openTags.length - 1, 1); // cut the last one which will be closed by the close Tag
				}
				value = value.replace(/\r/g, "");
				return value.replace(/\n/g, "<br/>") + closeTag;
			}

			var formattedStringArray = res.map(myFunction);

			function addEndTags(value, index, array) {
				var changedValue = value;
				if (value.substring(value.length - 5, value.length) === "<br/>") {
					value = value.substring(0, value.length - 5);
				}
				return changedValue;
			}

			var finalStringArray = formattedStringArray.map(addEndTags);
			var note = finalStringArray.join("")
				.replace(/<br\/><br\/><ul/g, "<br/><ul").replace(/<br\/><br\/><ol/g, "<br/><ol")
				.replace(/<\/ul><br\/>/g, "</ul>").replace(/<\/ol><br\/>/g, "</ol>")
				.replace(/<br\/><br\/><\/li/g, "</li").replace(/<br\/><\/li/g, "</li")
				.replace(/"/g, "&quot;");

			return note;
		},

		openEmplRespUserLinkedObjects: function (oEv) {
			var oBindingContext = oEv.getSource().getBindingContext("linkedObjects");
			var oData = oBindingContext.getObject();
			var sEmployeeId = oData["MCCResponsibleID"];
			var oPopover = new EmployeePopover({
				userId: sEmployeeId,
				mode: "full"
			});
			oPopover.openBy(oEv.getSource());
		},

		openEmplRespUserHighPrio: function (oEv) {
			var oBindingContext = oEv.getSource().getBindingContext("data") || oEv.getSource().getBindingContext("customerModel");
			var oData = oBindingContext.getObject();
			var sEmployeeId = oData["assigned_to.employee_number"];
			var oPopover = new EmployeePopover({
				userId: sEmployeeId,
				mode: "full"
			});
			oPopover.openBy(oEv.getSource());
		},

		openProcessorId: function (oEv) {
			var oData = oEv.getSource().getBindingInfo("text").binding.getContext().getObject();
			var sProcessorId = "";
			if (oData.IncidentId && oData.IncidentId.startsWith("002")) {
				sProcessorId = oData.Processor;
			} else {
				sProcessorId = oData.ProcessorId;
			}

			var oPopover = new EmployeePopover({
				userId: sProcessorId,
				mode: "full"
			});

			oPopover.openBy(oEv.getSource());
		},

		openProcessorIdSolution: function (oEv) {
			var oData = oEv.getSource().getBindingContext("solutionModel").getModel().getProperty(oEv.getSource().getBindingContext(
				"solutionModel").getPath());
			var sProcessorId = "";
			if (oData.IncidentId && oData.IncidentId.startsWith("002")) {
				sProcessorId = oData.Processor;
			} else {
				sProcessorId = oData.ProcessorId;
			}
			var oPopover = new EmployeePopover({
				userId: sProcessorId,
				mode: "full"
			});

			oPopover.openBy(oEv.getSource());
		},

		openProcessorIdCim: function (oEv) {
			var oBindingContext = oEv.getSource().getBindingContext("data") || oEv.getSource().getBindingContext("customerModel");
			var oData = oBindingContext.getObject();

			var sProcessorId = oData["assigned_to.employee_number"];

			var oPopover = new EmployeePopover({
				userId: sProcessorId,
				mode: "full"
			});

			oPopover.openBy(oEv.getSource());
		},

		openRequestorIdCim: function (oEv) {
			var oBindingContext = oEv.getSource().getBindingContext("data") || oEv.getSource().getBindingContext("customerModel");
			var oData = oBindingContext.getObject();
			var sProcessorId = oData["requested_by.employee_number"];
			//var sProcessorId = oEv.getSource().getText();

			var oPopover = new EmployeePopover({
				userId: sProcessorId,
				mode: "full"
			});

			oPopover.openBy(oEv.getSource());
		},

		openRequestorIdCimSolution: function (oEv) {
			var oData = oEv.getSource().getBindingContext("solutionModel").getObject();
			var sProcessorId = oData["RequestorId"];

			var oPopover = new EmployeePopover({
				userId: sProcessorId,
				mode: "full"
			});

			oPopover.openBy(oEv.getSource());
		},

		openRequestorIdCimCustomer: function (oEv) {
			var oData = oEv.getSource().getBindingContext("customerModel").getObject();
			var sProcessorId = oData["RequestorId"];

			var oPopover = new EmployeePopover({
				userId: sProcessorId,
				mode: "full"
			});

			oPopover.openBy(oEv.getSource());
		},

		concatProducts: function (aProducts, property) {
			var sProducts = "";
			var sProperty = property || "ProductVersionT";
			if (aProducts && aProducts.length > 0) {
				//first bring main to top
				aProducts.sort(function (x, y) {
					return x.Main === "X" ? -1 : y.Main === "X" ? 1 : 0;
				});
				//concat strings
				aProducts.forEach(function (product, idx) {
					sProducts += product[sProperty] !== "" ? product[sProperty] : "-";
					if (aProducts.length > (idx + 1)) {
						sProducts += ", ";
					}
				});
			}
			return sProducts;
		},

		concatProductsWithBoldedMain: function (aProducts, property) {
			var sProducts = "";
			var sProperty = property || "ProductVersionT";
			if (aProducts && aProducts.length > 0) {
				//first bring main to top
				aProducts.sort(function (x, y) {
					return x.Main === "X" ? -1 : y.Main === "X" ? 1 : 0;
				});
				//concat strings
				aProducts.forEach(function (product, idx) {

					//bold if main product
					if (product.Main === "X") {
						sProducts += product[sProperty] !== "" ? "<strong>" + product[sProperty] + "</strong>" : "-";
					} else {
						sProducts += product[sProperty] !== "" ? product[sProperty] : "-";
					}

					if (aProducts.length > (idx + 1)) {
						sProducts += ", ";
					}
				});
			}
			return sProducts;
		},

		getMainProduct: function (products) {
			var sMainProduct = "";
			if (products) {
				products.forEach(function (product) {
					if (product.Main === "X") {
						sMainProduct = product.ProductVersionT;
					}
				}.bind(this));
			}
			return sMainProduct;
		},

		stringToInt: function (value) {
			return parseInt(value);
		},

		getAffectedProducts: function (aProducts, property) {
			var sProducts = "";
			var sProperty = property || "ProductVersionT";
			if (aProducts && aProducts.length > 0) {
				//first bring main to top
				aProducts.sort(function (x, y) {
					return x.Main === "X" ? -1 : y.Main === "X" ? 1 : 0;
				});
				//concat strings
				aProducts.forEach(function (product, idx) {
					//bold if main product
					if (product.Main !== "X") {
						sProducts += product[sProperty] !== "" ? product[sProperty] : "-";
						if (aProducts.length > (idx + 1)) {
							sProducts += ", ";
						}
					}

				});
			}
			return sProducts;
		},
		/**
		 * format date object
		 */
		getDuration: function (createDate, endDate, status) {
			if (createDate) {
				var timeDifferece;
				if (status === "Closed") {
					//timeDifferece = endDate.getTime() - createDate.getTime();
					//return Math.round(timeDifferece / (1000 * 3600 * 24), 0);
					var delta = Math.abs(endDate - (createDate)) / 1000;
					// calculate (and subtract) whole days
					return Math.floor(delta / 86400);
				} else {
					// var today = new Date();
					// timeDifferece = today.getTime() - createDate.getTime();
					// return Math.round(timeDifferece / (1000 * 3600 * 24), 0);
					// get total seconds between the times
					var delta = Math.abs(new Date() - (createDate)) / 1000;
					// calculate (and subtract) whole days
					return Math.floor(delta / 86400);
				}
			}
			return 0;
		},

		getWeekDaysDuration: function (createDate, endDate, status) {
			if (createDate) {
				var workDays = 0;
				var currentDate = new Date(createDate);
				var end;
				if (status === "closed") {
					end = new Date(endDate);
				} else {
					end = new Date();
				}

				// If endDate is before createDate, swap the dates
				if (currentDate > end) {
					var temp = end;
					end = currentDate;
					currentDate = temp;
				}

				// Loop through each day between createDate and endDate
				while (currentDate <= end) {
					// If the current day is a workday (not Sat or Sun), increment workDays
					if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) {
						workDays++;
					}
					currentDate.setDate(currentDate.getDate() + 1);
				}
				return workDays;
			}
			return 0;
		},

		dateFormatFullUTC: function (oDate) {
			if (!oDate) {
				return "";
			}

			if (typeof oDate === "string" || oDate instanceof String) {
				oDate = new Date(oDate.replace(
					/^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/,
					'$4:$5:$6 $2/$3/$1'
				));
			}

			var sLocaleId = sap.ui.getCore().getConfiguration().getLanguage(); // "en-US" "en-GB";

			var oLocal = new sap.ui.core.Locale(sLocaleId);

			var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "MMM dd, yyyy",
				UTC: true
			}, oLocal);

			return dateFormat.format(oDate);
		},

		dateTimeFormatFullUTC: function (oDate) {
			if (!oDate) {
				return "";
			}
			// var soDate= oDate;
			if (typeof oDate === "string" || oDate instanceof String) {
				//in this case we can assume, that the data is coming from ServiceNow
				//the data is already returned as UTC/GTM and therefore we should create the date in Time Zone GMT
				oDate = new Date(oDate.replace(
					/^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/,
					'$4:$5:$6 $2/$3/$1'
				) + "Z"); // Z is needed in order to be interpreted as UTC

				// var now_utc = Date.UTC(tempDate.getUTCFullYear(), tempDate.getUTCMonth(), tempDate.getUTCDate(),
				// 	tempDate.getUTCHours(), tempDate.getUTCMinutes(), tempDate.getUTCSeconds());

				//oDate= new Date(now_utc);
			}

			var sLocaleId = sap.ui.getCore().getConfiguration().getLanguage(); // "en-US" "en-GB";

			var oLocal = new sap.ui.core.Locale(sLocaleId);

			// var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
			// 	pattern: "MMM dd, yyyy HH:mm z"
			// }, oLocal);
			// dateFormat.format(oDate);

			var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "MMM dd, yyyy HH:mm z",
				UTC: true
			}, oLocal);

			return dateFormat.format(oDate);
		},

		formatDurationToDaysHoursMinutes: function (durationInHours) {
			let durationString = "";
			const days = Math.floor(durationInHours / 24);
			const hours = Math.floor(durationInHours % 24);
			const minutes = Math.floor((durationInHours * 60) % 60);

			if (days > 0) {
				durationString += `${days} day${days > 1 ? "s" : ""} `;
			}

			if (hours > 0) {
				durationString += `${hours} hour${hours > 1 ? "s" : ""} `;
			}

			if (days === 0 && hours === 0) {
				durationString += `${minutes} minute${minutes > 1 ? "s" : ""} `;
			}

			return durationString.trim();
		},

		closingDateTimeFormatFullUTC: function (oDate, sStatus) {
			if (!oDate) {
				return "";
			}
			if (sStatus !== "Closed") {
				return "";
			}
			if (typeof oDate === "string" || oDate instanceof String) {
				oDate = new Date(oDate.replace(
					/^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/,
					'$4:$5:$6 $2/$3/$1'
				));
			}

			var sLocaleId = sap.ui.getCore().getConfiguration().getLanguage(); // "en-US" "en-GB";

			var oLocal = new sap.ui.core.Locale(sLocaleId);

			var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "MMM dd, yyyy HH:mm z",
				UTC: true
			}, oLocal);

			return dateFormat.format(oDate);
		},


		//Caution: Sometimes there is an Error when Date = 2023-12-31 -> Formatter will show Dec 31, 2024
		formatDateShort: function (oDate) {
			if (oDate !== null && oDate !== "" && oDate !== undefined) {
				oDate = new Date(oDate);
				oDate = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MMM dd, yyyy",
					style: "long"
				}).format(oDate);
			}
			return oDate;
		},

		fnTimeConverter: function (sTimestamp) {
			return sap.gantt.misc.Format.abapTimestampToDate(sTimestamp);
		},

		formatSuggestionItemBtn: function (sKey) {
			var aUserFavorites = this.getModel("favoriteModel").getProperty("/tiles");

			var aTmp = aUserFavorites.filter(function (val) {
				return val.ErpCustNo === sKey;
			});

			if (aTmp.length === 0) {
				return "sap-icon://add-favorite";
			} else {
				return "sap-icon://unfavorite";
			}
		},

		formatSuggestionItemBtnTooltip: function (sKey) {
			var aUserFavorites = this.getModel("favoriteModel").getProperty("/tiles");

			var aTmp = aUserFavorites.filter(function (val) {
				return val.ErpCustNo === sKey;
			});

			if (aTmp.length === 0) {
				return this.getResourceBundle().getText("addToFav");
			} else {
				return this.getResourceBundle().getText("removeFromFav");
			}

		},

		checkUrl: function (sUrl) {
			if (sUrl) {
				sUrl = sUrl.toLowerCase();
				//regex to match either 'http://' or 'https://' 
				if (!/^(?:http(s)?:\/\/)/.test(sUrl)) {
					//if sUrl does not contain http protocol add it to the string
					sUrl = "http://" + sUrl;
				}
				return sUrl;
			}
			return "";
		},

		formatRegion: function (sRegion) {
			return sRegion ? sRegion : "World";
		},

		getCustomerTicket: function (sBCPId, sSNOWId) {
			function formatIncidentId(id) {
				if (id) {
					var year = id.substring(id.length - 4);
					var ID = parseInt(id.substring(10, id.length - 4));
					return ID + "/" + year;
				} else {
					return "";
				}
			}
			if (sBCPId && sBCPId !== "000000000000000000000000" && sBCPId !== "") {
				var sBcpIdFormatted = formatIncidentId(sBCPId);
				return sBcpIdFormatted;
			} else if (sSNOWId && sSNOWId !== "000000000000000000000000" && sSNOWId !== "") {
				var sSnowIdFormatted = formatIncidentId(sSNOWId);
				return sSnowIdFormatted;
			} else {
				return "";
			}
		},

		formatBcpIncidentId: function (id) {
			if (id && id !== "000000000000000000000000") {
				var year = id.substring(id.length - 4);
				var key = parseInt(id.substring(10, id.length - 4));
				return key + "/" + year;
			}
			return "";
		},

		formatBcpIncidentUrl: function (id) {
			var currentUrl = window.location.href,
				url = "";
			if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard")) {
				//we are in DEV environment
				url = "https://" + "bcdmain.wdf.sap.corp/sap/support/message/" + id; //e.g. https://bcdmain.wdf.sap.corp/sap/support/message/002028376700009419642026
			} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
				//we are in TEST environment
				url = "https://" + "qa-support.wdf.sap.corp/sap/support/message/" + id; //e.g. https://qa-support.wdf.sap.corp/sap/support/message/00207512940000767452019
			} else {
				url = "https://" + "support.wdf.sap.corp/sap/support/message/" + id;
			}
			return url;
		},

		formatServiceNowCaseUrl: function (sID) {
			var currentUrl = window.location.href,
				url = "";
			if (sID && sID !== "") {
				if (sID.includes("CS") || sID.includes("ESC") || sID.includes("INC")) {
					if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard")) {
						//we are in test envrionment
						//url = "https://dev.itsm.services.sap/now/cwf/agent/record/sn_customerservice_case/" + sID;
						url = "https://dev.itsm.services.sap/number_redirect.do?sysparm_number=" + sID;
					} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
						//we are in test envrionment
						//url = "https://test.itsm.services.sap/now/cwf/agent/record/sn_customerservice_case/" + sID;
						url = "https://test.itsm.services.sap/number_redirect.do?sysparm_number=" + sID;
					} else {
						//url = "https://itsm.services.sap/now/cwf/agent/record/sn_customerservice_case/" + sID;
						url = "https://itsm.services.sap/number_redirect.do?sysparm_number=" + sID;
					}
				} else {
					//We got the NOW GUID, use normal method
					if (currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") || currentUrl.includes("eu10.applicationstudio")) {
						//we are in dev envrionment
						url = "https://dev.itsm.services.sap/now/cwf/agent/record/sn_customerservice_case/" + sID;
					} else if (currentUrl.includes("sapitcloudt") || currentUrl.includes("test-kinkajou")) {
						//we are in test envrionment
						url = "https://test.itsm.services.sap/now/cwf/agent/record/sn_customerservice_case/" + sID;
					} else {
						url = "https://itsm.services.sap/now/cwf/agent/record/sn_customerservice_case/" + sID;
					}

				}
			}
			return url;
		},

		// notNeededAnymore_getCustomerTicketFormatted: function (sID, sType) {
		// 	function formatIncidentId(id) {
		// 		if (id) {
		// 			var year = id.substring(id.length - 4);
		// 			var ID = parseInt(id.substring(10, id.length - 4));
		// 			return ID + "/" + year;
		// 		} else {
		// 			return "";
		// 		}
		// 	}
		// 	if (sType && sType.startsWith("PE Critical") && sID && sID !== "000000000000000000000000" && sID !== "") {
		// 		var sBcpIdFormatted = formatIncidentId(sID);
		// 		return sBcpIdFormatted;
		// 	} else {
		// 		return sID;
		// 	}
		// },

		/**
		 * format for a simple date
		 */
		dateFormatOneDate: function (sDateValue) {
			if (sDateValue) {
				return _globalDateFormatLong.format(sDateValue);
			}
			return "";
		},
		/**
		 * format for a simple date
		 */
		dateFormatOneTime: function (sDateValue) {
			if (sDateValue) {
				return _globalTimeFormatLong.format(sDateValue);
			}
			return "";
		},

		/**
		 * format for a simple dateTime
		 */
		dateTimeFormatOneDateTime: function (sDateTime) {
			if (sDateTime) {
				return _dateTimeFormatOneDateTime(sDateTime);
			}
			return "";
		},

		/**
		 * format for two simple dates seperated by a definable token and a optional linebreak after the token
		 */
		dateFormatTwoDatesWithSeperator: function (sStartDate, sEndDate, sToken, bWithLinebreak) {
			var sFormattedStartDate = _globalDateFormatLong.format(sStartDate);
			var sFormattedEndDate = _globalDateFormatLong.format(sEndDate);

			sToken = sToken || '-';
			bWithLinebreak = bWithLinebreak || false;

			if (bWithLinebreak)
				return sFormattedStartDate + " " + sToken + "\n" + sFormattedEndDate;
			else
				return sFormattedStartDate + " " + sToken + " " + sFormattedEndDate;
		},

		/**
		 *show a busy indicator for different ui elements, while the data is loading from the backend systems
		 */
		numberOrBusy: function (value) {
			if (value === null || value === undefined) {
				return true;
			} else {
				return false;
			}
		},
		/**
		 *check if there is data returned form the backend
		 * if not check the status and return based on the status a specific text
		 * if there is a value then do some "HEC" specific string modification
		 */
		noDataDeliveryUnit: function (sValue, sOpenNew, valueKey, bundle) {
			if (!sValue) {
				var oBundle = bundle;
				if (!oBundle) {
					oBundle = this.getModel("i18n").getResourceBundle();
				}
				return oBundle.getText("noData");
			} else {
				switch (valueKey) {
					case "0022187741": //CENTURYLINK COMMUNICATIONS LLC
					case "0017958862": //DIMENSION DATA CLOUD BUSINESS UNIT
					case "0022846399": //HEWLETT PACKARD ENTERPRISE (HPE)
					case "0021094140": //IBM DEUTSCHLAND GMBH
					case "0008604698": //INJAZAT DATA SYSTEMS LLC
					case "0011585500": //VIRTUSTREAM INC.
					case "0001092494": //Business Connexion
					case "0014081318": //CtrlS Datacenters Limited
					case "0001092747": //0001092747 T-SYSTEMS INTERNATIONAL GMBH
					case "0026226182": //DXC  DXC.Technology
						return "HEC (" + sValue + ")";
					case "0001212132": //SAP HOSTING AG & CO KG
						return "HEC";
					default:
						return sValue;
				}
			}
		},
		/**
		 * set the rating icon based on the rating returned from the backend
		 * applies to master and detail view
		 */
		ratingIcon: function (rating) {
			if (rating === "C") {
				return "sap-icon://alert"; //status-critical  message-warning
			} else if (rating === "B") {
				return "sap-icon://status-critical"; //status-inactive   notification
			} else if (rating === "A") {
				return "sap-icon://status-completed"; //status-positive  message-success
			} else {
				return "";
			}
		},

		/**
		 * set the rating color based on the rating text returned from the backend
		 * applies to Projects On Watch
		 */
		formatRatingToColor: function (rating) {
			if (rating === "POWC") {
				return "Red";
			} else if (rating === "POWB") {
				return "Yellow";
			} else if (rating === "POWA") {
				return "Green";
			} else {
				return "Unrated";
			}
		},

		/**
		 * Set the TriggeredBy Text Header Tag
		 * applies to Projects On Watch Detail Page
		 */
		formatTriggeredBy: function (TriggerdBy) {
			if (TriggerdBy === "EXTERNAL") {
				return "External";
			} else if (TriggerdBy === "INTERNAL") {
				return "Internal";
			} else if (TriggerdBy === "MCCINTERNAL") {
				return "MCC Internal";
			} else {
				return "Unknown";
			}
		},


		/**
		 * Use Boolean to show either 
		 * applies to Projects On Watch Detail Page
		 */
		formatBooleanToDoneStatus: function (Done) {
			if (Done === true) {
				return "Done";
			} else {
				return "";
			}
		},

		/**
		 * format the numbers shown on TotalEscalationCostsChart Tile
		 */
		numberThousandFormatter: function (sValue) {
			//format number of total Escalation Costs
			if (sValue) {
				sValue = Math.round(sValue / 1000);
				var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();
				return Number(sValue).toLocaleString(sCurrentLocale, {
					useGrouping: true,
					maximumFractionDigits: 2
				});
			}
			return 0;
		},
		/**
		 * format the numbers shown on TotalEscalationCostsChart Tile with YDT
		 */
		numberThousandFormatterYDT: function (sValue) {
			//format number of total Escalation Costs
			var oBundle = this.getModel("i18n").getResourceBundle();
			var sYDT = oBundle.getText("ydtLabel");
			var skEUR = oBundle.getText("totalEscalationCostsUnitYTD");

			if (sValue) {
				sValue = Math.round(sValue / 1000);
				var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();

				return sYDT + " " + Number(sValue).toLocaleString(sCurrentLocale, {
					useGrouping: true,
					maximumFractionDigits: 2
				}) + " " + skEUR;
			}
			return sYDT + " " + 0 + " " + skEUR;
		},

		/**
		 * format Number with . or , based on the user locale
		 * and two fraction digits
		 */
		numberFormatter: function (sValue) {
			if (sValue) {
				//	var iValue = Number(parseInt(sValue) / 1000).toFixed(2);
				var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();
				return Math.round(Number(sValue)).toLocaleString(sCurrentLocale, {
					minimumFractionDigits: 0,
					maximumFractionDigits: 0
				});
			}
			return sValue;
		},
		/**
		 * check if the the oData call returns data for the specific KPI chart
		 * if this is not the case, then a corresponding error message is shown on the ui
		 */
		checkIfKPIClosedNewOngoingEscalationsShowsData: function (iValue) {
			if (iValue && iValue > 0) {
				this.getModel("settings").setProperty("/kpi_ClosedNewOngoing_HasNoData", Boolean(false));
			}
			return iValue;
		},
		/**
		 * check if the the oData call returns data for the specific KPI chart
		 * if this is not the case, then a corresponding error message is shown on the ui
		 */
		checkIfKPIAverageDurationClosedEscalationsShowsData: function (iValue) {
			if (iValue && iValue > 0) {
				this.getModel("settings").setProperty("/kpi_AverageDurationClosed_HasNoData", Boolean(false));
			}
			return iValue;
		},
		/**
		 * check if the the oData call returns data for the specific KPI chart
		 * if this is not the case, then a corresponding error message is shown on the ui
		 */
		checkIfKPITotalEscalationCostsShowsData: function (iValue) {
			if (iValue && iValue > 0) {
				this.getModel("settings").setProperty("/kpi_TotalEscalationCosts_HasNoData", Boolean(false));
			}
			return iValue;
		},
		/**
		 * check if the the oData call returns data for the specific KPI chart
		 * if this is not the case, then a corresponding error message is shown on the ui
		 */
		checkIfKPIAverageEscalationCostsShowsData: function (iValue) {
			if (iValue && iValue > 0) {
				this.getModel("settings").setProperty("/kpi_AverageEscalationCosts_HasNoData", Boolean(false));
			}
			return iValue;
		},
		/**
		 * check if the the oData call returns data for the specific KPI chart
		 * if this is not the case, then a corresponding error message is shown on the ui
		 */
		checkIfKPITop5ProductsShowsData: function (iValue) {
			if (iValue && iValue > 0) {
				this.getModel("settings").setProperty("/kpi_Top5Products_HasNoData", Boolean(false));
			}
			return iValue;
		},
		/**
		 * check if the the oData call returns data for the specific KPI chart
		 * if this is not the case, then a corresponding error message is shown on the ui
		 */
		checkIfKPIStrategicProductsShowsData: function (iValue) {
			if (iValue && iValue > 0) {
				this.getModel("settings").setProperty("/kpi_StrategicProducts_HasNoData", Boolean(false));
			}
			return iValue;
		},
		showValueOrPlaceholder: function (sValue, sPlaceholder) {
			var sUsedPlaceholder = sPlaceholder || "-";
			if (sValue) {
				return sValue;
			}
			return sUsedPlaceholder;
		},

		concatenateDateAndOption: function (sOption, sDateValue1, sDateValue2) {
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				style: "medium"
			}, new sap.ui.core.Locale("en_GB"));
			var sReturn = "";
			if (sDateValue1 && (sDateValue1 instanceof Date)) {
				sDateValue1 = oDateFormat.format(sDateValue1);
			}
			if (sDateValue2 && (sDateValue2 instanceof Date)) {
				sDateValue2 = oDateFormat.format(sDateValue2);
			}
			if (sOption === "LE") {
				sOption = "<=";
				sReturn = sOption + " " + sDateValue1;
			} else if (sOption === "GE") {
				sOption = ">=";
				sReturn = sOption + " " + sDateValue1;
			} else if (sOption === "EQ") {
				sOption = "=";
				sReturn = sOption + " " + sDateValue1;
			} else {
				sOption = "-";
				sReturn = sDateValue1 + " " + sOption + " " + sDateValue2;
			}

			return sReturn;
		},
		formatClosingDateEmpty: function (bEmpty) {
			if (bEmpty) {
				return "#";
			} else {
				return "";
			}
		},
		returnStringAsArray: function (str) {
			return [str];
		},
		checkCostDataVisibilty: function (bGeneralVisibility, sProcessType) {
			if (bGeneralVisibility && (sProcessType === "ZSPRCTYP06" || sProcessType === "ZSPRCTYP01")) {
				return true;
			}
			return false;
		},
		getStatisticsSubTitle: function (bShowCostData) {
			var oBundle = this.getModel("i18n").getResourceBundle();
			var text = "";
			if (bShowCostData) {
				text = oBundle.getText("chartsSubTitle");
			} else {
				text = oBundle.getText("chartsSubTitleCRMOnly");
			}
			return text;
		},
		getDynamicMonthSubTitle: function (sText) {
			var dTemp = new Date();
			dTemp.setFullYear(dTemp.getFullYear() - 1);
			dTemp.setDate(1);

			var sDate = _globalDateFormatLong.format(dTemp);
			var text = sText + " " + sDate;
			return text;
		},
		returnCostOverviewCurrentYearStyleClass: function (sSelectedYear) {
			if (sSelectedYear) {
				//get current year 
				var thisYearDate = new Date();
				thisYearDate.setHours(0, 0, 0, 0);
				if (sSelectedYear.startsWith(thisYearDate.getFullYear())) {
					return "MCSDashboardCurrentYearClass";
				} else {
					return "";
				}
			} else {
				return "";
			}
		},
		formatSubscriptionItemBtn: function (sSubscriptionButtonAction) {
			if (sSubscriptionButtonAction === "ADD") {
				return "sap-icon://SAP-icons-TNT/message-start-event"; //sap-icon://emailnotification-2
			} else if (sSubscriptionButtonAction === "DELETE") {
				return "sap-icon://SAP-icons-TNT/message-end-event"; // sap-icon://ui-notifications
			} else {
				return null;
			}
		},
		formatSubscriptionItemBtnTooltip: function (sSubscriptionButtonAction) {
			var oBundle = this.getModel("i18n").getResourceBundle();
			if (sSubscriptionButtonAction === "ADD") {
				return oBundle.getText("subscribe");
			} else if (sSubscriptionButtonAction === "DELETE") {
				return oBundle.getText("unsubscribe");
			} else {
				return oBundle.getText("subscribeError");
			}
		},
		formatRegionNameToRegionCode: function (sRegionName) {
			if (sRegionName === "EMEA North") {
				return "EMEA_NORTH";
			} else if (sRegionName === "EMEA South") {
				return "EMEA_SOUTH";
			} else {
				return sRegionName;
			}
		},
		formatSNOWRequestReason: function (sValue) {
			switch (sValue) {
				case '7':
					return "PE Critical";
					break;
				case '8':
					return "Business Down";
					break;
				case '9':
					return "Go-Live endangered";
					break;
				case '10':
					return "xTec";
					break;
				default:
					return "";
			}

		},
		getDaysHoursMinSince: function (date) {
			if (date) {
				//remove seconds to always update the minutes at the top of the minute, e.g at 12:35:00 instead of 12:35:15
				date = date.substring(0, date.length - 3);
				var dDate = new Date(date);
				dDate = Date.UTC(dDate.getFullYear(), dDate.getMonth(), dDate.getDate(), dDate.getHours(), dDate.getMinutes());

				var oDateNow = new Date();
				var oDateUTC = Date.UTC(oDateNow.getUTCFullYear(), oDateNow.getUTCMonth(), oDateNow.getUTCDate(),
					oDateNow.getUTCHours(), oDateNow.getUTCMinutes(), oDateNow.getUTCSeconds());

				// get total seconds between the times
				var delta = Math.abs(oDateUTC - (dDate)) / 1000;

				// calculate (and subtract) whole days
				var days = Math.floor(delta / 86400);
				delta -= days * 86400;

				var iHours = Math.floor(delta / 3600);
				delta -= iHours * 3600;

				var iMinutes = Math.floor(delta / 60);

				return days + "d " + iHours + "h " + iMinutes + "min";
			}
			return "";
		},
		formatCustomerName: function (bIsAnonymizedMode, sName1, sName2) {
			if (bIsAnonymizedMode) {
				return this.getModel("i18n").getResourceBundle().getText("anonymizedText");
			}
			return sName1 + "" + sName2;
		},

		getCountryName: function (sCountryCode, oController) {
			var sCountryName = "";
			if (sCountryCode == "USA") {
				sCountryCode = "US";
			}
			if (sCountryCode && oController) {
				var aCountries = oController.getModel("countryRegionModel").getProperty("/RegionHelp");
				if (aCountries && aCountries.length > 0) {
					var oCountry = aCountries.find(oCountry => oCountry.countryCode === sCountryCode);
					if (oCountry && oCountry.countryCode) {
						sCountryName = oCountry.country;
					}
				}
			}
			return sCountryName;
		},

		sortPriorities: function (priorityText) {
			if (!priorityText) { //priorityText is NULL or undefined
				return 0;
			}

			var priorityValue = parseInt(priorityText);
			if (isNaN(priorityValue)) { //Priority is not a number

				switch (priorityText.toLowerCase()) {
					case "very high":
						return 10;
					case "high":
						return 9;
					case "medium":
						return 6;
					case "normal":
						return 5;
					case "required":
						return 4;
					case "expected":
						return 3;
					case "optional":
						return 2;
					case "low":
						return 1;
					case "":
						return 0;
					default:
						return 0;
				}

			} else {
				return priorityValue;
			}
		},

		shortenTagText: function (sText) {
			var sResult = "";
			switch (sText) {
				case "Customer":
					sResult = "";
					break;
				case "Global Ultimate":
					sResult = "";
					break;
				case "Confidential":
					sResult = "";
					break;
				case "Anonymized Mode enabled":
					sResult = "";
					break;
				default:
					sResult = sText;
					break;
			}
			return sResult;
		},

		shortenTagTextWithPartnerGu: function (Partner, Gu) {
			var sResult = "";
			var sText = "";

			if (Partner == Gu) {
				sText = "Global Ultimate";
			} else {
				sText = "Customer";
			}

			switch (sText) {
				case "Customer":
					sResult = "";
					break;
				case "Global Ultimate":
					sResult = "";
					break;
				default:
					sResult = sText;
					break;
			}
			return sResult;
		},

		// Formatters for Timeline
		formatColor: function (oRating) {
			if (oRating === "Green") {
				return "sapUiPositiveText";
			} else if (oRating === "Yellow") {
				return "sapUiLegend1";
			} else {
				return "sapUiNegativeText";
			}
		},
		formatDate2Display: function (oDate) {
			var oNewDate = new Date(oDate);
			if (oDate !== null) {
				var isValid = !isNaN(oNewDate.getTime());
			}
			if (isValid) {
				return String(oNewDate).substr(4, 6) + "," + String(oNewDate).substr(10, 5);
			}
			return "-";
		},
		formatTimestamp: function (sTimestamp) { //Changes time format so it can be used in the chart
			if (sTimestamp < 1) {
				sTimestamp = Date();
			}
			return Format.abapTimestampToDate(sTimestamp);
		},
		getCaseType: function (CaseType, ProcessTypeId) {
			var sCaseEngType = "";
			if (CaseType === "ZS01") {
				switch (ProcessTypeId) {
					case "ZSPRCTYP01":
						sCaseEngType = "Global Escalation Management";
						break;
					case "ZSPRCTYP06":
						sCaseEngType = "Global Escalation Management";
						break;
				}
			}
			if (CaseType == "ZS02") {
				switch (ProcessTypeId) {
					case "ZSCUSTYP02":
						sCaseEngType = "Guided Solution Support";
						break;
					case "ZSCUSTYP04":
						sCaseEngType = "Critical Period Coverage";
						break;
					case "ZSCUSTYP06":
						sCaseEngType = "Top Critical Customers";
						break;
					case "ZSCUSTYP05":
						sCaseEngType = "Critical Customer Management";
						break;
					case "ZSCUSTYP07":
						sCaseEngType = "Task Force";
						break;
				}
			}
			return sCaseEngType;
		},
		formatEscalationURL: function (sId) {
			var currentUrl = window.location.href,
				url = "";


			if (currentUrl.includes("test-kinkajou") || currentUrl.includes("sapit-home-test-004") || currentUrl.includes("fiorilaunchpad-sapitcloudt")) {
				//we are in test environment

				url = "https://" + "test.itsm.services.sap/now/cwf/agent/record/sn_customerservice_escalation/" + sId;
			} else if (currentUrl.includes("dev-mallard") || currentUrl.includes("port5000") || currentUrl.indexOf("localhost:5000") != -1) {
				//we are in dev environment

				url = "https://" + "dev.itsm.services.sap/now/cwf/agent/record/sn_customerservice_escalation/" + sId;
			} else {

				url = "https://" + "itsm.services.sap/now/cwf/agent/record/sn_customerservice_escalation/" + sId;
			}
			return url;
		},
		formatExpectedActionExecutiveEscalation: function (sExpectedAction) {
			switch (sExpectedAction) {
				case "accept_engagement":
					return "Accept Engagement";
				case "analysis_needed":
					return "Analysis Needed";
				default:
					return "Not Set";
			}
		},
	};
});