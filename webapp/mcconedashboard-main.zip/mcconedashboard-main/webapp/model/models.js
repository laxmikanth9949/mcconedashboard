sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {
		//MCCONE/MCSDashboard: main device model
		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		//MCCONE/MCSDashboard: country region model
		createCountryRegionModel: function (oCountryModel, oModel) {
			oModel.read("/RegionHelp", {
				success: function (oData) {
					oCountryModel.setProperty("/RegionHelp", oData.results);
					return oCountryModel;
				}.bind(this),
				error: function (oErr) {
					oCountryModel.setProperty("/RegionHelp", []);
					return oCountryModel;
				}.bind(this)
			});
		},
		//MCCONE/MCSDashboard: main application settings model
		createAppSettingModel: function (bShowCrmData, bShowCostData) {
			var model = new JSONModel({
				"defaultModel_metadataLoaded": false,
				"app_dep_Model_metadataLoaded": false,
				"ShowGlobalAggregation": false,
				"ShowGlobalEscalations": false,
				"ShowRegionalGlobalEscalations": false,
				"showTopIssuesSection": false,
				"flagCustomerFactSheet": false,
				"showFavoriteTab": false, //this flag is needed because of timing reasons, it only has to be set, when the Auth Model has been read, otherwise it leads to strange display effects
				"show_crm_data": Boolean(bShowCrmData),
				"show_cost_data": Boolean(bShowCostData),
				"initialReadOfVariantManagement": Boolean(true),
				"show_master_filter": Boolean(true),
				"tile_identifier": "",
				"isInOperationalKPITile": false,
				"isInChartsTile": false,
				"showDetailCheckpointsTab": false,
				"showDetailTopIssuesTab": false,
				"showNotesForProdDowns": true,
				"showInfoForClosedCases": false,

				"kpi_ClosedNewOngoing_HasNoData": false,
				"kpi_AverageDurationClosed_HasNoData": false,
				"kpi_TotalEscalationCosts_HasNoData": false,
				"kpi_AverageEscalationCosts_HasNoData": false,
				"kpi_Top5Products_HasNoData": false,
				"kpi_StrategicProducts_HasNoData": false,
				"kpi_Top5Products_TableVisibility": false,
				"kpi_StrategicProducts_TableVisibility": false,

				"isVisible_Top5ProductsWithHighEscCostsTable": false,
				"hasNoData_Top5ProductsWithHighEscCosts": false,

				"isVisible_EscCostsOfStrategicProductsTable": false,
				"hasNoData_EscCostsOfStrategicProducts": false,

				"isVisible_EscCostsPerProdCategoryTable": false,

				"kpiClosedNewOngoingEscalationsFilter": "ZSPRCTYP01", //initially read/show global Escalations
				"kpiTotalEscalationCostsFilter": "ALL", //initially show Global and Produkt Escalations
				"kpiAverageEscaltaionCostsFilter": "ALL", //initially show Global and Produkt Escalations
				"kpiEscalationRequestsUserStatusFilter": "ALL", //initially show ALL Escalatation Requests
				"kpiTotalEscalationCostsChartVisible": true,
				"kpiTotalEscalationCostsChartRegionVisible": false,
				"kpiTotalEscalationCostsTableVisible": false,
				"kpiAverageEscalationCostsChartVisible": true,
				"kpiAverageEscalationCostsChartRegionVisible": false,
				"kpiAverageEscalationCostsTableVisible": false,
				"selectedFilterVariant": null,
				"selectedRegionFilter": "WORLD",
				"showReportDownloadTile": Boolean(false),
				"showOperationalInformationTile": Boolean(false),
				"caseIdsForExport": null,
				"facetFilterVisible": true,
				"facetFilterMainProductSearchSelected": false,
				"isVisibleOpenCaseCheckerButton": false,
				"isStandAlone": true,
				"showProductEscalations": false,
				"isCIMQuickInfo": false,
				"isAnonymizedMode": false,
				"showHeaderOnStartPage": true,
				"isMobileMode": false
			});
			return model;
		},
		//MCCONE/MCSDashboard: main filter model
		createFilterModel: function () {
			var oFilterModel = new sap.ui.model.json.JSONModel({
				region: "",
				opennew: new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"), // StatusT = New
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"), // StatusT = In Process
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"), // StatusT = In Escalation
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99") // StatusT = In Management Review
				], false),
				facetFilterSelectionDisplay: {
					customers: [],
					globalUltimates: [],
					salesOrgs: [],
					serviceOrgs: [],
					products: [],
					productCategories: [],
					productLines: [],
					productVersions: [],
					customerSegments: [],
					serviceTeams: [],
					countries: [],
					regions: [],
					mccTags: []
				},
				oFilterForBWCosts: []
			});
			return oFilterModel;
		},

		////////////////////////
		////////////////////////
		//MCS Dashboard integration
		////////////////////////
		////////////////////////

		/**
		 *function in order to check if the end user has corresponding sales org user rights
		 **/
		//MCCONE/MCSDashboard: MCS Dashboard specific authorization check
		checkSalesOrgAuth: function (dashboardModel, settingsModel, oResourceBundle) {
			dashboardModel.read("/AuthoritySet", {
				success: function (data, response) {
					//Show tile for Report download, if the end user has the needed role assigned on IC* Landscape
					settingsModel.setProperty("/showReportDownloadTile", (data.results[0].ShowPDFTile === "X") ? Boolean(true) : Boolean(false));
					//Show tile for MCS Operation Statistics, if the end user has the needed role assigned on IC* Landscape
					settingsModel.setProperty("/showOperationalInformationTile", (data.results[0].ShowPDFTile === "X") ? Boolean(true) : Boolean(
						false));
					if (data.results[0].Global !== "X") {
						//hide BW tiles and data in case the role assignment is not correct
						//usually the user should not have any BW roles assigned and therefore not see it out of the box
						settingsModel.setProperty("/show_cost_data", Boolean(false));
					}
				},
				error: function (oError, response) {
					settingsModel.setProperty("/showReportDownloadTile", Boolean(false));
					settingsModel.setProperty("/showOperationalInformationTile", Boolean(false));
				}
			});
		},

		/**
		 * create filter model in order to store the selected filters
		 */
		//MCCONE/MCSDashboard: model to build BW related filter strings; filter setup for BW is different compared to the one for CRM
		createBWFiltersModel: function (settingsModel) {
			var model = new JSONModel({});

			//MCCONE/MCSDashboard: needed for BW related Region filter setup
			model.buildURLVariableFilterForBWP = function (aRegionFilter, sType, sRegionFilterValueForKPIs) {
				var sRegionFilterValue = "";
				if (aRegionFilter !== null && aRegionFilter.length > 0) {
					sRegionFilterValue = aRegionFilter.slice(0)[0].oValue1;
				}
				//for KPIs we need to loop over all regions to get the needed data, this means aRegionFilter will contain WORLD, yet we need to call the oData for all different regions
				if (sRegionFilterValueForKPIs && sRegionFilterValueForKPIs.length > 0) {
					sRegionFilterValue = sRegionFilterValueForKPIs;
				}
				//possible filters, only region can be used, because Variable filters only support one filter criteria -->  all other need to use $filter
				/**
				 * MCASE_NMM_OY_003	BP Region (Country Hierarchy)
				 * MCASE_CMM_OY_007	CRM Service Org.
				 * MCASE_CMM_OY_002	Case Product
				 * MCASE_CMM_OY_008	Delivery Unit
				 * MCASE_NMM_OY_005	Master Code (Hierarchy)
				 * MCASE_CMM_OY_006	CRM Sales Org.
				 * MCASE_HMM_YO_001	MCS Product Version Hierarchy
				 * MCASE_HCS_MY_01_0SALESORG	Sales Org. Hierarchy
				 * MCASE_NAM_ON_01_0SALESORG	Sales Org. Hierarchy Node
				 * MCASE_CMS_MY_0001 Target Currency Selection
				 * MCASE_NMM_OY_0002  Escalations Worldwide Hier.
				 */
				//the oData service do have different KEY Predicates in the URL, we need to distinguish
				if (sType === "CostOverviewStructure") { //(MCASE_CMS_MY_0001='EUR',MCASE_NMM_OY_0002='0HIER_NODE:ESCA_WW')
					return "MCASE_CMS_MY_0001='EUR',MCASE_NMM_OY_0002='" + sRegionFilterValue + "'";
				} else if (sType === "CostStandardStructure") {
					return "MCASE_NMM_OY_003='" + sRegionFilterValue +
						"',MCASE_CMM_OY_007='',MCASE_CMM_OY_002='',MCASE_CMM_OY_008='',MCASE_NMM_OY_005='',MCASE_CMM_OY_006='',MCASE_HMM_YO_001='',MCASE_HCS_MY_01_0SALESORG='',MCASE_NAM_ON_01_0SALESORG=''";
				} else if (sType === "TopTenHighCostStructure") {
					return "MCASE_NMM_OY_003='" + sRegionFilterValue +
						"',MCASE_CMM_OY_007='',MCASE_CMM_OY_002='',MCASE_CMM_OY_008='',MCASE_NMM_OY_005='',MCASE_CMM_OY_006='',MCASE_HMM_YO_001='',MCASE_HCS_MY_01_0SALESORG='',MCASE_NAM_ON_01_0SALESORG='',MCASE_FMS_MY_0001='10'";
				} else {
					return "MCASE_NMM_OY_003='" + sRegionFilterValue + "',MCASE_HCS_MY_01_0SALESORG='',MCASE_NAM_ON_01_0SALESORG=''";
				}
			};
			//MCCONE/MCSDashboard: CATS specific filters need to be generated
			model.buildURLVariableFilterForBWPCATS = function (aRegionFilter) {
				//BWP CATS Activities
				var sRegionFilterValue = "";
				if (aRegionFilter !== null && aRegionFilter.length > 0) {
					sRegionFilterValue = aRegionFilter.slice(0)[0].oValue1;
				}

				//possible filters, only region can be used, because Variable filters only support one filter criteria -->  all other need to use $filter
				/**
				 * MCASE_NAM_ON_00_0COMP_CODE='0HIER_NODE:CCMV'
				 */
				return "MCASE_NAM_ON_00_0COMP_CODE='" + sRegionFilterValue + "'";
			};

			/*
			Due to multiple systems there are different naming conventions for the region filters.
			This function maps the specific names to the corresponding system.
			*/
			//MCCONE/MCSDashboard: needed for BW related Region filter setup
			model.buildRegionOnlyODataFilter = function (sTargetSystem, sRegion) {
				var sRegionFilterParameter = "region";
				var sRegionFilterValue = sRegion;
				var sSystem = sTargetSystem || "";
				var oRegionFilterMapping = {};

				// Map Filter Parameter names to specified system
				// World, EMEA, MEE, NA, LAC, APJ, GTC
				switch (sSystem) {
					// add new cases for different system mapping here...
				case "BWP":
					/* BWP MAPPING ================================================================================================= /*
					hierachy info can be found under:
					https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sap/fiori/mcsdashboard/webapp/destinations/int_bw/sap/opu/odata/sap/MCASE_COST_ODA_002N_SRV/MCASE_NMM_OY_003
					App	Filter			System																			Description
					-----------------------------------------------------------------------------------------------------------------
					World			13	'0HIER_NODE:SUP_COUNTRY%20HIERARCHY'or ''										World (all)
					EMEA			12	'0HIER_NODE:SUP_EMEA W/O MEE'		or '0HIER_NODE%3ASUP_EMEA%20W%2FO%20MEE'	EMEA w/o MEE
					EMEA NORTH			0HIER_NODE%3ASUP_EMEA%20NORTH
					EMEA_SOUTH			0HIER_NODE%3ASUP_EMEA%20SOUTH
					MEE				11	'0HIER_NODE:SUP_MEE'				or '0HIER_NODE%3ASUP_MEE'					MEE
					LAC				 9	'0HIER_NODE:SUP_LAC'				or '0HIER_NODE%3ASUP_LAC'					Latin America
					NA				10	'0HIER_NODE:SUP_NA' 				or '0HIER_NODE%3ASUP_NA'					North America
					APJ				10	'0HIER_NODE:SUP_APJ W/O GC' 		or '0HIER_NODE%3ASUP_APJ%20W%2FO%20GC'		APJ w/o GC
					GTC				 3	'0HIER_NODE:SUP_GREATER CHINA'				or '0HIER_NODE%3ASUP_GREATER%20CHINA'					Greater China
					/* ============================================================================================================== */
					var oBWPRegionFilterMapping = {
						WORLD: "0HIER_NODE:SUP_COUNTRY%20HIERARCHY",
						EMEA: "0HIER_NODE%3ASUP_EMEA%20W%2FO%20MEE",
						EMEA_NORTH: "0HIER_NODE%3ASUP_EMEA%20NORTH",
						EMEA_SOUTH: "0HIER_NODE%3ASUP_EMEA%20SOUTH",
						MEE: "0HIER_NODE%3ASUP_MEE",
						LAC: "0HIER_NODE%3ASUP_LAC",
						NA: "0HIER_NODE%3ASUP_NA",
						APJ: "0HIER_NODE%3ASUP_APJ%20W%2FO%20GC",
						GTC: "0HIER_NODE%3ASUP_GREATER%20CHINA"
					};
					oRegionFilterMapping = oBWPRegionFilterMapping;
					sRegionFilterParameter = "MCASE_NMM_OY_003";
					//sRegionFilterValue = sRegionFilterValue || "0HIER_NODE:SUP_COUNTRY%20HIERARCHY";
					sRegionFilterValue = sRegionFilterValue || "WORLD";

					break;
				case "BWPCATS":
					/* BWP MAPPING ================================================================================================= /*
					App	Filter			System																			Description
					-----------------------------------------------------------------------------------------------------------------
					World			08	'0HIER_NODE:CCMV'									
					EMEA NORTH		17	'0HIER_NODE:M017'  0HIER_NODE%3AM017		
					EMEA SOUTH		12	'0HIER_NODE:M018' 0HIER_NODE%3AM018		
					MEE				11	'0HIER_NODE:M011'				
					LAC				 9	'0HIER_NODE:TLAM'			
					NA				10	'0HIER_NODE:TNAM' 				
					APJ				10	'0HIER_NODE:M032' 		
					GTC				 3	'0HIER_NODE:M031'				
					/* ============================================================================================================== */
					var oBWPRegionFilterMapping = {
						WORLD: "0HIER_NODE%3ACCMV",
						EMEA_NORTH: "0HIER_NODE%3AM017",
						EMEA_SOUTH: "0HIER_NODE:M018",
						MEE: "0HIER_NODE%3AM011",
						LAC: "0HIER_NODE%3ATLAM",
						NA: "0HIER_NODE%3ATNAM",
						APJ: "0HIER_NODE%3AM032",
						GTC: "0HIER_NODE%3AM031"
					};
					oRegionFilterMapping = oBWPRegionFilterMapping;
					sRegionFilterParameter = "MCASE_NAM_ON_00_0COMP_CODE";
					//sRegionFilterValue = sRegionFilterValue || "0HIER_NODE:SUP_COUNTRY%20HIERARCHY";
					sRegionFilterValue = sRegionFilterValue || "WORLD";

					break;
				default:
					sRegionFilterValue = sRegionFilterValue || "WORLD";
				}

				//setRegion to Settingsmodel
				settingsModel.setProperty("/selectedRegionFilter", sRegionFilterValue);

				// Perform Mapping
				sRegionFilterValue = oRegionFilterMapping[sRegionFilterValue] || sRegionFilterValue;

				// create Filter from mapped values
				var oFilter = new sap.ui.model.Filter([
					sRegionFilterValue ? new sap.ui.model.Filter(
						sRegionFilterParameter,
						sap.ui.model.FilterOperator.EQ,
						sRegionFilterValue) : null
				].filter(Boolean), true);

				return oFilter;
			};
			return model;
		},

		/**
		 * check if the filters have change since last selection
		 */
		//MCCONE/MCSDashboard: for now not used anymore. maybe still needed in a later version?
		PARKED_equalFilter: function (filters1, filters2, that) {
			// Keep track of filters and only read again if filters changed
			if (typeof filters1.aFilters !== typeof filters2.aFilters) {
				return false;
			} else if (filters1.aFilters && filters2.aFilters) {
				if (filters1.aFilters.length !== filters2.aFilters.length) {
					return false;
				} else {
					var equal = filters1.aFilters.every(function (filter1, index) {
						return that._equalFilter(filter1, filters2.aFilters[index], that);
					});
					if (!equal) {
						return false;
					}
				}
			}
			return (
				filters1.sPath === filters2.sPath &&
				filters1.oValue1 === filters2.oValue1 &&
				filters1.oValue2 === filters2.oValue2 &&
				filters1.sOperator === filters2.sOperator &&
				filters1.bAnd === filters2.bAnd &&
				filters1._bMultiFilter === filters2._bMultiFilter
			);

		},

		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		//~~~~~ KPI TILE ~~~~~~~~~~~~~~~~~~~
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

		/**
		 * create filter model in order to store the selected filters
		 */
		//MCCONE/MCSDashboard: filter model for Report Tile - PDF and XLS with filter possiblities
		createExtReportFiltersModel: function () {
			var model = new JSONModel({
				case_id: null,
				id: null,
				process_type: null,
				region: null,
				status: null,
				rating: null,
				master_code: null,
				service_org: null,
				delivery_unit: null,
				ref_objectprodCat: null,
				ref_objectprodLine: null,
				ref_object: null,
				sales_org: null,
				service_team: null,
				customer_bp_id: null,
				creation_date: null,
				closing_date: null,
				mainProductSearch: false
			});
			//MCCONE/MCSDashboard: define filters for call to the backend to generate the PDF/XLS files
			model.buildPOSTFilterString = function () {
				var case_id = this.getProperty("/case_id");
				var id = this.getProperty("/id");
				var processType = this.getProperty("/process_type");
				var region = this.getProperty("/region");
				var status = this.getProperty("/status");
				var rating = this.getProperty("/rating");
				var masterCode = this.getProperty("/master_code");
				var deliveryUnit = this.getProperty("/delivery_unit");
				var serviceOrg = this.getProperty("/service_org");
				var refObjectCat = this.getProperty("/ref_objectprodCat");
				var refObjectLine = this.getProperty("/ref_objectprodLine");
				var refObject = this.getProperty("/ref_object");
				var salesOrg = this.getProperty("/sales_org");
				var mainCust = this.getProperty("/customer_bp_id");
				var creationDate = this.getProperty("/creation_date");
				var closingDate = this.getProperty("/closing_date");
				var mainProductSearch = this.getProperty("/mainProductSearch");
				var serviceTeam = this.getProperty("/service_team");
				//ICT & ICP ["14235363", "14235364", "14235365", "14217791", "13732949", "25970641", "25970644", "25970643", "16673868"];
				//ICD ["0001040360"];
				// var creationDateOption = this.getProperty("/creation_date_option");
				// var closingDateOption = this.getProperty("/closing_date_option");
				// var closingDateEmpty = this.getProperty("/closing_date_empty");

				var sCaseId = "CASE_ID";
				var sId = "ID";
				var sProcessType = "PROCESS_TYPE";
				var sRegion = "REGION";
				var sStatus = "STATUS";
				var sRating = "RATING";
				var sMasterCode = "MASTER_CODE";
				var sDeliveryUnit = "DELIVERY_UNIT";
				var sServiceOrg = "SERVICE_ORG";
				var sRefObject = "PRODUCT_GUID";
				var sRefObjectCat = "PRODUCT_CATEGORY";
				var sRefObjectLine = "PRODUCT_LINE";
				var sSalesOrg = "SALES_ORG";
				var sMainCust = "CUSTOMER_BP_ID";
				var sCreationDate = "CREATE_TIME";
				var sClosingDate = "CLOSE_TIME";
				var sMainProductSearch = "product_rel_type";
				var sServiceTeam = "SERVICE_TEAM";
				//filtersModel.setProperty("/mainProductSearch",
				//You should have a new parameter: product_rel_type. 
				//ZSCASEPROM - Main Products
				//ZSCASEPROD - All the rest products.
				//To select both you can specify them both or just ignore. So far we do not have other relationships. 

				//if (!region) region = ["WORLD"];

				// = (Equality test) -> EQ
				// <> (Inequality test) -> NE
				// > (Greater than test) -> GT
				// < (Less than test) -> LT
				// >= (Greater than or equals) -> GE
				// <= (Less than or equals test) -> LE 
				//BT (BeTween) und NB (Not Between)

				var sSign = "<SIGN>I</SIGN>",
					sOptionEQ = "<OPTION>EQ</OPTION>",
					sHigh = "<HIGH></HIGH>",
					sAttrName = "";
				var sPostFilterForMIME = "<FILTER>";
				var concatFilterStringsEQ = function (item) {
					sPostFilterForMIME = sPostFilterForMIME.concat("<" + sAttrName + ">" + sSign + sOptionEQ);
					sPostFilterForMIME = sPostFilterForMIME.concat("<LOW>" + item + "</LOW>" + sHigh);
					sPostFilterForMIME = sPostFilterForMIME.concat("</" + sAttrName + ">");
				};
				var concatDateFilterStringsEQ = function (sType, oDate) {
					if (oDate.length > 1) {
						sPostFilterForMIME = sPostFilterForMIME.concat("<" + sAttrName + ">" + sSign + "<OPTION>" + oDate[0] + "</OPTION>");
						sPostFilterForMIME = sPostFilterForMIME.concat("<LOW>" + oDate[1] + "</LOW>");
						if (oDate[0] === "BT") {
							sPostFilterForMIME = sPostFilterForMIME.concat("<HIGH>" + oDate[2] + "</HIGH>");
						}
						sPostFilterForMIME = sPostFilterForMIME.concat("</" + sAttrName + ">");
					}
					//only in case of Closing Date we also have to add the filter of Empty dates if needed
					//close_time eq ''
					if (sType === "closing") {
						var bEmptyClosingDateSelected = false;
						if (oDate.length === 1) {
							bEmptyClosingDateSelected = oDate[0];
						} else if (oDate[0] === "BT") {
							bEmptyClosingDateSelected = oDate[3];
						} else {
							bEmptyClosingDateSelected = oDate[2];
						}
						if (bEmptyClosingDateSelected) {
							sPostFilterForMIME = sPostFilterForMIME.concat("<" + sAttrName + ">" + sSign + sOptionEQ);
							sPostFilterForMIME = sPostFilterForMIME.concat("<LOW></LOW>" + sHigh);
							sPostFilterForMIME = sPostFilterForMIME.concat("</" + sAttrName + ">");
						}
					}
				};

				if (case_id) {
					sAttrName = sCaseId;
					case_id.forEach(concatFilterStringsEQ);
				}
				if (id) {
					sAttrName = sId;
					id.forEach(concatFilterStringsEQ);
				}
				if (processType) {
					sAttrName = sProcessType;
					processType.forEach(concatFilterStringsEQ);
				}
				if (region) {
					sAttrName = sRegion;
					region.forEach(concatFilterStringsEQ);
				}
				if (status) {
					sAttrName = sStatus;
					status.forEach(concatFilterStringsEQ);
				}
				if (rating) {
					sAttrName = sRating;
					rating.forEach(concatFilterStringsEQ);
				}
				if (masterCode) {
					sAttrName = sMasterCode;
					masterCode.forEach(concatFilterStringsEQ);
				}
				if (deliveryUnit) {
					sAttrName = sDeliveryUnit;
					deliveryUnit.forEach(concatFilterStringsEQ);
				}
				if (serviceOrg) {
					sAttrName = sServiceOrg;
					serviceOrg.forEach(concatFilterStringsEQ);
				}
				if (refObjectCat) {
					sAttrName = sRefObjectCat;
					refObjectCat.forEach(concatFilterStringsEQ);
				}
				if (refObjectLine) {
					sAttrName = sRefObjectLine;
					refObjectLine.forEach(concatFilterStringsEQ);
				}
				if (refObject) {
					sAttrName = sRefObject;
					refObject.forEach(concatFilterStringsEQ);
				}
				if (mainProductSearch) {
					sAttrName = sMainProductSearch;
					concatFilterStringsEQ(mainProductSearch);
				}
				if (salesOrg) {
					sAttrName = sSalesOrg;
					salesOrg.forEach(concatFilterStringsEQ);
				}
				if (mainCust) {
					sAttrName = sMainCust;
					mainCust.forEach(concatFilterStringsEQ);
				}
				if (creationDate) {
					sAttrName = sCreationDate;
					concatDateFilterStringsEQ("creation", creationDate);
				}
				if (closingDate) {
					sAttrName = sClosingDate;
					concatDateFilterStringsEQ("closing", closingDate);
				}
				if (serviceTeam) {
					sAttrName = sServiceTeam;
					serviceTeam.forEach(concatFilterStringsEQ);
				}

				sPostFilterForMIME = sPostFilterForMIME.concat("</FILTER>");
				return sPostFilterForMIME;
			};

			return model;
		},

		/**
		 * read casespecific data for extended pdf or excel download view
		 */
		//MCCONE/MCSDashboard: PDF/XLS Download generic functions for all calls -->  List view and Export tile
		handleCasesForMIME: function (dashboardModel, sfinalPOSTFilter, resultModel, bCreate, sMimeType) {
			var model = resultModel;
			if (!resultModel) {
				model = new JSONModel({
					mimeFilteredCount: null,
					mimeGUID: null,
					mimeGenerated: "",
					oDataCallStatus: "OK"
				});
			}
			if (!sMimeType) {
				sMimeType = "PDF";
			}
			// Cases
			model.setProperty("/mimeFilteredCount", 0);
			model.setProperty("/mimeGUID", null);

			var oFilterData = {
				filter: sfinalPOSTFilter,
				create_flag: bCreate ? "X" : "",
				mime_type: sMimeType
			};

			dashboardModel.create("/MIMERequestInSet", oFilterData, {
				success: function (data, response) {
					model.setProperty("/mimeFilteredCount", parseInt(data.counter));
					model.setProperty("/mimeGUID", data.mime_guid);
					model.setProperty("/oDataCallStatus", "OK");
				},
				error: function (oError, response) {
					model.setProperty("/mimeFilteredCount", 0);
					model.setProperty("/mimeGUID", null);
					model.setProperty("/oDataCallStatus", "ERROR");
				}
			});
			return model;
		},

		/**
		 * read casespecific data for extended pdf or excel download view
		 */
		//MCCONE/MCSDashboard: general check, if PDF has been already generated or still needs some time in the Backend; if generated, then show on UI, otherwise recheck again some time later
		checkMimeGenerationStatus: function (dashboardModel, resultModel) {
			var mimeGUID = resultModel.getProperty("/mimeGUID");

			dashboardModel.read("/MIMERequestOutSet(mime_guid='" + mimeGUID + "')", {
				success: function (data, response) {
					resultModel.setProperty("/mimeGenerated", data.generated);
					resultModel.setProperty("/oDataCallStatus", "OK");
				},
				error: function (oError, response) {
					resultModel.setProperty("/mimeGenerated", "");
					resultModel.setProperty("/oDataCallStatus", "ERROR");
				}
			});
		},

		//MCCONE/MCSDashboard: mabye for later?
		PARKED_getUTCDateAndTime: function () {
			var isoDateStr = new Date().toISOString();
			var isoDate = new Date(isoDateStr); // ISO Date
			var nowDate = new Date();
			var utcDate = new Date(nowDate.getUTCFullYear(), nowDate.getUTCMonth(), nowDate.getUTCDate(), nowDate.getUTCHours(), nowDate.getUTCMinutes(),
				nowDate.getUTCSeconds());
			var now_utc = Date.UTC(nowDate.getUTCFullYear(), nowDate.getUTCMonth(), nowDate.getUTCDate(), nowDate.getUTCHours(), nowDate.getUTCMinutes(),
				nowDate.getUTCSeconds());
		}
	};
});