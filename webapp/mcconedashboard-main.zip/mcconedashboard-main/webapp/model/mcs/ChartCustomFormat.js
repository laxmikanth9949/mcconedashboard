sap.ui.define([
	'sap/viz/ui5/format/ChartFormatter',
	'sap/viz/ui5/api/env/Format'
], function (ChartFormatter, Format) {
	return {
		FIORI_LABEL_SHORTFORMAT_10: "__UI5__ShortIntegerMaxFraction10",
		FIORI_LABEL_FORMAT_2: "__UI5__FloatMaxFraction2",
		FIORI_LABEL_SHORTFORMAT_2: "__UI5__ShortIntegerMaxFraction2",
		FIORI_PERCENTAGE_FORMAT_2: "__UI5__PercentageMaxFraction2",
		FIORI_PERCENTAGE_FORMAT_2_PERCENTAGE_SIGN_ONLY: "__UI5__PercentageMaxFraction2_PercentateSignOnly",
		FIORI_VALUE_INT_ROUND: "__UI5__ValueIntRound",
		FIORI_VALUE_LOCALE_EURO_NO_SIGNS: "__UI5__ValueLocaleEuroNoSigns",
		FIORI_VALUE_LOCALE_EURO: "__UI5__ValueLocaleEuro",
		FIORI_VALUE_LOCALE_EURO_K: "__UI5__ValueLocaleEuroK",
		FIORI_VALUE_LOCALE_EURO_M: "__UI5__ValueLocaleEuroM",

		VALUE_CONVERT_BASE_TO_BASE: "VALUE_CONVERT_BASE_TO_BASE",
		VALUE_CONVERT_BASE_TO_K: "VALUE_CONVERT_BASE_TO_K",
		VALUE_CONVERT_BASE_TO_M: "VALUE_CONVERT_BASE_TO_M",

		VALUE_CONVERT_K_TO_BASE: "VALUE_CONVERT_K_TO_BASE",
		VALUE_CONVERT_K_TO_K: "VALUE_CONVERT_K_TO_K",
		VALUE_CONVERT_K_TO_M: "VALUE_CONVERT_K_TO_M",

		VALUE_CONVERT_M_TO_BASE: "VALUE_CONVERT_M_TO_BASE",
		VALUE_CONVERT_M_TO_K: "VALUE_CONVERT_M_TO_K",
		VALUE_CONVERT_M_TO_M: "VALUE_CONVERT_M_TO_M",

		VALUE_DEFAULT_NOSIGN_BASE_TO_BASE: "VALUE_DEFAULT_NOSIGN_BASE_TO_BASE",
		VALUE_DEFAULT_NOSIGN_BASE_TO_K: "VALUE_DEFAULT_NOSIGN_BASE_TO_K",
		VALUE_DEFAULT_NOSIGN_BASE_TO_M: "VALUE_DEFAULT_NOSIGN_BASE_TO_M",

		VALUE_DEFAULT_NOSIGN_K_TO_BASE: "VALUE_DEFAULT_NOSIGN_K_TO_BASE",
		VALUE_DEFAULT_NOSIGN_K_TO_K: "VALUE_DEFAULT_NOSIGN_K_TO_K",
		VALUE_DEFAULT_NOSIGN_K_TO_M: "VALUE_DEFAULT_NOSIGN_K_TO_M",

		VALUE_DEFAULT_NOSIGN_M_TO_BASE: "VALUE_DEFAULT_NOSIGN_M_TO_BASE",
		VALUE_DEFAULT_NOSIGN_M_TO_K: "VALUE_DEFAULT_NOSIGN_M_TO_K",
		VALUE_DEFAULT_NOSIGN_M_TO_M: "VALUE_DEFAULT_NOSIGN_M_TO_M",

		VALUE_DEFAULT_EUR_BASE_TO_BASE: "VALUE_DEFAULT_EUR_BASE_TO_BASE",
		VALUE_DEFAULT_EUR_BASE_TO_K: "VALUE_DEFAULT_EUR_BASE_TO_K",
		VALUE_DEFAULT_EUR_BASE_TO_M: "VALUE_DEFAULT_EUR_BASE_TO_M",

		VALUE_DEFAULT_EUR_K_TO_BASE: "VALUE_DEFAULT_EUR_K_TO_BASE",
		VALUE_DEFAULT_EUR_K_TO_K: "VALUE_DEFAULT_EUR_K_TO_K",
		VALUE_DEFAULT_EUR_K_TO_M: "VALUE_DEFAULT_EUR_K_TO_M",

		VALUE_DEFAULT_EUR_M_TO_BASE: "VALUE_DEFAULT_EUR_M_TO_BASE",
		VALUE_DEFAULT_EUR_M_TO_K: "VALUE_DEFAULT_EUR_M_TO_K",
		VALUE_DEFAULT_EUR_M_TO_M: "VALUE_DEFAULT_EUR_M_TO_M",

		FORMATTERPARAMETER_VALUE_BASE: "ValueBASE",
		FORMATTERPARAMETER_VALUE_K: "ValueAs_K",
		FORMATTERPARAMETER_VALUE_M: "ValueAs_M",

		CURRENCY_EUR: "EUR",
		CURRENCY_NOSIGN: "NOSIGN",

		FORMATOPTION_DEFAULT: "FORMATOPTION_DEFAULT",
		FORMATOPTION_VALUEONLY: "FORMATOPTION_VALUEONLY",

		MFS1: "month_s1",
		MFS2: "month_s2",
		MFS3: "month_s3",
		MFS4: "month_s4",
		MDFS1: "month_day_s1",
		MDFS2: "month_day_s5",
		MDFS3: "month_day_s6",
		YFS0: "year_s0",
		YFS1: "year_s1",
		YFS2: "year_s2",
		chartFormatter: null,

		_convertValue: function (fValue, sToValue, sFromValue) {
			// e.g: 12345, formatterParameterValueAs_K, (formatterParameterValueAsIs)

			var fResult = fValue;
			sFromValue = sFromValue || this.FORMATTERPARAMETER_VALUE_BASE;
			sToValue = sToValue || this.FORMATTERPARAMETER_VALUE_BASE;

			if (sFromValue !== sToValue) {
				// convert given value to base
				switch (sFromValue) {
				case this.FORMATTERPARAMETER_VALUE_M:
					fResult = fResult * 1000000;
					break;
				case this.FORMATTERPARAMETER_VALUE_K:
					fResult = fResult * 1000;
					break;
				case this.FORMATTERPARAMETER_VALUE_BASE:
				default:
					// dont change the value
				}

				// convert base value to target
				switch (sToValue) {
				case this.FORMATTERPARAMETER_VALUE_M:
					fResult = fResult / 1000000;
					break;
				case this.FORMATTERPARAMETER_VALUE_K:
					fResult = fResult / 1000;
					break;
				case this.FORMATTERPARAMETER_VALUE_BASE:
				default:
					// dont change the value
				}
			}

			return fResult;
		},

		_formatValue: function (fValue, sToValue, sCurrency, sFormatOption) {

			var absoluteFormatter = sap.ui.core.format.NumberFormat.getCurrencyInstance({
				style: 'Standard',
				maxFractionDigits: 0,
				minFractionDigits: 0,
				groupingEnabled: true,
				groupingSeparator: '.',
				decimalSeparator: ','
			});

			var relativeFormatter = sap.ui.core.format.NumberFormat.getCurrencyInstance({
				style: 'Standard',
				maxFractionDigits: 0,
				minFractionDigits: 0,
				groupingEnabled: true,
				groupingSeparator: '.',
				decimalSeparator: ','
			});

			sCurrency = sCurrency || this.CURRENCY_EUR; //default Currency is EUR
			sToValue = sToValue || this.FORMATTERPARAMETER_VALUE_BASE; //default is Base so no conversion will be performed
			sFormatOption = sFormatOption || this.FORMATOPTION_DEFAULT;
			var sCurrencySign = "";
			var sToValueToken = "";
			var sFormattedValue = "";

			// Get Currency
			switch (sCurrency) {
				//----------------------
				// add cases if needed
				//----------------------
			case this.CURRENCY_NOSIGN:
				sCurrencySign = "";
				break;
			case this.CURRENCY_EUR:
			default:
				sCurrencySign = "\u20ac";
			}

			// Get ToValue
			switch (sToValue) {
			case this.FORMATTERPARAMETER_VALUE_M:
				sToValueToken = "m";
				break;
			case this.FORMATTERPARAMETER_VALUE_K:
				sToValueToken = "k";
				break;
			case this.FORMATTERPARAMETER_VALUE_BASE:
			default:
				sToValueToken = "";
			}

			// Combine Elements
			switch (sFormatOption) {
			case this.FORMATOPTION_VALUEONLY:
				// Default format for MCS Dashboard
				if (absoluteFormatter.format(fValue) === "0")
					sFormattedValue = relativeFormatter.format(fValue);
				else
					sFormattedValue = absoluteFormatter.format(fValue);
				break;
				//----------------------
				// add alternative formats if needed
				//----------------------
			case this.FORMATOPTION_DEFAULT:
			default:
				// Default format for MCS Dashboard
				if (absoluteFormatter.format(fValue) === "0")
					sFormattedValue = sCurrencySign + relativeFormatter.format(fValue) + sToValueToken;
				else
					sFormattedValue = sCurrencySign + absoluteFormatter.format(fValue) + sToValueToken;
			}

			return sFormattedValue;
		},

		registerCustomFormat: function () {
			var chartFormatter = this.chartFormatter = ChartFormatter.getInstance();

			/**
			 * FORMAT: 123456 -> 123.456
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_CONVERT_BASE_TO_BASE,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_BASE, this.FORMATTERPARAMETER_VALUE_BASE);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_BASE, this.CURRENCY_NOSIGN, this.FORMATOPTION_VALUEONLY);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456 -> 123
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_CONVERT_BASE_TO_K,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_K, this.FORMATTERPARAMETER_VALUE_BASE);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_K, this.CURRENCY_NOSIGN, this.FORMATOPTION_VALUEONLY);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456 -> 0.1
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_CONVERT_BASE_TO_M,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_M, this.FORMATTERPARAMETER_VALUE_BASE);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_M, this.CURRENCY_NOSIGN, this.FORMATOPTION_VALUEONLY);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456k -> 123.456.000
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_CONVERT_K_TO_BASE,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_BASE, this.FORMATTERPARAMETER_VALUE_K);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_BASE, this.CURRENCY_NOSIGN, this.FORMATOPTION_VALUEONLY);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456 -> 123.000
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_CONVERT_K_TO_K,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_K, this.FORMATTERPARAMETER_VALUE_K);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_K, this.CURRENCY_NOSIGN, this.FORMATOPTION_VALUEONLY);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456 -> 123
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_CONVERT_K_TO_M,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_M, this.FORMATTERPARAMETER_VALUE_K);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_M, this.CURRENCY_NOSIGN, this.FORMATOPTION_VALUEONLY);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456m -> 123.456.000.000
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_CONVERT_M_TO_BASE,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_BASE, this.FORMATTERPARAMETER_VALUE_M);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_BASE, this.CURRENCY_NOSIGN, this.FORMATOPTION_VALUEONLY);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456m -> 123.456.000
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_CONVERT_M_TO_K,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_K, this.FORMATTERPARAMETER_VALUE_M);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_K, this.CURRENCY_NOSIGN, this.FORMATOPTION_VALUEONLY);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456 -> 123.456
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_CONVERT_M_TO_M,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_M, this.FORMATTERPARAMETER_VALUE_M);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_M, this.CURRENCY_NOSIGN, this.FORMATOPTION_VALUEONLY);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456 -> 123.456
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_NOSIGN_BASE_TO_BASE,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_BASE, this.FORMATTERPARAMETER_VALUE_BASE);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_BASE, this.CURRENCY_NOSIGN, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456 -> 123k
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_NOSIGN_BASE_TO_K,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_K, this.FORMATTERPARAMETER_VALUE_BASE);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_K, this.CURRENCY_NOSIGN, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456 -> 0.1m
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_NOSIGN_BASE_TO_M,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_M, this.FORMATTERPARAMETER_VALUE_BASE);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_M, this.CURRENCY_NOSIGN, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456k -> 123.456.000
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_NOSIGN_K_TO_BASE,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_BASE, this.FORMATTERPARAMETER_VALUE_K);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_BASE, this.CURRENCY_NOSIGN, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456k -> 123.456k
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_NOSIGN_K_TO_K,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_K, this.FORMATTERPARAMETER_VALUE_K);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_K, this.CURRENCY_NOSIGN, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456k -> 123m
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_NOSIGN_K_TO_M,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_M, this.FORMATTERPARAMETER_VALUE_K);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_M, this.CURRENCY_NOSIGN, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456m -> 123.456.000.000
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_NOSIGN_M_TO_BASE,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_BASE, this.FORMATTERPARAMETER_VALUE_M);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_BASE, this.CURRENCY_NOSIGN, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456m -> 123.456.000k
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_NOSIGN_M_TO_K,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_K, this.FORMATTERPARAMETER_VALUE_M);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_K, this.CURRENCY_NOSIGN, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456m -> 123.456m
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_NOSIGN_M_TO_M,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_M, this.FORMATTERPARAMETER_VALUE_M);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_M, this.CURRENCY_NOSIGN, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456 -> €123.456
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_EUR_BASE_TO_BASE,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_BASE, this.FORMATTERPARAMETER_VALUE_BASE);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_BASE, this.CURRENCY_EUR, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456 -> €123k
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_EUR_BASE_TO_K,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_K, this.FORMATTERPARAMETER_VALUE_BASE);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_K, this.CURRENCY_EUR, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456 -> €0.1m
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_EUR_BASE_TO_M,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_M, this.FORMATTERPARAMETER_VALUE_BASE);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_M, this.CURRENCY_EUR, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456k -> €123.456.000
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_EUR_K_TO_BASE,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_BASE, this.FORMATTERPARAMETER_VALUE_K);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_BASE, this.CURRENCY_EUR, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456k -> €123.456k
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_EUR_K_TO_K,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_K, this.FORMATTERPARAMETER_VALUE_K);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_K, this.CURRENCY_EUR, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456k -> €123m
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_EUR_K_TO_M,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_M, this.FORMATTERPARAMETER_VALUE_K);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_M, this.CURRENCY_EUR, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456m -> €123.456.000.000
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_EUR_M_TO_BASE,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_BASE, this.FORMATTERPARAMETER_VALUE_M);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_BASE, this.CURRENCY_EUR, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456m -> €123.456.000k
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_EUR_M_TO_K,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_K, this.FORMATTERPARAMETER_VALUE_M);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_K, this.CURRENCY_EUR, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			/**
			 * FORMAT: 123456m -> €123456m
			 */
			chartFormatter.registerCustomFormatter(this.VALUE_DEFAULT_EUR_M_TO_M,
				function (fValue) {
					var sResult = "";
					// value, (toValue, fromValue)
					sResult = this._convertValue(fValue, this.FORMATTERPARAMETER_VALUE_M, this.FORMATTERPARAMETER_VALUE_M);
					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(sResult, this.FORMATTERPARAMETER_VALUE_M, this.CURRENCY_EUR, this.FORMATOPTION_DEFAULT);
					return sResult;
				}.bind(this));

			chartFormatter.registerCustomFormatter(this.FIORI_VALUE_LOCALE_EURO,
				function (fValue) {

					var sResult = "";

					// value, (toValue, fromValue)
					sResult = this._convertValue(
						fValue,
						this.FORMATTERPARAMETER_VALUE_BASE);

					// value, (toValue, currency, formatoption)
					sResult = this._formatValue(
						sResult,
						this.FORMATTERPARAMETER_VALUE_BASE,
						this.CURRENCY_EUR,
						this.FORMATOPTION_DEFAULT);

					return sResult;

				}.bind(this));

			chartFormatter.registerCustomFormatter(this.FIORI_VALUE_LOCALE_EURO_K,
				function (value, sFromValue) {

					var absoluteFormatter = sap.ui.core.format.NumberFormat.getCurrencyInstance({
						style: 'Standard',
						maxFractionDigits: 0,
						minFractionDigits: 0,
						groupingEnabled: true,
						groupingSeparator: '.',
						decimalSeparator: '.'
					});

					value = this._convertValue(value, this.FORMATTERPARAMETER_VALUE_K, sFromValue || this.FORMATTERPARAMETER_VALUE_K);

					return "\u20ac" + absoluteFormatter.format(value) + "k";
				}.bind(this));

			chartFormatter.registerCustomFormatter(this.FIORI_VALUE_LOCALE_EURO_M,
				function (value, sFromValue) {

					var absoluteFormatter = sap.ui.core.format.NumberFormat.getCurrencyInstance({
						style: 'Standard',
						maxFractionDigits: 0,
						minFractionDigits: 0,
						groupingEnabled: true,
						groupingSeparator: '.',
						decimalSeparator: '.'
					});

					value = this._convertValue(value, this.FORMATTERPARAMETER_VALUE_M, sFromValue || this.FORMATTERPARAMETER_VALUE_M);

					return "\u20ac" + absoluteFormatter.format(value) + "M";
				}.bind(this));

			chartFormatter.registerCustomFormatter(this.FIORI_VALUE_LOCALE_EURO_NO_SIGNS,
				function (value) {

					var absoluteFormatter = sap.ui.core.format.NumberFormat.getCurrencyInstance({
						style: 'Standard',
						maxFractionDigits: 0,
						minFractionDigits: 0,
						groupingEnabled: true,
						groupingSeparator: '.',
						decimalSeparator: '.'
					});
					return absoluteFormatter.format(value);
				});

			chartFormatter.registerCustomFormatter(this.FIORI_LABEL_SHORTFORMAT_10,
				function (value) {
					var fixedInteger = sap.ui.core.format.NumberFormat.getIntegerInstance({
						style: "short",
						maxFractionDigits: 10
					});
					return fixedInteger.format(value);
				});
			chartFormatter.registerCustomFormatter(this.FIORI_LABEL_FORMAT_2,
				function (value) {
					var fixedFloat = sap.ui.core.format.NumberFormat.getFloatInstance({
						style: 'Standard',
						maxFractionDigits: 2
					});
					return fixedFloat.format(value);
				});
			chartFormatter.registerCustomFormatter(this.FIORI_LABEL_SHORTFORMAT_2,
				function (value) {
					var fixedInteger = sap.ui.core.format.NumberFormat.getIntegerInstance({
						style: "short",
						maxFractionDigits: 2
					});
					return fixedInteger.format(value);
				});
			chartFormatter.registerCustomFormatter(this.FIORI_PERCENTAGE_FORMAT_2,
				function (value) {
					var percentage = sap.ui.core.format.NumberFormat.getPercentInstance({
						style: 'precent',
						maxFractionDigits: 2
					});
					return percentage.format(value);
				});
			chartFormatter.registerCustomFormatter(this.FIORI_PERCENTAGE_FORMAT_2_PERCENTAGE_SIGN_ONLY,
				function (value) {
					return value +" %";
				});

			// chartFormatter.registerCustomFormatter(this.FIORI_VALUE_LOCALE_EURO_K,
			// 	function(value) {
			// 		var fixedFloat = sap.ui.core.format.NumberFormat.getFloatInstance({
			// 			style: 'Standard',
			// 			maxFractionDigits: 0
			// 		});
			// 		return "Euro " + fixedFloat.format(value) + " k";
			// 	});

			chartFormatter.registerCustomFormatter(this.FIORI_VALUE_INT_ROUND,
				function (value) {
					var fixedFloat = sap.ui.core.format.NumberFormat.getFloatInstance({
						style: 'Standard',
						maxFractionDigits: 0
					});
					return fixedFloat.format(value);
				});

			function registerTime(key, formatString) {
				chartFormatter.registerCustomFormatter(key, function (value) {
					var dateFormatter = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: formatString
					});
					return dateFormatter.format(value);
				});
			}
			var patterns = {
				"month_s1": "M",
				"month_s2": "MM",
				"month_s3": "MMM",
				"month_s4": "MMMM",
				"month_day_s1": 'MM/dd',
				"month_day_s5": 'MMM d',
				"month_day_s6": 'MMMM d',
				"year_s0": 'yy',
				"year_s1": 'yyy',
				"year_s2": 'yyyy',
				"YearMonthDay": "MM/dd/yy"
			};
			for (var key in patterns) {
				if (patterns.hasOwnProperty(key)) {
					registerTime(key, patterns[key]);
				}
			}
			Format.numericFormatter(chartFormatter);
		}
	};
});