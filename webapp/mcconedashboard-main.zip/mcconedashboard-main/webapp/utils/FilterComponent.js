sap.ui.define([
	"sap/ui/base/Object",
	"com/sap/mcconedashboard/control/CustomFacetFilterList",
	"com/sap/mcconedashboard/model/Constants",
	"sap/m/MessageToast",
	"com/sap/mcconedashboard/model/models",
	"com/sap/mcconedashboard/control/CustomDashboardTile",
	"com/sap/mcconedashboard/control/CustomDashboardTileItem",
	"com/sap/mcconedashboard/control/CustomFacetFilterListRegion",
	"sap/m/StandardListItem"
], function (UI5Object, CustomFacetFilterList, Constants, MessageToast, models, CustomDashboardTile, CustomDashboardTileItem,
	CustomFacetFilterListRegion, StandardListItem) {
	"use strict";
	return UI5Object.extend("com.sap.mcconedashboard.utils.FilterComponent", {
		constructor: function (oController) {
			this.oController = oController;
			this.oView = oController.getView();
			this.oTileModel = this.oController.getModel("tileModel"); //this.oView.getModel("tileModel");
			this.oTaskForcesModel = this.oController.getModel("taskForcesModel");
			this.oFacetFilter = this.oView.byId("idFacetFilter");
			this._initializeFacetFilter();
		},

		_initializeFacetFilter: function () {
			//FACET FILTER Rework 
			this._generateFilterEntryRegion("REGION_FLT", true); //Region filter, no data source
			this._generateFilterEntryMCCHANA("MCC_TAG_FLT", false); //MCC Tags with datasource in MCC Hana DB
			this._generateFilterEntry("COUNTRY_FLT", true); //Country
			this._generateFilterEntry("CUSTOMER_FLT", false); // Customer 
			this._generateFilterEntry("MASTER_CODE_FLT", false); // customer segment
			this._generateFilterEntry("GLOBAL_ULTIMATE_FLT", false); // Global Ultimate 
			this._generateFilterEntry("PRODUCT_CATEGORY_FLT", false); //Product Category
			this._generateFilterEntry("PRODUCT_LINE_FLT", true); // Product Line
			this._generateFilterEntry("PRODUCT_FLT", false); // Product
			this._generateFilterEntry("PRODUCTVERSION_FLT", false); // Product Version
			this._generateFilterEntry("SALES_ORG_FLT", false); //Sales Org
			this._generateFilterEntry("SERVICE_ORG_FLT", false); //Service Org

		},

		_generateFilterEntry: function (sFilterName, bActive) {
			var oMainModel = this.oController.getOwnerComponent().getModel("mainModelNoBatch");
			//General Filter Creation
			var aFilters = [
				new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, sFilterName)
			];
			var oSorter = new sap.ui.model.Sorter({
				path: "ValueText",
				descending: false
			});
			var bGrowing = sFilterName === "COUNTRY_FLT";
			if (sFilterName === "SERVICE_ORG_FLT") {
				aFilters.push(new sap.ui.model.Filter("ValueText", sap.ui.model.FilterOperator.EQ, "Sols-"));
			} else {
				aFilters.push(new sap.ui.model.Filter("ValueText", sap.ui.model.FilterOperator.EQ, ""));
			}


			var filterListValuesFilters = new sap.ui.model.Filter(aFilters.filter(Boolean), true);

			var customFilterList = new CustomFacetFilterList(this.oView.createId("id" + sFilterName), {
				title: this.getResourceBundle().getText("filterList" + sFilterName),
				key: "{value_key}",
				growing: bGrowing,
				growingScrollToLoad: bGrowing,
				growingThreshold: 300,
				enableCaseInsensitiveSearch: true,
				listOpen: function (oEv) {
					if (oEv.getSource().getTitle() === "Service Org") {
						var oList = oEv.getSource();
						var aFilters = [
							new sap.ui.model.Filter("FilterName", sap.ui.model.FilterOperator.EQ, sFilterName)
						];
						aFilters.push(new sap.ui.model.Filter("ValueText", sap.ui.model.FilterOperator.EQ, "Sols-"));
						var filterListValuesFilters = new sap.ui.model.Filter(aFilters.filter(Boolean), true);
						var filterListBinding = oList.getBinding("items");
						filterListBinding.filter(filterListValuesFilters);
						filterListBinding.sort(oSorter);
					}
				}.bind(this),
				//FACET FILTER REwork 
				active: bActive,
				listClose: [this._setFilter, this],
				items: {
					path: "/GenericFilterSet",
					template: new sap.m.FacetFilterItem({
						text: "{ValueText}",
						key: "{ValueKey}"
					})
				}
			});

			oMainModel.iSizeLimit = 100;
			customFilterList.setModel(oMainModel);
			var filterListBinding = customFilterList.getBinding("items");
			filterListBinding.filter(filterListValuesFilters);
			filterListBinding.sort(oSorter);
			customFilterList.attachUpdateFinished(function (event) {
				this._checkNumber(event);
			}.bind(this));

			this.oFacetFilter.addList(customFilterList);
		},
		_generateFilterEntryRegion: function (sFilterName, bActive) {
			var oRegionModel = new sap.ui.model.json.JSONModel({
				"regions": [{
					"id": "WORLD",
					"name": this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonglobal")
				}, {
					"id": "APJ",
					"name": this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonapj")
				}, {
					"id": "EMEA_NORTH",
					"name": this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonemea_north")
				}, {
					"id": "EMEA_SOUTH",
					"name": this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonemea_south")
				}, {
					"id": "GTC",
					"name": this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttongtc")
				}, {
					"id": "LAC",
					"name": this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonlac")
				}, {
					"id": "MEE",
					"name": this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonmee")
				}, {
					"id": "NA",
					"name": this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonna")
				}]
			});
			this.oController.getOwnerComponent().setModel(oRegionModel, "regionFilterModel");

			var oFacetFilterListRegion = new CustomFacetFilterListRegion(this.oView.createId("id" + sFilterName), {
				title: this.getResourceBundle().getText("filterList" + sFilterName),
				key: "region",
				growing: false,
				enableCaseInsensitiveSearch: true,
				selectionChange: function (oEv) {
					if (oEv.getSource().getSelectedItems().length === 0) {
						oEv.getSource().setSelectedKeys(JSON.parse('{"WORLD":"World"}'));
					} else if (oEv.getParameter("listItem").getKey() === "WORLD") {
						if (oEv.getParameter("selected")) {
							oEv.getSource().setSelectedKeys(JSON.parse('{"WORLD":"World"}'));
						} else {
							oEv.getSource().removeSelectedKey(JSON.parse('{"WORLD":"World"}'));
						}
					} else if (oEv.getSource().getSelectedItems().length > 1 && oEv.getSource().getSelectedItems().filter(function (e) {
						return e.getProperty("key") === 'WORLD';
					}).length > 0) {
						oEv.getSource().removeSelectedKey("WORLD", "World");
					}
				},
				listOpen: function (oEvent) {
					// Preventing the internal behavior FacetFilter control
					oEvent.preventDefault();
					// if (!oEvent.getSource().getSelectedKeys().lenght) {
					// 	oEvent.getSource().setSelectedKeys(JSON.parse('{"WORLD":"World"}'));
					// }
				}.bind(this),
				listClose: [this._setFilter, this],
				//search: this._handleTagSearch,
				active: bActive,
				showRemoveFacetIcon: false,
				items: {
					path: "/regions",
					template: new sap.m.FacetFilterItem({
						text: "{name}",
						key: "{id}"
					})
				}
			});
			oFacetFilterListRegion.setModel(oRegionModel);
			//set the default selection of the Region to WORLD
			oFacetFilterListRegion.setSelectedKeys(JSON.parse('{"WORLD":"World"}'));
			// var filterListTaggingBinding = oFacetFilterListTagging.getBinding("items");
			// filterListTaggingBinding.filter(filterListValuesFilters);
			oFacetFilterListRegion.attachUpdateFinished(function (event) {
				this._checkNumber(event);
			}.bind(this));

			this.oFacetFilter.addList(oFacetFilterListRegion);
		},
		_generateFilterEntryMCCHANA: function (sFilterName, bActive) {
			var oSubModel = this.oController.getOwnerComponent().getModel("subModel");
			//General Filter Creation
			var dToday = new Date();
			var aFilters = [];
			// we decided to show for subscriptions and facet filters all active MCC Tags aFilters.push(new sap.ui.model.Filter("ShowInOneDashboard", sap.ui.model.FilterOperator.EQ, true));
			aFilters.push(new sap.ui.model.Filter([
				new sap.ui.model.Filter("DateFrom", sap.ui.model.FilterOperator.LE, dToday),
				new sap.ui.model.Filter("DateTo", sap.ui.model.FilterOperator.GE, dToday)
			], true));

			//aFilters.push(new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.EQ, sKey));
			var filterListValuesFilters = new sap.ui.model.Filter(aFilters.filter(Boolean), true);

			var oFacetFilterListTagging = new sap.m.FacetFilterList(this.oView.createId("id" + sFilterName), {
				title: this.getResourceBundle().getText("filterList" + sFilterName),
				key: "mccTag",
				growing: false,
				enableCaseInsensitiveSearch: true,
				listOpen: function (oEvent) {
					// Preventing the internal behavior FacetFilter control
					oEvent.preventDefault();
				}.bind(this),
				listClose: [this._setFilter, this],
				search: this._handleTagSearch,
				active: bActive,
				items: {
					path: "/MCCTags",
					template: new sap.m.FacetFilterItem({
						text: "{Name} - {Description}",
						key: "{Name}"
					})
				}
			});
			oFacetFilterListTagging.setModel(oSubModel);
			// if (sCurrentViewContext !== "GLOBAL") {
			// 	oFacetFilterListTagging.addStyleClass("MCCOneHidden")
			// }
			var filterListTaggingBinding = oFacetFilterListTagging.getBinding("items");
			filterListTaggingBinding.filter(filterListValuesFilters);
			oFacetFilterListTagging.attachUpdateFinished(function (event) {
				this._checkNumber(event);
			}.bind(this));

			this.oFacetFilter.addList(oFacetFilterListTagging);
		},
		_handleTagSearch: function (oEvent) {
			// Preventing the internal filtering behavior FacetFilter control
			oEvent.preventDefault();

			var oFacetFilterList = oEvent.getSource(),
				sSearchString = oEvent.getParameter("term"),
				//standard SAPUI5 implementation 
				sEncodedString = "'" + String(sSearchString).toLowerCase().replace(/'/g, "''") + "'",
				bClearButtonPressed = oEvent.getParameter("clearButtonPressed"),
				// Define filter to be used for resetting the current list state or another one for searching through the list items
				oFilter = bClearButtonPressed ? new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, "") : new sap.ui.model.Filter(
					"tolower(Name)", sap.ui.model.FilterOperator.Contains,
					sEncodedString);

			if (oFacetFilterList.isBound("items")) {
				// Items are already bound and we apply the filtering
				oFacetFilterList.getBinding("items").filter(oFilter, sap.ui.model.FilterType.Application);
			}
		},

		_setFilter: function (oEvent, bVariantNotChanged) {
			var oFilterModel = this.oView.getModel("filterModel");
			var oFacetFilter = this.oFacetFilter;
			//if a filter Value has been set/removed, the updated filter should be set up
			var oFilterForICP = this._getFilterModel(oFacetFilter, "ICP");
			var oFilterForICPwithouthTags = this._getFilterModel(oFacetFilter, "ICP_WO_TAGS");
			var oFilterForICPGlobalEscalRequests = this._getFilterModel(oFacetFilter, "ICP_GER");
			var oFilterForBCP = this._getFilterModel(oFacetFilter, "BCP");
			var oFilterForMCS = this._getFilterModel(oFacetFilter, "MCS");
			//	var oFilterForBD = this._getFilterModel(oFacetFilter, "BD");
			var oFilterForOutages = this._getFilterModel(oFacetFilter, "Outages");
			var oFilterForServiceNow = this._getServiceNowFilterProperties(oFacetFilter);
			var oFilterForServiceNowForCPC = this._getServiceNowFilterPropertiesForCPC(oFacetFilter);
			var oFilterForMissionRadarCC = this._getMissionRadarCCFilterProperties(oFacetFilter);
			var oFilterForMissionRadarGoLives = this._getMissionRadarGoLiveFilterProperties(oFacetFilter);
			var oFilterForMissionRadarGoLivesFromMCC = this._getMissionRadarGoLiveFromMCCFilterProperties(oFacetFilter);
			var oFilterForProjectsOnWatch = this._getFilterModel(oFacetFilter, "MCCObjects");
			var oFilterForCriticalEventCoverage = this._getFilterModel(oFacetFilter, "CEC");
			//var oFilterForProjectsOnWatch = this._getProjectsOnWatchFilterProperties(oFacetFilter);
			var oFilterModelForICPwithoutSalesOrgServiceOrg = this._getFilterModel(oFacetFilter, "ICP_WO_SalesO_ServiceO");
			var oFilterForBWCost = this._getFilterModel(oFacetFilter, "BWP");
			var oFilterModelICPforCustomerVisits = this._getFilterModel(oFacetFilter, "ICP");

			//if filter changed set flag to reload data after tab changed
			this._reloadExecutiveInformation = true;
			this._reloadMccEngagements = true;
			this._reloadAffectedSolutions = true;
			this._reloadInitiatives = true;

			if (oEvent && oEvent.getSource().getTitle() === this.getResourceBundle().getText("filterList" + "REGION_FLT")) {
				//set RegionString:
				var sRegionTmp = "",
					sRegionTextTmp = "";
				oEvent.getSource().getSelectedItems().forEach(function (item, idx) {
					if (item.getKey() === "WORLD") {
						return;
					}
					if (idx > 0) {
						sRegionTmp += ",";
						sRegionTextTmp += ",";
					}
					sRegionTmp += item.getKey();
					sRegionTextTmp += item.getText();
				});
				oFilterModel.setProperty("/region", sRegionTmp);
				oFilterModel.setProperty("/regionText", sRegionTextTmp);
			}

			// Check, if there are any filters for ICP or BCP and if so call the oData Service
			//it should be enought to check for the ICP filter, because that one should always be filled, if some filters are selected in the facet filter
			if (oFilterForICP && oFilterForICP.aFilters && oFilterForICP.aFilters.length > 0) { //if (!jQuery.isEmptyObject(oSelectedKey)) {
				oFilterModel.setProperty("/oFilterModelICP", oFilterForICP);
				oFilterModel.setProperty("/oFilterModelICPforCustomerVisits", oFilterModelICPforCustomerVisits);
				oFilterModel.setProperty("/oFilterModelForICPwithoutSalesOrgServiceOrg", oFilterModelForICPwithoutSalesOrgServiceOrg);
				oFilterModel.setProperty("/oFilterModelICPWOTAGS", oFilterForICPwithouthTags);
				oFilterModel.setProperty("/oFilterModelICPGER", oFilterForICPGlobalEscalRequests);
				oFilterModel.setProperty("/oFilterModelBCP", oFilterForBCP);
				oFilterModel.setProperty("/oFilterModelMCS", oFilterForMCS);
				//oFilterModel.setProperty("/oFilterModelBD", oFilterForBD);
				oFilterModel.setProperty("/oFilterForServiceNow", oFilterForServiceNow);
				oFilterModel.setProperty("/oFilterForServiceNowForCPC", oFilterForServiceNowForCPC);
				oFilterModel.setProperty("/oFilterForMissionRadarCC", oFilterForMissionRadarCC);
				oFilterModel.setProperty("/oFilterForMissionRadarGoLives", oFilterForMissionRadarGoLives);
				oFilterModel.setProperty("/oFilterForMissionRadarGoLivesFromMCC", oFilterForMissionRadarGoLivesFromMCC);
				oFilterModel.setProperty("/oFilterForProjectsOnWatch", oFilterForProjectsOnWatch);
				oFilterModel.setProperty("/oFilterForCriticalEventCoverage", oFilterForCriticalEventCoverage);
				oFilterModel.setProperty("/oFilterForCriticalPeriodCoverage", oFilterForProjectsOnWatch);

				oFilterModel.setProperty("/oFilterForOutages", oFilterForOutages);
				oFilterModel.setProperty("/oFilterForBWCosts", oFilterForBWCost);
				this.setFaceFilterSelection(oFacetFilter);

				//otherwise call the oData Services without any specific FacetFilter restriction
			} else {
				oFilterModel.setProperty("/oFilterModelICP", null);
				oFilterModel.setProperty("/oFilterModelICPforCustomerVisits", null);
				oFilterModel.setProperty("/oFilterModelForICPwithoutSalesOrgServiceOrg", null);
				oFilterModel.setProperty("/oFilterModelICPWOTAGS", null);
				oFilterModel.setProperty("/oFilterModelICPGER", null);
				oFilterModel.setProperty("/oFilterModelBCP", null);
				oFilterModel.setProperty("/oFilterModelMCS", null);
				//oFilterModel.setProperty("/oFilterModelBD", null);
				oFilterModel.setProperty("/facetFilterSelection", null);
				oFilterModel.setProperty("/oFilterForServiceNow", null);
				oFilterModel.setProperty("/oFilterForServiceNowForCPC", null);
				oFilterModel.setProperty("/oFilterForMissionRadarCC", null);
				oFilterModel.setProperty("/oFilterForMissionRadarGoLives", null);
				oFilterModel.setProperty("/oFilterForMissionRadarGoLivesFromMCC", null);
				oFilterModel.setProperty("/oFilterForProjectsOnWatch", null);
				oFilterModel.setProperty("/oFilterForCriticalPeriodCoverage", null);
				oFilterModel.setProperty("/oFilterForOutages", null);
				oFilterModel.setProperty("/oFilterForBWCosts", []);
				this.setFaceFilterSelection(oFacetFilter);
			}

			//wait for authorization set in component
			this.oController.getOwnerComponent().authorityPromise.then(function (layers) {
				this._updateTileNumbers(layers);

				//Update MCS Charts
				if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInChartsTile")) {
					if (this.oController.getOwnerComponent().getModel("KPICases")) {
						this.readCases();
						//this.readCasesNoFiltersApply();
						this.readCasesBWKPI(true);
					}
				}

				//Update OperationalKPITile  
				if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInOperationalKPITile")) {
					if (this.oController.getModel("OperationalInformationModel")) {
						this.oController.readCases(this.oController.getModel("OperationalInformationModel"));
					}
				}

			}.bind(this));

			if (!bVariantNotChanged) {
				this.oView.byId("filterVariantManagement").currentVariantSetModified(true);
			}
		},

		_getOutagesFilterProperties: function (oFacetFilter) {

		},

		_getServiceNowFilterProperties: function (oFacetFilter) {
			var mFacetFilterLists = oFacetFilter.getLists().filter(function (oList) {
				return oList.getSelectedItems().length;
			});
			var aFilter = [];
			var sTmp = "";
			var iLength = 0;
			var sFilterProp = "";
			if (mFacetFilterLists.length) {
				mFacetFilterLists.forEach(function (filter) {
					sTmp = "";
					iLength = filter.getSelectedItems().length;

					switch (filter.getTitle()) {
						case "Product Category":
							sFilterProp = "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id";
							break;
						case "Product Line":
							sFilterProp = "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id";
							break;
						case "Product":
							sFilterProp = "u_task_record.u_install_base_item.u_product.model_number";
							break;
						case "Product Version":
							sFilterProp = "u_task_record.u_install_base_item.u_product_version.model_number";
							break;
						case "Customer":
							sFilterProp = "u_task_record.account.number";
							break;
						case "Country":
							sFilterProp = "u_task_record.account.country";
							break;
					}

					if (sFilterProp !== "") {
						filter.getSelectedItems().forEach(function (item, idx) {
							sTmp += sFilterProp + "=" + item.getKey();
							if ((idx + 1) < iLength) {
								sTmp += "^OR";
							}
						});
						sFilterProp = "";
						aFilter.push(sTmp);
					}
				});
			}
			return aFilter;
		},

		_getServiceNowFilterPropertiesForCPC: function (oFacetFilter) {
			var mFacetFilterLists = oFacetFilter.getLists().filter(function (oList) {
				return oList.getSelectedItems().length;
			});
			var aFilter = [];
			var sTmp = "";
			var iLength = 0;
			var sFilterProp = "";
			if (mFacetFilterLists.length) {
				mFacetFilterLists.forEach(function (filter) {
					sTmp = "";
					iLength = filter.getSelectedItems().length;

					switch (filter.getTitle()) {
						case "Product Category":
							sFilterProp = "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_category_id";
							break;
						case "Product Line":
							sFilterProp = "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id";
							break;
						case "Product":
							sFilterProp = "u_task_record.u_install_base_item.u_product.model_number";
							break;
						case "Product Version":
							sFilterProp = "u_task_record.u_install_base_item.u_product_version.model_number";
							break;
						case "Customer":
							sFilterProp = "u_task_record.account.number";
							break;
						case "Country":
							sFilterProp = "u_customer_3.country";
							break;
					}

					if (sFilterProp !== "") {
						filter.getSelectedItems().forEach(function (item, idx) {
							sTmp += sFilterProp + "=" + item.getKey();
							if ((idx + 1) < iLength) {
								sTmp += "^OR";
							}
						});
						sFilterProp = "";
						aFilter.push(sTmp);
					}
				});
			}
			return aFilter;
		},

		_getMissionRadarCCFilterProperties: function (oFacetFilter) {
			var mFacetFilterLists = oFacetFilter.getLists().filter(function (oList) {
				return oList.getSelectedItems().length;
			});
			var aFilter = [];
			var sTmp = "";
			var iLength = 0;
			var sFilterProp = "";
			if (mFacetFilterLists.length) {
				mFacetFilterLists.forEach(function (filter) {
					sTmp = "";
					iLength = filter.getSelectedItems().length;

					switch (filter.getTitle()) {
						case "Customer":
							sFilterProp = "ERP_Account";
							break;
						case "Global Ultimate":
							sFilterProp = "Global_Ultimate";
							break;
						case "Country":
							sFilterProp = "Country";
							break;
						case "Customer Segment":
							sFilterProp = "Master_Code";
							break;
					}

					if (sFilterProp !== "" && sFilterProp !== "Master_Code" && sFilterProp !== "Country" && sFilterProp !== "Global_Ultimate") {
						filter.getSelectedItems().forEach(function (item, idx) {
							sTmp += sFilterProp + "=" + item.getKey();
							if ((idx + 1) < iLength) {
								sTmp += "^OR";
							}
						});
						sFilterProp = "";
						aFilter.push(sTmp);
					} else if (sFilterProp == "Master_Code" || sFilterProp == "Country") {
						filter.getSelectedItems().forEach(function (item, idx) {
							sTmp += sFilterProp + "=" + item.getText();
							if ((idx + 1) < iLength) {
								sTmp += "^OR";
							}
						});
						sFilterProp = "";
						aFilter.push(sTmp);
					} else if (sFilterProp == "Global_Ultimate") {
						filter.getSelectedItems().forEach(function (item, idx) {
							var text = item.getText();
							var match = text.match(/\((\d+)\)/);
							if (match && match[1]) {
								sTmp += sFilterProp + "=" + match[1];
							}
							if ((idx + 1) < iLength) {
								sTmp += "^OR";
							}
						});
						sFilterProp = "";
						aFilter.push(sTmp);
					}


				});
			}
			return aFilter;
		},

		_getMissionRadarGoLiveFilterProperties: function (oFacetFilter) {
			var mFacetFilterLists = oFacetFilter.getLists().filter(function (oList) {
				return oList.getSelectedItems().length;
			});
			var aFilter = [];
			var sTmp = "";
			var iLength = 0;
			var sFilterProp = "";
			if (mFacetFilterLists.length) {
				mFacetFilterLists.forEach(function (filter) {
					sTmp = "";
					iLength = filter.getSelectedItems().length;

					switch (filter.getTitle()) {
						case "Customer":
							sFilterProp = "Customer_ERP_ID";
							break;
						case "Country":
							sFilterProp = "Country_Code";
							break;
						case "Global Ultimate":
							sFilterProp = "Customer_Global_Ultimate";
							break;
					}

					if (sFilterProp !== "" && sFilterProp !== "Country" && sFilterProp !== "Customer_Global_Ultimate") {
						filter.getSelectedItems().forEach(function (item, idx) {
							sTmp += sFilterProp + "=" + item.getKey();
							if ((idx + 1) < iLength) {
								sTmp += "^OR";
							}
						});
						sFilterProp = "";
						aFilter.push(sTmp);
					} else if (sFilterProp == "Customer_Global_Ultimate") {
						filter.getSelectedItems().forEach(function (item, idx) {
							var text = item.getText();
							var match = text.match(/\((\d+)\)/); // Regular expression to extract number within parentheses
							var number = match ? match[1] : ""; // Extracted number
							sTmp += sFilterProp + "=" + number;
							if ((idx + 1) < iLength) {
								sTmp += "^OR";
							}
						});
						sFilterProp = "";
						aFilter.push(sTmp);
					} else if (sFilterProp == "Country_Code") {
						filter.getSelectedItems().forEach(function (item, idx) {
							sTmp += sFilterProp + "=" + item.getText();
							if ((idx + 1) < iLength) {
								sTmp += "^OR";
							}
						});
						sFilterProp = "";
						aFilter.push(sTmp);
					}

				});
			}
			return aFilter;
		},

		_getMissionRadarGoLiveFromMCCFilterProperties: function (oFacetFilter) {
			var mFacetFilterLists = oFacetFilter.getLists().filter(function (oList) {
				return oList.getSelectedItems().length;
			});
			var aFilter = [];
			var sTmp = "";
			var iLength = 0;
			var sFilterProp = "";
			if (mFacetFilterLists.length) {
				mFacetFilterLists.forEach(function (filter) {
					sTmp = "";
					iLength = filter.getSelectedItems().length;

					switch (filter.getTitle()) {
						case "Customer":
							sFilterProp = "Customer_ERP_Account";
							break;
						case "Country":
							sFilterProp = "Country_Code";
							break;
						case "Global Ultimate":
							sFilterProp = "Global_Ultimate";
							break;
					}

					if (sFilterProp !== "" && sFilterProp !== "Country_Code") {
						filter.getSelectedItems().forEach(function (item, idx) {
							sTmp += sFilterProp + "=" + item.getKey();
							if ((idx + 1) < iLength) {
								sTmp += "^OR";
							}
						});
						sFilterProp = "";
						aFilter.push(sTmp);
					} else if (sFilterProp == "Country_Code") {
						filter.getSelectedItems().forEach(function (item, idx) {
							sTmp += sFilterProp + "=" + item.getKey();
							if ((idx + 1) < iLength) {
								sTmp += "^OR";
							}
						});
						sFilterProp = "";
						aFilter.push(sTmp);
					}
				});
			}
			return aFilter;
		},



		_formatBWValues: function (sFilterProperty, oFilterValue) {
			if (!oFilterValue)
				return null;

			var finalValue = oFilterValue;
			//for BWP values: Sales Org and Service Org filters must be provided without the leading "O "
			//e.g 'O 50139984' --> '50139984'
			if (sFilterProperty === "A4MCASEX017CRM_SALORG" || sFilterProperty === "A4MCASEX017CRM_SRVORG") {
				finalValue = oFilterValue.substring(2);
			}
			if (sFilterProperty === "A4MCASEX017CSM_DELU" && oFilterValue === "ONPREM") {
				finalValue = "";
			}

			return finalValue;
		},

		_formatMCCObjectValues: function (sFilterProperty, oItem) {
			if (!oItem)
				return null;

			var finalValue = oItem;

			switch (sFilterProperty) {
				case "CustomerID":
					finalValue = parseInt(oItem.getKey(), 10); //Remove leading zeros
					break;
				case "CustomerCountry":
					finalValue = oItem.getText(); //We need the full name for MCCObjects Country
					break;
				/* Now handled in POWController
				case "Region":
					if (oItem.getKey() == "EMEA_NORTH" || oItem.getKey() == "EMEA_SOUTH") {
						finalValue = "EMEA";
					} else {
						finalValue = oItem.getKey();
					}
					break; */
			}

			return finalValue;
		},


		_getFilterModel: function (oFacetFilter, sSystem) {
			var mFacetFilterLists = oFacetFilter.getLists().filter(function (oList) {
				return oList.getSelectedItems().length;
			});

			if (mFacetFilterLists.length) {
				// Build the nested filter with ORs between the values of each group and
				// ANDs between each group
				var that = this;
				//	var sSalesRegion = this.oView.getModel("filterModel").getProperty("/region");

				var oFilter = new sap.ui.model.Filter(mFacetFilterLists.filter(function (oList) {
					//return !(oList.getTitle() === "Sales Org" && sSystem === "BCP");
					// if ((oList.getTitle() === "Sales Org" && sSystem === "BCP") || (oList.getTitle() === "Service Org" && sSystem === "BCP")) {
					// 	return false;
					// } else 

					if (sSystem === "MCS" && (oList.getTitle().startsWith("MCC Tag"))) {
						return false;
					} else if (sSystem === "BWP" && (oList.getTitle() === "Region" || oList.getTitle().startsWith("MCC Tag"))) {
						return false;
					} else if (sSystem === "ICP_WO_TAGS" && (oList.getTitle().startsWith("MCC Tag"))) {
						return false;
					} else if (sSystem === "ICP_WO_SalesO_ServiceO" && (oList.getTitle().startsWith("Service Org") || oList.getTitle().startsWith("Sales Org"))) {
						return false;
					} else if (sSystem === "MCCObjects" && (oList.getTitle() === "Region" || oList.getTitle() === "Global Ultimate" || oList.getTitle() ===
						"Product Category" || oList.getTitle() === "Product Line" || oList.getTitle() === "Product" || oList.getTitle() ===
						"Product Version" || oList.getTitle() === "Sales Org" || oList.getTitle() === "Service Org" || oList.getTitle().startsWith(
							"MCC Tag"))) {
						return false;
					} else if (sSystem === "CEC" && (oList.getTitle() === "Region" || oList.getTitle() === "Country" || oList.getTitle() === "Customer" || oList.getTitle() === "Global Ultimate" || oList.getTitle() ===
						"Product Category" || oList.getTitle() === "Product Line" || oList.getTitle() ===
						"Product Version" || oList.getTitle() === "Sales Org" || oList.getTitle() === "Service Org")) {
						return false;
					} else if (sSystem === "Outages" && (oList.getTitle() === "Global Ultimate" || oList.getTitle() ===
						"Product Category" || oList.getTitle() === "Product Line" || oList.getTitle() === "Product" || oList.getTitle() ===
						"Product Version" || oList.getTitle() === "Sales Org" || oList.getTitle() === "Service Org" || oList.getTitle().startsWith(
							"MCC Tag"))) {
						return false;
						//Global Escalataion Request does not have any Product information attached	
					} else if (sSystem === "ICP_GER" && (oList.getTitle() === that.getResourceBundle().getText("filterList" + "PRODUCT_FLT") ||
						oList.getTitle() === that.getResourceBundle()
							.getText("filterList" + "PRODUCT_LINE_FLT") || oList.getTitle() === that.getResourceBundle()
								.getText("filterList" + "PRODUCTVERSION_FLT") || oList.getTitle() === that.getResourceBundle().getText("filterList" +
									"PRODUCT_CATEGORY_FLT"))) {
						return false;
					} else if (oList.getTitle() === "Region" && oList.getSelectedItems().filter(function (e) {
						return e.getProperty("key") === 'WORLD';
					}).length > 0 && (sSystem === "ICP" || sSystem === "ICP_WO_TAGS" || sSystem === "ICP_GER" || sSystem === "ICP_WO_SalesO_ServiceO")) {
						return false;
					} else {
						return true;
					}
				}).map(function (oList) {
					return new sap.ui.model.Filter(oList.getSelectedItems().map(function (oItem) {
						var sFilterKey = "";
						if (oList.getTitle() === "Customer") {
							if (sSystem === "ICP" || sSystem === "ICP_GER" || sSystem === "ICP_WO_TAGS" || sSystem === "ICP_WO_SalesO_ServiceO") {
								sFilterKey = "CustomerErpNo";
							} else if (sSystem === "Outages") {
								sFilterKey = "CustomerERPID";
							} else if (sSystem === "BWP") {
								sFilterKey = "A4MCASEX017CUSTOMER";
							} else if (sSystem === "MCS") {
								sFilterKey = "customer_erp_no";
							} else if (sSystem === "MCCObjects") {
								sFilterKey = "CustomerID";
							} else {
								sFilterKey = "ErpCustNo";
							}
						} else if (oList.getTitle() === "Global Ultimate") {
							if (sSystem === "ICP" || sSystem === "ICP_GER" || sSystem === "ICP_WO_TAGS" || sSystem === "ICP_WO_SalesO_ServiceO") {
								sFilterKey = "GuErpNo";
							} else if (sSystem === "BWP") {
								sFilterKey = "A4MCASEX017GU_CUSTOMER";
							} else if (sSystem === "MCS") {
								sFilterKey = "gu_erp_no";
							} else {
								sFilterKey = "GlobalUltimate";
							}
						} else if (oList.getTitle() === "Sales Org") {
							if (sSystem === "ICP" || sSystem === "ICP_GER" || sSystem === "ICP_WO_TAGS" || sSystem === "BCP") {
								sFilterKey = "SalesOrg";
							} else if (sSystem === "MCS") {
								sFilterKey = "sales_org";
							} else if (sSystem === "BWP") {
								sFilterKey = "A4MCASEX017CRM_SALORG";
							}
						} else if (oList.getTitle() === "Service Org") {
							if (sSystem === "ICP" || sSystem === "ICP_GER" || sSystem === "ICP_WO_TAGS" || sSystem === "BCP") {
								sFilterKey = "ServiceOrg";
							} else if (sSystem === "MCS") {
								sFilterKey = "service_org";
							} else if (sSystem === "BWP") {
								sFilterKey = "A4MCASEX017CRM_SRVORG";
							}
						} else if (oList.getTitle() === that.getResourceBundle().getText("filterList" + "PRODUCT_FLT")) {
							if (sSystem === "ICP" || sSystem === "ICP_WO_TAGS" || sSystem === "ICP_WO_SalesO_ServiceO") {
								sFilterKey = "Product";
								return new sap.ui.model.Filter(sFilterKey, "EQ", oItem.getKey());
							} else if (sSystem === "MCS") {
								sFilterKey = "product_no";
							} else if (sSystem === "BWP") {
								sFilterKey = "A4MCASEX017PPMSPID";
							} else if (sSystem === "CEC") {
								sFilterKey = "ProductID";
							} else {
								sFilterKey = "Product";
							}
						} else if (oList.getTitle() === that.getResourceBundle().getText("filterList" + "PRODUCT_CATEGORY_FLT")) {
							if (sSystem === "ICP" || sSystem === "ICP_WO_TAGS" || sSystem === "ICP_WO_SalesO_ServiceO") {
								sFilterKey = "ProductCat";
								return new sap.ui.model.Filter(sFilterKey, "EQ", oItem.getKey());
							} else if (sSystem === "MCS") {
								sFilterKey = "product_category";
								return new sap.ui.model.Filter(sFilterKey, "EQ", oItem.getKey());
							} else if (sSystem === "BWP") {
								sFilterKey = "A4MCASEX017PPMSCATE";
							} else {
								sFilterKey = "ProductCat";
							}
						} else if (oList.getTitle() === that.getResourceBundle().getText("filterList" + "PRODUCTVERSION_FLT")) {
							if (sSystem === "ICP" || sSystem === "ICP_WO_TAGS" || sSystem === "ICP_WO_SalesO_ServiceO") {
								sFilterKey = "ProductVersion";
								return new sap.ui.model.Filter(sFilterKey, "EQ", oItem.getKey());
							} else if (sSystem === "MCS") {
								sFilterKey = "product_version_no";
							} else if (sSystem === "BWP") {
								sFilterKey = "A4MCASEX017PPMSVER";
							} else {
								sFilterKey = "ProductVersion";
							}
						} else if (oList.getTitle() === that.getResourceBundle().getText("filterList" + "PRODUCT_LINE_FLT")) {
							if (sSystem === "ICP" || sSystem === "ICP_WO_TAGS" || sSystem === "ICP_WO_SalesO_ServiceO") {
								sFilterKey = "ProductLine";
								return new sap.ui.model.Filter(sFilterKey, "EQ", oItem.getKey());
							} else if (sSystem === "MCS") {
								sFilterKey = "product_line";
							} else if (sSystem === "BWP") {
								sFilterKey = "A4MCASEX017PPMSPRLN";
							} else {
								sFilterKey = "ProductLine";
							}
						} else if (oList.getTitle() === that.getResourceBundle().getText("filterList" + "MASTER_CODE_FLT")) {
							if (sSystem === "ICP" || sSystem === "ICP_GER" || sSystem === "ICP_WO_TAGS" || sSystem === "ICP_WO_SalesO_ServiceO") {
								sFilterKey = "MasterCode";
							} else if (sSystem === "MCS") {
								sFilterKey = "master_code";
							} else if (sSystem === "Outages") {
								sFilterKey = "CustomerIndustryCode";
							} else if (sSystem === "BWP") {
								sFilterKey = "A4MCASEX017MP_PMASTERC";
							} else {
								sFilterKey = "CustSegm";
							}
						} else if (oList.getTitle() === that.getResourceBundle().getText("filterList" + "COUNTRY_FLT")) {
							if (sSystem === "MCS") {
								sFilterKey = "country";
							} else if (sSystem === "Outages") {
								sFilterKey = "F_AddressCountryCode";
							} else if (sSystem === "BWP") {
								sFilterKey = "A4MCASEX017MP_0COUNTRY";
							} else if (sSystem === "MCCObjects") {
								sFilterKey = "CustomerCountry";
							} else {
								sFilterKey = "Country";
							}

						} else if (oList.getTitle() === that.getResourceBundle().getText("filterList" + "REGION_FLT")) {
							if (sSystem === "ICP" || sSystem === "ICP_GER" || sSystem === "ICP_WO_TAGS" || sSystem === "ICP_WO_SalesO_ServiceO") {
								sFilterKey = "Region";
							} else if (sSystem === "Outages") {
								sFilterKey = "CustomerGlobalRegionCode";
							} else if (sSystem === "MCS") {
								sFilterKey = "region";
							} else {
								sFilterKey = "Region";
							}

						} else if (oList.getTitle().startsWith("MCC Tag")) {
							if (sSystem === "ICP" || sSystem === "ICP_WO_SalesO_ServiceO") {
								sFilterKey = "CaseTag";
							} else if (sSystem === "MCCObjects") {
								sFilterKey = "MCCTag";
							} else {
								sFilterKey = "MCCTag";
							}
						}
						var sKey = oItem.getKey();
						if (sSystem === "BWP") {
							sKey = that._formatBWValues(sFilterKey, sKey);
						}
						if (sSystem === "MCCObjects") {
							sKey = that._formatMCCObjectValues(sFilterKey, oItem);
						}
						return new sap.ui.model.Filter(sFilterKey, "EQ", sKey);
					}), false);
				}), true);
				return oFilter;
			} else {
				return [];
			}
		},

		/*
		 * Method to synchronise facet Filter in different views
		 * Get all selected items and build the needed object and set it to the Filtermodel 
		 */
		setFaceFilterSelection: function (oFaceFilter) {
			var aLists = oFaceFilter.getLists();
			var oFilterModel = this.oView.getModel("filterModel");
			var oObject = {};
			var oFacetFilterDisplay = {
				customers: [],
				globalUltimates: [],
				salesOrgs: [],
				products: [],
				productCategories: [],
				productLines: [],
				productVersions: [],
				customerSegments: [],
				serviceTeams: [],
				serviceOrgs: [],
				countries: [],
				regions: [],
				mccTags: []
			};
			aLists.forEach(function (oList) {

				var sListId = oList.getId();
				var oSelectedKeys = {};
				var aSelectedKeysDisplay = [];
				var aSelectedItems = oList.getSelectedItems();
				aSelectedItems.forEach(function (oSelectedItem) {
					var sKey = oSelectedItem.getKey();
					var sText = oSelectedItem.getText();
					var oHelper = {};
					oSelectedKeys[sKey] = sText;
					oHelper.key = sKey;
					oHelper.text = sText;
					aSelectedKeysDisplay.push(oHelper);
				});
				if (sListId.lastIndexOf("idCUSTOMER_FLT") > -1) {
					oObject.customer = oSelectedKeys;
					oFacetFilterDisplay.customers = aSelectedKeysDisplay;
				} else if (sListId.lastIndexOf("idGLOBAL_ULTIMATE_FLT") > -1) {
					oObject.globalUltimate = oSelectedKeys;
					oFacetFilterDisplay.globalUltimates = aSelectedKeysDisplay;
				} else if (sListId.lastIndexOf("idSALES_ORG_FLT") > -1) {
					oObject.salesOrg = oSelectedKeys;
					oFacetFilterDisplay.salesOrgs = aSelectedKeysDisplay;
				} else if (sListId.lastIndexOf("idSERVICE_ORG_FLT") > -1) {
					oObject.serviceOrg = oSelectedKeys;
					oFacetFilterDisplay.serviceOrgs = aSelectedKeysDisplay;
				} else if (sListId.lastIndexOf("idPRODUCT_FLT") > -1) {
					oObject.product = oSelectedKeys;
					oFacetFilterDisplay.products = aSelectedKeysDisplay;
				} else if (sListId.lastIndexOf("idPRODUCT_CATEGORY_FLT") > -1) {
					oObject.productCategory = oSelectedKeys;
					oFacetFilterDisplay.productCategories = aSelectedKeysDisplay;
				} else if (sListId.lastIndexOf("idPRODUCT_LINE_FLT") > -1) {
					oObject.productLine = oSelectedKeys;
					oFacetFilterDisplay.productLines = aSelectedKeysDisplay;
				} else if (sListId.lastIndexOf("idMASTER_CODE_FLT") > -1) {
					oObject.customerSegment = oSelectedKeys;
					oFacetFilterDisplay.customerSegments = aSelectedKeysDisplay;
				} else if (sListId.lastIndexOf("idSERVICE_TEAM_FLT") > -1) {
					oObject.serviceTeam = oSelectedKeys;
					oFacetFilterDisplay.serviceTeams = aSelectedKeysDisplay;
				} else if (sListId.lastIndexOf("idPRODUCTVERSION_FLT") > -1) {
					oObject.productVersion = oSelectedKeys;
					oFacetFilterDisplay.productVersions = aSelectedKeysDisplay;
				} else if (sListId.lastIndexOf("idCOUNTRY_FLT") > -1) {
					oObject.country = oSelectedKeys;
					oFacetFilterDisplay.countries = aSelectedKeysDisplay;
				} else if (sListId.lastIndexOf("idREGION_FLT") > -1) {
					oObject.region = oSelectedKeys;
					oFacetFilterDisplay.region = aSelectedKeysDisplay;
				} else if (sListId.lastIndexOf("idMCC_TAG_FLT") > -1) {
					oObject.mccTags = oSelectedKeys;
					oFacetFilterDisplay.mccTags = aSelectedKeysDisplay;
				}
			});

			oFilterModel.setProperty("/facetFilterSelection", oObject);
			oFilterModel.setProperty("/facetFilterSelectionDisplay", oFacetFilterDisplay);

			this.oFacetFilter.rerender();
		},

		/*
		 * After navigation synchronisation of facet filter selection takes place
		 * Facet filter selection is stored in filter model and needs to be set to the appropriate filter lists
		 */
		syncFacetFilters: function (oFaceFilterSelection, bIsInitial) {
			this.oFacetFilter.getLists().forEach(function (oList) {
				var sListId = oList.getId();
				if (sListId.lastIndexOf("idCUSTOMER_FLT") > -1) {
					if (!bIsInitial && oFaceFilterSelection) {
						oList.setSelectedKeys(oFaceFilterSelection.customer);
					}
					if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInOperationalKPITile")) {
						oList.setActive(false);
					} else if (oList.getSelectedItems().length > 0) {
						oList.setActive(true);
					} else {
						oList.setActive(false);
					}
				} else if (sListId.lastIndexOf("idGLOBAL_ULTIMATE_FLT") > -1) {
					if (!bIsInitial && oFaceFilterSelection) {
						oList.setSelectedKeys(oFaceFilterSelection.globalUltimate);
					}
					if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInOperationalKPITile")) {
						oList.setActive(false);
					} else if (oList.getSelectedItems().length > 0) {
						oList.setActive(true);
					} else {
						oList.setActive(false);
					}
				} else if (sListId.lastIndexOf("idSALES_ORG_FLT") > -1) {
					if (!bIsInitial && oFaceFilterSelection) {
						oList.setSelectedKeys(oFaceFilterSelection.salesOrg);
					}
					if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInOperationalKPITile")) {
						oList.setActive(false);
					} else if (oList.getSelectedItems().length > 0) {
						oList.setActive(true);
					} else {
						oList.setActive(false);
					}
				} else if (sListId.lastIndexOf("idSERVICE_ORG_FLT") > -1) {
					if (!bIsInitial && oFaceFilterSelection) {
						oList.setSelectedKeys(oFaceFilterSelection.serviceOrg);
					}
					if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInOperationalKPITile")) {
						oList.setActive(false);
					} else if (oList.getSelectedItems().length > 0) {
						oList.setActive(true);
					} else {
						oList.setActive(false);
					}
				} else if (sListId.lastIndexOf("idPRODUCT_FLT") > -1) {
					if (!bIsInitial && oFaceFilterSelection) {
						oList.setSelectedKeys(oFaceFilterSelection.product);
					}
					if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInOperationalKPITile")) {
						oList.setActive(false);
					} else if (oList.getSelectedItems().length > 0) {
						oList.setActive(true);
					} else {
						oList.setActive(false);
					}
				} else if (sListId.lastIndexOf("idPRODUCT_CATEGORY_FLT") > -1) {
					if (!bIsInitial && oFaceFilterSelection) {
						oList.setSelectedKeys(oFaceFilterSelection.productCategory);
					}
					if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInOperationalKPITile")) {
						oList.setActive(false);
					} else if (oList.getSelectedItems().length > 0) {
						oList.setActive(true);
					} else {
						oList.setActive(false);
					}
				} else if (sListId.lastIndexOf("idPRODUCT_LINE_FLT") > -1) {
					if (!bIsInitial && oFaceFilterSelection) {
						oList.setSelectedKeys(oFaceFilterSelection.productLine);
					}
					if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInOperationalKPITile")) {
						oList.setActive(false);
					} else {
						oList.setActive(true);
					}
				} else if (sListId.lastIndexOf("idMASTER_CODE_FLT") > -1) {
					if (!bIsInitial && oFaceFilterSelection) {
						oList.setSelectedKeys(oFaceFilterSelection.customerSegment);
					}
					if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInOperationalKPITile")) {
						oList.setActive(false);
					} else if (oList.getSelectedItems().length > 0) {
						oList.setActive(true);
					} else {
						oList.setActive(false);
					}
				} else if (sListId.lastIndexOf("idSERVICE_TEAM_FLT") > -1) {
					if (!bIsInitial && oFaceFilterSelection) {
						oList.setSelectedKeys(oFaceFilterSelection.serviceTeam);
					}
					if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInOperationalKPITile")) {
						oList.setActive(false);
					} else if (oList.getSelectedItems().length > 0) {
						oList.setActive(true);
					} else {
						oList.setActive(false);
					}
				} else if (sListId.lastIndexOf("idCOUNTRY_FLT") > -1) {
					if (!bIsInitial && oFaceFilterSelection) {
						oList.setSelectedKeys(oFaceFilterSelection.country);
					}
					if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInOperationalKPITile")) {
						oList.setActive(false);
					} else {
						oList.setActive(true);
					}
				} else if (sListId.lastIndexOf("idREGION_FLT") > -1) {
					if (!bIsInitial && oFaceFilterSelection) {
						oList.setSelectedKeys(oFaceFilterSelection.region);
					}
				} else if (sListId.lastIndexOf("idMCC_TAG_FLT") > -1) {
					if (!bIsInitial && oFaceFilterSelection) {
						oList.setSelectedKeys(oFaceFilterSelection.mccTags);
					}
					if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInOperationalKPITile")) {
						oList.setTitle(this.getResourceBundle().getText("filterListMCC_TAG_FLT"));
						oList.setActive(false);
						oList.setVisible(false);
						//	this.oView.byId("idMCC_TAG_FLT").addStyleClass("MCCOneHidden");
					} else if (this.oController.getOwnerComponent().getModel("settings").getProperty("/isInChartsTile")) {
						oList.setTitle(this.getResourceBundle().getText("filterListMCC_TAG_FLT") + " - not supported");
						oList.setActive(false);
						oList.setVisible(false);
						//this.oView.byId("idMCC_TAG_FLT").addStyleClass("MCCOneHidden");
					} else if (oList.getSelectedItems().length > 0) {
						oList.setTitle(this.getResourceBundle().getText("filterListMCC_TAG_FLT"));
						oList.setActive(true);
						oList.setVisible(true);
						//	this.oView.byId("idMCC_TAG_FLT").removeStyleClass("MCCOneHidden");
					} else {
						oList.setTitle(this.getResourceBundle().getText("filterListMCC_TAG_FLT"));
						oList.setActive(false);
						oList.setVisible(true);
					}
				}
			}.bind(this));

			this.oFacetFilter.rerender();

			// var oFiltersModel = this.oController.getOwnerComponent().getModel("filterModel");
			// var sSalesRegion = oFiltersModel.getProperty("/region");
			// var that = this;
			// if (sSalesRegion === "" || sSalesRegion === "WORLD") {
			// 	this.oView.byId("regionContainer").getItems().forEach(function (item) {
			// 		item.setSelected(false);
			// 	});
			// 	this.oView.byId("regionContainer").getItems()[0].setSelected(true);
			// } else {
			// 	this.oView.byId("regionContainer").getItems().forEach(function (item) {
			// 		//item.setSelected(sSalesRegion.indexOf(item.getText()) > -1);
			// 		item.setSelected(sSalesRegion.indexOf(that.oController.formatter.formatRegionNameToRegionCode(item.getText())) > -1);
			// 	});
			// }

			//set selected "Saved Filter Variant"
			if (this.oController.getOwnerComponent().getModel("settings").getProperty("/selectedFilterVariant")) {
				this.oView.byId("filterVariantManagement")._setSelectedItem(this.oController.getOwnerComponent().getModel("settings").getProperty(
					"/selectedFilterVariant"));
			} else {
				//if nothing is set, then the filter has been deleted - in that case reset to standard
				this.oView.byId("filterVariantManagement").clearVariantSelection();
			}
			this._setFilter(null, true);
		},

		_checkNumber: function (oEvent) {
			// Not needed in "Refresh" case (reason)
			if (oEvent.getParameter("reason") === "Filter") {
				if (oEvent.getParameter("actual") === 100) {
					// oEvent.getSource().getParent()._showFooterInfo();
					// If typing is fireing the event, the parent is not the facetFilter ? -> workaround
					if (this.oView.byId(oEvent.getSource().getAssociation("facetFilter"))) {
						this.oView.byId(oEvent.getSource().getAssociation("facetFilter"))._showFooterInfo();
					}
				} else {
					if (this.oView.byId(oEvent.getSource().getAssociation("facetFilter"))) {
						this.oView.byId(oEvent.getSource().getAssociation("facetFilter"))._removeFooterInfo();
					}
				}
			}
		},

		_tabSelectionChange: function (sKey) {
			if (sKey === "executiveInfo") {
				this._loadExecutiveInformation();
			} else if (sKey === "mccEngagements") {
				this._loadMccEngagements();
			} else if (sKey === "mccTags") {
				this._loadInitiatives();
			} else if (sKey === "affectedSolutions") {
				this._loadAffectedSolutions();
			}
		},

		_loadExecutiveInformation: function () {
			this._setTileFilterIcons();
			var oFilterModel = this.oView.getModel("filterModel");
			var sRegion = oFilterModel.getProperty("/region");
			var oFilterForServiceNow = oFilterModel.getProperty("/oFilterForServiceNow");
			var oFilterForMCS = oFilterModel.getProperty("/oFilterModelMCS");
			var oFilterForBWCost = oFilterModel.getProperty("/oFilterForBWCosts");
			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			var oFilterForOutages = oFilterModel.getProperty("/oFilterForOutages");

			if (this._reloadExecutiveInformation) {
				this._reloadExecutiveInformation = false;
				this._getAmountBusinessDowns(sRegion, oFilterForServiceNow);
				this._getOngoingCustomerEscalations(oFilterForMCS);
				this._getTotalCustomerEscalationCosts(sRegion, oFilterForBWCost);
				this._getAmountGlobalEscalationsSet(oFilterForICP);
				this._getAmoutTopCriticalCustomers(oFilterForICP);
				var oOutagesModel = this.oController.getOwnerComponent().getModel("outageMainModel");
				oOutagesModel.metadataLoaded(true).then(
					function () {
						// model is ready now
						this._getAmountOutagesSet(oFilterForOutages, oOutagesModel);
					}.bind(this),
					function () {
						this.oTileModel.setProperty("/outagesState", "Loaded");
						this.oTileModel.setProperty("/outagesClosedState", "Loaded");
					}.bind(this)
				);
			}

		},

		_loadMccEngagements: function () {
			this._setTileFilterIcons();
			var oFilterModel = this.oView.getModel("filterModel");
			var sRegion = oFilterModel.getProperty("/region");
			var oFilterForServiceNow = oFilterModel.getProperty("/oFilterForServiceNow");
			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			var oFilterForICPwithoutSalesOrgServiceOrg = oFilterModel.getProperty("/oFilterModelForICPwithoutSalesOrgServiceOrg");
			var oFilterForProjectsOnWatch = oFilterModel.getProperty("/oFilterForProjectsOnWatch");
			var oFilterEventPeriodCoverage = oFilterModel.getProperty("/oFilterForCriticalPeriodCoverage");
			var oFilterForICPwithouthTags = oFilterModel.getProperty("/oFilterModelICPWOTAGS");
			var oFilterForCriticalEventCoverage = oFilterModel.getProperty("/oFilterForCriticalEventCoverage");

			if (this._reloadMccEngagements) {
				this._reloadMccEngagements = false;
				this._getAmountPECriticalSituations(sRegion, oFilterForServiceNow);
				this._getAmount_xTec(sRegion, oFilterForServiceNow);
				this._getAmountCriticalSituationsSet(oFilterForICP);
				this._getAmountGlobalEscalationsSet(oFilterForICP);
				this._getAmountEngagementTaskForces(oFilterForICP);
				this._getAmoutCriticalPeriodCoverage(oFilterForICP);
				this._getAmoutTopCriticalCustomers(oFilterForICP);
				this._getAmountProjectsOnWatch(oFilterForProjectsOnWatch);
				this._getAmountCustomerVisits(oFilterForICPwithoutSalesOrgServiceOrg);
				this._getAmoutCriticalEventCoverage(oFilterForCriticalEventCoverage);
				this._getAmountCim(sRegion, oFilterForServiceNow);
				this._getAmountCreEngagements(oFilterEventPeriodCoverage);
				this._getAmountCrossIssuesSet(oFilterForICPwithouthTags);
				this._getAmountBusinessDowns(sRegion, oFilterForServiceNow);
			}
		},

		_loadAffectedSolutions: function () {
			this._setTileFilterIcons();
			var oFilterModel = this.oView.getModel("filterModel");
			var sRegion = oFilterModel.getProperty("/region");
			var oFilterForMCS = oFilterModel.getProperty("/oFilterModelMCS");
			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			var oFilterForICPwithouthTags = oFilterModel.getProperty("/oFilterModelICPWOTAGS");
			var oFilterForServiceNow = oFilterModel.getProperty("/oFilterForServiceNow");
			if (this._reloadAffectedSolutions) {
				this._reloadAffectedSolutions = false;
				this._getAmountSolutions(sRegion, oFilterForMCS, oFilterForICP, oFilterForICPwithouthTags, oFilterForServiceNow);
			}

		},

		_loadInitiatives: function () {
			this._setTileFilterIcons();
			var oFilterModel = this.oView.getModel("filterModel");
			var oFilterForICP = oFilterModel.getProperty("/oFilterModelICP");
			var oFilterForMCS = oFilterModel.getProperty("/oFilterModelMCS");
			if (this._reloadInitiatives) {
				this._reloadInitiatives = false;
				this._getAmountProductEscalationSet(oFilterForMCS);
				this._getAmountTaskForces(oFilterForICP);
			}
		},

		_updateTileNumbers: function (layers, sTabName) {
			var bIsMobile = this.oController.getOwnerComponent().getModel("settings").getProperty("/isMobileMode");
			var sKey;
			if (bIsMobile) {
				this._loadExecutiveInformation();
				this._loadMccEngagements();
				this._loadInitiatives();
				this._loadAffectedSolutions();
			} else {
				if (this.oView.byId("globalIconTabBar")) {
					sKey = this.oView.byId("globalIconTabBar").getSelectedKey();
				} else if (sTabName) {
					sKey = sTabName;
				}

				if (sKey === "executiveInfo" && !layers.layer3) {
					this.oView.byId("globalIconTabBar").setSelectedKey("mccEngagements");
					sKey = "mccEngagements";
				}
				//load only data for current tab
				if (sKey === "executiveInfo" && layers.layer3) {
					this._loadExecutiveInformation();
				} else if (sKey === "mccEngagements" && layers.layer2) {
					this._loadMccEngagements();
				} else if (sKey === "mccTags" && layers.layer2) {
					this._loadInitiatives();
				} else if (sKey === "affectedSolutions" && layers.layer2) {
					this._loadAffectedSolutions();
				}
			}
		},

		_setTileFilterIcons: function () {
			var oTileModel = this.oTileModel;
			var oFilterModel = this.oView.getModel("filterModel");
			var oFilter = oFilterModel.getProperty("/facetFilterSelectionDisplay");
			var sRegion = oFilterModel.getProperty("/region");
			var sIconFilter = "sap-icon://filter";
			var sIconNotFilter = "sap-icon://clear-filter";

			//first reset all icons
			oTileModel.setProperty("/businessDownFilterIcon", sIconFilter);
			oTileModel.setProperty("/critIncidentsFilterIcon", sIconFilter);
			oTileModel.setProperty("/mccCasesFilterIcon", sIconFilter);
			oTileModel.setProperty("/globalEscalationsFilterIcon", sIconFilter);
			oTileModel.setProperty("/taskForcesFilterIcon", sIconFilter);
			oTileModel.setProperty("/globalEscRequestsFilterIcon", sIconFilter);
			oTileModel.setProperty("/criticalPeriodCoverageIcon", sIconFilter);
			oTileModel.setProperty("/taskForcesIcon", sIconFilter);
			oTileModel.setProperty("/outagesFilterIcon", sIconFilter);
			oTileModel.setProperty("/topCriticalCustomersIcon", sIconFilter);
			oTileModel.setProperty("/customerVisitsIconIcon", sIconFilter);
			oTileModel.setProperty("/criticalEventCoverageIcon", sIconFilter);
			oTileModel.setProperty("/creIcon", sIconFilter);
			oTileModel.setProperty("/projectsOnWatchIcon", sIconFilter);
			oTileModel.setProperty("/missionRadarIcon", sIconFilter);
			oTileModel.setProperty("/crossIssuesIcon", sIconFilter);
			oTileModel.setProperty("/solutionsFilterIcon", sIconFilter);
			oTileModel.setProperty("/cimsFilterIcon", sIconFilter);
			oTileModel.setProperty("/topTenHighCostFilterIcon", sIconFilter);
			oTileModel.setProperty("/prodEscaFilterIcon", sIconFilter);
			oTileModel.setProperty("/peCriticalSituationFilterIcon", sIconFilter);

			if (oFilter.salesOrgs.length > 0 || oFilter.serviceOrgs.length > 0 || oFilter.customerSegments.length > 0 || oFilter.globalUltimates
				.length > 0 || oFilter.mccTags.length > 0) {
				oTileModel.setProperty("/solutionsFilterIcon", sIconNotFilter);
			}

			if (oFilter.products.length > 0 || oFilter.productCategories.length > 0 || oFilter.productLines.length > 0 || oFilter.productVersions
				.length > 0 || oFilter.mccTags.length > 0) {
				oTileModel.setProperty("/globalEscRequestsFilterIcon", sIconNotFilter);
			}

			if (oFilter.customerSegments.length > 0 || oFilter.globalUltimates.length > 0 || oFilter.serviceOrgs.length > 0 || oFilter.salesOrgs
				.length > 0 || oFilter.mccTags.length > 0) {
				oTileModel.setProperty("/cimsFilterIcon", sIconNotFilter);
				oTileModel.setProperty("/businessDownFilterIcon", sIconNotFilter);
				oTileModel.setProperty("/peCriticalSituationFilterIcon", sIconNotFilter);
			}

			if (oFilter.globalUltimates.length > 0 || oFilter.productCategories.length > 0 || oFilter.productLines
				.length > 0 || oFilter.products.length > 0 || oFilter.productVersions.length > 0 || oFilter.salesOrgs.length > 0 || oFilter.serviceOrgs
					.length > 0 || oFilter.mccTags.length > 0) {
				oTileModel.setProperty("/outagesFilterIcon", sIconNotFilter);
				oTileModel.setProperty("/projectsOnWatchIcon", sIconNotFilter);
			}

			//Nothing but Product + MCC Tag
			if (oFilter.globalUltimates.length > 0 || oFilter.productCategories.length > 0 || oFilter.productLines
				.length > 0 || oFilter.customerSegments.length > 0 || oFilter.productVersions.length > 0 || oFilter.salesOrgs.length > 0 || oFilter.serviceOrgs
					.length > 0 || oFilter.countries.length > 0 || oFilter.customers.length > 0 || oFilter.regions.length > 0 || oFilter.region[0].key !== "WORLD" || oFilter.serviceTeams.length > 0) {
				oTileModel.setProperty("/criticalEventCoverageIcon", sIconNotFilter);
			}

			if (oFilter.mccTags.length > 0) {
				oTileModel.setProperty("/topTenHighCostFilterIcon", sIconNotFilter);
				oTileModel.setProperty("/crossIssuesIcon", sIconNotFilter);
				oTileModel.setProperty("/prodEscaFilterIcon", sIconNotFilter);
			}

			//reset icons if no filter selected
			if (sRegion === "" && oFilter.customerSegments.length === 0 && oFilter.customers.length === 0 && oFilter.globalUltimates.length ===
				0 && oFilter.productCategories.length === 0 && oFilter.productLines.length === 0 && oFilter.productVersions.length === 0 &&
				oFilter.products.length === 0 && oFilter.salesOrgs.length === 0 && oFilter.serviceOrgs.length === 0 && oFilter.countries.length ===
				0 && oFilter.mccTags.length === 0) {
				oTileModel.setProperty("/businessDownFilterIcon", null);
				oTileModel.setProperty("/critIncidentsFilterIcon", null);
				oTileModel.setProperty("/mccCasesFilterIcon", null);
				oTileModel.setProperty("/globalEscalationsFilterIcon", null);
				oTileModel.setProperty("/taskForcesFilterIcon", null);
				oTileModel.setProperty("/globalEscRequestsFilterIcon", null);
				oTileModel.setProperty("/criticalPeriodCoverageIcon", null);
				oTileModel.setProperty("/taskForcesIcon", null);
				oTileModel.setProperty("/topCriticalCustomersIcon", null);
				oTileModel.setProperty("/customerVisitsIconIcon", null);
				oTileModel.setProperty("/criticalEventCoverageIcon", null);
				oTileModel.setProperty("/creIcon", null);
				oTileModel.setProperty("/projectsOnWatchIcon", null);
				oTileModel.setProperty("/missionRadarIcon", null);
				oTileModel.setProperty("/crossIssuesIcon", null);
				oTileModel.setProperty("/outagesFilterIcon", null);
				oTileModel.setProperty("/solutionsFilterIcon", null);
				oTileModel.setProperty("/cimsFilterIcon", null);
				oTileModel.setProperty("/topTenHighCostFilterIcon", null);
				oTileModel.setProperty("/prodEscaFilterIcon", null);
				oTileModel.setProperty("/peCriticalSituationFilterIcon", null);


			}

			oTileModel.refresh();
		},

		_getAmountSolutions: function (sRegion, oFilterForMCS, oFilterForICP, oFilterForICPwithouthTags, oFilterForServiceNow) {

			var oSettings = this.oController.getOwnerComponent().getModel("settings").getData();

			//if authoritySet is not yet loadrd, call method until it is
			if (!oSettings.dataLoaded || !this.oView.getModel("solutions")) {
				var that = this;
				setTimeout(function () {
					that._getAmountSolutions(sRegion, oFilterForMCS, oFilterForICP, oFilterForICPwithouthTags, oFilterForServiceNow);
				}, 200);
				return null;
			}

			var aSolutions = this.oView.getModel("solutions").getData();

			aSolutions.forEach(function (solution) {
				solution.busy = true;
				var aPromises = [];
				var aProductLines = this._getProdLinesFromSolution(solution);

				var oTaskForcesPromise = new Promise(function (resolve) {
					var aFilters = [];
					var tmpFilter = oFilterForICP;
					var oFinalFilter = this.oController._getCombinedSolutionFilter(tmpFilter, aProductLines, "ProductLine");

					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false)
					],
						true
					);
					oFinalFilter.push(tileSpecificFilters);
					oFinalFilter.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP07"));

					oFinalFilter.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

					var oICModel = this.oController.getOwnerComponent().getModel();

					oICModel.read("/CustomerEngagementSet/$count", {
						filters: [new sap.ui.model.Filter(oFinalFilter, true)],
						//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
						success: function (data) {
							resolve(parseInt(data, 10));
						}.bind(this),
						error: function () {
							resolve(0);
						}
					});
				}.bind(this));
				aPromises.push(oTaskForcesPromise);

				//in case of anonymized mode, no Cross Issues should be retunrned
				if (oSettings.isAnonymizedMode === false) {
					var oCrossIssuesPromise = new Promise(function (resolve) {

						var tmpFilter = oFilterForICPwithouthTags;
						var oFinalFilter = this.oController._getCombinedSolutionFilter(tmpFilter, aProductLines, "ProductLine");

						var tileSpecificFilters = new sap.ui.model.Filter([
							new sap.ui.model.Filter([
								new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0010"),
								new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0011"),
								new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0016")
							], false)
						],
							true
						);
						oFinalFilter.push(tileSpecificFilters);

						//set SoldToParty ID dependent on system
						var currentUrl = window.location.href;
						var sSoldToParty = currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") ? "4699754" : "20672944";
						oFinalFilter.push(new sap.ui.model.Filter("SoldToParty", sap.ui.model.FilterOperator.EQ, sSoldToParty));

						var oICModel = this.oController.getOwnerComponent().getModel();

						oICModel.read("/CrossIssueSet/$count", {
							filters: [new sap.ui.model.Filter(oFinalFilter, true)],
							//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
							success: function (data) {
								resolve(parseInt(data, 10));
							}.bind(this),
							error: function () {
								resolve(0);
							}
						});
					}.bind(this));
					aPromises.push(oCrossIssuesPromise);
				}

				var oBusinessDownPromise = new Promise(function (revolve) {
					// var oFacetFilter = null;

					// if (oFilterForBusinessDown && oFilterForBusinessDown.aFilters.length > 0) {
					// 	var tmpFilter = oFilterForBusinessDown;
					// 	oFacetFilter = this.oController._mapFacetFiltersForBusinessDowns(tmpFilter);
					// }

					// var oFinalFilter = this.oController._getCombinedSolutionFilter(oFacetFilter, aProductLines, "product_line" );

					// var tileSpecificFilters = new sap.ui.model.Filter([
					// 		new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "20"),
					// 		new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "30"),
					// 		new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "40")
					// 	],
					// 	false
					// );

					// oFinalFilter.push(tileSpecificFilters);

					// oFinalFilter.push(new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP02"));

					// var oMCSModel = this.oView.getModel("mcsModel");

					// oMCSModel.metadataLoaded(true).then(
					// 	function () {
					// 		oMCSModel.read("/MCSDashboardSet/$count", {
					// 			filters: oFinalFilter,
					// 			success: function (data) {
					// 				solution.counterBDM = parseInt(data, 10);
					// 				revolve(parseInt(data, 10));
					// 			}.bind(this),
					// 			error: function (data) {
					// 				revolve(0);
					// 			}.bind(this)
					// 		});
					// 	},
					// 	function () {
					// 		revolve(0);
					// 	});

					var sFilterString =
						"sysparm_query=state=101^u_escalation_type=0^u_request_reason=8^ORu_request_reason=9";

					if (sRegion) {
						var sRegionFilterString = "^",
							sRegionEMEAFilterString = "",
							bBothEMEAFiltersSelected = false;
						sRegion.split(",").forEach(function (region, i) {
							//For Service Now we need to implement EMEA_North and EMEA_South differently, because it is not implmeneted yet
							//we need to take the specific countries instead
							//Moreover we need to take care, that it is still working together with the other region filters like MEE and NA
							if (region === "EMEA_NORTH") {
								if (bBothEMEAFiltersSelected) {
									sRegionEMEAFilterString += "^OR";
								} else if (!sRegionFilterString.endsWith("^OR")) {
									sRegionEMEAFilterString += "^";
								}
								sRegionEMEAFilterString += Constants.emeaNorthCountries;
								bBothEMEAFiltersSelected = true;
								//e.g. %5eu_task_record.account.country=AL%5eORu_task_record.account.country=DZ
							} else if (region === "EMEA_SOUTH") {
								if (bBothEMEAFiltersSelected) {
									sRegionEMEAFilterString += "^OR";
								} else if (!sRegionFilterString.endsWith("^OR")) {
									sRegionEMEAFilterString += "^";
								}
								sRegionEMEAFilterString += Constants.emeaSouthCountries;
								bBothEMEAFiltersSelected = true;
								//e.g. %5eu_task_record.account.country=AL%5eORu_task_record.account.country=DZ
							} else {
								sRegionFilterString += "u_task_record.account.u_region=" + region;
								if (i < (sRegion.split(",").length - 1)) {
									sRegionFilterString += "^OR";
								}
							}
						});
						if (sRegionEMEAFilterString !== "" && sRegionFilterString !== "^") {
							sRegionFilterString = sRegionFilterString + sRegionEMEAFilterString.replace("^", "^OR"); // we need to add an OR, because the countries need to be handled as an OR related to the region filter in this specific case, It should not be an AND
						} else if (sRegionEMEAFilterString !== "") {
							sRegionFilterString = sRegionEMEAFilterString;
						}
						sFilterString += sRegionFilterString;
					}

					var prodLineVariable = "u_task_record.u_install_base_item.u_product.u_product_line_id.u_product_line_id";
					var aFilter = this.oController._getCombinedSolutionFilterCims(oFilterForServiceNow, aProductLines, prodLineVariable);

					if (aFilter && aFilter.length > 0) {
						aFilter.forEach(function (filter) {
							sFilterString += "^" + filter;
						});
					}

					sFilterString = sFilterString.replaceAll("^", "%5e");
					//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
					if (sFilterString.startsWith("%5esysparm_query")) {
						sFilterString.replace("%5esysparm_query", "sysparm_query");
					}

					sFilterString += "&sysparm_count=true";

					$.ajax({
						method: "GET",
						contentType: "application/json",
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						success: function (oData) {
							if (oData.result && oData.result.stats && oData.result.stats.count) {
								solution.counterBDM = parseInt(oData.result.stats.count, 10);
								revolve(parseInt(oData.result.stats.count, 10));
							} else {
								revolve(0);
							}
						}.bind(this),
						error: function (err) {
							revolve(0);
						}.bind(this)
					});

				}.bind(this));
				aPromises.push(oBusinessDownPromise);

				var oCriticalCustomerManagementPromise = new Promise(function (revolve) {

					var tmpFilter = oFilterForICP;
					var oFinalFilter = this.oController._getCombinedSolutionFilter(tmpFilter, aProductLines, "ProductLine");

					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"), new sap.ui.model.Filter(
							"Status", sap.ui.model.FilterOperator.EQ, "80"), new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
						new sap
							.ui.model.Filter(
								"Status", sap.ui.model.FilterOperator.EQ, "99")
						], false)
					],
						true
					);
					oFinalFilter.push(tileSpecificFilters);

					oFinalFilter.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP05"));

					var oICModel = this.oController.getOwnerComponent().getModel();
					oICModel.metadataLoaded(true).then(
						function () {
							oFinalFilter.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
							oICModel.read("/CustomerEngagementSet", {
								urlParameters: {
									"$select": "CaseId"
								},
								filters: oFinalFilter,
								success: function (data) {
									solution.counterCCM = parseInt(data.results.length, 10);
									revolve(parseInt(data.results.length, 10));
									//filter ccm light cases

									/*var aFilteredData = [];
									var aFilters = [new sap.ui.model.Filter([
										new sap.ui.model.Filter("bCCML1", sap.ui.model.FilterOperator.EQ, true),
										new sap.ui.model.Filter("bCCML2", sap.ui.model.FilterOperator.NE, true)
									], true)];
									this.oController.getOwnerComponent().getModel("subModel").read("/Cases", {
										filters: aFilters,
										urlParameters: {
											"$select": "CaseID,bCCML1,bCCML2"
										},
										success: function (oData) {
											//check if not a light case
											data.results.forEach(function (c) {
												var oCase = oData.results.find(function (hanaCase) {
													return c.CaseId === hanaCase.CaseID.toString();
												});
												if (!oCase) {
													aFilteredData.push(c);
												}
											});
											solution.counterCCM = parseInt(aFilteredData.length, 10);
											revolve(parseInt(aFilteredData.length, 10));
										}.bind(this)
									});*/
								}.bind(this),
								error: function (data) {
									revolve(0);
								}.bind(this)
							});
						}.bind(this),
						function () {
							revolve(0);
						});

				}.bind(this));
				aPromises.push(oCriticalCustomerManagementPromise);

				var oTopCriticalCustomersPromise = new Promise(function (revolve) {
					var tmpFilter = oFilterForICP;
					var oFinalFilter = this.oController._getCombinedSolutionFilter(tmpFilter, aProductLines, "ProductLine");

					//Top Critical Customers
					//User Status: New, In Process, In Escalation, In Management Review
					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false)
					],
						true
					);
					oFinalFilter.push(tileSpecificFilters);

					oFinalFilter.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP06"));
					oFinalFilter.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

					var oModel = this.oController.getOwnerComponent().getModel();
					oModel.metadataLoaded(true).then(
						function () {
							//oFinalFilter.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
							oModel.read("/CustomerEngagementSet/$count", {
								filters: oFinalFilter,
								success: function (data) {
									revolve(parseInt(data, 10));
								}.bind(this),
								error: function (data) {
									revolve(0);
								}.bind(this)
							});
						},
						function () {
							revolve(0);
						});

				}.bind(this));
				aPromises.push(oTopCriticalCustomersPromise);

				var oCriticalPeriodCoveragePromise = new Promise(function (revolve) {

					var tmpFilter = oFilterForICP;
					var oFinalFilter = this.oController._getCombinedSolutionFilter(tmpFilter, aProductLines, "ProductLine");

					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false),
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04")
						], false)
					],
						true
					);

					oFinalFilter.push(tileSpecificFilters);

					var oModel = this.oController.getOwnerComponent().getModel();
					oModel.metadataLoaded(true).then(
						function () {
							oFinalFilter.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
							oModel.read("/CustomerEngagementSet/$count", {
								filters: oFinalFilter,
								success: function (data) {
									revolve(parseInt(data, 10));
								}.bind(this),
								error: function (data) {
									revolve(0);
								}.bind(this)
							});
						},
						function () {
							revolve(0);
						});

				}.bind(this));
				aPromises.push(oCriticalPeriodCoveragePromise);

				//dont load if not authorized
				if (oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations || oSettings.ShowGlobalAggregation) {
					//in case of anonymized mode, no GEM should be retunrned
					if (oSettings.isAnonymizedMode === false) {
						var oGlobalEscalationsPromise = new Promise(function (revolve) {
							var tmpFilter = oFilterForICP;
							var oFinalFilter = this.oController._getCombinedSolutionFilter(tmpFilter, aProductLines, "ProductLine");

							var tileSpecificFilters = new sap.ui.model.Filter([
								//new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ,	"ZSPRCTYP01"),
								new sap.ui.model.Filter([new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30"), new sap.ui.model.Filter(
									"Status", sap.ui.model.FilterOperator.EQ, "20")], false)
							],
								true
							);

							oFinalFilter.push(tileSpecificFilters);

							var oModel = this.oController.getOwnerComponent().getModel();

							oModel.metadataLoaded(true).then(
								function () {
									oModel.read("/GlobalEscalationsSet/$count", {
										filters: oFinalFilter,
										success: function (data) {
											solution.counterGlobalEscalation = parseInt(data, 10);
											revolve(parseInt(data, 10));
										}.bind(this),
										error: function (data) {
											revolve(0);
										}.bind(this)
									});
								}.bind(this),
								function () {
									revolve(0);
								});
						}.bind(this));
						aPromises.push(oGlobalEscalationsPromise);
					}
				}

				Promise.all(aPromises).then(function (aResults) {
					var iSum = 0;
					aResults.forEach(function (result) {
						iSum += result;
					});
					solution.counter = iSum;
					solution.busy = false;
					//solution.headerTitleIcon = sap.ui.require.toUrl("com/sap/mcconedashboard/image/" + solution.SolKey + ".png");

					var bFileExists = false;

					jQuery.ajax({
						url: solution.headerTitleIcon,
						type: 'HEAD',
						async: false,
						success: function () {
							bFileExists = true;
						}
					});

					if (bFileExists) {
						//solution.solutionImage = sap.ui.require.toUrl("com/sap/mcconedashboard/image/" + solution.SolKey + ".png");

					} else {
						solution.solutionImage = "sap-icon://documents";
					}
					this.oView.getModel("solutions").refresh();
				}.bind(this));

			}.bind(this));
			//this.oView.getModel("solutions").refresh();
		},

		_getAmountOutagesSet: function (oFacetFilterFilters, oModel) {
			var aFilters = [];

			this.oTileModel.setProperty("/outagesBusyOngoing", true);
			this.oTileModel.setProperty("/outagesBusyClosed", true);
			this.oTileModel.setProperty("/outagesBusy", true);

			var oUrlParameters = {
				"$select": "MasterEventID,CecEventID,CecEventStartDateTime,CecEventEndDateTime,MasterEventCustomerCount,MasterEventLobCount,MasterEventServiceStatusCode,SwatModeIsActive"
			};

			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter("SwatModeIsActive", sap.ui.model.FilterOperator.EQ, 1)
			]);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			var oPromiseOngoing = new Promise(function (resolve) {
				oModel.read("/GetSwatOutages/$count", {
					urlParameters: oUrlParameters,
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						resolve();
						this.oTileModel.setProperty("/outagesBusyOngoing", false);
						this._updateTileModel("outages", data);
					}.bind(this),
					error: function (err) {
						resolve();
						this.oTileModel.setProperty("/outagesBusyOngoing", false);
					}
				});
			}.bind(this));

			aFilters = [];
			tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter("SwatModeIsActive", sap.ui.model.FilterOperator.EQ, 0)
			]);
			aFilters.push(tileSpecificFilters);

			var dateOffset = (24 * 60 * 60 * 1000) * Constants.closedCasesPastDays;
			var dateInPast = new Date();
			dateInPast.setTime(dateInPast.getTime() - dateOffset);
			var oFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyyMMddHHmmss"
			});
			dateInPast = oFormat.format(dateInPast);
			var dateToday = oFormat.format(new Date());

			var timeFilter = new sap.ui.model.Filter([
				new sap.ui.model.Filter("CecEventEndDateTime", sap.ui.model.FilterOperator.BT, dateInPast, dateToday)
			]);
			aFilters.push(timeFilter);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			var oPromiseClosed = new Promise(function (resolve) {
				oModel.read("/GetSwatOutages/$count", {
					urlParameters: oUrlParameters,
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						resolve();
						this.oTileModel.setProperty("/outagesBusyClosed", false);
						this._updateTileModel("outagesClosed", data);
					}.bind(this),
					error: function (err) {
						resolve();
						this.oTileModel.setProperty("/outagesBusyClosed", false);
					}
				});
			}.bind(this));

			Promise.all([oPromiseOngoing, oPromiseClosed]).then(function () {
				this.oTileModel.setProperty("/outagesBusy", false);
			}.bind(this));

		},

		_getAmountEngagementTaskForces: function (oFacetFilterFilters) {
			var aFilters = [];
			var oModel = this.oController.getOwnerComponent().getModel();
			this.oTileModel.setProperty("/engagementTaskForcesBusy", true);
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP07")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			oModel.read("/CustomerEngagementSet/$count", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
				success: function (data) {
					this._updateTileModel("taskFoces", data);
					this.oTileModel.setProperty("/engagementTaskForcesBusy", false);
				}.bind(this),
				error: function (data) {
					this.oTileModel.setProperty("/engagementTaskForcesBusy", false);
				}.bind(this)
			});
		},

		_getAmountGlobalEscalationsSet: function (oFacetFilterFilters) {
			var aFilters = [];
			var oModel = this.oController.getOwnerComponent().getModel();
			var oSettings = this.oController.getOwnerComponent().getModel("settings").getData();
			this.oTileModel.setProperty("/globalEscalationsBusyOngoing", true);
			this.oTileModel.setProperty("/globalEscalationsBusyRed", true);
			this.oTileModel.setProperty("/globalEscalationsBusyClosed", true);
			this.oTileModel.setProperty("/globalEscalationsBusy", true);
			this.oTileModel.setProperty("/globalEscalationsState", "Loading");
			this.oTileModel.setProperty("/globalEscalationsStateClosed", "Loading");
			this.oTileModel.setProperty("/globalEscalationsStateRED", "Loading");
			this.oTileModel.setProperty("/globalEscalationsStateLongRunning", "Loading");
			this.oTileModel.setProperty("/globalEscalationsStateClosedTwelveMonths", "Loading");
			this.oTileModel.setProperty("/globalEscalationsStateTopHighCost", "Loading");

			//if authoritySet is not yet loadrd, call method until it is
			if (!oSettings.dataLoaded) {
				var that = this;
				setTimeout(function () {
					that._getAmountGlobalEscalationsSet(oFacetFilterFilters);
				}, 200);
				return null;
			}

			//dont load if not authorized
			if (!oSettings.ShowGlobalEscalations && !oSettings.ShowRegionalGlobalEscalations && !oSettings.ShowGlobalAggregation) {
				return null;
			}

			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			//Critical Situation Section
			//ALL ongoing escalations
			//Rating =   ALL
			//Case Status = status eq '20' or status eq '30'
			//process_type  Global Escalations (ZSPRCTYP01)  -->  should be predefined in Backend
			var tileSpecificFilters = new sap.ui.model.Filter([
				//new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ,	"ZSPRCTYP01"),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20")
				],
					false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			var oPromiseOngoing = new Promise(function (resolve) {
				oModel.read("/GlobalEscalationsSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						this._updateTileModel("globalEscalations", data);
						this.oTileModel.setProperty("/globalEscalationsBusyOngoing", false);
						this.oTileModel.setProperty("/globalEscalationsState", "Loaded");
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/globalEscalationsBusyOngoing", false);
						this.oTileModel.setProperty("/globalEscalationsState", "Loaded");
						resolve();
					}.bind(this)
				});
			}.bind(this));

			aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			//Critical Situation Section
			//ALL ongoing escalations
			//Rating =   ALL
			//Case Status = status eq '20' or status eq '30'
			//process_type  Global Escalations (ZSPRCTYP01)  -->  should be predefined in Backend
			var tileSpecificFilters = new sap.ui.model.Filter([
				//new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ,	"ZSPRCTYP01"),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20")
				],
					false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			aFilters.push(new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"));

			var oPromiseRed = new Promise(function (resolve) {
				oModel.read("/GlobalEscalationsSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						this._updateTileModel("globalEscalationsRed", data);
						this.oTileModel.setProperty("/globalEscalationsBusyRed", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/globalEscalationsBusyRed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			//alos closed cases
			aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			//ALL ongoing escalations
			//Rating =   ALL
			//Case Status = status eq '20' or status eq '30'
			//process_type  Global Escalations (ZSPRCTYP01)  -->  should be predefined in Backend
			tileSpecificFilters = new sap.ui.model.Filter([
				//new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ,	"ZSPRCTYP01"),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "40")
				],
					false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			var closedDate = this.getClosedDateFilter("ClosingDate");
			aFilters.push(closedDate);

			var oPromiseClosed = new Promise(function (resolve) {
				oModel.read("/GlobalEscalationsSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						this._updateTileModel("globalEscalationsClosed", data);
						this.oTileModel.setProperty("/globalEscalationsBusyClosed", false);
						this.oTileModel.setProperty("/globalEscalationsStateClosed", "Loaded");
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/globalEscalationsBusyClosed", false);
						this.oTileModel.setProperty("/globalEscalationsStateClosed", "Loaded");
						resolve();
					}.bind(this)
				});
			}.bind(this));

			//Executive Information
			//RED ongoing escalations
			//Rating =   RED
			//Case Status = status eq '20' or status eq '30'
			//process_type  Global Escalations (ZSPRCTYP01)  -->  should be predefined in Backend
			aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			tileSpecificFilters = new sap.ui.model.Filter(
				[new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"),
				//new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ,"ZSPRCTYP01"),
				new sap.ui.model.Filter([new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30"), new sap.ui.model.Filter(
					"Status", sap.ui.model.FilterOperator.EQ, "20")].filter(Boolean), false)
				].filter(Boolean),
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			oModel.read("/GlobalEscalationsSet/$count", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					this._updateTileModel("globalEscalationsRED", data);
					this.oTileModel.setProperty("/globalEscalationsStateRED", "Loaded");
				}.bind(this),
				error: function (data) {
					this.oTileModel.setProperty("/globalEscalationsStateRED", "Loaded");
				}.bind(this)
			});

			//LongRunning ongoing escalations
			//Rating =   RED
			//Case Status = status eq '20' or status eq '30'
			//process_type  Global Escalations (ZSPRCTYP01)  -->  should be predefined in Backend
			aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			var dTemp = new Date();
			dTemp.setDate(dTemp.getDate() - 180);
			tileSpecificFilters = new sap.ui.model.Filter(
				[new sap.ui.model.Filter("CreateDate", sap.ui.model.FilterOperator.LE, dTemp),
				new sap.ui.model.Filter(
					[new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"), new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator
						.EQ, "B")].filter(Boolean), false),
				new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30")
				].filter(Boolean),
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			oModel.read("/GlobalEscalationsSet/$count", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					this._updateTileModel("globalEscalationsLongRunning", data);
					this.oTileModel.setProperty("/globalEscalationsStateLongRunning", "Loaded");
				}.bind(this),
				error: function (data) {
					this.oTileModel.setProperty("/globalEscalationsStateLongRunning", "Loaded");
				}.bind(this)
			});

			//Global Customer Escalations closed within the last 12 months
			//Rating =   ALL
			//Case Status = status eq '40'
			//process_type  Global Escalations (ZSPRCTYP01) 
			//closing_date= today-12 months
			aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			//Calculate date
			dTemp = new Date();
			dTemp.setFullYear(dTemp.getFullYear() - 1);
			dTemp.setDate(1);
			dTemp.setUTCHours(0, [0], [0], [0]);
			//dMinus6.getMonth()+1 because the service delivers the date string with months from 01-12, but javascript uses 00-11
			//.todayMinus12Months = "" + dTemp.getFullYear() + ("0" + (dTemp.getMonth() + 1)).slice(-2) + ("0" + dTemp.getDate()).slice(-2) +
			//	("0" + dTemp.getHours()).slice(-2) + ("0" + dTemp.getMinutes()).slice(-2) + ("0" + dTemp.getSeconds()).slice(-2);

			tileSpecificFilters = new sap.ui.model.Filter([new sap.ui.model.Filter("ClosingDate", sap.ui.model.FilterOperator.GE, dTemp),
			//	new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ,"ZSPRCTYP01"),
			new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "40")
			].filter(Boolean),
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			oModel.read("/GlobalEscalationsSet/$count", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					this._updateTileModel("globalEscalationsClosedTwelveMonths", data);
					this.oTileModel.setProperty("/globalEscalationsStateClosedTwelveMonths", "Loaded");
				}.bind(this),
				error: function (data) {
					this.oTileModel.setProperty("/globalEscalationsStateClosedTwelveMonths", "Loaded");
				}.bind(this)
			});

			//Board & Executive Requested Global Customer Escalations ongoing escalations
			//Case Status = status eq '20' or status eq '30'
			//process_type  Global Escalations (ZSPRCTYP01)  -->  should be predefined in Backend
			// in addition we need to read the data from the MCC HANA DB --> all ongoing escalations with requesting unit "RU_Board" and "RU_Exec" 
			//-->  the returned case IDs we need to add the the ICP call
			aFilters = [];
			//read relevant case Ids form Hana DB
			//int_mcshana/odata/v2/MCCOnedashboard/Cases?
			//$filter=(RequestingUnit%20eq%20%27RU_BOARD%27%20or%20RequestingUnit%20eq%20%27RU_EXEC%27)%20and%20UseCaseType%20eq%20%27mcs-gem%27

			var oPromiseBoardAndExec = new Promise(function (resolve) {
				this.oController.getOwnerComponent().getModel("subModel").read("/Cases", {
					filters: [new sap.ui.model.Filter(
						[new sap.ui.model.Filter(
							[new sap.ui.model.Filter("RequestingUnit", sap.ui.model.FilterOperator.StartsWith, "RU_BOARD"),
							new sap.ui.model.Filter(
								"RequestingUnit", sap.ui.model.FilterOperator
								.StartsWith, "RU_EXEC")].filter(Boolean), false),
						new sap.ui.model.Filter("UseCaseType", sap.ui.model.FilterOperator.EQ, "mcs-gem")
						].filter(Boolean),
						true
					)],
					urlParameters: {
						"$select": "CaseID"
					},
					success: function (oData) {
						var aCaseIdFilters = [];
						oData.results.forEach(function (element) {
							aCaseIdFilters.push(new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.EQ, element.CaseID));
						});
						aFilters.push(new sap.ui.model.Filter(aCaseIdFilters, false));
						resolve();
					},
					error: function () {
						resolve();
					}
				});
			}.bind(this));

			oPromiseBoardAndExec.then(function () {
				var tileSpecificFilters = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30"),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20")
					],
						false)
				],
					true
				);
				aFilters.push(tileSpecificFilters);

				if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
					aFilters.push(oFacetFilterFilters);
				}

				oModel.read("/GlobalEscalationsSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						this._updateTileModel("globalEscalationsBoardAndExec", data);
						this.oTileModel.setProperty("/globalEscalationsStateBoardAndExec", "Loaded");
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/globalEscalationsStateBoardAndExec", "Loaded");
					}.bind(this)
				});
			}.bind(this));

			//the count for High Cost Customer escalations is not needed, because we do not show the counter on the ui. it is always the top ten
			//-----------------------------
			//High Cost Global Customer escalations Count
			//-----------------------------
			this._updateTileModel("globalEscalationsTopTenHIghCostCaseIds", 0);
			this.oTileModel.setProperty("/globalEscalationsStateTopHighCost", "Loaded");

			Promise.all([oPromiseOngoing, oPromiseRed, oPromiseClosed]).then(function () {
				this.oTileModel.setProperty("/globalEscalationsBusy", false);
			}.bind(this));
		},

		_getAmountProductEscalationSet: function (oFacetFilterFilters) {
			this.oTileModel.setProperty("/prodEscaBusyOngoing", true);
			//	this.oTileModel.setProperty("/prodEscaState", "Loading");
			this.oTileModel.setProperty("/prodEscaBusyRed", true);
			this.oTileModel.setProperty("/prodEscaBusy", true);

			var aFilters = [];
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "20"),
				new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "30")
			],
				false
			);
			aFilters.push(tileSpecificFilters);

			aFilters.push(new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP06"));

			//check in a separate call without any specific filters set, if any Product Escalation exists and set visiblity based on return value
			var oMCSModel = this.oView.getModel("mcsModel");

			oMCSModel.read("/MCSDashboardSet/$count", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					//check if Product Escalations should be shown
					if (this.oController.getOwnerComponent().getModel("settings").getProperty("/show_crm_data")) {
						if (data > 0) {
							this.oController.getOwnerComponent().getModel("settings").setProperty("/showProductEscalations", true);
						}
					}
				}.bind(this),
				error: function (data) {
					this.oController.getOwnerComponent().getModel("settings").setProperty("/showProductEscalations", false);
				}.bind(this)
			});

			// add additional selected filters
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				//var oTempFacetFilterFilters = this.oController._mapFacetFiltersForBusinessDowns(oFacetFilterFilters);
				if (oFacetFilterFilters.aFilters.length > 0) {
					aFilters.push(oFacetFilterFilters);
				}
			}

			var oPromiseOngoing = new Promise(function (resolve) {
				oMCSModel.read("/MCSDashboardSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						this._updateTileModel("prodEsca", data);
						this.oTileModel.setProperty("/prodEscaBusyOngoing", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/prodEscaBusyOngoing", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			//also load red cases
			aFilters = [];
			// if (sRegion) {
			// 	aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				//oTempFacetFilterFilters = this.oController._mapFacetFiltersForBusinessDowns(oFacetFilterFilters);
				if (oFacetFilterFilters.aFilters.length > 0) {
					aFilters.push(oFacetFilterFilters);
				}
			}

			//Escalation Status Flag:  15 - Business Down

			tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "20"),
				new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "30")
			],
				false
			);
			aFilters.push(tileSpecificFilters);

			aFilters.push(new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP06"));
			aFilters.push(new sap.ui.model.Filter("rating", sap.ui.model.FilterOperator.EQ, "C"));

			var oPromiseRed = new Promise(function (resolve) {
				oMCSModel.read("/MCSDashboardSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						this.oTileModel.setProperty("/prodEscaBusyRed", false);
						this._updateTileModel("prodEscaRed", data);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/prodEscaBusyRed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			Promise.all([oPromiseOngoing, oPromiseRed]).then(function () {
				this.oTileModel.setProperty("/prodEscaBusy", false);
			}.bind(this));

		},
		_getOngoingCustomerEscalations: function (oFacetFilterFilters) {

			// Ongoing Escalations
			//process_type has been set as static in backend for perfomance reasons	
			this.oTileModel.setProperty("/ongoingGEMStatisticState", "Loading");

			var aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				//var oTempFacetFilterFilters = this.oController._mapFacetFiltersForBusinessDowns(oFacetFilterFilters);
				if (oFacetFilterFilters.aFilters.length > 0) {
					aFilters.push(oFacetFilterFilters);
				}
			}

			var oMCSModel = this.oView.getModel("mcsModel");
			oMCSModel.read("/OngoingEscalationsSet", {
				filters: [new sap.ui.model.Filter(aFilters, true)],
				success: function (data) {
					var stats = data.results[0];
					if (stats) {
						this.oTileModel.setProperty("/ongoingEscalations/", {
							m3: {
								label: stats.month1.substring(0, 3),
								y1: stats.month1_global //,
								//y2: stats.month1_proddown
							},
							m2: {
								label: stats.month2.substring(0, 3),
								y1: stats.month2_global //,
								//y2: stats.month2_proddown
							},
							m1: {
								label: stats.month3.substring(0, 3),
								y1: stats.month3_global //,
								//	y2: stats.month3_proddown
							}
						});

						if (stats.month1_global === 0 &&
							stats.month2_global === 0 &&
							stats.month3_global === 0) {
							this.oTileModel.setProperty("/ongoingEscalations/hasRecords", false);
						} else {
							this.oTileModel.setProperty("/ongoingEscalations/hasRecords", true);
						}
					} else {
						this.oTileModel.setProperty("/ongoingEscalations/hasRecords", false);
					}
					this.oTileModel.setProperty("/ongoingGEMStatisticState", "Loaded");
				}.bind(this),
				error: function (data) {
					this.oTileModel.setProperty("/ongoingGEMStatisticState", "Loaded");
				}.bind(this)
			});

		},

		_getAmoutCriticalPeriodCoverage: function (oFacetFilterFilters) {

			this.oTileModel.setProperty("/CriticalPeriodCoverageBusyOngoing", true);
			this.oTileModel.setProperty("/CriticalPeriodCoverageBusyRed", true);
			this.oTileModel.setProperty("/CriticalPeriodCoverageBusyClosed", true);
			this.oTileModel.setProperty("/CriticalPeriodCoverageBusy", true);

			var aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			var oICModel = this.oController.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			var oPromiseOngoing = new Promise(function (resolve) {
				oICModel.read("/CustomerEngagementSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this._updateTileModel("criticalPeriodCoverage", data);
						this.oTileModel.setProperty("/CriticalPeriodCoverageBusyOngoing", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/CriticalPeriodCoverageBusyOngoing", false);
						this.oTileModel.setProperty("/CriticalPeriodCoverageBusyRed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			var oICModel = this.oController.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			aFilters.push(new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"));

			var oPromiseRed = new Promise(function (resolve) {
				oICModel.read("/CustomerEngagementSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this.oTileModel.setProperty("/CriticalPeriodCoverageBusyRed", false);
						this._updateTileModel("criticalPeriodCoverageRed", data);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/CriticalPeriodCoverageBusyRed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			//also load closed cases
			var aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP04")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			aFilters.push(this.getClosedDateFilter("ClosingDate"));

			var oICModel = this.oController.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			var oPromiseClosed = new Promise(function (resolve) {
				oICModel.read("/CustomerEngagementSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this._updateTileModel("criticalPeriodCoverageClosed", data);
						this.oTileModel.setProperty("/CriticalPeriodCoverageBusyClosed", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/CriticalPeriodCoverageBusyClosed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			Promise.all([oPromiseOngoing, oPromiseRed, oPromiseClosed]).then(function () {
				this.oTileModel.setProperty("/CriticalPeriodCoverageBusy", false);
			}.bind(this));
		},



		_getAmoutCriticalEventCoverage: function (oFacetFilterFilters) {
			this.oTileModel.setProperty("/CriticalEventCoverageBusyOngoing", true);
			this.oTileModel.setProperty("/CriticalEventCoverageBusyClosed", true);
			this.oTileModel.setProperty("/CriticalEventCoverageBusy", true);
			var oFilterModel = this.oView.getModel("filterModel");
			var sRegion = oFilterModel.getProperty("/regionText");

			var aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "CECSTAT01"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "CECSTAT03")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "CEC")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);


			/*if (typeof sRegion !== "undefined" && sRegion !== "") {
      
				var aRegionHelp = this.oView.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.country;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var eqFilters = regionCountryValues.map(function (country) {
					return new sap.ui.model.Filter("CustomerCountry", sap.ui.model.FilterOperator.EQ, country);
				});

				var regionFilter = new sap.ui.model.Filter({
					filters: eqFilters,
					and: false //OR
				});


				// Combine the regionFilter with filterCondition using AND conjunction
				aFilters.push(regionFilter);
			}*/

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			var oICModel = this.oController.getOwnerComponent().getModel("subModel");

			var oPromiseOngoing = new Promise(function (resolve) {
				oICModel.read("/MCCObject/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						this._updateTileModel("criticalEventCoverage", data);
						this.oTileModel.setProperty("/CriticalEventCoverageBusyOngoing", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/CriticalEventCoverageBusyOngoing", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));


			//also load closed cases
			var aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "CECSTAT11")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "CEC")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			//Only Showing Closed Entries for the past 4 weeks
			var pastDate = new Date();
			pastDate.setDate(pastDate.getDate() - 364);

			var closedDateFilter = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("ClosureDate", sap.ui.model.FilterOperator.GE, pastDate)
				], false)
			],
				true
			);

			aFilters.push(closedDateFilter);

			var oICModel = this.oController.getOwnerComponent().getModel("subModel");

			var oPromiseClosed = new Promise(function (resolve) {
				oICModel.read("/MCCObject/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						this._updateTileModel("criticalEventCoverageClosed", data);
						this.oTileModel.setProperty("/CriticalEventCoverageBusyClosed", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/CriticalEventCoverageBusyClosed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			Promise.all([oPromiseOngoing, oPromiseClosed]).then(function () {
				this.oTileModel.setProperty("/CriticalEventCoverageBusy", false);
			}.bind(this));
		},

		_getAmountCreEngagements: function (oFacetFilterFilters) {
			this.oTileModel.setProperty("/creEngagementsBusyClosed", true);
			this.oTileModel.setProperty("/creEngagementsBusyOngoing", true);
			this.oTileModel.setProperty("/creEngagementsBusy", true);
			var oFilterModel = this.oView.getModel("filterModel");
			var sRegion = oFilterModel.getProperty("/regionText");

			var aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "SWATSTAT01"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "SWATSTAT05"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "SWATSTAT06"),
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "SWAT")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (typeof sRegion !== "undefined" && sRegion !== "") {


				var aRegionHelp = this.oView.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.country;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var eqFilters = regionCountryValues.map(function (country) {
					return new sap.ui.model.Filter("CustomerCountry", sap.ui.model.FilterOperator.EQ, country);
				});

				var regionFilter = new sap.ui.model.Filter({
					filters: eqFilters,
					and: false //OR
				});


				// Combine the regionFilter with filterCondition using AND conjunction
				aFilters.push(regionFilter);
			}

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			var oICModel = this.oController.getOwnerComponent().getModel("subModel");

			var oPromiseOngoing = new Promise(function (resolve) {
				oICModel.read("/MCCObject/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						this._updateTileModel("creEngagements", data);
						this.oTileModel.setProperty("/creEngagementsBusyOngoing", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/creEngagementsBusyOngoing", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));


			//also load closed cases
			var aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "CECSTAT02"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "CECSTAT04"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "CECSTAT08")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "SWAT")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			//Only Showing Closed Entries for the past 4 weeks
			var pastDate = new Date();
			pastDate.setDate(pastDate.getDate() - 364);

			var closedDateFilter = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("ClosureDate", sap.ui.model.FilterOperator.GE, pastDate)
				], false)
			],
				true
			);

			aFilters.push(closedDateFilter);

			var oICModel = this.oController.getOwnerComponent().getModel("subModel");

			var oPromiseClosed = new Promise(function (resolve) {
				oICModel.read("/MCCObject/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						this._updateTileModel("creEngagementsClosed", data);
						this.oTileModel.setProperty("/creEngagementsBusyClosed", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/creEngagementsBusyClosed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			Promise.all([oPromiseOngoing, oPromiseClosed]).then(function () {
				this.oTileModel.setProperty("/creEngagementsBusy", false);
			}.bind(this));
		},

		_getAmoutTopCriticalCustomers: function (oFacetFilterFilters) {
			this.oTileModel.setProperty("/TopCriticalCustomersBusyOngoing", true);
			this.oTileModel.setProperty("/TopCriticalCustomersBusyRed", true);
			this.oTileModel.setProperty("/TopCriticalCustomersBusyClosed", true);
			this.oTileModel.setProperty("/TopCriticalCustomersBusy", true);

			var aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP06")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			var oICModel = this.oController.getOwnerComponent().getModel();

			var oPromiseOngoing = new Promise(function (resolve) {
				oICModel.read("/CustomerEngagementSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this._updateTileModel("topCriticalCustomers", data);
						this.oTileModel.setProperty("/TopCriticalCustomersBusyOngoing", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/TopCriticalCustomersBusyOngoing", false);
						this.oTileModel.setProperty("/TopCriticalCustomersBusyRed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			//also load red ratings
			aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP06")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
			aFilters.push(new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"));

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			var oICModel = this.oController.getOwnerComponent().getModel();

			var oPromiseRed = new Promise(function (resolve) {
				oICModel.read("/CustomerEngagementSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this.oTileModel.setProperty("/TopCriticalCustomersBusyRed", false);
						this._updateTileModel("topCriticalCustomersRed", data);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/TopCriticalCustomersBusyOngoing", false);
						this.oTileModel.setProperty("/TopCriticalCustomersBusyRed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			//also load closed cases
			var aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90")
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP06")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			aFilters.push(this.getClosedDateFilter("ClosingDate"));

			var oICModel = this.oController.getOwnerComponent().getModel();

			var oPromiseClosed = new Promise(function (resolve) {
				oICModel.read("/CustomerEngagementSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this._updateTileModel("topCriticalCustomersClosed", data);
						this.oTileModel.setProperty("/TopCriticalCustomersBusyClosed", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/TopCriticalCustomersBusyClosed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			Promise.all([oPromiseOngoing, oPromiseRed, oPromiseClosed]).then(function () {
				this.oTileModel.setProperty("/TopCriticalCustomersBusy", false);
			}.bind(this));
		},

		_getAmountProjectsOnWatch: function (oFacetFilterFilters) {
			var aPromises = [];
			this.oTileModel.setProperty("/ProjectsOnWatchBusy", true);
			this.oTileModel.setProperty("/ProjectsOnWatchBusyOngoing", true);
			this.oTileModel.setProperty("/ProjectsOnWatchBusyClosed", true);
			var oFilterModel = this.oView.getModel("filterModel");
			var sRegion = oFilterModel.getProperty("/regionText");

			var aFilters = [];
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "POWSTAT01"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "POWSTAT02")
				], false)
			],
				true
			);

			/* Only apply if there is no Country set
			if (typeof sRegion !== "undefined" && sRegion !== "" && !oFacetFilterFilters.aFilters.some(filterGroup => {
				return filterGroup.aFilters.some(subFilter => subFilter.sPath.includes("Country"));
			})) { */

			if (typeof sRegion !== "undefined" && sRegion !== "") {


				var aRegionHelp = this.oView.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.country;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var eqFilters = regionCountryValues.map(function (country) {
					return new sap.ui.model.Filter("CustomerCountry", sap.ui.model.FilterOperator.EQ, country);
				});

				var regionFilter = new sap.ui.model.Filter({
					filters: eqFilters,
					and: false //OR
				});


				// Combine the regionFilter with filterCondition using AND conjunction
				aFilters.push(regionFilter);
			}

			aFilters.push(tileSpecificFilters);
			aFilters.push(new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "POW"));
			aFilters.push(new sap.ui.model.Filter("TriggeredBy", sap.ui.model.FilterOperator.EQ, "EXTERNAL"));
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}


			var oICModel = this.oController.getOwnerComponent().getModel("subModel");

			aPromises.push(new Promise(function (resolve) {
				oICModel.read("/MCCObject/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this._updateTileModel("projectsOnWatch", data);
						this.oTileModel.setProperty("/ProjectsOnWatchBusyOngoing", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/ProjectsOnWatchBusyOngoing", false);
						resolve();
					}.bind(this)
				});
			}.bind(this)));

			//Closed
			var aFilters = [];
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "POWSTAT03")
				], false)
			],
				true
			);

			aFilters.push(tileSpecificFilters);
			aFilters.push(new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "POW"));
			aFilters.push(new sap.ui.model.Filter("TriggeredBy", sap.ui.model.FilterOperator.EQ, "EXTERNAL"));
			aFilters.push(tileSpecificFilters);

			/* Only apply if there is no Country set
			if (typeof sRegion !== "undefined" && sRegion !== "" && !oFacetFilterFilters.aFilters.some(filterGroup => {
				return filterGroup.aFilters.some(subFilter => subFilter.sPath.includes("Country"));
			})) { */

			if (typeof sRegion !== "undefined" && sRegion !== "") {

				var aRegionHelp = this.oView.getModel("countryRegionModel").getData();
				var selectedRegions = sRegion.split(","); // Split the selected regions into an array

				// Create an object to map selected regions to filterBasis (given in countryRegionModel)
				var regionFilterBasisMap = {
					"EMEA North": "subsubregion",
					"EMEA South": "subsubregion",
					"NA": "region",
					"APJ": "region",
					"MEE": "subregion",
					"GTC": "subregion",
					"LAC": "subregion"
				};

				var regionCountryValues = [];

				// Iterate through selectedRegions and create filters based on filterBasis
				selectedRegions.forEach(function (region) {
					var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

					// Filter regionCountries based on the chosen filter basis
					var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
						return item[filterBasis] === region;
					});

					// Add regionCountryValues for the current region to the array
					regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
						return regionCountry.country;
					}));
				});

				// Create the regionFilter with all regionCountryValues
				var eqFilters = regionCountryValues.map(function (country) {
					return new sap.ui.model.Filter("CustomerCountry", sap.ui.model.FilterOperator.EQ, country);
				});

				var regionFilter = new sap.ui.model.Filter({
					filters: eqFilters,
					and: false //OR
				});


				// Combine the regionFilter with filterCondition using AND conjunction
				aFilters.push(regionFilter);
			}

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			var oICModel = this.oController.getOwnerComponent().getModel("subModel");

			aPromises.push(new Promise(function (resolve) {
				oICModel.read("/MCCObject/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this._updateTileModel("projectsOnWatchClosed", data);
						this.oTileModel.setProperty("/ProjectsOnWatchBusyClosed", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/ProjectsOnWatchBusyClosed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this)));

			Promise.all(aPromises).then(function () {
				this.oTileModel.setProperty("/ProjectsOnWatchBusy", false);
			}.bind(this));

		},

		_getAmountCustomerVisits: function (oFacetFilterFilters) {
			this.oTileModel.setProperty("/CustomerVisitsBusyOngoing", true);
			this.oTileModel.setProperty("/CustomerVisitsBusyClosed", true);
			this.oTileModel.setProperty("/CustomerVisitsBusy", true);

			var aFilters = [];
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("StatusT", sap.ui.model.FilterOperator.EQ, "New"),
					new sap.ui.model.Filter("StatusT", sap.ui.model.FilterOperator.EQ, "In Process Backoffice"),
					new sap.ui.model.Filter("StatusT", sap.ui.model.FilterOperator.EQ, "In MCC Focus Teams")
				], false)
			],
				true
			);

			aFilters.push(tileSpecificFilters);
			aFilters.push(new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "ZVM"));
			aFilters.push(new sap.ui.model.Filter("ProcessType", sap.ui.model.FilterOperator.EQ, "ZS46"));
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				oFacetFilterFilters.aFilters = oFacetFilterFilters.aFilters.filter(function (filter) {
					if (filter.aFilters && filter.aFilters.length > 0) {
						return filter.aFilters[0].sPath !== "SalesOrg" && filter.aFilters[0].sPath !== "ServiceOrg" && filter.aFilters[0].sPath !== "CaseTag";
					}
					return true;
				});
				if (oFacetFilterFilters.aFilters.length !== 0) {
					aFilters.push(oFacetFilterFilters);
				}
			}

			var oICModel = this.oController.getOwnerComponent().getModel();

			var oPromiseOngoing = new Promise(function (resolve) {
				oICModel.read("/MCCActivitiesSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this._updateTileModel("customerVisits", data);
						this.oTileModel.setProperty("/CustomerVisitsBusyOngoing", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/CustomerVisitsBusyOngoing", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			//also load closed cases
			var aFilters = [];
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("StatusT", sap.ui.model.FilterOperator.EQ, "Confirmed"),
					new sap.ui.model.Filter("StatusT", sap.ui.model.FilterOperator.EQ, "Completed")
				], false)
			],
				true
			);

			aFilters.push(tileSpecificFilters);
			aFilters.push(new sap.ui.model.Filter("Category", sap.ui.model.FilterOperator.EQ, "ZVM"));
			aFilters.push(new sap.ui.model.Filter("ProcessType", sap.ui.model.FilterOperator.EQ, "ZS46"));

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				oFacetFilterFilters.aFilters = oFacetFilterFilters.aFilters.filter(function (filter) {
					if (filter.aFilters && filter.aFilters.length > 0) {
						return filter.aFilters[0].sPath !== "SalesOrg" && filter.aFilters[0].sPath !== "ServiceOrg" && filter.aFilters[0].sPath !== "CaseTag";
					}
					return true;
				});
				if (oFacetFilterFilters.aFilters.length !== 0) {
					aFilters.push(oFacetFilterFilters);
				}
			}

			aFilters.push(this.getClosedDateFilter("ClosingDate", "180"));

			var oICModel = this.oController.getOwnerComponent().getModel();

			var oPromiseClosed = new Promise(function (resolve) {
				oICModel.read("/MCCActivitiesSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this._updateTileModel("customerVisitsClosed", data);
						this.oTileModel.setProperty("/CustomerVisitsBusyClosed", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/CustomerVisitsBusyClosed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			Promise.all([oPromiseOngoing, oPromiseClosed]).then(function () {
				this.oTileModel.setProperty("/CustomerVisitsBusy", false);
			}.bind(this));
		},

		_getAmountTaskForces: function (oFacetFilterFilters) {
			var oTileContainer = this.oView.byId("tileContainerInitiativesTaskForces");
			var oList = this.oView.byId("taskForcesList");
			//First delete all
			if (!oTileContainer) {
				if (oList) {
					var oTaskForcesModel = this.oController.getOwnerComponent().getModel("taskForcesModel");
					oTaskForcesModel.setProperty("/count", 0);
					oList.removeAllItems();
					//Then add static one
					var oListItem = new StandardListItem({
						title: "{i18n>productEscalationsTitle}",
						press: this.oController.onNavToProdEsca.bind(this),
						busy: "{tileModel>/prodEscaBusy}",
						counter: "{= parseInt(${tileModel>/prodEsca})}",
						iconDensityAware: false,
						iconInset: false,
						type: "Navigation",
					}).data("controller", this).data("tagName", "");
					oListItem.bindProperty("visible", {
						parts: [{
							path: "settings>/showProductEscalations"
						}, {
							path: "settings>/isAnonymizedMode"
						}],
						formatter: function (a, b) {
							return a && !b;
						}
					});
					oList.addItem(oListItem);
					//	oTaskForcesModel.setProperty("/count", oTaskForcesModel.getProperty("/count") + 1);
					var oAppDepModel = this.oController.getOwnerComponent().getModel("appDepModel");
					oAppDepModel.read("/BusinessUnitSet", {
						urlParameters: {
							"$expand": "toServiceTeam"
						},
						success: function (data) {
							oTaskForcesModel.setProperty("/count", oTaskForcesModel.getProperty("/count") + data.results.length);
							data.results.forEach(function (bp) {
								this._generateTaskForcesModel(bp, oFacetFilterFilters);
							}.bind(this));
						}.bind(this),
						error: function (data) {

						}.bind(this)
					});

					//also add tiles per Tag
					var oSubModel = this.oController.getOwnerComponent().getModel("subModel");
					var dToday = new Date();
					var aFilters = [];
					aFilters.push(new sap.ui.model.Filter("ShowInOneDashboard", sap.ui.model.FilterOperator.EQ, true));

					aFilters.push(new sap.ui.model.Filter([
						new sap.ui.model.Filter("DateFrom", sap.ui.model.FilterOperator.LE, dToday),
						new sap.ui.model.Filter("DateTo", sap.ui.model.FilterOperator.GE, dToday),
						new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "MCC")
					], true));

					oSubModel.read("/MCCTags", {
						filters: aFilters,
						success: function (data) {
							data.results.forEach(function (tag) {
								this._generateEngagementTagListEntries(tag, oFacetFilterFilters);
							}.bind(this));
						}.bind(this)
					});
				} else {
					return null;
				}
			}
			if (oTileContainer) {
				oTileContainer.removeAllItems();
				//Then add static one
				var oCard = new CustomDashboardTile({
					headerTitle: "{i18n>productEscalationsTitle}",
					headerFilterIconSrc: "{tileModel>/prodEscaFilterIcon}",
					headerInfoIconText: "{i18n>productEscalationsTitle}",
					headerInfoIconPress: function (oEv) {
						this.oController.onPressInfoIconCards(oEv);
					}.bind(this),
					press: this.oController.onNavToProdEsca.bind(this),
					busyAll: "{tileModel>/prodEscaBusy}",
					numberAll: "{= parseInt(${tileModel>/prodEsca})}",
					items: [
						new CustomDashboardTileItem({
							text: "{i18n>ongoing}",
							value: "{tileModel>/prodEsca}",
							state: "Information",
							busy: "{tileModel>/prodEscaBusyOngoing}",
							press: this.oController.onNavToProdEsca.bind(this)
						}).data("controller", this).data("tagName", ""),
						new CustomDashboardTileItem({
							text: "{i18n>ratingRed}",
							value: "{tileModel>/prodEscaRed}",
							state: "Error",
							busy: "{tileModel>/prodEscaBusyRed}",
							press: this.oController.onNavToProdEscaRed
						}).data("controller", this).data("tagName", "")
					]
				}).data("controller", this).data("tagName", "");
				oCard.bindProperty("visible", {
					parts: [{
						path: "settings>/showProductEscalations"
					}, {
						path: "settings>/isAnonymizedMode"
					}],
					formatter: function (a, b) {
						return a && !b;
					}
				});
				oTileContainer.addItem(oCard);
				var oAppDepModel = this.oController.getOwnerComponent().getModel("appDepModel");
				oAppDepModel.read("/BusinessUnitSet", {
					urlParameters: {
						"$expand": "toServiceTeam"
					},
					success: function (data) {
						data.results.forEach(function (bp) {
							this._generateTaskForcesTiles(bp, oFacetFilterFilters);
							this._generateTaskForcesClosedTiles(bp, oFacetFilterFilters);
						}.bind(this));
					}.bind(this),
					error: function (data) {

					}.bind(this)
				});

				//also add tiles per Tag
				var oSubModel = this.oController.getOwnerComponent().getModel("subModel");
				var dToday = new Date();
				var aFilters = [];
				aFilters.push(new sap.ui.model.Filter("ShowInOneDashboard", sap.ui.model.FilterOperator.EQ, true));

				aFilters.push(new sap.ui.model.Filter([
					new sap.ui.model.Filter("DateFrom", sap.ui.model.FilterOperator.LE, dToday),
					new sap.ui.model.Filter("DateTo", sap.ui.model.FilterOperator.GE, dToday),
					new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, "MCC")
				], true));

				oSubModel.read("/MCCTags", {
					filters: aFilters,
					success: function (data) {
						data.results.forEach(function (tag) {
							this._generateEngagementTagTiles(tag, oFacetFilterFilters);
						}.bind(this));
					}.bind(this)
				});
			}
		},

		_generateEngagementTagListEntries: function (tag, oFacetFilterFilters) {
			var aPromises = [];
			var oTaskForcesModel = this.oController.getOwnerComponent().getModel("taskForcesModel");
			var oSettings = this.oController.getOwnerComponent().getModel("settings").getData();
			var oList = this.oView.byId("taskForcesList");
			if (oList) {
				var oListItem = new StandardListItem({
					title: tag.Name,
					description: "{= ${filterModel>/region} === '' ? 'Global' : ${filterModel>/regionText}}",
					//icon: "{tileModel>/taskForcesIcon}",
					press: this.oController.onNavToTaskForces.bind(this),
					busy: "{tileModel>/" + tag.Name + "Busy}",
					iconDensityAware: false,
					iconInset: false,
					type: "Navigation",
					counter: {
						parts: ["tileModel>/" + tag.Name + "ValueOngoing"],
						//parts: ["tileModel>/" + tag.Name + "ValueOngoing", "tileModel>/" + tag.Name + "ValueClosed"],
						formatter: function (a, b) {
							var iNum = 0;
							if (a) {
								iNum += a;
							}
							if (b) {
								iNum += b;
							}
							return iNum;
						}
					},
				}).data("key", tag.Name).data("controller", this.oController).data("tagName", tag.Name).data("description", tag.Name).data(
					"serviceTeams", []);
				oList.addItem(oListItem);

				oTaskForcesModel.setProperty("/count", oTaskForcesModel.getProperty("/count") + 1);

				//Customer Engagements
				var oCustomerEngagementPromise = new Promise(function (resolve) {
					var aFiltersCustomerEngagement = [];
					// if (sRegion) {
					// 	var aRegionFilter = [];
					// 	sRegion.split(",").forEach(function (region) {
					// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
					// 	});
					// 	aFiltersCustomerEngagement.push(new sap.ui.model.Filter(aRegionFilter, false));
					// }

					//all ongoing Critical MCC Customer Sit
					//User Status: New, In Process, In Escalation, In Management Review
					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false)
					],
						true
					);
					aFiltersCustomerEngagement.push(tileSpecificFilters);

					if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
						aFiltersCustomerEngagement.push(oFacetFilterFilters);
					}

					var oICModel = this.oController.getOwnerComponent().getModel();
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, tag.Name));

					//CriticalSituations Promise	
					oICModel.read("/CustomerEngagementSet/$count", {
						filters: [new sap.ui.model.Filter(aFiltersCustomerEngagement, true)],
						success: function (data) {
							var obj = {
								iCounter: data,
								entity: "CustomerEngagement"
							};
							resolve(obj);
						}.bind(this),
						error: function () {
							resolve(0);
						}
					});
				}.bind(this));
				aPromises.push(oCustomerEngagementPromise);

				var oCustomerEngagementPromiseRed = new Promise(function (resolve) {
					var aFiltersCustomerEngagement = [];
					// if (sRegion) {
					// 	var aRegionFilter = [];
					// 	sRegion.split(",").forEach(function (region) {
					// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
					// 	});
					// 	aFiltersCustomerEngagement.push(new sap.ui.model.Filter(aRegionFilter, false));
					// }

					//all ongoing Critical MCC Customer Sit
					//User Status: New, In Process, In Escalation, In Management Review
					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false)
					],
						true
					);
					aFiltersCustomerEngagement.push(tileSpecificFilters);

					if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
						aFiltersCustomerEngagement.push(oFacetFilterFilters);
					}

					var oICModel = this.oController.getOwnerComponent().getModel();
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, tag.Name));
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"));

					//CriticalSituations Promise	
					oICModel.read("/CustomerEngagementSet/$count", {
						filters: [new sap.ui.model.Filter(aFiltersCustomerEngagement, true)],
						//urlParameters: {
						//	"$select": "Rating"
						//},
						success: function (data) {
							var obj = {
								iCounterRed: data,
								entity: "CustomerEngagement"
							};
							resolve(obj);
						}.bind(this),
						error: function () {
							resolve(0);
						}
					});
				}.bind(this));
				aPromises.push(oCustomerEngagementPromiseRed);

				var oCustomerEngagementClosed = new Promise(function (resolve) {
					var aFiltersCustomerEngagement = [];
					// if (sRegion) {
					// 	var aRegionFilter = [];
					// 	sRegion.split(",").forEach(function (region) {
					// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
					// 	});
					// 	aFiltersCustomerEngagement.push(new sap.ui.model.Filter(aRegionFilter, false));
					// }

					//all ongoing Critical MCC Customer Sit
					//User Status: New, In Process, In Escalation, In Management Review
					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90")
						], false)
					],
						true
					);
					aFiltersCustomerEngagement.push(tileSpecificFilters);

					if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
						aFiltersCustomerEngagement.push(oFacetFilterFilters);
					}

					var oICModel = this.oController.getOwnerComponent().getModel();
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, tag.Name));

					aFiltersCustomerEngagement.push(this.getClosedDateFilter("ClosingDate"));

					//CriticalSituations Promise	
					oICModel.read("/CustomerEngagementSet/$count", {
						filters: [new sap.ui.model.Filter(aFiltersCustomerEngagement, true)],
						success: function (data) {
							var obj = {
								iCounterClosed: data,
								entity: "CustomerEngagement"
							};
							resolve(obj);
						}.bind(this),
						error: function () {
							resolve(0);
						}
					});
				}.bind(this));
				aPromises.push(oCustomerEngagementClosed);

				var oCCMCPCPromise = new Promise(function (resolve) {

					//read Entries in Service Now for the given Tag in the URL
					var escalationIDsString;

					var sFilterString = "sysparm_query=id_type=Escalation%5elabel.global=true%5elabel.name=" + tag.Name + "&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";
					var oServiceNowTagPromise = new Promise(function (resolve) {
						$.ajax({
							method: "GET",
							headers: {
								"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
							},
							contentType: "application/json",
							url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
							success: function (data) {

								if (data.result.length > 0) {
									var escalationIDs = data.result.map(function (obj) {
										return obj.id_display;
									});

									// Filter out empty or null values
									var validEscalationIDs = escalationIDs.filter(function (id) {
										return id !== null && id !== '';
									});

									// Combine all valid Escalation IDs into a string for the filter
									escalationIDsString = validEscalationIDs.join(',');
									resolve(escalationIDsString);
								} else {
									resolve(escalationIDsString);
								}
							}.bind(this),
							error: function (err) {
								resolve();

							}.bind(this)
						});
					}.bind(this));

					oServiceNowTagPromise.then(function (escalationIDsString) {
						if (escalationIDsString) {
							var oFilterModel = this.oController.getOwnerComponent().getModel("filterModel");
							oFilterModel.refresh(true);
							var sRegion = this.oController.getRegionFilterModel();
							var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");
							var sFilterString = "sysparm_query=state=101^ORstate=100^numberIN" + escalationIDsString;

							if (typeof sRegion !== "undefined" && sRegion !== "") {

								var aRegionHelp = this.getModel("countryRegionModel").getData();
								var selectedRegions = sRegion.split(","); // Split the selected regions into an array

								// Create an object to map selected regions to filterBasis (given in countryRegionModel)
								var regionFilterBasisMap = {
									"EMEA North": "subsubregion",
									"EMEA South": "subsubregion",
									"NA": "region",
									"APJ": "region",
									"MEE": "subregion",
									"GTC": "subregion",
									"LAC": "subregion"
								};

								var regionCountryValues = [];

								// Iterate through selectedRegions and create filters based on filterBasis
								selectedRegions.forEach(function (region) {
									var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

									// Filter regionCountries based on the chosen filter basis
									var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
										return item[filterBasis] === region;
									});

									// Add regionCountryValues for the current region to the array
									regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
										return regionCountry.countryCode;
									}));
								});

								// Extend sFilterString based on regionCountryValues
								if (regionCountryValues.length > 0) {
									var regionFilters = regionCountryValues.map(function (country) {
										return "u_customer_3.country=" + encodeURIComponent(country);
									}).join("%5eOR");

									// Append the new regionFilters to the existing sFilterString
									sFilterString += "^" + regionFilters;
								}

							}

							if (aFilter && aFilter.length > 0) {
								aFilter.forEach(function (filter) {
									sFilterString += "^" + filter;
								});
							}

							sFilterString = sFilterString.replaceAll("^", "%5e");
							//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
							if (sFilterString.startsWith("%5esysparm_query")) {
								sFilterString.replace("%5esysparm_query", "sysparm_query");
							}
							sFilterString += "&sysparm_count=true";

							$.ajax({
								method: "GET",
								contentType: "application/json",
								headers: {
									"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
								},
								url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
								success: function (data) {
									var obj = {
										iCounter: data.result.stats.count,
										entity: "Escalations"
									};
									resolve(obj);
								}.bind(this),
								error: function (err) {
									resolve(0);
								}.bind(this)
							});
						} else {
							resolve(0);
						}
					}.bind(this));
				}.bind(this));
				aPromises.push(oCCMCPCPromise);

				var oCCMCPCPromiseRed = new Promise(function (resolve) {

					//read Entries in Service Now for the given Tag in the URL
					var escalationIDsString;

					//This Filter is only used for DEV since the Global Variable is not working as intended yet
					var sFilterString = "sysparm_query=id_type=Escalation%5elabel.global=true%5elabel.name=" + tag.Name + "&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";
					var oServiceNowTagPromise = new Promise(function (resolve) {
						$.ajax({
							method: "GET",
							headers: {
								"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
							},
							contentType: "application/json",
							url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
							success: function (data) {

								if (data.result.length > 0) {
									var escalationIDs = data.result.map(function (obj) {
										return obj.id_display;
									});

									// Filter out empty or null values
									var validEscalationIDs = escalationIDs.filter(function (id) {
										return id !== null && id !== '';
									});

									// Combine all valid Escalation IDs into a string for the filter
									escalationIDsString = validEscalationIDs.join(',');
									resolve(escalationIDsString);
								} else {
									resolve(escalationIDsString);
								}
							}.bind(this),
							error: function (err) {
								resolve();
							}.bind(this)
						});
					}.bind(this));

					oServiceNowTagPromise.then(function (escalationIDsString) {
						if (escalationIDsString) {
							var oFilterModel = this.oController.getOwnerComponent().getModel("filterModel");
							oFilterModel.refresh(true);
							var sRegion = this.oController.getRegionFilterModel();
							var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");
							var sFilterString = "sysparm_query=state=101^ORstate=100^u_rating=1^numberIN" + escalationIDsString;

							if (typeof sRegion !== "undefined" && sRegion !== "") {

								var aRegionHelp = this.getModel("countryRegionModel").getData();
								var selectedRegions = sRegion.split(","); // Split the selected regions into an array

								// Create an object to map selected regions to filterBasis (given in countryRegionModel)
								var regionFilterBasisMap = {
									"EMEA North": "subsubregion",
									"EMEA South": "subsubregion",
									"NA": "region",
									"APJ": "region",
									"MEE": "subregion",
									"GTC": "subregion",
									"LAC": "subregion"
								};

								var regionCountryValues = [];

								// Iterate through selectedRegions and create filters based on filterBasis
								selectedRegions.forEach(function (region) {
									var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

									// Filter regionCountries based on the chosen filter basis
									var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
										return item[filterBasis] === region;
									});

									// Add regionCountryValues for the current region to the array
									regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
										return regionCountry.countryCode;
									}));
								});

								// Extend sFilterString based on regionCountryValues
								if (regionCountryValues.length > 0) {
									var regionFilters = regionCountryValues.map(function (country) {
										return "u_customer_3.country=" + encodeURIComponent(country);
									}).join("%5eOR");

									// Append the new regionFilters to the existing sFilterString
									sFilterString += "^" + regionFilters;
								}

							}

							if (aFilter && aFilter.length > 0) {
								aFilter.forEach(function (filter) {
									sFilterString += "^" + filter;
								});
							}

							sFilterString += "&sysparm_count=true";
							sFilterString = sFilterString.replaceAll("^", "%5e");
							//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
							if (sFilterString.startsWith("%5esysparm_query")) {
								sFilterString.replace("%5esysparm_query", "sysparm_query");
							}
							sFilterString += Constants.fieldsForCPCTable;

							$.ajax({
								method: "GET",
								contentType: "application/json",
								headers: {
									"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
								},
								url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
								success: function (data) {
									var obj = {
										iCounterRed: data.result.stats.count,
										entity: "Escalations"
									};
									resolve(obj);
								}.bind(this),
								error: function (err) {
									resolve(0);
								}.bind(this)
							});
						} else {
							resolve(0);
						}
					}.bind(this));
				}.bind(this));
				aPromises.push(oCCMCPCPromiseRed);

				var oCCMCPCPromiseClosed = new Promise(function (resolve) {

					//read Entries in Service Now for the given Tag in the URL
					var escalationIDsString;

					//This Filter is only used for DEV since the Global Variable is not working as intended yet
					var sFilterString = "sysparm_query=id_type=Escalation%5elabel.global=true%5elabel.name=" + tag.Name + "&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";
					var oServiceNowTagPromise = new Promise(function (resolve) {
						$.ajax({
							method: "GET",
							headers: {
								"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
							},
							contentType: "application/json",
							url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
							success: function (data) {

								if (data.result.length > 0) {
									var escalationIDs = data.result.map(function (obj) {
										return obj.id_display;
									});

									// Filter out empty or null values
									var validEscalationIDs = escalationIDs.filter(function (id) {
										return id !== null && id !== '';
									});

									// Combine all valid Escalation IDs into a string for the filter
									escalationIDsString = validEscalationIDs.join(',');
									resolve(escalationIDsString);
								} else {
									resolve(escalationIDsString);
								}
							}.bind(this),
							error: function (err) {
								resolve();
							}.bind(this)
						});
					}.bind(this));

					oServiceNowTagPromise.then(function (escalationIDsString) {
						if (escalationIDsString) {
							var oFilterModel = this.oController.getOwnerComponent().getModel("filterModel");
							oFilterModel.refresh(true);
							var sRegion = this.oController.getRegionFilterModel();
							var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");
							var sFilterString = "sysparm_query=state=103^numberIN" + escalationIDsString;

							if (typeof sRegion !== "undefined" && sRegion !== "") {

								var aRegionHelp = this.getModel("countryRegionModel").getData();
								var selectedRegions = sRegion.split(","); // Split the selected regions into an array

								// Create an object to map selected regions to filterBasis (given in countryRegionModel)
								var regionFilterBasisMap = {
									"EMEA North": "subsubregion",
									"EMEA South": "subsubregion",
									"NA": "region",
									"APJ": "region",
									"MEE": "subregion",
									"GTC": "subregion",
									"LAC": "subregion"
								};

								var regionCountryValues = [];

								// Iterate through selectedRegions and create filters based on filterBasis
								selectedRegions.forEach(function (region) {
									var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

									// Filter regionCountries based on the chosen filter basis
									var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
										return item[filterBasis] === region;
									});

									// Add regionCountryValues for the current region to the array
									regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
										return regionCountry.countryCode;
									}));
								});

								// Extend sFilterString based on regionCountryValues
								if (regionCountryValues.length > 0) {
									var regionFilters = regionCountryValues.map(function (country) {
										return "u_customer_3.country=" + encodeURIComponent(country);
									}).join("%5eOR");

									// Append the new regionFilters to the existing sFilterString
									sFilterString += "^" + regionFilters;
								}

							}

							if (aFilter && aFilter.length > 0) {
								aFilter.forEach(function (filter) {
									sFilterString += "^" + filter;
								});
							}

							sFilterString = sFilterString.replaceAll("^", "%5e");
							//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
							if (sFilterString.startsWith("%5esysparm_query")) {
								sFilterString.replace("%5esysparm_query", "sysparm_query");
							}
							sFilterString += "&sysparm_count=true";

							$.ajax({
								method: "GET",
								contentType: "application/json",
								headers: {
									"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
								},
								url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
								success: function (data) {
									var obj = {
										iCounterClosed: data.result.stats.count,
										entity: "Escalations"
									};
									resolve(obj);
								}.bind(this),
								error: function (err) {
									resolve(0);
								}.bind(this)
							});
						} else {
							resolve(0);
						}
					}.bind(this));
				}.bind(this));
				aPromises.push(oCCMCPCPromiseClosed);

				//Global Escalationsw
				//dont load if not authorized
				if (oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations || oSettings.ShowGlobalAggregation) {
					//in case of anonymized mode, no GEM should be retunrned
					if (oSettings.isAnonymizedMode === false) {
						var oGlobalEscalationsPromise = new Promise(function (resolve) {
							var aFiltersGlobalEscalations = [];
							// if (sRegion) {
							// 	var aRegionFilter = [];
							// 	sRegion.split(",").forEach(function (region) {
							// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
							// 	});
							// 	aFiltersGlobalEscalations.push(new sap.ui.model.Filter(aRegionFilter, false));
							// }

							//all ongoing Critical MCC Customer Sit
							//User Status: New, In Process, In Escalation, In Management Review
							var tileSpecificFilters = new sap.ui.model.Filter([
								new sap.ui.model.Filter([
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20"),
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30")
								], false)
							],
								true
							);
							aFiltersGlobalEscalations.push(tileSpecificFilters);

							if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
								aFiltersGlobalEscalations.push(oFacetFilterFilters);
							}

							aFiltersGlobalEscalations.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, tag.Name));

							var oICModel = this.oController.getOwnerComponent().getModel();

							//CriticalSituations Promise	
							oICModel.read("/GlobalEscalationsSet/$count", {
								filters: [new sap.ui.model.Filter(aFiltersGlobalEscalations, true)],
								success: function (data) {
									var obj = {
										iCounter: data,
										entity: "GlobalEscalation"
									};
									resolve(obj);
								}.bind(this),
								error: function () {
									resolve(0);
								}
							});
						}.bind(this));
						aPromises.push(oGlobalEscalationsPromise);

						var oGlobalEscalationsPromiseRed = new Promise(function (resolve) {
							var aFiltersGlobalEscalations = [];
							/*if (sRegion) {
								var aRegionFilter = [];
								sRegion.split(",").forEach(function (region) {
									aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
								});
								aFiltersGlobalEscalations.push(new sap.ui.model.Filter(aRegionFilter, false));
							}*/

							//all ongoing Critical MCC Customer Sit
							//User Status: New, In Process, In Escalation, In Management Review
							var tileSpecificFilters = new sap.ui.model.Filter([
								new sap.ui.model.Filter([
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20"),
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30")
								], false)
							],
								true
							);
							aFiltersGlobalEscalations.push(tileSpecificFilters);

							if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
								aFiltersGlobalEscalations.push(oFacetFilterFilters);
							}

							var oICModel = this.oController.getOwnerComponent().getModel();
							aFiltersGlobalEscalations.push(new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"));
							aFiltersGlobalEscalations.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, tag.Name));
							//CriticalSituations Promise	
							oICModel.read("/GlobalEscalationsSet/$count", {
								filters: [new sap.ui.model.Filter(aFiltersGlobalEscalations, true)],
								success: function (data) {
									var obj = {
										iCounterRed: data,
										entity: "GlobalEscalation"
									};
									resolve(obj);
								}.bind(this),
								error: function () {
									resolve(0);
								}
							});
						}.bind(this));
						aPromises.push(oGlobalEscalationsPromiseRed);

						var oGlobalEscalationsPromiseClosed = new Promise(function (resolve) {
							var aFiltersGlobalEscalations = [];
							// if (sRegion) {
							// 	var aRegionFilter = [];
							// 	sRegion.split(",").forEach(function (region) {
							// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
							// 	});
							// 	aFiltersGlobalEscalations.push(new sap.ui.model.Filter(aRegionFilter, false));
							// }

							//all ongoing Critical MCC Customer Sit
							//User Status: New, In Process, In Escalation, In Management Review
							var tileSpecificFilters = new sap.ui.model.Filter([
								new sap.ui.model.Filter([
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "40")
								], false)
							],
								true
							);
							aFiltersGlobalEscalations.push(tileSpecificFilters);

							if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
								aFiltersGlobalEscalations.push(oFacetFilterFilters);
							}

							var oICModel = this.oController.getOwnerComponent().getModel();
							aFiltersGlobalEscalations.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, tag.Name));
							aFiltersGlobalEscalations.push(this.getClosedDateFilter("ClosingDate"));
							//CriticalSituations Promise	
							oICModel.read("/GlobalEscalationsSet/$count", {
								filters: [new sap.ui.model.Filter(aFiltersGlobalEscalations, true)],
								success: function (data) {
									var obj = {
										iCounterClosed: data,
										entity: "GlobalEscalation"
									};
									resolve(obj);
								}.bind(this),
								error: function () {
									resolve(0);
								}
							});
						}.bind(this));
						aPromises.push(oGlobalEscalationsPromiseClosed);
					}
				}

				Promise.all(aPromises).then(function (aResults) {
					var iSum = 0;
					var iSumRed = 0;
					var iSumClosed = 0;
					var bGlobalEscalation = false;
					aResults.forEach(function (result) {
						if (result.iCounterRed) {
							iSumRed += parseInt(result.iCounterRed, 10);
						}
						if (result.iCounterClosed) {
							iSumClosed += parseInt(result.iCounterClosed, 10);
						}
						if (result.iCounter) {
							iSum += parseInt(result.iCounter, 10);
							bGlobalEscalation = result.entity === "GlobalEscalation" && parseInt(result.iCounter, 10) > 0;
						}
					});

					var sFooter = "";
					var bShowRestrictedView = this.oController.getOwnerComponent().getModel("settings").getProperty(
						"/ShowRegionalGlobalEscalations");
					if (bGlobalEscalation && bShowRestrictedView) {
						sFooter = this.oController.getOwnerComponent().getModel("i18n").getProperty("restrictedView");
					}

					this.oTileModel.setProperty("/" + tag.Name + "ValueOngoing", iSum);
					this.oTileModel.setProperty("/" + tag.Name + "BusyOngoing", false);
					this.oTileModel.setProperty("/" + tag.Name + "ValueRed", iSumRed);
					this.oTileModel.setProperty("/" + tag.Name + "BusyRed", false);
					this.oTileModel.setProperty("/" + tag.Name + "ValueClosed", iSumClosed);
					this.oTileModel.setProperty("/" + tag.Name + "BusyClosed", false);
					this.oTileModel.setProperty("/" + tag.Name + "Busy", false);
				}.bind(this));

			}
		},

		_generateEngagementTagTiles: function (tag, oFacetFilterFilters) {
			var aPromises = [];
			var oSettings = this.oController.getOwnerComponent().getModel("settings").getData();
			var oTileContainer = this.oView.byId("tileContainerInitiativesTaskForces");

			if (oTileContainer) {
				this.oTileModel.setProperty("/" + tag.Name + "BusyOngoing", true);
				this.oTileModel.setProperty("/" + tag.Name + "BusyRed", true);
				this.oTileModel.setProperty("/" + tag.Name + "Busy", true);
				this.oTileModel.setProperty("/" + tag.Name + "ValueOngoing", 0);
				this.oTileModel.setProperty("/" + tag.Name + "BusyClosed", true);
				this.oTileModel.setProperty("/" + tag.Name + "ValueClosed", 0);

				var oCard = new CustomDashboardTile({
					headerTitle: tag.Title,
					headerFilterIconSrc: "{tileModel>/taskForcesIcon}",
					headerInfoIconText: tag.Description,
					headerInfoIconPress: function (oEv) {
						this.oController.onPressInfoIconCards(oEv);
					}.bind(this),
					press: this.oController.onNavToTaskForces.bind(this),
					busyAll: "{tileModel>/" + tag.Name + "Busy}",
					numberAll: {
						parts: ["tileModel>/" + tag.Name + "ValueOngoing", "tileModel>/" + tag.Name + "ValueClosed"],
						formatter: function (a, b) {
							var iNum = 0;
							if (a) {
								iNum += a;
							}
							if (b) {
								iNum += b;
							}
							return iNum;
						}
					},
					items: [
						new CustomDashboardTileItem({
							text: "{i18n>ongoing}",
							value: "{tileModel>/" + tag.Name + "ValueOngoing}",
							state: "Information",
							busy: "{tileModel>/" + tag.Name + "BusyOngoing}",
							press: this.oController.onNavToTaskForces.bind(this)
						}).data("key", tag.Name).data("controller", this.oController).data("tagName", tag.Name).data("description", tag.Name).data(
							"serviceTeams", []),
						new CustomDashboardTileItem({
							text: "{i18n>ratingRed}",
							value: "{tileModel>/" + tag.Name + "ValueRed}",
							state: "Error",
							busy: "{tileModel>/" + tag.Name + "BusyRed}",
							press: this.oController.onNavToTaskForcesRed
						}).data("key", tag.Name).data("controller", this.oController).data("tagName", tag.Name).data("description", tag.Name).data(
							"serviceTeams", []),
						new CustomDashboardTileItem({
							text: "{i18n>closed}",
							value: "{tileModel>/" + tag.Name + "ValueClosed}",
							state: "None",
							busy: "{tileModel>/" + tag.Name + "BusyClosed}",
							press: this.oController.onNavToTaskForcesClosed
						}).data("key", tag.Name).data("controller", this.oController).data("tagName", tag.Name).data("description", tag.Name).data(
							"serviceTeams", [])
					]
				}).data("key", tag.Name).data("controller", this.oController).data("tagName", tag.Name).data("description", tag.Name).data(
					"serviceTeams", []);
				oTileContainer.addItem(oCard);

				//Customer Engagements
				var oCustomerEngagementPromise = new Promise(function (resolve) {
					var aFiltersCustomerEngagement = [];
					// if (sRegion) {
					// 	var aRegionFilter = [];
					// 	sRegion.split(",").forEach(function (region) {
					// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
					// 	});
					// 	aFiltersCustomerEngagement.push(new sap.ui.model.Filter(aRegionFilter, false));
					// }

					//all ongoing Critical MCC Customer Sit
					//User Status: New, In Process, In Escalation, In Management Review
					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false)
					],
						true
					);
					aFiltersCustomerEngagement.push(tileSpecificFilters);

					if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
						aFiltersCustomerEngagement.push(oFacetFilterFilters);
					}

					var oICModel = this.oController.getOwnerComponent().getModel();
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, tag.Name));

					//CriticalSituations Promise	
					oICModel.read("/CustomerEngagementSet/$count", {
						filters: [new sap.ui.model.Filter(aFiltersCustomerEngagement, true)],
						success: function (data) {
							var obj = {
								iCounter: data,
								entity: "CustomerEngagement"
							};
							resolve(obj);
						}.bind(this),
						error: function () {
							resolve(0);
						}
					});
				}.bind(this));
				aPromises.push(oCustomerEngagementPromise);

				var oCustomerEngagementPromiseRed = new Promise(function (resolve) {
					var aFiltersCustomerEngagement = [];
					// if (sRegion) {
					// 	var aRegionFilter = [];
					// 	sRegion.split(",").forEach(function (region) {
					// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
					// 	});
					// 	aFiltersCustomerEngagement.push(new sap.ui.model.Filter(aRegionFilter, false));
					// }

					//all ongoing Critical MCC Customer Sit
					//User Status: New, In Process, In Escalation, In Management Review
					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false)
					],
						true
					);
					aFiltersCustomerEngagement.push(tileSpecificFilters);

					if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
						aFiltersCustomerEngagement.push(oFacetFilterFilters);
					}

					var oICModel = this.oController.getOwnerComponent().getModel();
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, tag.Name));
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"));

					//CriticalSituations Promise	
					oICModel.read("/CustomerEngagementSet/$count", {
						filters: [new sap.ui.model.Filter(aFiltersCustomerEngagement, true)],
						//urlParameters: {
						//	"$select": "Rating"
						//},
						success: function (data) {
							var obj = {
								iCounterRed: data,
								entity: "CustomerEngagement"
							};
							resolve(obj);
						}.bind(this),
						error: function () {
							resolve(0);
						}
					});
				}.bind(this));
				aPromises.push(oCustomerEngagementPromiseRed);

				var oCustomerEngagementClosed = new Promise(function (resolve) {
					var aFiltersCustomerEngagement = [];
					// if (sRegion) {
					// 	var aRegionFilter = [];
					// 	sRegion.split(",").forEach(function (region) {
					// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
					// 	});
					// 	aFiltersCustomerEngagement.push(new sap.ui.model.Filter(aRegionFilter, false));
					// }

					//all ongoing Critical MCC Customer Sit
					//User Status: New, In Process, In Escalation, In Management Review
					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90")
						], false)
					],
						true
					);
					aFiltersCustomerEngagement.push(tileSpecificFilters);

					if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
						aFiltersCustomerEngagement.push(oFacetFilterFilters);
					}

					var oICModel = this.oController.getOwnerComponent().getModel();
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
					aFiltersCustomerEngagement.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, tag.Name));

					aFiltersCustomerEngagement.push(this.getClosedDateFilter("ClosingDate"));

					//CriticalSituations Promise	
					oICModel.read("/CustomerEngagementSet/$count", {
						filters: [new sap.ui.model.Filter(aFiltersCustomerEngagement, true)],
						success: function (data) {
							var obj = {
								iCounterClosed: data,
								entity: "CustomerEngagement"
							};
							resolve(obj);
						}.bind(this),
						error: function () {
							resolve(0);
						}
					});
				}.bind(this));
				aPromises.push(oCustomerEngagementClosed);

				var oCCMCPCPromise = new Promise(function (resolve) {

					//read Entries in Service Now for the given Tag in the URL
					var escalationIDsString;

					//This Filter is only used for DEV since the Global Variable is not working as intended yet
					var sFilterString = "sysparm_query=id_type=Escalation%5elabel.global=true%5elabel.name=" + tag.Name + "&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";
					var oServiceNowTagPromise = new Promise(function (resolve) {
						$.ajax({
							method: "GET",
							headers: {
								"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
							},
							contentType: "application/json",
							url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
							success: function (data) {

								if (data && data.result && data.result.length > 0) {
									var escalationIDs = data.result.map(function (obj) {
										return obj.id_display;
									});

									// Filter out empty or null values
									var validEscalationIDs = escalationIDs.filter(function (id) {
										return id !== null && id !== '';
									});

									// Combine all valid Escalation IDs into a string for the filter
									escalationIDsString = validEscalationIDs.join(',');
									resolve(escalationIDsString);
								} else {
									resolve(escalationIDsString);
								}
							}.bind(this),
							error: function (err) {
								resolve();
							}.bind(this)
						});
					}.bind(this));

					oServiceNowTagPromise.then(function (escalationIDsString) {
						if (escalationIDsString) {
							var oFilterModel = this.oController.getOwnerComponent().getModel("filterModel");
							oFilterModel.refresh(true);
							var sRegion = this.oController.getRegionFilterModel();
							var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");
							var sFilterString = "sysparm_query=state=101^ORstate=100^numberIN" + escalationIDsString;

							if (typeof sRegion !== "undefined" && sRegion !== "") {

								var aRegionHelp = this.getModel("countryRegionModel").getData();
								var selectedRegions = sRegion.split(","); // Split the selected regions into an array

								// Create an object to map selected regions to filterBasis (given in countryRegionModel)
								var regionFilterBasisMap = {
									"EMEA North": "subsubregion",
									"EMEA South": "subsubregion",
									"NA": "region",
									"APJ": "region",
									"MEE": "subregion",
									"GTC": "subregion",
									"LAC": "subregion"
								};

								var regionCountryValues = [];

								// Iterate through selectedRegions and create filters based on filterBasis
								selectedRegions.forEach(function (region) {
									var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

									// Filter regionCountries based on the chosen filter basis
									var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
										return item[filterBasis] === region;
									});

									// Add regionCountryValues for the current region to the array
									regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
										return regionCountry.countryCode;
									}));
								});

								// Extend sFilterString based on regionCountryValues
								if (regionCountryValues.length > 0) {
									var regionFilters = regionCountryValues.map(function (country) {
										return "u_customer_3.country=" + encodeURIComponent(country);
									}).join("%5eOR");

									// Append the new regionFilters to the existing sFilterString
									sFilterString += "^" + regionFilters;
								}

							}

							if (aFilter && aFilter.length > 0) {
								aFilter.forEach(function (filter) {
									sFilterString += "^" + filter;
								});
							}

							sFilterString = sFilterString.replaceAll("^", "%5e");
							//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
							if (sFilterString.startsWith("%5esysparm_query")) {
								sFilterString.replace("%5esysparm_query", "sysparm_query");
							}
							sFilterString += "&sysparm_count=true";

							$.ajax({
								method: "GET",
								contentType: "application/json",
								headers: {
									"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
								},
								url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
								success: function (data) {
									var obj = {
										iCounter: data.result.stats.count,
										entity: "Escalations"
									};
									resolve(obj);
								}.bind(this),
								error: function (err) {
									resolve(0);
								}.bind(this)
							});
						} else {
							resolve(0);
						}
					}.bind(this));
				}.bind(this));
				aPromises.push(oCCMCPCPromise);

				var oCCMCPCPromiseRed = new Promise(function (resolve) {

					//read Entries in Service Now for the given Tag in the URL
					var escalationIDsString;

					//This Filter is only used for DEV since the Global Variable is not working as intended yet
					var sFilterString = "sysparm_query=id_type=Escalation%5elabel.global=true%5elabel.name=" + tag.Name + "&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";
					var oServiceNowTagPromise = new Promise(function (resolve) {
						$.ajax({
							method: "GET",
							headers: {
								"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
							},
							contentType: "application/json",
							url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
							success: function (data) {

								if (data && data.result && data.result.length > 0) {
									var escalationIDs = data.result.map(function (obj) {
										return obj.id_display;
									});

									// Filter out empty or null values
									var validEscalationIDs = escalationIDs.filter(function (id) {
										return id !== null && id !== '';
									});

									// Combine all valid Escalation IDs into a string for the filter
									escalationIDsString = validEscalationIDs.join(',');
									resolve(escalationIDsString);
								} else {
									resolve(escalationIDsString);
								}
							}.bind(this),
							error: function (err) {
								resolve();
							}.bind(this)
						});
					}.bind(this));

					oServiceNowTagPromise.then(function (escalationIDsString) {
						if (escalationIDsString) {
							var oFilterModel = this.oController.getOwnerComponent().getModel("filterModel");
							oFilterModel.refresh(true);
							var sRegion = this.oController.getRegionFilterModel();
							var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");
							var sFilterString = "sysparm_query=state=101^ORstate=100^u_rating=1^numberIN" + escalationIDsString;

							if (typeof sRegion !== "undefined" && sRegion !== "") {

								var aRegionHelp = this.getModel("countryRegionModel").getData();
								var selectedRegions = sRegion.split(","); // Split the selected regions into an array

								// Create an object to map selected regions to filterBasis (given in countryRegionModel)
								var regionFilterBasisMap = {
									"EMEA North": "subsubregion",
									"EMEA South": "subsubregion",
									"NA": "region",
									"APJ": "region",
									"MEE": "subregion",
									"GTC": "subregion",
									"LAC": "subregion"
								};

								var regionCountryValues = [];

								// Iterate through selectedRegions and create filters based on filterBasis
								selectedRegions.forEach(function (region) {
									var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

									// Filter regionCountries based on the chosen filter basis
									var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
										return item[filterBasis] === region;
									});

									// Add regionCountryValues for the current region to the array
									regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
										return regionCountry.countryCode;
									}));
								});

								// Extend sFilterString based on regionCountryValues
								if (regionCountryValues.length > 0) {
									var regionFilters = regionCountryValues.map(function (country) {
										return "u_customer_3.country=" + encodeURIComponent(country);
									}).join("%5eOR");

									// Append the new regionFilters to the existing sFilterString
									sFilterString += "^" + regionFilters;
								}

							}

							if (aFilter && aFilter.length > 0) {
								aFilter.forEach(function (filter) {
									sFilterString += "^" + filter;
								});
							}

							sFilterString += "&sysparm_count=true";
							sFilterString = sFilterString.replaceAll("^", "%5e");
							//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
							if (sFilterString.startsWith("%5esysparm_query")) {
								sFilterString.replace("%5esysparm_query", "sysparm_query");
							}
							sFilterString += Constants.fieldsForCPCTable;

							$.ajax({
								method: "GET",
								contentType: "application/json",
								headers: {
									"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
								},
								url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
								success: function (data) {
									var obj = {
										iCounterRed: data.result.stats.count,
										entity: "Escalations"
									};
									resolve(obj);
								}.bind(this),
								error: function (err) {
									resolve(0);
								}.bind(this)
							});
						} else {
							resolve(0);
						}
					}.bind(this));
				}.bind(this));
				aPromises.push(oCCMCPCPromiseRed);

				var oCCMCPCPromiseClosed = new Promise(function (resolve) {

					//read Entries in Service Now for the given Tag in the URL
					var escalationIDsString;

					//This Filter is only used for DEV since the Global Variable is not working as intended yet
					var sFilterString = "sysparm_query=id_type=Escalation%5elabel.global=true%5elabel.name=" + tag.Name + "&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";
					var oServiceNowTagPromise = new Promise(function (resolve) {
						$.ajax({
							method: "GET",
							headers: {
								"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
							},
							contentType: "application/json",
							url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
							success: function (data) {

								if (data && data.result && data.result.length > 0) {
									var escalationIDs = data.result.map(function (obj) {
										return obj.id_display;
									});

									// Filter out empty or null values
									var validEscalationIDs = escalationIDs.filter(function (id) {
										return id !== null && id !== '';
									});

									// Combine all valid Escalation IDs into a string for the filter
									escalationIDsString = validEscalationIDs.join(',');
									resolve(escalationIDsString);
								} else {
									resolve(escalationIDsString);
								}
							}.bind(this),
							error: function (err) {
								resolve();
							}.bind(this)
						});
					}.bind(this));

					oServiceNowTagPromise.then(function (escalationIDsString) {
						if (escalationIDsString) {
							var oFilterModel = this.oController.getOwnerComponent().getModel("filterModel");
							oFilterModel.refresh(true);
							var sRegion = this.oController.getRegionFilterModel();
							var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");
							var sFilterString = "sysparm_query=state=103^numberIN" + escalationIDsString;

							if (typeof sRegion !== "undefined" && sRegion !== "") {

								var aRegionHelp = this.getModel("countryRegionModel").getData();
								var selectedRegions = sRegion.split(","); // Split the selected regions into an array

								// Create an object to map selected regions to filterBasis (given in countryRegionModel)
								var regionFilterBasisMap = {
									"EMEA North": "subsubregion",
									"EMEA South": "subsubregion",
									"NA": "region",
									"APJ": "region",
									"MEE": "subregion",
									"GTC": "subregion",
									"LAC": "subregion"
								};

								var regionCountryValues = [];

								// Iterate through selectedRegions and create filters based on filterBasis
								selectedRegions.forEach(function (region) {
									var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

									// Filter regionCountries based on the chosen filter basis
									var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
										return item[filterBasis] === region;
									});

									// Add regionCountryValues for the current region to the array
									regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
										return regionCountry.countryCode;
									}));
								});

								// Extend sFilterString based on regionCountryValues
								if (regionCountryValues.length > 0) {
									var regionFilters = regionCountryValues.map(function (country) {
										return "u_customer_3.country=" + encodeURIComponent(country);
									}).join("%5eOR");

									// Append the new regionFilters to the existing sFilterString
									sFilterString += "^" + regionFilters;
								}

							}

							if (aFilter && aFilter.length > 0) {
								aFilter.forEach(function (filter) {
									sFilterString += "^" + filter;
								});
							}

							sFilterString = sFilterString.replaceAll("^", "%5e");
							//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
							if (sFilterString.startsWith("%5esysparm_query")) {
								sFilterString.replace("%5esysparm_query", "sysparm_query");
							}
							sFilterString += "&sysparm_count=true";

							$.ajax({
								method: "GET",
								contentType: "application/json",
								headers: {
									"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
								},
								url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
								success: function (data) {
									var obj = {
										iCounterClosed: data.result.stats.count,
										entity: "Escalations"
									};
									resolve(obj);
								}.bind(this),
								error: function (err) {
									resolve(0);
								}.bind(this)
							});
						} else {
							resolve(0);
						}
					}.bind(this));
				}.bind(this));
				aPromises.push(oCCMCPCPromiseClosed);

				//Global Escalationsw
				//dont load if not authorized
				if (oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations || oSettings.ShowGlobalAggregation) {
					//in case of anonymized mode, no GEM should be retunrned
					if (oSettings.isAnonymizedMode === false) {
						var oGlobalEscalationsPromise = new Promise(function (resolve) {
							var aFiltersGlobalEscalations = [];
							// if (sRegion) {
							// 	var aRegionFilter = [];
							// 	sRegion.split(",").forEach(function (region) {
							// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
							// 	});
							// 	aFiltersGlobalEscalations.push(new sap.ui.model.Filter(aRegionFilter, false));
							// }

							//all ongoing Critical MCC Customer Sit
							//User Status: New, In Process, In Escalation, In Management Review
							var tileSpecificFilters = new sap.ui.model.Filter([
								new sap.ui.model.Filter([
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20"),
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30")
								], false)
							],
								true
							);
							aFiltersGlobalEscalations.push(tileSpecificFilters);

							if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
								aFiltersGlobalEscalations.push(oFacetFilterFilters);
							}

							aFiltersGlobalEscalations.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, tag.Name));

							var oICModel = this.oController.getOwnerComponent().getModel();

							//CriticalSituations Promise	
							oICModel.read("/GlobalEscalationsSet/$count", {
								filters: [new sap.ui.model.Filter(aFiltersGlobalEscalations, true)],
								success: function (data) {
									var obj = {
										iCounter: data,
										entity: "GlobalEscalation"
									};
									resolve(obj);
								}.bind(this),
								error: function () {
									resolve(0);
								}
							});
						}.bind(this));
						aPromises.push(oGlobalEscalationsPromise);

						var oGlobalEscalationsPromiseRed = new Promise(function (resolve) {
							var aFiltersGlobalEscalations = [];
							/*if (sRegion) {
								var aRegionFilter = [];
								sRegion.split(",").forEach(function (region) {
									aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
								});
								aFiltersGlobalEscalations.push(new sap.ui.model.Filter(aRegionFilter, false));
							}*/

							//all ongoing Critical MCC Customer Sit
							//User Status: New, In Process, In Escalation, In Management Review
							var tileSpecificFilters = new sap.ui.model.Filter([
								new sap.ui.model.Filter([
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20"),
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30")
								], false)
							],
								true
							);
							aFiltersGlobalEscalations.push(tileSpecificFilters);

							if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
								aFiltersGlobalEscalations.push(oFacetFilterFilters);
							}

							var oICModel = this.oController.getOwnerComponent().getModel();
							aFiltersGlobalEscalations.push(new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"));
							aFiltersGlobalEscalations.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, tag.Name));
							//CriticalSituations Promise	
							oICModel.read("/GlobalEscalationsSet/$count", {
								filters: [new sap.ui.model.Filter(aFiltersGlobalEscalations, true)],
								success: function (data) {
									var obj = {
										iCounterRed: data,
										entity: "GlobalEscalation"
									};
									resolve(obj);
								}.bind(this),
								error: function () {
									resolve(0);
								}
							});
						}.bind(this));
						aPromises.push(oGlobalEscalationsPromiseRed);

						var oGlobalEscalationsPromiseClosed = new Promise(function (resolve) {
							var aFiltersGlobalEscalations = [];
							// if (sRegion) {
							// 	var aRegionFilter = [];
							// 	sRegion.split(",").forEach(function (region) {
							// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
							// 	});
							// 	aFiltersGlobalEscalations.push(new sap.ui.model.Filter(aRegionFilter, false));
							// }

							//all ongoing Critical MCC Customer Sit
							//User Status: New, In Process, In Escalation, In Management Review
							var tileSpecificFilters = new sap.ui.model.Filter([
								new sap.ui.model.Filter([
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "40")
								], false)
							],
								true
							);
							aFiltersGlobalEscalations.push(tileSpecificFilters);

							if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
								aFiltersGlobalEscalations.push(oFacetFilterFilters);
							}

							var oICModel = this.oController.getOwnerComponent().getModel();
							aFiltersGlobalEscalations.push(new sap.ui.model.Filter("CaseTag", sap.ui.model.FilterOperator.EQ, tag.Name));
							aFiltersGlobalEscalations.push(this.getClosedDateFilter("ClosingDate"));
							//CriticalSituations Promise	
							oICModel.read("/GlobalEscalationsSet/$count", {
								filters: [new sap.ui.model.Filter(aFiltersGlobalEscalations, true)],
								success: function (data) {
									var obj = {
										iCounterClosed: data,
										entity: "GlobalEscalation"
									};
									resolve(obj);
								}.bind(this),
								error: function () {
									resolve(0);
								}
							});
						}.bind(this));
						aPromises.push(oGlobalEscalationsPromiseClosed);
					}
				}

				Promise.all(aPromises).then(function (aResults) {
					var iSum = 0;
					var iSumRed = 0;
					var iSumClosed = 0;
					var bGlobalEscalation = false;
					aResults.forEach(function (result) {
						if (result.iCounterRed) {
							iSumRed += parseInt(result.iCounterRed, 10);
						}
						if (result.iCounterClosed) {
							iSumClosed += parseInt(result.iCounterClosed, 10);
						}
						if (result.iCounter) {
							iSum += parseInt(result.iCounter, 10);
							bGlobalEscalation = result.entity === "GlobalEscalation" && parseInt(result.iCounter, 10) > 0;
						}
					});

					var sFooter = "";
					var bShowRestrictedView = this.oController.getOwnerComponent().getModel("settings").getProperty(
						"/ShowRegionalGlobalEscalations");
					if (bGlobalEscalation && bShowRestrictedView) {
						sFooter = this.oController.getOwnerComponent().getModel("i18n").getProperty("restrictedView");
					}

					this.oTileModel.setProperty("/" + tag.Name + "ValueOngoing", iSum);
					this.oTileModel.setProperty("/" + tag.Name + "BusyOngoing", false);
					this.oTileModel.setProperty("/" + tag.Name + "ValueRed", iSumRed);
					this.oTileModel.setProperty("/" + tag.Name + "BusyRed", false);
					this.oTileModel.setProperty("/" + tag.Name + "ValueClosed", iSumClosed);
					this.oTileModel.setProperty("/" + tag.Name + "BusyClosed", false);
					this.oTileModel.setProperty("/" + tag.Name + "Busy", false);
				}.bind(this));

			}
		},

		_generateTaskForcesModel: function (bp, oFacetFilterFilters) {
			var oList = this.oView.byId("taskForcesList");
			if (oList) {
				var oSettings = this.oController.getOwnerComponent().getModel("settings").getData();
				var sDescription = this.oController.getTaskForcesDescription(bp.Description);
				this.oTileModel.setProperty("/" + bp.Key + "TFName");
				this.oTileModel.setProperty("/" + bp.Key + "BusyOngoing", true);
				this.oTileModel.setProperty("/" + bp.Key + "BusyRed", true);
				this.oTileModel.setProperty("/" + bp.Key + "Busy", true);

				var oListItem = new StandardListItem({
					title: sDescription,
					//icon: "{tileModel>/taskForcesIcon}",
					description: "{= ${filterModel>/region} === '' ? 'Global' : ${filterModel>/regionText}}",
					press: this.oController.onNavToTaskForces.bind(this),
					busy: "{tileModel>/" + bp.Key + "Busy}",
					counter: "{tileModel>/" + bp.Key + "ValueOngoing}",
					iconDensityAware: false,
					iconInset: false,
					type: "Navigation",
				}).data("controller", this.oController).data("key", bp.Key).data("description", sDescription).data("serviceTeams", aServiceTeams)
					.data("tagName", "");
				oList.addItem(oListItem);

				var aServiceTeamFilter = [];
				var aServiceTeams = [];
				var aPromises = [];
				bp.toServiceTeam.results.forEach(function (serviceTeam) {
					aServiceTeamFilter.push(new sap.ui.model.Filter("ServiceTeam", sap.ui.model.FilterOperator.EQ, this.oController.pad(
						serviceTeam.Key, 10)));
					aServiceTeams.push(this.oController.pad(serviceTeam.Key, 10));
				}.bind(this));

				var oServiceTeamFilter = new sap.ui.model.Filter(aServiceTeamFilter, false);

				var oCriticalSituationsPromise = new Promise(function (resolve) {
					var aFiltersCriticalSituations = [];
					// if (sRegion) {
					// 	var aRegionFilter = [];
					// 	sRegion.split(",").forEach(function (region) {
					// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
					// 	});
					// 	aFiltersCriticalSituations.push(new sap.ui.model.Filter(aRegionFilter, false));
					// }

					//all ongoing Critical MCC Customer Sit
					//User Status: New, In Process, In Escalation, In Management Review
					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false),
						oServiceTeamFilter
					],
						true
					);
					aFiltersCriticalSituations.push(tileSpecificFilters);

					if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
						aFiltersCriticalSituations.push(oFacetFilterFilters);
					}

					var oICModel = this.oController.getOwnerComponent().getModel();
					aFiltersCriticalSituations.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

					//CriticalSituations Promise	
					oICModel.read("/CriticalSituationsSet/$count", {
						filters: [new sap.ui.model.Filter(aFiltersCriticalSituations, true)],
						success: function (data) {
							var obj = {
								iCounter: data,
								entity: "CriticalSituation"
							};
							resolve(obj);
						}.bind(this),
						error: function () {
							resolve(0);
						}
					});
				}.bind(this));
				aPromises.push(oCriticalSituationsPromise);

				var oCriticalSituationsPromiseRed = new Promise(function (resolve) {
					var aFiltersCriticalSituations = [];
					// if (sRegion) {
					// 	var aRegionFilter = [];
					// 	sRegion.split(",").forEach(function (region) {
					// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
					// 	});
					// 	aFiltersCriticalSituations.push(new sap.ui.model.Filter(aRegionFilter, false));
					// }

					//all ongoing Critical MCC Customer Sit
					//User Status: New, In Process, In Escalation, In Management Review
					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false),
						oServiceTeamFilter
					],
						true
					);
					aFiltersCriticalSituations.push(tileSpecificFilters);

					if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
						aFiltersCriticalSituations.push(oFacetFilterFilters);
					}

					var oICModel = this.oController.getOwnerComponent().getModel();
					aFiltersCriticalSituations.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
					aFiltersCriticalSituations.push(new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"));
					//CriticalSituations Promise	
					oICModel.read("/CriticalSituationsSet/$count", {
						filters: [new sap.ui.model.Filter(aFiltersCriticalSituations, true)],
						//urlParameters: {
						//	"$select": "Rating"
						//},
						success: function (data) {
							var obj = {
								iCounterRed: data,
								entity: "CriticalSituation"
							};
							resolve(obj);
						}.bind(this),
						error: function () {
							resolve(0);
						}
					});
				}.bind(this));
				aPromises.push(oCriticalSituationsPromiseRed);

				//dont load if not authorized
				if (oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations || oSettings.ShowGlobalAggregation) {
					//in case of anonymized mode, no GEM should be retunrned
					if (oSettings.isAnonymizedMode === false) {
						var oGlobalEscalationsPromise = new Promise(function (resolve) {
							var aFiltersGlobalEscalations = [];
							// if (sRegion) {
							// 	var aRegionFilter = [];
							// 	sRegion.split(",").forEach(function (region) {
							// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
							// 	});
							// 	aFiltersGlobalEscalations.push(new sap.ui.model.Filter(aRegionFilter, false));
							// }

							//all ongoing Critical MCC Customer Sit
							//User Status: New, In Process, In Escalation, In Management Review
							var tileSpecificFilters = new sap.ui.model.Filter([
								new sap.ui.model.Filter([
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20"),
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30")
								], false),
								oServiceTeamFilter
							],
								true
							);
							aFiltersGlobalEscalations.push(tileSpecificFilters);

							if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
								aFiltersGlobalEscalations.push(oFacetFilterFilters);
							}

							var oICModel = this.oController.getOwnerComponent().getModel();

							//CriticalSituations Promise	
							oICModel.read("/GlobalEscalationsSet/$count", {
								filters: [new sap.ui.model.Filter(aFiltersGlobalEscalations, true)],
								success: function (data) {
									var obj = {
										iCounter: data,
										entity: "GlobalEscalation"
									};
									resolve(obj);
								}.bind(this),
								error: function () {
									resolve(0);
								}
							});
						}.bind(this));
						aPromises.push(oGlobalEscalationsPromise);

						var oGlobalEscalationsPromiseRed = new Promise(function (resolve) {
							var aFiltersGlobalEscalations = [];
							// if (sRegion) {
							// 	var aRegionFilter = [];
							// 	sRegion.split(",").forEach(function (region) {
							// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
							// 	});
							// 	aFiltersGlobalEscalations.push(new sap.ui.model.Filter(aRegionFilter, false));
							// }

							//all ongoing Critical MCC Customer Sit
							//User Status: New, In Process, In Escalation, In Management Review
							var tileSpecificFilters = new sap.ui.model.Filter([
								new sap.ui.model.Filter([
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20"),
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30")
								], false),
								oServiceTeamFilter
							],
								true
							);
							aFiltersGlobalEscalations.push(tileSpecificFilters);

							if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
								aFiltersGlobalEscalations.push(oFacetFilterFilters);
							}

							var oICModel = this.oController.getOwnerComponent().getModel();
							aFiltersGlobalEscalations.push(new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"));
							//CriticalSituations Promise	
							oICModel.read("/GlobalEscalationsSet/$count", {
								filters: [new sap.ui.model.Filter(aFiltersGlobalEscalations, true)],
								success: function (data) {
									var obj = {
										iCounterRed: data,
										entity: "GlobalEscalation"
									};
									resolve(obj);
								}.bind(this),
								error: function () {
									resolve(0);
								}
							});
						}.bind(this));
						aPromises.push(oGlobalEscalationsPromiseRed);
					}
				}

				var oCCMCPCPromise = new Promise(function (resolve) {
					//read Entries in Service Now for the given Tag in the URL
					var escalationIDsString;

					//This Filter is only used for DEV since the Global Variable is not working as intended yet
					var sFilterString = "sysparm_query=id_type=Escalation%5elabel.global=true%5elabel.name=" + bp.key + "&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";
					var oServiceNowTagPromise = new Promise(function (resolve) {
						$.ajax({
							method: "GET",
							headers: {
								"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
							},
							contentType: "application/json",
							url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
							success: function (data) {

								if (data.result.length > 0) {
									var escalationIDs = data.result.map(function (obj) {
										return obj.id_display;
									});

									// Filter out empty or null values
									var validEscalationIDs = escalationIDs.filter(function (id) {
										return id !== null && id !== '';
									});

									// Combine all valid Escalation IDs into a string for the filter
									escalationIDsString = validEscalationIDs.join(',');
									resolve(escalationIDsString);
								} else {
									resolve(escalationIDsString);
								}
							}.bind(this),
							error: function (err) {
								resolve();
							}.bind(this)
						});
					}.bind(this));

					oServiceNowTagPromise.then(function (escalationIDsString) {
						if (escalationIDsString) {
							var oFilterModel = this.oController.getOwnerComponent().getModel("filterModel");
							oFilterModel.refresh(true);
							var sRegion = this.oController.getRegionFilterModel();
							var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");
							var sFilterString = "sysparm_query=state=101^ORstate=100^numberIN" + escalationIDsString;

							if (typeof sRegion !== "undefined" && sRegion !== "") {

								var aRegionHelp = this.getModel("countryRegionModel").getData();
								var selectedRegions = sRegion.split(","); // Split the selected regions into an array

								// Create an object to map selected regions to filterBasis (given in countryRegionModel)
								var regionFilterBasisMap = {
									"EMEA North": "subsubregion",
									"EMEA South": "subsubregion",
									"NA": "region",
									"APJ": "region",
									"MEE": "subregion",
									"GTC": "subregion",
									"LAC": "subregion"
								};

								var regionCountryValues = [];

								// Iterate through selectedRegions and create filters based on filterBasis
								selectedRegions.forEach(function (region) {
									var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

									// Filter regionCountries based on the chosen filter basis
									var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
										return item[filterBasis] === region;
									});

									// Add regionCountryValues for the current region to the array
									regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
										return regionCountry.countryCode;
									}));
								});

								// Extend sFilterString based on regionCountryValues
								if (regionCountryValues.length > 0) {
									var regionFilters = regionCountryValues.map(function (country) {
										return "u_customer_3.country=" + encodeURIComponent(country);
									}).join("%5eOR");

									// Append the new regionFilters to the existing sFilterString
									sFilterString += "^" + regionFilters;
								}

							}

							if (aFilter && aFilter.length > 0) {
								aFilter.forEach(function (filter) {
									sFilterString += "^" + filter;
								});
							}

							sFilterString = sFilterString.replaceAll("^", "%5e");
							//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
							if (sFilterString.startsWith("%5esysparm_query")) {
								sFilterString.replace("%5esysparm_query", "sysparm_query");
							}
							sFilterString += "&sysparm_count=true";

							$.ajax({
								method: "GET",
								contentType: "application/json",
								headers: {
									"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
								},
								url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
								success: function (data) {
									var obj = {
										iCounter: data.result.stats.count,
										entity: "Escalations"
									};
									resolve(obj);
								}.bind(this),
								error: function (err) {
									resolve(0);
								}.bind(this)
							});
						} else {
							resolve(0);
						}
					}.bind(this));
				}.bind(this));
				aPromises.push(oCCMCPCPromise);

				var oCCMCPCPromiseRed = new Promise(function (resolve) {

					//read Entries in Service Now for the given Tag in the URL
					var escalationIDsString;

					//This Filter is only used for DEV since the Global Variable is not working as intended yet
					var sFilterString = "sysparm_query=id_type=Escalation%5elabel.global=true%5elabel.name=" + bp.key + "&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";
					var oServiceNowTagPromise = new Promise(function (resolve) {
						$.ajax({
							method: "GET",
							headers: {
								"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
							},
							contentType: "application/json",
							url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
							success: function (data) {

								if (data.result.length > 0) {
									var escalationIDs = data.result.map(function (obj) {
										return obj.id_display;
									});

									// Filter out empty or null values
									var validEscalationIDs = escalationIDs.filter(function (id) {
										return id !== null && id !== '';
									});

									// Combine all valid Escalation IDs into a string for the filter
									escalationIDsString = validEscalationIDs.join(',');
									resolve(escalationIDsString);
								} else {
									resolve(escalationIDsString);
								}
							}.bind(this),
							error: function (err) {
								resolve();
							}.bind(this)
						});
					}.bind(this));

					oServiceNowTagPromise.then(function (escalationIDsString) {
						if (escalationIDsString) {
							var oFilterModel = this.oController.getOwnerComponent().getModel("filterModel");
							oFilterModel.refresh(true);
							var sRegion = this.oController.getRegionFilterModel();
							var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");
							var sFilterString = "sysparm_query=state=101^ORstate=100^u_rating=1^numberIN" + escalationIDsString;

							if (typeof sRegion !== "undefined" && sRegion !== "") {

								var aRegionHelp = this.getModel("countryRegionModel").getData();
								var selectedRegions = sRegion.split(","); // Split the selected regions into an array

								// Create an object to map selected regions to filterBasis (given in countryRegionModel)
								var regionFilterBasisMap = {
									"EMEA North": "subsubregion",
									"EMEA South": "subsubregion",
									"NA": "region",
									"APJ": "region",
									"MEE": "subregion",
									"GTC": "subregion",
									"LAC": "subregion"
								};

								var regionCountryValues = [];

								// Iterate through selectedRegions and create filters based on filterBasis
								selectedRegions.forEach(function (region) {
									var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

									// Filter regionCountries based on the chosen filter basis
									var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
										return item[filterBasis] === region;
									});

									// Add regionCountryValues for the current region to the array
									regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
										return regionCountry.countryCode;
									}));
								});

								// Extend sFilterString based on regionCountryValues
								if (regionCountryValues.length > 0) {
									var regionFilters = regionCountryValues.map(function (country) {
										return "u_customer_3.country=" + encodeURIComponent(country);
									}).join("%5eOR");

									// Append the new regionFilters to the existing sFilterString
									sFilterString += "^" + regionFilters;
								}

							}

							if (aFilter && aFilter.length > 0) {
								aFilter.forEach(function (filter) {
									sFilterString += "^" + filter;
								});
							}

							sFilterString += "&sysparm_count=true";
							sFilterString = sFilterString.replaceAll("^", "%5e");
							//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
							if (sFilterString.startsWith("%5esysparm_query")) {
								sFilterString.replace("%5esysparm_query", "sysparm_query");
							}

							$.ajax({
								method: "GET",
								contentType: "application/json",
								headers: {
									"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
								},
								url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
								success: function (data) {
									var obj = {
										iCounterRed: data.result.stats.count,
										entity: "Escalations"
									};
									resolve(obj);
								}.bind(this),
								error: function (err) {
									resolve(0);
								}.bind(this)
							});
						} else {
							resolve(0);
						}
					}.bind(this));
				}.bind(this));
				aPromises.push(oCCMCPCPromiseRed);

				var oCCMCPCPromiseClosed = new Promise(function (resolve) {

					//read Entries in Service Now for the given Tag in the URL
					var escalationIDsString;

					//This Filter is only used for DEV since the Global Variable is not working as intended yet
					var sFilterString = "sysparm_query=id_type=Escalation%5elabel.global=true%5elabel.name=" + bp.key + "&sysparm_fields=id_type,label.sys_id,label.name,label.sys_created_on,id_display,label.global";
					var oServiceNowTagPromise = new Promise(function (resolve) {
						$.ajax({
							method: "GET",
							headers: {
								"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
							},
							contentType: "application/json",
							url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?" + sFilterString,
							success: function (data) {

								if (data.result.length > 0) {
									var escalationIDs = data.result.map(function (obj) {
										return obj.id_display;
									});

									// Filter out empty or null values
									var validEscalationIDs = escalationIDs.filter(function (id) {
										return id !== null && id !== '';
									});

									// Combine all valid Escalation IDs into a string for the filter
									escalationIDsString = validEscalationIDs.join(',');
									resolve(escalationIDsString);
								} else {
									resolve(escalationIDsString);
								}
							}.bind(this),
							error: function (err) {
								resolve();
							}.bind(this)
						});
					}.bind(this));

					oServiceNowTagPromise.then(function (escalationIDsString) {
						if (escalationIDsString) {
							var oFilterModel = this.oController.getOwnerComponent().getModel("filterModel");
							oFilterModel.refresh(true);
							var sRegion = this.oController.getRegionFilterModel();
							var aFilter = oFilterModel.getProperty("/oFilterForServiceNowForCPC");
							var sFilterString = "sysparm_query=state=103^numberIN" + escalationIDsString;

							if (typeof sRegion !== "undefined" && sRegion !== "") {

								var aRegionHelp = this.getModel("countryRegionModel").getData();
								var selectedRegions = sRegion.split(","); // Split the selected regions into an array

								// Create an object to map selected regions to filterBasis (given in countryRegionModel)
								var regionFilterBasisMap = {
									"EMEA North": "subsubregion",
									"EMEA South": "subsubregion",
									"NA": "region",
									"APJ": "region",
									"MEE": "subregion",
									"GTC": "subregion",
									"LAC": "subregion"
								};

								var regionCountryValues = [];

								// Iterate through selectedRegions and create filters based on filterBasis
								selectedRegions.forEach(function (region) {
									var filterBasis = regionFilterBasisMap[region] || "region"; // Default to "region"

									// Filter regionCountries based on the chosen filter basis
									var regionCountries = aRegionHelp.RegionHelp.filter(function (item) {
										return item[filterBasis] === region;
									});

									// Add regionCountryValues for the current region to the array
									regionCountryValues = regionCountryValues.concat(regionCountries.map(function (regionCountry) {
										return regionCountry.countryCode;
									}));
								});

								// Extend sFilterString based on regionCountryValues
								if (regionCountryValues.length > 0) {
									var regionFilters = regionCountryValues.map(function (country) {
										return "u_customer_3.country=" + encodeURIComponent(country);
									}).join("%5eOR");

									// Append the new regionFilters to the existing sFilterString
									sFilterString += "^" + regionFilters;
								}

							}

							if (aFilter && aFilter.length > 0) {
								aFilter.forEach(function (filter) {
									sFilterString += "^" + filter;
								});
							}

							//sFilterString += "&sysparm_count=true";
							sFilterString = sFilterString.replaceAll("^", "%5e");
							//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
							if (sFilterString.startsWith("%5esysparm_query")) {
								sFilterString.replace("%5esysparm_query", "sysparm_query");
							}
							sFilterString += Constants.fieldsForCPCTable;

							$.ajax({
								method: "GET",
								contentType: "application/json",
								headers: {
									"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
								},
								url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
								success: function (data) {
									var obj = {
										iCounterClosed: data.result.stats.count,
										entity: "Escalations"
									};
									resolve(obj);
								}.bind(this),
								error: function (err) {
									resolve(0);
								}.bind(this)
							});
						} else {
							resolve(0);
						}
					}.bind(this));
				}.bind(this));
				aPromises.push(oCCMCPCPromiseClosed);

				Promise.all(aPromises).then(function (aResults) {
					var iSum = 0;
					var iSumRed = 0;
					var iSumClosed = 0;
					var bGlobalEscalation = false;
					aResults.forEach(function (result) {
						if (result.iCounterRed) {
							iSumRed += parseInt(result.iCounterRed);
						}
						if (result.iCounterClosed) {
							iSumClosed += parseInt(result.iCounterClosed);
						}
						if (result.iCounter) {
							iSum += parseInt(result.iCounter);
							bGlobalEscalation = result.entity === "GlobalEscalation" && parseInt(result.iCounter) > 0;
						}
					});

					var bShowRestrictedView = this.oController.getOwnerComponent().getModel("settings").getProperty(
						"/ShowRegionalGlobalEscalations");
					if (bGlobalEscalation && bShowRestrictedView) {
						sFooter = this.oController.getOwnerComponent().getModel("i18n").getProperty("restrictedView");
					}

					this.oTileModel.setProperty("/" + bp.Key + "ValueOngoing", iSum);
					this.oTileModel.setProperty("/" + bp.Key + "BusyOngoing", false);
					this.oTileModel.setProperty("/" + bp.Key + "ValueRed", iSumRed);
					this.oTileModel.setProperty("/" + bp.Key + "BusyRed", false);
					this.oTileModel.setProperty("/" + bp.Key + "Busy", false);
				}.bind(this));
			}
		},

		_generateTaskForcesTiles: function (bp, oFacetFilterFilters) {
			var oTileContainer = this.oView.byId("tileContainerInitiativesTaskForces");
			if (oTileContainer) {
				var oSettings = this.oController.getOwnerComponent().getModel("settings").getData();
				var sDescription = this.oController.getTaskForcesDescription(bp.Description);
				this.oTileModel.setProperty("/" + bp.Key + "BusyOngoing", true);
				this.oTileModel.setProperty("/" + bp.Key + "BusyRed", true);
				this.oTileModel.setProperty("/" + bp.Key + "Busy", true);
				this.oTileModel.setProperty("/" + bp.Key + "ValueOngoing", 0);
				var oCard = new CustomDashboardTile({
					headerTitle: sDescription,
					headerFilterIconSrc: "{tileModel>/taskForcesIcon}",
					headerInfoIconText: sDescription,
					headerInfoIconPress: function (oEv) {
						this.oController.onPressInfoIconCards(oEv);
					}.bind(this),
					press: this.oController.onNavToTaskForces.bind(this),
					busyAll: "{tileModel>/" + bp.Key + "Busy}",
					numberAll: {
						parts: ["tileModel>/" + bp.Key + "ValueOngoing", "tileModel>/" + bp.Key + "ValueClosed"],
						formatter: function (a, b) {
							var iNum = 0;
							if (a) {
								iNum += a;
							}
							if (b) {
								iNum += b;
							}
							return iNum;
						}
					},
					items: [
						new CustomDashboardTileItem({
							text: "{i18n>ongoing}",
							value: "{tileModel>/" + bp.Key + "ValueOngoing}",
							state: "Information",
							busy: "{tileModel>/" + bp.Key + "BusyOngoing}",
							press: this.oController.onNavToTaskForces.bind(this)
						}).data("controller", this.oController).data("key", bp.Key).data("description", sDescription).data("serviceTeams",
							aServiceTeams).data("tagName", ""),
						new CustomDashboardTileItem({
							text: "{i18n>ratingRed}",
							value: "{tileModel>/" + bp.Key + "ValueRed}",
							state: "Error",
							busy: "{tileModel>/" + bp.Key + "BusyRed}",
							press: this.oController.onNavToTaskForcesRed
						}).data("controller", this.oController).data("key", bp.Key).data("description", sDescription).data("serviceTeams",
							aServiceTeams).data("tagName", ""),
						new CustomDashboardTileItem({
							text: "{i18n>closed}",
							value: "{tileModel>/" + bp.Key + "ValueClosed}",
							state: "None",
							busy: "{tileModel>/" + bp.Key + "BusyClosed}",
							press: this.oController.onNavToTaskForcesClosed
						}).data("controller", this.oController).data("key", bp.Key).data("description", sDescription).data("serviceTeams",
							aServiceTeams).data("tagName", "")
					]
				}).data("controller", this.oController).data("key", bp.Key).data("description", sDescription).data("serviceTeams", aServiceTeams)
					.data("tagName", "");
				oTileContainer.addItem(oCard);

				var aServiceTeamFilter = [];
				var aServiceTeams = [];
				var aPromises = [];
				bp.toServiceTeam.results.forEach(function (serviceTeam) {
					aServiceTeamFilter.push(new sap.ui.model.Filter("ServiceTeam", sap.ui.model.FilterOperator.EQ, this.oController.pad(
						serviceTeam.Key, 10)));
					aServiceTeams.push(this.oController.pad(serviceTeam.Key, 10));
				}.bind(this));

				var oServiceTeamFilter = new sap.ui.model.Filter(aServiceTeamFilter, false);

				var oCriticalSituationsPromise = new Promise(function (resolve) {
					var aFiltersCriticalSituations = [];
					// if (sRegion) {
					// 	var aRegionFilter = [];
					// 	sRegion.split(",").forEach(function (region) {
					// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
					// 	});
					// 	aFiltersCriticalSituations.push(new sap.ui.model.Filter(aRegionFilter, false));
					// }

					//all ongoing Critical MCC Customer Sit
					//User Status: New, In Process, In Escalation, In Management Review
					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false),
						oServiceTeamFilter
					],
						true
					);
					aFiltersCriticalSituations.push(tileSpecificFilters);

					if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
						aFiltersCriticalSituations.push(oFacetFilterFilters);
					}

					var oICModel = this.oController.getOwnerComponent().getModel();
					aFiltersCriticalSituations.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

					//CriticalSituations Promise	
					oICModel.read("/CriticalSituationsSet/$count", {
						filters: [new sap.ui.model.Filter(aFiltersCriticalSituations, true)],
						success: function (data) {
							var obj = {
								iCounter: data,
								entity: "CriticalSituation"
							};
							resolve(obj);
						}.bind(this),
						error: function () {
							resolve(0);
						}
					});
				}.bind(this));
				aPromises.push(oCriticalSituationsPromise);

				var oCriticalSituationsPromiseRed = new Promise(function (resolve) {
					var aFiltersCriticalSituations = [];
					// if (sRegion) {
					// 	var aRegionFilter = [];
					// 	sRegion.split(",").forEach(function (region) {
					// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
					// 	});
					// 	aFiltersCriticalSituations.push(new sap.ui.model.Filter(aRegionFilter, false));
					// }

					//all ongoing Critical MCC Customer Sit
					//User Status: New, In Process, In Escalation, In Management Review
					var tileSpecificFilters = new sap.ui.model.Filter([
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
							new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
						], false),
						oServiceTeamFilter
					],
						true
					);
					aFiltersCriticalSituations.push(tileSpecificFilters);

					if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
						aFiltersCriticalSituations.push(oFacetFilterFilters);
					}

					var oICModel = this.oController.getOwnerComponent().getModel();
					aFiltersCriticalSituations.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
					aFiltersCriticalSituations.push(new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"));
					//CriticalSituations Promise	
					oICModel.read("/CriticalSituationsSet/$count", {
						filters: [new sap.ui.model.Filter(aFiltersCriticalSituations, true)],
						//urlParameters: {
						//	"$select": "Rating"
						//},
						success: function (data) {
							var obj = {
								iCounterRed: data,
								entity: "CriticalSituation"
							};
							resolve(obj);
						}.bind(this),
						error: function () {
							resolve(0);
						}
					});
				}.bind(this));
				aPromises.push(oCriticalSituationsPromiseRed);

				//dont load if not authorized
				if (oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations || oSettings.ShowGlobalAggregation) {
					//in case of anonymized mode, no GEM should be retunrned
					if (oSettings.isAnonymizedMode === false) {
						var oGlobalEscalationsPromise = new Promise(function (resolve) {
							var aFiltersGlobalEscalations = [];
							// if (sRegion) {
							// 	var aRegionFilter = [];
							// 	sRegion.split(",").forEach(function (region) {
							// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
							// 	});
							// 	aFiltersGlobalEscalations.push(new sap.ui.model.Filter(aRegionFilter, false));
							// }

							//all ongoing Critical MCC Customer Sit
							//User Status: New, In Process, In Escalation, In Management Review
							var tileSpecificFilters = new sap.ui.model.Filter([
								new sap.ui.model.Filter([
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20"),
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30")
								], false),
								oServiceTeamFilter
							],
								true
							);
							aFiltersGlobalEscalations.push(tileSpecificFilters);

							if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
								aFiltersGlobalEscalations.push(oFacetFilterFilters);
							}

							var oICModel = this.oController.getOwnerComponent().getModel();

							//CriticalSituations Promise	
							oICModel.read("/GlobalEscalationsSet/$count", {
								filters: [new sap.ui.model.Filter(aFiltersGlobalEscalations, true)],
								success: function (data) {
									var obj = {
										iCounter: data,
										entity: "GlobalEscalation"
									};
									resolve(obj);
								}.bind(this),
								error: function () {
									resolve(0);
								}
							});
						}.bind(this));
						aPromises.push(oGlobalEscalationsPromise);

						var oGlobalEscalationsPromiseRed = new Promise(function (resolve) {
							var aFiltersGlobalEscalations = [];
							// if (sRegion) {
							// 	var aRegionFilter = [];
							// 	sRegion.split(",").forEach(function (region) {
							// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
							// 	});
							// 	aFiltersGlobalEscalations.push(new sap.ui.model.Filter(aRegionFilter, false));
							// }

							//all ongoing Critical MCC Customer Sit
							//User Status: New, In Process, In Escalation, In Management Review
							var tileSpecificFilters = new sap.ui.model.Filter([
								new sap.ui.model.Filter([
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "20"),
									new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30")
								], false),
								oServiceTeamFilter
							],
								true
							);
							aFiltersGlobalEscalations.push(tileSpecificFilters);

							if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
								aFiltersGlobalEscalations.push(oFacetFilterFilters);
							}

							var oICModel = this.oController.getOwnerComponent().getModel();
							aFiltersGlobalEscalations.push(new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"));
							//CriticalSituations Promise	
							oICModel.read("/GlobalEscalationsSet/$count", {
								filters: [new sap.ui.model.Filter(aFiltersGlobalEscalations, true)],
								success: function (data) {
									var obj = {
										iCounterRed: data,
										entity: "GlobalEscalation"
									};
									resolve(obj);
								}.bind(this),
								error: function () {
									resolve(0);
								}
							});
						}.bind(this));
						aPromises.push(oGlobalEscalationsPromiseRed);
					}
				}

				Promise.all(aPromises).then(function (aResults) {
					var iSum = 0;
					var iSumRed = 0;
					var bGlobalEscalation = false;
					aResults.forEach(function (result) {
						if (result.iCounterRed) {
							iSumRed += parseInt(result.iCounterRed);
						}
						if (result.iCounter) {
							iSum += parseInt(result.iCounter);
							bGlobalEscalation = result.entity === "GlobalEscalation" && parseInt(result.iCounter) > 0;
						}
					});

					var sFooter = "";
					var bShowRestrictedView = this.oController.getOwnerComponent().getModel("settings").getProperty(
						"/ShowRegionalGlobalEscalations");
					if (bGlobalEscalation && bShowRestrictedView) {
						sFooter = this.oController.getOwnerComponent().getModel("i18n").getProperty("restrictedView");
					}

					this.oTileModel.setProperty("/" + bp.Key + "ValueOngoing", iSum);
					this.oTileModel.setProperty("/" + bp.Key + "BusyOngoing", false);
					this.oTileModel.setProperty("/" + bp.Key + "ValueRed", iSumRed);
					this.oTileModel.setProperty("/" + bp.Key + "BusyRed", false);
					this.oTileModel.setProperty("/" + bp.Key + "Busy", false);
				}.bind(this));
			}
		},

		_generateTaskForcesClosedTiles: function (bp, oFacetFilterFilters) {
			var oSettings = this.oController.getOwnerComponent().getModel("settings").getData();
			var aServiceTeamFilter = [];
			var aServiceTeams = [];
			var aPromises = [];
			this.oTileModel.setProperty("/" + bp.Key + "BusyClosed", true);
			this.oTileModel.setProperty("/" + bp.Key + "ValueClosed", 0);
			bp.toServiceTeam.results.forEach(function (serviceTeam) {
				aServiceTeamFilter.push(new sap.ui.model.Filter("ServiceTeam", sap.ui.model.FilterOperator.EQ, this.oController.pad(
					serviceTeam.Key, 10)));
				aServiceTeams.push(this.oController.pad(serviceTeam.Key, 10));
			}.bind(this));

			var oServiceTeamFilter = new sap.ui.model.Filter(aServiceTeamFilter, false);

			var oCriticalSituationsPromise = new Promise(function (resolve) {
				var aFiltersCriticalSituations = [];
				// if (sRegion) {
				// 	var aRegionFilter = [];
				// 	sRegion.split(",").forEach(function (region) {
				// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				// 	});
				// 	aFiltersCriticalSituations.push(new sap.ui.model.Filter(aRegionFilter, false));
				// }

				//all ongoing Critical MCC Customer Sit
				//User Status: New, In Process, In Escalation, In Management Review
				var tileSpecificFilters = new sap.ui.model.Filter([
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90")
					], false),
					oServiceTeamFilter
				],
					true
				);
				aFiltersCriticalSituations.push(tileSpecificFilters);

				if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
					aFiltersCriticalSituations.push(oFacetFilterFilters);
				}

				var oICModel = this.oController.getOwnerComponent().getModel();
				aFiltersCriticalSituations.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));
				aFiltersCriticalSituations.push(this.getClosedDateFilter("ClosingDate"));

				//CriticalSituations Promise	
				oICModel.read("/CriticalSituationsSet/$count", {
					filters: [new sap.ui.model.Filter(aFiltersCriticalSituations, true)],
					success: function (iCounter) {
						var obj = {
							iCounter: iCounter,
							entity: "CriticalSituation"
						};
						resolve(obj);
					}.bind(this),
					error: function () {
						resolve(0);
					}
				});
			}.bind(this));
			aPromises.push(oCriticalSituationsPromise);
			//dont load if not authorized
			if (oSettings.ShowGlobalEscalations || oSettings.ShowRegionalGlobalEscalations || oSettings.ShowGlobalAggregation) {
				//in case of anonymized mode, no GEM should be retunrned
				if (oSettings.isAnonymizedMode === false) {
					var oGlobalEscalationsPromise = new Promise(function (resolve) {
						var aFiltersGlobalEscalations = [];
						// if (sRegion) {
						// 	var aRegionFilter = [];
						// 	sRegion.split(",").forEach(function (region) {
						// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
						// 	});
						// 	aFiltersGlobalEscalations.push(new sap.ui.model.Filter(aRegionFilter, false));
						// }

						//all ongoing Critical MCC Customer Sit
						//User Status: New, In Process, In Escalation, In Management Review
						var tileSpecificFilters = new sap.ui.model.Filter([
							new sap.ui.model.Filter([
								new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "40")
							], false),
							oServiceTeamFilter
						],
							true
						);
						aFiltersGlobalEscalations.push(tileSpecificFilters);

						if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
							aFiltersGlobalEscalations.push(oFacetFilterFilters);
						}

						aFiltersGlobalEscalations.push(this.getClosedDateFilter("ClosingDate"));

						var oICModel = this.oController.getOwnerComponent().getModel();

						//CriticalSituations Promise	
						oICModel.read("/GlobalEscalationsSet/$count", {
							filters: [new sap.ui.model.Filter(aFiltersGlobalEscalations, true)],
							success: function (iCounter) {
								var obj = {
									iCounter: iCounter,
									entity: "GlobalEscalation"
								};
								resolve(obj);
							}.bind(this),
							error: function () {
								resolve(0);
							}
						});
					}.bind(this));
					aPromises.push(oGlobalEscalationsPromise);
				}
			}

			Promise.all(aPromises).then(function (aResults) {
				var iSum = 0;
				var bGlobalEscalation = false;
				aResults.forEach(function (result) {
					iSum += parseInt(result.iCounter);
					bGlobalEscalation = result.entity === "GlobalEscalation" && parseInt(result.iCounter) > 0;
				});

				var sFooter = "";
				var bShowRestrictedView = this.oController.getOwnerComponent().getModel("settings").getProperty("/ShowRegionalGlobalEscalations");
				if (bGlobalEscalation && bShowRestrictedView) {
					sFooter = this.oController.getOwnerComponent().getModel("i18n").getProperty("restrictedView");
				}

				this.oTileModel.setProperty("/" + bp.Key + "ValueClosed", iSum || 0);
				this.oTileModel.setProperty("/" + bp.Key + "BusyClosed", false);

			}.bind(this));
		},

		_getAmountCriticalSituationsSet: function (oFacetFilterFilters) {
			this.oTileModel.setProperty("/mccCasesOngoingBusy", true);
			this.oTileModel.setProperty("/mccCasesClosedBusy", true);
			this.oTileModel.setProperty("/mccCasesRedBusy", true);
			this.oTileModel.setProperty("/mccCasesBusy", true);

			var aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			//all ongoing Critical MCC Customer Sit
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP05"));

			var oICModel = this.oController.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			var oPromiseOngoing = new Promise(function (resolve) {
				oICModel.read("/CustomerEngagementSet", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					urlParameters: {
						"$select": "CaseId"
					},
					success: function (data) {

						this._updateTileModel("mccCases", data.results.length);
						this.oTileModel.setProperty("/mccCasesOngoingBusy", false);
						resolve();

						//filter ccm light cases
						/*var aFilteredData = [];
						var aFilters = [new sap.ui.model.Filter([
							new sap.ui.model.Filter("bCCML1", sap.ui.model.FilterOperator.EQ, true),
							new sap.ui.model.Filter("bCCML2", sap.ui.model.FilterOperator.NE, true)
						], true)];
						this.oController.getOwnerComponent().getModel("subModel").read("/Cases", {
							filters: aFilters,
							urlParameters: {
								"$select": "CaseID,bCCML1,bCCML2"
							},
							success: function (oData) {
								//check if not a light case
								data.results.forEach(function (c) {
									var oCase = oData.results.find(function (hanaCase) {
										return c.CaseId === hanaCase.CaseID.toString();
									});
									if (!oCase) {
										aFilteredData.push(c);
									}
								});
								this._updateTileModel("mccCases", aFilteredData.length);
								this.oTileModel.setProperty("/mccCasesOngoingBusy", false);
								resolve();
							}.bind(this)
						});*/

					}.bind(this),
					error: function (data) {
						resolve();
						this.oTileModel.setProperty("/mccCasesOngoingBusy", false);
					}.bind(this)
				});
			}.bind(this));

			aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			//all ongoing Critical MCC Customer Sit
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "71"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "80"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "81"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "99")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);
			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}
			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP05"));
			aFilters.push(new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"));
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			var oPromiseRed = new Promise(function (resolve) {
				oICModel.read("/CustomerEngagementSet", {
					urlParameters: {
						"$select": "CaseId"
					},
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this._updateTileModel("mccCasesRed", data.results.length);
						resolve();
						this.oTileModel.setProperty("/mccCasesRedBusy", false);

						//filter ccm light cases
						/*var aFilteredData = [];
						var aFilters = [new sap.ui.model.Filter([
							new sap.ui.model.Filter("bCCML1", sap.ui.model.FilterOperator.EQ, true),
							new sap.ui.model.Filter("bCCML2", sap.ui.model.FilterOperator.NE, true)
						], true)];
						this.oController.getOwnerComponent().getModel("subModel").read("/Cases", {
							filters: aFilters,
							urlParameters: {
								"$select": "CaseID,bCCML1,bCCML2"
							},
							success: function (oData) {
								//check if not a light case
								data.results.forEach(function (c) {
									var oCase = oData.results.find(function (hanaCase) {
										return c.CaseId === hanaCase.CaseID.toString();
									});
									if (!oCase) {
										aFilteredData.push(c);
									}
								});
								this._updateTileModel("mccCasesRed", aFilteredData.length);
								resolve();
								this.oTileModel.setProperty("/mccCasesRedBusy", false);
							}.bind(this)
						});*/
					}.bind(this),
					error: function (data) {
						resolve();
						this.oTileModel.setProperty("/mccCasesRedBusy", false);
					}.bind(this)
				});
			}.bind(this));

			//Also load closed cases
			aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			//all ongoing Critical MCC Customer Sit
			//User Status: New, In Process, In Escalation, In Management Review
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "90")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			aFilters.push(new sap.ui.model.Filter("CustomerType", sap.ui.model.FilterOperator.EQ, "ZSCUSTYP05"));

			var dateOffset = (24 * 60 * 60 * 1000) * Constants.closedCasesPastDays;
			var dateInPast = new Date();
			dateInPast.setTime(dateInPast.getTime() - dateOffset);

			aFilters.push(new sap.ui.model.Filter({
				path: "ClosingDate",
				operator: sap.ui.model.FilterOperator.GE,
				value1: dateInPast
			}));

			oICModel = this.oController.getOwnerComponent().getModel();
			aFilters.push(new sap.ui.model.Filter("Reason", sap.ui.model.FilterOperator.EQ, "ENGA"));

			var oPromiseClosed = new Promise(function (resolve) {
				oICModel.read("/CustomerEngagementSet", {
					urlParameters: {
						"$select": "CaseId"
					},
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this._updateTileModel("mccCasesClosed", data.results.length);
						this.oTileModel.setProperty("/mccCasesClosedBusy", false);
						resolve();

						//filter ccm light cases
						/*var aFilteredData = [];
						var aFilters = [new sap.ui.model.Filter([
							new sap.ui.model.Filter("bCCML1", sap.ui.model.FilterOperator.EQ, true),
							new sap.ui.model.Filter("bCCML2", sap.ui.model.FilterOperator.NE, true)
						], true)];
						this.oController.getOwnerComponent().getModel("subModel").read("/Cases", {
							filters: aFilters,
							urlParameters: {
								"$select": "CaseID,bCCML1,bCCML2"
							},
							success: function (oData) {
								//check if not a light case
								data.results.forEach(function (c) {
									var oCase = oData.results.find(function (hanaCase) {
										return c.CaseId === hanaCase.CaseID.toString();
									});
									if (!oCase) {
										aFilteredData.push(c);
									}
								});
								this._updateTileModel("mccCasesClosed", aFilteredData.length);
								this.oTileModel.setProperty("/mccCasesClosedBusy", false);
								resolve();
							}.bind(this)
						});*/

					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/mccCasesClosedBusy", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			Promise.all([oPromiseOngoing, oPromiseClosed, oPromiseRed]).then(function () {
				this.oTileModel.setProperty("/mccCasesBusy", false);
			}.bind(this));
		},

		_getAmountCrossIssuesSet: function (oFacetFilterFilters) {
			this.oTileModel.setProperty("/CrossIssuesBusyOngoing", true);
			this.oTileModel.setProperty("/CrossIssuesBusyRed", true);
			this.oTileModel.setProperty("/CrossIssuesBusyClosed", true);
			this.oTileModel.setProperty("/CrossIssuesBusy", true);

			var aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			//all ongoing Cross Issues
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0010"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0011"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0016")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			//set SoldToParty ID dependent on system
			var currentUrl = window.location.href;
			var sSoldToParty = currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") ? "4699754" : "20672944";
			aFilters.push(new sap.ui.model.Filter("SoldToParty", sap.ui.model.FilterOperator.EQ, sSoldToParty));

			var oICModel = this.oController.getOwnerComponent().getModel();

			var oPromiseOngoing = new Promise(function (resolve) {
				oICModel.read("/CrossIssueSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this._updateTileModel("crossIssues", data);
						this.oTileModel.setProperty("/CrossIssuesBusyOngoing", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/CrossIssuesBusyOngoing", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			//also load red ratings
			var aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			//all ongoing Cross Issues
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0010"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0011"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0016")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			//set SoldToParty ID dependent on system
			var currentUrl = window.location.href;
			var sSoldToParty = currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") ? "4699754" : "20672944";
			aFilters.push(new sap.ui.model.Filter("SoldToParty", sap.ui.model.FilterOperator.EQ, sSoldToParty));
			aFilters.push(new sap.ui.model.Filter("Rating", sap.ui.model.FilterOperator.EQ, "C"));

			var oICModel = this.oController.getOwnerComponent().getModel();

			var oPromiseRed = new Promise(function (resolve) {
				oICModel.read("/CrossIssueSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this.oTileModel.setProperty("/CrossIssuesBusyRed", false);
						this._updateTileModel("crossIssuesRed", data);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/CrossIssuesBusyRed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			//get also closed cases
			var aFilters = [];
			// if (sRegion) {
			// 	var aRegionFilter = [];
			// 	sRegion.split(",").forEach(function (region) {
			// 		aRegionFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			// 	});
			// 	aFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
			// }

			//all ongoing Cross Issues
			var tileSpecificFilters = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0012"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0013"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0014"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0017"),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0018")
				], false)
			],
				true
			);
			aFilters.push(tileSpecificFilters);

			if (oFacetFilterFilters && oFacetFilterFilters.aFilters.length > 0) {
				aFilters.push(oFacetFilterFilters);
			}

			aFilters.push(this.getClosedDateFilter("ChangeDate"));

			//set SoldToParty ID dependent on system
			var currentUrl = window.location.href;
			var sSoldToParty = currentUrl.includes("br339jmc4c") || currentUrl.includes("dev-mallard") ? "4699754" : "20672944";
			aFilters.push(new sap.ui.model.Filter("SoldToParty", sap.ui.model.FilterOperator.EQ, sSoldToParty));

			var oICModel = this.oController.getOwnerComponent().getModel();
			var oPromiseClosed = new Promise(function (resolve) {
				oICModel.read("/CrossIssueSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					//not needed for $count, this is handled in the backend	urlParameters: "$top=999999",
					success: function (data) {
						this._updateTileModel("crossIssuesClosed", data);
						this.oTileModel.setProperty("/CrossIssuesBusyClosed", false);
						resolve();
					}.bind(this),
					error: function (data) {
						this.oTileModel.setProperty("/CrossIssuesBusyClosed", false);
						resolve();
					}.bind(this)
				});
			}.bind(this));

			Promise.all([oPromiseOngoing, oPromiseRed, oPromiseClosed]).then(function () {
				this.oTileModel.setProperty("/CrossIssuesBusy", false);
			}.bind(this));

		},

		_getAmountCim: function (sRegion, aFilter) {
			this.oTileModel.setProperty("/cimBusy", true);
			this.oTileModel.setProperty("/cimOngoinBusy", true);

			var sFilterString =
				"sysparm_query=state=101^u_escalation_type=3";

			if (sRegion) {
				var sRegionFilterString = "^",
					sRegionEMEAFilterString = "",
					bBothEMEAFiltersSelected = false;
				sRegion.split(",").forEach(function (region, i) {
					//For Service Now we need to implement EMEA_North and EMEA_South differently, because it is not implmeneted yet
					//we need to take the specific countries instead
					//Moreover we need to take care, that it is still working together with the other region filters like MEE and NA
					if (region === "EMEA_NORTH") {
						if (bBothEMEAFiltersSelected) {
							sRegionEMEAFilterString += "^OR";
						} else if (!sRegionFilterString.endsWith("^OR")) {
							sRegionEMEAFilterString += "^";
						}
						sRegionEMEAFilterString += Constants.emeaNorthCountries;
						bBothEMEAFiltersSelected = true;
						//e.g. %5eu_task_record.account.country=AL%5eORu_task_record.account.country=DZ
					} else if (region === "EMEA_SOUTH") {
						if (bBothEMEAFiltersSelected) {
							sRegionEMEAFilterString += "^OR";
						} else if (!sRegionFilterString.endsWith("^OR")) {
							sRegionEMEAFilterString += "^";
						}
						sRegionEMEAFilterString += Constants.emeaSouthCountries;
						bBothEMEAFiltersSelected = true;
						//e.g. %5eu_task_record.account.country=AL%5eORu_task_record.account.country=DZ
					} else {
						sRegionFilterString += "u_task_record.account.u_region=" + region;
						if (i < (sRegion.split(",").length - 1)) {
							sRegionFilterString += "^OR";
						}
					}
				});
				if (sRegionEMEAFilterString !== "" && sRegionFilterString !== "^") {
					sRegionFilterString = sRegionFilterString + sRegionEMEAFilterString.replace("^", "^OR"); // we need to add an OR, because the countries need to be handled as an OR related to the region filter in this specific case, It should not be an AND
				} else if (sRegionEMEAFilterString !== "") {
					sRegionFilterString = sRegionEMEAFilterString;
				}
				sFilterString += sRegionFilterString;
			}

			if (aFilter && aFilter.length > 0) {
				aFilter.forEach(function (filter) {
					sFilterString += "^" + filter;
				});
			}

			sFilterString = sFilterString.replaceAll("^", "%5e");
			//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
			if (sFilterString.startsWith("%5esysparm_query")) {
				sFilterString.replace("%5esysparm_query", "sysparm_query");
			}

			sFilterString += "&sysparm_count=true";

			$.ajax({
				method: "GET",
				contentType: "application/json",
				headers: {
					"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
				},
				url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
				success: function (oData) {
					if (oData.result && oData.result.stats && oData.result.stats.count) {
						this._updateTileModel("cims", oData.result.stats.count);
					} else {
						this._updateTileModel("cims", 0);
					}

					this.oTileModel.setProperty("/cimOngoinBusy", false);
					this.oTileModel.setProperty("/cimBusy", false);
				}.bind(this),
				error: function (err) {
					this.oTileModel.setProperty("/cimOngoinBusy", false);
					this.oTileModel.setProperty("/cimBusy", false);
				}.bind(this)
			});

		},
		_getAmount_xTec: function (sRegion, aFilter) {
			var sFilterString = this._getAmountEscalationsFilterString(sRegion, aFilter, '10')
			this.oTileModel.setProperty("/xTecBusyOngoing", true);
			$.ajax({
				method: "GET",
				contentType: "application/json",
				headers: {
					"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
				},
				url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
				success: function (oData) {
					//update this ffs
					if (oData.result && oData.result.stats && oData.result.stats.count) {
						this._updateTileModel("xTec", oData.result.stats.count);
						this.oTileModel.setProperty("/xTecState", "Loaded");
					} else {
						this._updateTileModel("xTec", 0);
					}
					this.oTileModel.setProperty("/xTecOngoing", false);
					this.oTileModel.setProperty("/xTecBusyOngoing", false);
				}.bind(this),
				error: function (err) {
					this.oTileModel.setProperty("/xTecBusyOngoing", false);
				}.bind(this)
			});
		},

		_getAmountBusinessDowns: function (sRegion, aFilter) {
			var sFilterString = this._getAmountEscalationsFilterString(sRegion, aFilter)
			$.ajax({
				method: "GET",
				contentType: "application/json",
				headers: {
					"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
				},
				url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
				success: function (oData) {
					//update this ffs
					if (oData.result && oData.result.stats && oData.result.stats.count) {
						this._updateTileModel("businessDown", oData.result.stats.count);
						this.oTileModel.setProperty("/businessDownState", "Loaded");
					} else {
						this._updateTileModel("businessDown", 0);
					}
					this.oTileModel.setProperty("/businessDownBusyOngoing", false);
				}.bind(this),
				error: function (err) {
					this.oTileModel.setProperty("/businessDownBusyOngoing", false);
				}.bind(this)
			});
		},

		_getAmountPECriticalSituations: function (sRegion, aFilter) {
			var sFilterString = this._getAmountPECriticalsFilterString(sRegion, aFilter)
			$.ajax({
				method: "GET",
				contentType: "application/json",
				headers: {
					"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
				},
				url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/stats/sn_customerservice_escalation?" + sFilterString,
				success: function (oData) {
					//update this ffs
					if (oData.result && oData.result.stats && oData.result.stats.count) {
						this._updateTileModel("peCriticalSituation", oData.result.stats.count);
						this.oTileModel.setProperty("/peCriticalSituationState", "Loaded");
					} else {
						this._updateTileModel("peCriticalSituation", 0);
					}
					this.oTileModel.setProperty("/peCriticalSituationBusyOngoing", false);
				}.bind(this),
				error: function (err) {
					this.oTileModel.setProperty("/peCriticalSituationBusyOngoing", false);
				}.bind(this)
			});
		},

		_getAmountEscalationsFilterString: function (sRegion, aFilter, reason = '9', count = true) {
			this.oTileModel.setProperty("/businessDownBusyOngoing", true);

			var sFilterString =
				"sysparm_query=state=101^u_escalation_type=0^u_request_reason=8^ORu_request_reason=";
			sFilterString += reason;

			if (reason === '10') {
				//MCCBusinessDownGroup = "e782a6a51b38081020c8fddacd4bcb44"
				sFilterString =
					"sysparm_query=state=101^u_escalation_type=0^u_request_reason=10^assignment_group=e782a6a51b38081020c8fddacd4bcb44"
			}

			if (sRegion) {
				var sRegionFilterString = "^",
					sRegionEMEAFilterString = "",
					bBothEMEAFiltersSelected = false;
				sRegion.split(",").forEach(function (region, i) {
					//For Service Now we need to implement EMEA_North and EMEA_South differently, because it is not implmeneted yet
					//we need to take the specific countries instead
					//Moreover we need to take care, that it is still working together with the other region filters like MEE and NA
					if (region === "EMEA_NORTH") {
						if (bBothEMEAFiltersSelected) {
							sRegionEMEAFilterString += "^OR";
						} else if (!sRegionFilterString.endsWith("^OR")) {
							sRegionEMEAFilterString += "^";
						}
						sRegionEMEAFilterString += Constants.emeaNorthCountries;
						bBothEMEAFiltersSelected = true;
						//e.g. %5eu_task_record.account.country=AL%5eORu_task_record.account.country=DZ
					} else if (region === "EMEA_SOUTH") {
						if (bBothEMEAFiltersSelected) {
							sRegionEMEAFilterString += "^OR";
						} else if (!sRegionFilterString.endsWith("^OR")) {
							sRegionEMEAFilterString += "^";
						}
						sRegionEMEAFilterString += Constants.emeaSouthCountries;
						bBothEMEAFiltersSelected = true;
						//e.g. %5eu_task_record.account.country=AL%5eORu_task_record.account.country=DZ
					} else {
						sRegionFilterString += "u_task_record.account.u_region=" + region;
						if (i < (sRegion.split(",").length - 1)) {
							sRegionFilterString += "^OR";
						}
					}
				});
				if (sRegionEMEAFilterString !== "" && sRegionFilterString !== "^") {
					sRegionFilterString = sRegionFilterString + sRegionEMEAFilterString.replace("^", "^OR"); // we need to add an OR, because the countries need to be handled as an OR related to the region filter in this specific case, It should not be an AND
				} else if (sRegionEMEAFilterString !== "") {
					sRegionFilterString = sRegionEMEAFilterString;
				}
				sFilterString += sRegionFilterString;
			}
			if (aFilter && aFilter.length > 0) {
				aFilter.forEach(function (filter) {
					sFilterString += "^" + filter;
				});
			}

			sFilterString = sFilterString.replaceAll("^", "%5e");
			//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
			if (sFilterString.startsWith("%5esysparm_query")) {
				sFilterString.replace("%5esysparm_query", "sysparm_query");
			}
			if (count) {
				sFilterString += "&sysparm_count=true";
				return sFilterString
			}

		},

		_getAmountPECriticalsFilterString: function (sRegion, aFilter, count = true) {
			this.oTileModel.setProperty("/peCriticalSituationBusyOngoing", true);

			var sFilterString =
				"sysparm_query=state=101^u_escalation_type=0^u_request_reason=7";

			if (sRegion) {
				var sRegionFilterString = "^",
					sRegionEMEAFilterString = "",
					bBothEMEAFiltersSelected = false;
				sRegion.split(",").forEach(function (region, i) {
					//For Service Now we need to implement EMEA_North and EMEA_South differently, because it is not implmeneted yet
					//we need to take the specific countries instead
					//Moreover we need to take care, that it is still working together with the other region filters like MEE and NA
					if (region === "EMEA_NORTH") {
						if (bBothEMEAFiltersSelected) {
							sRegionEMEAFilterString += "^OR";
						} else if (!sRegionFilterString.endsWith("^OR")) {
							sRegionEMEAFilterString += "^";
						}
						sRegionEMEAFilterString += Constants.emeaNorthCountries;
						bBothEMEAFiltersSelected = true;
						//e.g. %5eu_task_record.account.country=AL%5eORu_task_record.account.country=DZ
					} else if (region === "EMEA_SOUTH") {
						if (bBothEMEAFiltersSelected) {
							sRegionEMEAFilterString += "^OR";
						} else if (!sRegionFilterString.endsWith("^OR")) {
							sRegionEMEAFilterString += "^";
						}
						sRegionEMEAFilterString += Constants.emeaSouthCountries;
						bBothEMEAFiltersSelected = true;
						//e.g. %5eu_task_record.account.country=AL%5eORu_task_record.account.country=DZ
					} else {
						sRegionFilterString += "u_task_record.account.u_region=" + region;
						if (i < (sRegion.split(",").length - 1)) {
							sRegionFilterString += "^OR";
						}
					}
				});
				if (sRegionEMEAFilterString !== "" && sRegionFilterString !== "^") {
					sRegionFilterString = sRegionFilterString + sRegionEMEAFilterString.replace("^", "^OR"); // we need to add an OR, because the countries need to be handled as an OR related to the region filter in this specific case, It should not be an AND
				} else if (sRegionEMEAFilterString !== "") {
					sRegionFilterString = sRegionEMEAFilterString;
				}
				sFilterString += sRegionFilterString;
			}
			if (aFilter && aFilter.length > 0) {
				aFilter.forEach(function (filter) {
					sFilterString += "^" + filter;
				});
			}

			sFilterString = sFilterString.replaceAll("^", "%5e");
			//sometimes a %5e is copied to the beginning of the filterstring and leads to issues
			if (sFilterString.startsWith("%5esysparm_query")) {
				sFilterString.replace("%5esysparm_query", "sysparm_query");
			}
			if (count) {
				sFilterString += "&sysparm_count=true";
				return sFilterString
			}

		},

		_updateTileModel: function (property, amount) {
			var sProperty = "/" + property;
			this.oTileModel.setProperty(sProperty, amount);
		},

		_getProdLinesFromSolution: function (solution) {
			var aIds = [];
			solution.toSolutionProdLin.results.forEach(function (line) {
				if (line.PlKey !== "") {
					aIds.push(line.PlKey);
				}
			});
			return aIds;
		},

		getResourceBundle: function () {
			return this.oController.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		//Variant Management implementation
		//stored in IC* backend in ZSCMG_MCSDB_VAR; it's a cluster table, data stored in LRAW (HEX-string) format

		onSaveVariant: function (event) {
			//
			//ProductFilters was used in MCS Dashboard for Product version --> should not be used anymore
			//ProdFilter and ProdVersionFilters have been added for the MCC One Dashboard
			//
			//event parameters key:"SV1527663006886"  name:"abc"  overwrite:false/true
			var oVMModel = this.oView.getModel("variantManagement"); //"myVMData"
			//var oFilterModel = this.oView.getModel("filterModel");
			//var sRegion = oFilterModel.getProperty("/region");
			var iTotalAmountOfSelectedFilter = 0;
			this.oFacetFilter.getLists().forEach(function (list) {
				iTotalAmountOfSelectedFilter += list.getSelectedItems().length;
			});
			if (iTotalAmountOfSelectedFilter > 50) {
				MessageToast.show(this.getResourceBundle().getText("tooManyFiltersSelected"));
				//reset filter to previous value
				this.oFacetFilter._selectedProductHierarchy = this.oFacetFilter._selectedProductHierarchyInitial;
				// Restore selected keys
				this.oFacetFilter.getLists().forEach(function (list) {
					list.setSelectedKeys(this._selectedKeysPerList[list.getId()]);
				}.bind(this.oFacetFilter));
				return;
			}
			//in case of create

			// if (sRegion === "") {
			// 	sRegion = "WORLD";
			// }

			var oVariantElement = {
				VarName: event.getParameter("name"),
				VarKey: event.getParameter("key"),
				RegionFilter: "", //OLD implementation sRegion.toUpperCase(),
				CustomerFilters: "",
				CustSegmentFilters: "",
				GlobalUltimateFilters: "",
				ProdCatFilters: "",
				ProdLineFilters: "",
				ProdFilters: "",
				ProdVersionFilters: "",
				SalesOrgFilters: "",
				ServiceOrgFilters: "",
				CountryFilters: "",
				CategoryFilters: "",
				MccTagFilters: "",
				Default: event.getParameter("def") ? "X" : ""
			};
			this.oFacetFilter.getLists().forEach(function (list) {
				var sTitle = list.getTitle();
				if (sTitle.startsWith("MCC Tag")) {
					sTitle = this.getResourceBundle().getText("filterListMCC_TAG_FLT");
				}

				if (list.getSelectedItems().length > 0) {
					var oSelectedKeys = JSON.stringify(list.getSelectedKeys());
					switch (sTitle) {
						case "Customer":
							oVariantElement.CustomerFilters = oSelectedKeys;
							break;
						case "Customer Segment":
							oVariantElement.CustSegmentFilters = oSelectedKeys;
							break;
						case "Global Ultimate":
							oVariantElement.GlobalUltimateFilters = oSelectedKeys;
							break;
						case "Product Category":
							oVariantElement.ProdCatFilters = oSelectedKeys;
							break;
						case "Product Line":
							oVariantElement.ProdLineFilters = oSelectedKeys;
							break;
						case "Product":
							oVariantElement.ProdFilters = oSelectedKeys;
							break;
						case "Product Version":
							oVariantElement.ProdVersionFilters = oSelectedKeys;
							break;
						case "Sales Org":
							oVariantElement.SalesOrgFilters = oSelectedKeys;
							break;
						case "Service Org":
							oVariantElement.ServiceOrgFilters = oSelectedKeys;
							break;
						case "Country":
							oVariantElement.CountryFilters = oSelectedKeys;
							break;
						case "Category":
							oVariantElement.CategoryFilters = oSelectedKeys;
							break;
						case "Region":
							oVariantElement.RegionFilter = oSelectedKeys;
							break;
						case "MCC Tag":
							oVariantElement.MccTagFilters = oSelectedKeys;
							break;
					}
				}

			}.bind(this));
			var that = this;
			var dfd = jQuery.Deferred();
			var overwrite = event.getParameter("overwrite");
			var key = event.getParameter("key");
			$.when(dfd).done(function () {
				if (!overwrite) {
					this.oView.getModel().create("/SearchVariantSet", oVariantElement, {
						success: function (oData, oResponse) {
							// Success
							//save the selected key in order to be used, when synching the filters
							this.oController.getOwnerComponent().getModel("settings").setProperty("/selectedFilterVariant", that.oView.byId(
								"filterVariantManagement").oSelectedItem);
							this._refreshVariantModel();
						}.bind(this)
					});
				} else {
					//var bindingPath = event.getSource().getItemByKey(event.getParameter("key")).getBindingContext("variantManagement").getPath(); //"myVMData"
					//var oVMModelData = this.oView.byId("filterVariantManagement").getModel().getProperty(bindingPath);
					var bindingPath = "/SearchVariantSet('" + key + "')";
					this.oView.getModel().update(bindingPath, oVariantElement, {
						success: function (oData, oResponse) {
							// Success
							this._refreshVariantModel();
						}.bind(this),
						error: function (oError) {
							// Error 
						}
					});
				}
			}.bind(this));

			if (event.getParameter("def")) {
				//remove old default flag
				var aVMData = oVMModel.getData().results;
				var aCurrentDefault = aVMData.filter(function (variant) {
					return variant.Default === "X";
				});

				if (aCurrentDefault.length === 1) {
					aCurrentDefault[0].Default = "";
					var bindingPath = "/SearchVariantSet('" + aCurrentDefault[0].VarKey + "')";
					this.oView.getModel().update(bindingPath, aCurrentDefault[0], {
						success: function (oData, oResponse) {
							dfd.resolve();
						}.bind(this),
						error: function (oError) {
							dfd.resolve();
						}
					});
				} else {
					dfd.resolve();
				}
			} else {
				dfd.resolve();
			}

		},
		onManageVariant: function (event) {
			//wait for all calls to be finished and then update the model binding in order to show the current state of filters
			var that = this;
			var oVariantManagement = this.oView.byId("filterVariantManagement");
			//in case the current selected variant is updated, the oSelectedItem object is not updated, only the aggregation of the drop down. 
			// therefore we need to update the oSelectedItem manually
			var oToShowAfterRename = null;
			this.oModelDataDeferredDeleted = jQuery.Deferred();
			this.oModelDataDeferredMerged = jQuery.Deferred();
			var finishWait = function () {
				this.oView.byId("filterVariantManagement").getBinding("variantItems").refresh();
				// save the selected key in order to be used, when synching the filters 
				if (oToShowAfterRename) {
					this.oController.getOwnerComponent().getModel("settings").setProperty("/selectedFilterVariant", oToShowAfterRename);
				} else {
					this.oController.getOwnerComponent().getModel("settings").setProperty("/selectedFilterVariant", this.oView.byId(
						"filterVariantManagement").oSelectedItem);
				}

			};
			jQuery.when(this.oModelDataDeferredMerged)
				.done(jQuery.proxy(finishWait, this));
			jQuery.when(this.oModelDataDeferredDeleted)
				.done(jQuery.proxy(finishWait, this));

			//event parameters renamed 	[object Object][], deleted 	[object Object][]
			var oVMModel = this.oView.getModel("variantManagement"); //"myVMData"

			//in case of new default
			if (event.getParameter("def") !== "") {
				//remove default flag from current default
				var aItemsToUpdate = [];
				var aVMData = oVMModel.getData().results;
				var aCurrentDefault = aVMData.filter(function (variant) {
					return variant.Default === "X";
				});

				if (aCurrentDefault.length === 1) {
					if (aCurrentDefault[0].VarKey !== event.getParameter("def")) {
						aCurrentDefault[0].Default = "";

						//do now update is its going to delete
						if (event.getParameter("deleted").indexOf(aCurrentDefault[0].VarKey) === -1) {
							aItemsToUpdate.push(aCurrentDefault[0]);
						}

						if (event.getParameter("def") !== "*standard*") {
							var aNewDefault = aVMData.filter(function (variant) {
								return variant.VarKey === event.getParameter("def");
							});
							aNewDefault[0].Default = "X";
							aItemsToUpdate.push(aNewDefault[0]);
						}
					}
				} else {
					if (event.getParameter("def") !== "*standard*") {
						var aNewDefault = aVMData.filter(function (variant) {
							return variant.VarKey === event.getParameter("def");
						});
						aNewDefault[0].Default = "X";
						aItemsToUpdate.push(aNewDefault[0]);
					}
				}

				aItemsToUpdate.forEach(function (item) {
					var bindingPath = "/SearchVariantSet('" + item.VarKey + "')";
					setTimeout(function () {
						this.oView.getModel().update(bindingPath, item, {
							success: function (oData, oResponse) { },
							error: function (oError) {
								// Error 
							}
						});
					}.bind(this), 500);
				}.bind(this));

			}

			if (event.getParameter("deleted").length > 0) {
				event.getParameter("deleted").forEach(function (item) {
					//var bindingPath = event.getSource().getItemByKey(item).getBindingContext("variantManagement").getPath(); //"myVMData"
					var bindingPath = "/SearchVariantSet('" + item + "')";
					this.oView.getModel().remove(bindingPath, {
						success: function (oData, oResponse) {
							// Success
							that.oModelDataDeferredDeleted.resolve();
							//remove deleted item
							var aItems = oVMModel.getData().results;
							var aNewItems = aItems.filter(function (id) {
								return id.VarKey !== item;
							});
							oVMModel.setProperty("/results", aNewItems);
						}.bind(this),
						error: function (oError) {
							// Error 
						},
						groupId: item
					});
				}.bind(this));
			}

			//in case of rename
			if (event.getParameter("renamed").length > 0) {
				event.getParameter("renamed").forEach(function (list) {
					var bindingPath = event.getSource().getItemByKey(list.key).getBindingContext("variantManagement").getPath(); //"myVMData"
					var oVMModelData = this.oView.getModel("variantManagement").getProperty(bindingPath);
					//store object in variable if renamed object ist the one, which is currently selected. needed for synchFilters later, because otherwise it is not correctly updated
					if (event.getSource().oSelectedItem && (event.getSource().oSelectedItem.getProperty("key") === list.key)) {
						oToShowAfterRename = event.getSource().getItemByKey(list.key);
					}
					oVMModelData.VarName = list.name;
					bindingPath = "/SearchVariantSet('" + list.key + "')";
					this.oView.getModel().update(bindingPath, oVMModelData, {
						success: function (oData, oResponse) {
							// Success
							that.oModelDataDeferredMerged.resolve();
						},
						error: function (oError) {
							// Error 
						},
						groupId: list.key
					});
				}.bind(this));
			}
		},
		onSelectVariant: function (event) {
			//in case there are still old Variantmanagement settings from MCS Dashboard used, which do not work with the one introduced for MCC One Dashboard
			//affected values are region and Product (has been used for Product version in MCS Dashboard)
			//ProductFilters was used in MCS Dashboard for Product version --> should not be used anymore
			//ProdFilter and ProdVersionFilters have been added for the MCC One Dashboard
			var bOldImplementationUsed = false;
			//var sWarningMessageProduct = "";
			//var selectedKey = event.getSource().getSelectionKey();
			var selectedKey = event.getParameter("key");
			// set the flag, that the variant has been initially selected -->  needed for the dirty flag
			this.oFacetFilter._variantInitiallyLoaded = true;
			if (selectedKey) {
				//save the selected key in order to be used, when synching the filters
				this.oController.getOwnerComponent().getModel("settings").setProperty("/selectedFilterVariant", event.getSource().oSelectedItem);

				//if standard
				if (selectedKey === this.oView.byId("filterVariantManagement").STANDARDVARIANTKEY) {
					var oFilterModel = this.oView.getModel("filterModel");
					oFilterModel.setProperty("/oFilterModelICP", null);
					oFilterModel.setProperty("/oFilterModelICPforCustomerVisits", null);
					oFilterModel.setProperty("/oFilterModelForICPwithoutSalesOrgServiceOrg", null);
					oFilterModel.setProperty("/oFilterForProjectsOnWatch", null);
					oFilterModel.setProperty("/oFilterCriticalEventCoverage", null);
					oFilterModel.setProperty("/oFilterModelICPWOTAGS", null);
					oFilterModel.setProperty("/oFilterModelICPGER", null);
					oFilterModel.setProperty("/oFilterModelBCP", null);
					oFilterModel.setProperty("/oFilterModelMCS", null);
					//oFilterModel.setProperty("/oFilterModelBD", null);
					oFilterModel.setProperty("/oFilterForServiceNow", null);
					oFilterModel.setProperty("/oFilterForServiceNowForCPC", null);
					oFilterModel.setProperty("/oFilterForOutages", null);

					var aFacetFilterLists = this.oFacetFilter.getLists();
					for (var i = 0; i < aFacetFilterLists.length; i++) {
						aFacetFilterLists[i].setSelectedKeys();
						//region filter needs to be set to WORLD
						if (aFacetFilterLists[i].getTitle() === "Region") {
							aFacetFilterLists[i].setSelectedKeys(JSON.parse('{"WORLD":"World"}'));
						}
					}
					this.setFaceFilterSelection(this.oFacetFilter);

					//var oRadioBtnGrp = this.oView.byId("regionGroup");
					//oRadioBtnGrp.setSelectedIndex(0);
					// Create filter based on selected radio button
					// this.oView.byId("regionContainer").getItems().forEach(function (item) {
					// 	item.setSelected(item.getText() === "World");
					// });
					oFilterModel.setProperty("/region", "");
					oFilterModel.setProperty("/regionText", "");
					//oFilterModel.setProperty("/regionID", "");
				} else {
					var bindingPath = event.getSource().getItemByKey(selectedKey).getBindingContext("variantManagement").getPath(); //"myVMData"

					var oVMModelData = this.oView.getModel("variantManagement").getProperty(bindingPath);

					//check if Variant has been selected, which has been created by the MCS Dashboard
					if (oVMModelData.RegionFilter) {
						//in case there is an variant created by MCS dashboard, the region cannot be selected 
						//and we should show a message in the UI
						if (this._isNumeric(oVMModelData.RegionFilter)) {
							bOldImplementationUsed = true;
						} else {
							// Create filter based on selected Checkbox button
							var sRegion = oVMModelData.RegionFilter;

							//check if region is already stored as an array of key/value pairs == new implementation with facet Filter. Then we need to transform sRegion
							//if not, then the region is still stored in the OLD way
							//region is stored as e.g. 'EMEA_NORTH,EMEA_SOUTH,GTC' for historic reasons, moreover we still need to support the MCS Dashboard
							if (sRegion.startsWith("{")) {
								sRegion = Object.keys(JSON.parse(sRegion)).toString();
							}

							//var that = this;
							if (sRegion === "WORLD") {
								// this.oView.byId("regionContainer").getItems().forEach(function (item) {
								// 	item.setSelected(false);
								// });
								// this.oView.byId("regionContainer").getItems()[0].setSelected(true);
								sRegion = "";
							}
							// else {
							// 	this.oView.byId("regionContainer").getItems().forEach(function (item) {
							// 		//	item.setSelected(oVMModelData.RegionFilter.indexOf(item.getText()) > -1);
							// 		item.setSelected(oVMModelData.RegionFilter.indexOf(that.oController.formatter.formatRegionNameToRegionCode(item.getText())) >
							// 			-1);
							// 	});
							// }
							this.oView.getModel("filterModel").setProperty("/region", sRegion);
							//replace EMEA_NORTH and EMEA_SOUTH
							this.oView.getModel("filterModel").setProperty("/regionText", sRegion.replace("EMEA_NORTH", "EMEA North").replace("EMEA_SOUTH",
								"EMEA South"));

							//this.oView.getModel("filterModel").setProperty("/regionID", sRegion);
						}
					}

					this.oFacetFilter.getLists().forEach(function (list) {
						list.setSelectedKeys();
						var sTitle = list.getTitle();
						if (sTitle.startsWith("MCC Tag")) {
							sTitle = this.getResourceBundle().getText("filterListMCC_TAG_FLT");
						}
						switch (sTitle) {
							case "Customer":
								if (oVMModelData.CustomerFilters.length > 0) {
									list.setSelectedKeys(JSON.parse(oVMModelData.CustomerFilters));
								}
								break;
							case "Customer Segment":
								if (oVMModelData.CustSegmentFilters.length > 0) {
									list.setSelectedKeys(JSON.parse(oVMModelData.CustSegmentFilters));
								}
								break;
							case "Global Ultimate":
								if (oVMModelData.GlobalUltimateFilters.length > 0) {
									list.setSelectedKeys(JSON.parse(oVMModelData.GlobalUltimateFilters));
								}
								break;
							case "Product Category":
								if (oVMModelData.ProdCatFilters.length > 0) {
									list.setSelectedKeys(JSON.parse(oVMModelData.ProdCatFilters));
								}
								break;
							case "Product Line":
								if (oVMModelData.ProdLineFilters.length > 0) {
									list.setSelectedKeys(JSON.parse(oVMModelData.ProdLineFilters));
								}
								break;
							case "Product":
								if (oVMModelData.ProdFilters.length > 0) {
									list.setSelectedKeys(JSON.parse(oVMModelData.ProdFilters));
								}
								break;
							case "Product Version":
								if (oVMModelData.ProdVersionFilters.length > 0) {
									list.setSelectedKeys(JSON.parse(oVMModelData.ProdVersionFilters));
								}
								break;
							case "Sales Org":
								if (oVMModelData.SalesOrgFilters.length > 0) {
									list.setSelectedKeys(JSON.parse(oVMModelData.SalesOrgFilters));
								}
								break;
							case "Service Org":
								if (oVMModelData.ServiceOrgFilters.length > 0) {
									list.setSelectedKeys(JSON.parse(oVMModelData.ServiceOrgFilters));
								}
								break;
							case "Country":
								if (oVMModelData.CountryFilters.length > 0) {
									list.setSelectedKeys(JSON.parse(oVMModelData.CountryFilters));
								}
								break;
							case "Category":
								if (oVMModelData.CountryFilters.length > 0) {
									list.setSelectedKeys(JSON.parse(oVMModelData.CountryFilters));
								}
								break;
							case "Region":
								if (oVMModelData.RegionFilter.length > 0 && !bOldImplementationUsed) {
									list.setSelectedKeys(JSON.parse(this._transformRegionFilterSelectionFromVariantManagement(oVMModelData.RegionFilter)));
								} else {
									list.setSelectedKeys(JSON.parse('{"WORLD":"World"}'));
								}
								break;
							case "MCC Tag":
								if (oVMModelData.MccTagFilters.length > 0) {
									list.setSelectedKeys(JSON.parse(oVMModelData.MccTagFilters));
								}
								break;
						}

					}.bind(this));

					//Check if there are Product Versions stored in ProductFilters via MCS Dashboard
					//if this is the case, then check if the new ProdVersionFilters is empty or not
					//if it is empty, then a warning message should be shown in the UI
					if (oVMModelData.ProductFilters.length > 0 && oVMModelData.ProdVersionFilters.length === 0) {
						bOldImplementationUsed = true;
						// sWarningMessageProduct = "\n\n Product Version selected in the variant for MCS Dashboard:\n\n " + oVMModelData.ProductFilters.substring(oVMModelData.ProductFilters
						// 	.indexOf(
						// 		":") + 2, oVMModelData.ProductFilters.length - 2);
					}

					//region selection old implementation based on index
					//var selectedIndex = parseInt(oVMModelData.RegionFilter);
					//var oRadioBtnGrp = this.oView.byId("regionGroup");
					//oRadioBtnGrp.setSelectedIndex(selectedIndex);
					//region selection new implementation based on ID

				}

				this.oFacetFilter.rerender();

				this._setFilter(null, true);
				if (bOldImplementationUsed) {
					if (!this.oErrorMessageDialogVariant) {
						this.oErrorMessageDialogVariant = new sap.m.Dialog({
							type: sap.m.DialogType.Message,
							title: "Error during read of saved variant!",
							state: sap.ui.core.ValueState.Warning,
							contentWidth: "30rem",
							content: new sap.m.Text({
								text: "Please recheck the current variant selection. It looks like you are using a definition specific to MCS Dashboard.\n\n  Please reselect the needed Region or Product Version selection. \n\n If you are still using the MCS Dashboard application then please save it with a new name, otherwise feel free to resave the same variant."
							}),
							// new sap.m.Text({
							// 	text: sWarningMessageProduct
							// })],
							beginButton: new sap.m.Button({
								type: sap.m.ButtonType.Emphasized,
								text: "OK",
								press: function () {
									this.oErrorMessageDialogVariant.close();
								}.bind(this)
							})
						});
					}

					this.oErrorMessageDialogVariant.open();
				}
			}
		},
		_isNumeric: function (n) {
			return !isNaN(parseFloat(n)) && isFinite(n);
		},
		_refreshVariantModel: function () {
			this.oController.getModel().read("/SearchVariantSet", {
				success: function (oData) {
					var oModel = new sap.ui.model.json.JSONModel(oData);
					//sap.ui.getCore().setModel(oModel, "variantManagement");
					this.oController.getOwnerComponent().setModel(oModel, "variantManagement");
				}.bind(this)
			});
		},

		getClosedDateFilter: function (sProperty, sDays) {
			if (!sDays) {
				sDays = Constants.closedCasesPastDays
			}
			var dateOffset = (24 * 60 * 60 * 1000) * sDays;
			var dateInPast = new Date();
			dateInPast.setTime(dateInPast.getTime() - dateOffset);

			return new sap.ui.model.Filter({
				path: sProperty,
				operator: sap.ui.model.FilterOperator.GE,
				value1: dateInPast
			});
		},

		_getTotalCustomerEscalationCosts: function (sRegion, oFilterForBWCost) {

			var nRegionCallCounter = 0,
				nRegionCounter = 0;

			//Total Escalation Costs
			var now = new Date();
			var nowMinusOneMonth = new Date();
			nowMinusOneMonth.setDate(1);
			nowMinusOneMonth.setMonth(nowMinusOneMonth.getMonth() - 1);
			var nowMinusTwoMonths = new Date();
			nowMinusTwoMonths.setDate(1);
			nowMinusTwoMonths.setMonth(nowMinusTwoMonths.getMonth() - 2);
			var aFilters = [];
			//temp variables to store sum of costs per last three months
			var iNowCosts = 0,
				iNowMinusOneCosts = 0,
				iNowMinusTwoCosts = 0,
				iYTDCosts = 0;

			// Fill model with month names
			var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
			// var mParamsMap = [
			// 	sFilterSearch
			// ];

			/*Example
			https://bwp.wdf.sap.corp/sap/opu/odata/sap/MCASE_COST_ODA_002N_SRV/MCASE_COST_ODA_002N(MCASE_NMM_OY_003='0HIER_NODE:SUP_COUNTRY%20HIERARCHY',MCASE_CMM_OY_007='',MCASE_CMM_OY_002='',MCASE_CMM_OY_008='',MCASE_NMM_OY_005='',MCASE_CMM_OY_006='',MCASE_HMM_YO_001='',MCASE_HCS_MY_01_0SALESORG='',MCASE_NAM_ON_01_0SALESORG='')/Results/?$select=A00O2TFCW5W1LNCK7SZ7PCASWN,A00O2TFCW5W1LNCK7SZ7PCAZ87,A00O2TFCW5W1LNCK7SZ7PCB5JR,A00O2TFCW5W1LNCK7HR7IERSU9,A4MCASEX017MP_0COUNTRY_T_L
			,A4MCASEX017CRM_SRVORG,A4MCASEX017CRM_SRVORG_T,A4MCASEX017CRM_SALORG,A4MCASEX017CRM_SALORG_T,A4MCASEX017CSM_DELU,A4MCASEX017CSM_DELU_T,A4MCASEX017MP_PMASTERC,A4MCASEX017MP_PMASTERC_T
			*/

			//BW specific filter model for URL specific filter
			var oBWFilterModel = this.oView.getModel("bwFilterModel");
			//var bwp002TotalCostBWModel = this.oController.getOwnerComponent().getModel("bwp002TotalCostBWModel");
			var bwp002TotalCostBWModel = new sap.ui.model.odata.v2.ODataModel(
				sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCASE_COST_ODA_002N_SRV", {
				"metadataUrlParams": {
					"sap-documentation": "heading"
				},
				"defaultCountMode": true,
				"useBatch": false,
				"headers": {
					"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
				}
			});
			bwp002TotalCostBWModel.attachMetadataFailed(function (oEvent) {
				this.oController.getOwnerComponent().getModel("settings").setProperty("/show_cost_data", Boolean(false));
			}, this);

			bwp002TotalCostBWModel.attachMetadataLoaded(function (oEvent) {
				this.oController.getOwnerComponent().getModel("settings").setProperty("/show_cost_data", Boolean(true));
			}, this);

			this.oTileModel.setProperty("/totalEscalationCosts", {});
			//var regionOnlyFilterForBWP = filtersModel.buildRegionOnlyODataFilter("BWP").aFilters;
			//var sFilter = filtersModel.buildURLVariableFilterForBWP(regionOnlyFilterForBWP, "CostStandardStructure");
			var that = this;

			var sRegionBW = "WORLD";
			if (sRegion && sRegion !== "") {
				sRegionBW = sRegion;
			}
			// var model = new JSONModel({
			// 	cases: null //,
			// 		//totalEscalationCosts: null
			// });

			function mergeBWCost() {
				if (nRegionCallCounter !== nRegionCounter) {
					setTimeout(function () {
						jQuery.proxy(mergeBWCost(), this);
					}, 200);
					return null;
				} else {
					that.oTileModel.setProperty("/totalEscalationCosts/", {
						m3: {
							label: monthNames[now.getMonth()],
							y: iNowCosts
						},
						m2: {
							label: monthNames[nowMinusOneMonth.getMonth()],
							y: iNowMinusOneCosts
						},
						m1: {
							label: monthNames[nowMinusTwoMonths.getMonth()],
							y: iNowMinusTwoCosts
						},
						ydt: {
							label: "",
							ydtValue: iYTDCosts
						}
					});
				}
			}
			//for BW we need to read the data for each Region separately
			if (sRegionBW && bwp002TotalCostBWModel) {
				sRegionBW.split(",").forEach(function (region) {
					nRegionCounter++;
					aFilters = [];
					var regionOnlyFilterForBWP = oBWFilterModel.buildRegionOnlyODataFilter("BWP", region).aFilters;
					var sFilter = oBWFilterModel.buildURLVariableFilterForBWP(regionOnlyFilterForBWP, "CostStandardStructure");

					if (oFilterForBWCost && oFilterForBWCost.aFilters && oFilterForBWCost.aFilters.length > 0) {
						aFilters.push(oFilterForBWCost);
					}

					bwp002TotalCostBWModel.read(
						"/MCASE_COST_ODA_002N(" + sFilter +
						")/Results", {
						filters: [new sap.ui.model.Filter(aFilters, true)],
						urlParameters: "$select=A00O2TFCW5W1LNCK7SZ7PCASWN,A00O2TFCW5W1LNCK7SZ7PCAZ87,A00O2TFCW5W1LNCK7SZ7PCB5JR,A00O2TFCW5W1LNCK7HR7IERSU9", //A4MCASEX017MP_0COUNTRY_T_L
						dataType: "json",
						success: function (data, response) {
							var stats = data.results[0];
							if (stats) {
								iNowCosts += parseInt(stats.A00O2TFCW5W1LNCK7SZ7PCASWN, 10);
								iNowMinusOneCosts += parseInt(stats.A00O2TFCW5W1LNCK7SZ7PCAZ87, 10);
								iNowMinusTwoCosts += parseInt(stats.A00O2TFCW5W1LNCK7SZ7PCB5JR, 10);
								iYTDCosts += parseInt(stats.A00O2TFCW5W1LNCK7HR7IERSU9, 10);
							}
							nRegionCallCounter++;
						},
						error: function (oError, response) {
							nRegionCallCounter++;
						}
					});
				});
				mergeBWCost();
			}
		},

		//////////////////
		// MCS Dashboard Charts
		////////////////////

		readCases: function () { //model, dashboardModel, oFilterModel, settingsModel
			var model = this.oController.getOwnerComponent().getModel("KPICases"),
				dashboardModel = this.oController.getOwnerComponent().getModel("mcsModel"),
				oFilterModel = this.oController.getOwnerComponent().getModel("filterModel"),
				settingsModel = this.oController.getOwnerComponent().getModel("settings");
			//settingsModel.setProperty("/kpi_ClosedNewOngoing_HasNoData", Boolean(true));
			//settingsModel.setProperty("/kpi_AverageDurationClosed_HasNoData", Boolean(true));

			//var changed = true;
			var escalationFilters = []; //oFilterModel.buildODataFilter("CRM").aFilters;
			var onlyRegionFilter = []; //oFilterModel.buildRegionOnlyODataFilter("CRM").aFilters;

			var oFilterForICP = oFilterModel.getProperty("/oFilterModelMCS");
			if (oFilterForICP && oFilterForICP.aFilters.length > 0) {
				escalationFilters.push(oFilterForICP);
			}
			var sRegion = oFilterModel.getProperty("/region"); //this.getRegionFilterModel();

			if (sRegion) {
				var aRegionFilter = [];
				sRegion.split(",").forEach(function (region) {
					aRegionFilter.push(new sap.ui.model.Filter("region", sap.ui.model.FilterOperator.EQ, region));
				});
				//not needed anymore, because region is laready part of escalationFilters.push(new sap.ui.model.Filter(aRegionFilter, false));
				//the onlyRegionFilter we still need
				onlyRegionFilter.push(new sap.ui.model.Filter(aRegionFilter, false));
			}

			//only execute the call, if the filters changed
			// changed = (escalationFilters.length !== filtersBefore.length) || escalationFilters.some(function (filter, index) {
			// 	var filterBefore = filtersBefore[index];
			// 	if (!filterBefore) {
			// 		return true;
			// 	} else {
			// 		return !(that._equalFilter(filter, filterBefore, that));
			// 	}
			// });
			// if (!changed) {
			// 	return;
			// }
			// filtersBefore = escalationFilters.slice(0);

			// Cases
			model.setProperty("/casesKPIOngoingEscalationsRegion", null);
			dashboardModel.read("/KPIOngoingEscalationsRegionSet", {
				groupId: "regionSetGroup",
				filters: escalationFilters.slice(0),
				success: function (data, response) {
					model.setProperty("/casesKPIOngoingEscalationsRegion", data.results);
				},
				error: function (oError, response) {
					model.setProperty("/casesKPIOngoingEscalationsRegion", null);
					//	that._showODataError(oError, settingsModel, oResourceBundle);
				}
			});

			model.setProperty("/casesKPIAverageDurationClosedEscalations", null);
			dashboardModel.read("/KPIAverageDurationClosedEscalationsSet", {
				filters: escalationFilters.slice(0),
				success: function (data, response) {
					settingsModel.setProperty("/kpi_AverageDurationClosed_HasNoData", Boolean(true));

					//remove last element to hide ongoing quarter in average escalation chart
					data.results.pop();
					model.setProperty("/casesKPIAverageDurationClosedEscalations", data.results);
				},
				error: function (oError, response) {
					model.setProperty("/casesKPIAverageDurationClosedEscalations", null);
					//	that._showODataError(oError, settingsModel, oResourceBundle);
				}
			});
			//for closed new and ongoing escalation there could be a chart specific filter for global or prod down cases

			var finalFilter = escalationFilters;
			if (settingsModel.getProperty("/kpiClosedNewOngoingEscalationsFilter") !== "ALL") {
				//	finalFilter = [];
				var tileSpecificFilters = new sap.ui.model.Filter([new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ,
					settingsModel.getProperty(
						"/kpiClosedNewOngoingEscalationsFilter"))].filter(Boolean), true);
				//finalFilter = oFilterModel.buildODataFilter("CRM", tileSpecificFilters).aFilters;
				// finalFilter = [new sap.ui.model.Filter({
				// 	filters: [finalFilter[0], finalFilter[1]],
				// 	and: true
				// })];
				finalFilter.push(tileSpecificFilters);
			}
			model.setProperty("/casesKPIClosedNewOngoingEscalations", null);
			model.setProperty("/casesKPIClosedNewOngoingEscalationsTable", null);
			dashboardModel.read("/KPIClosedNewOngoingEscalationsSet", {
				filters: finalFilter,
				success: function (data, response) {
					settingsModel.setProperty("/kpi_ClosedNewOngoing_HasNoData", Boolean(true));
					model.setProperty("/casesKPIClosedNewOngoingEscalations", data.results);

					//table data
					var kpiCases = [];
					var jsonDataTableClosed = {};
					var jsonDataTableNew = {};
					var jsonDataTableOngoing = {};
					jsonDataTableClosed["type_column"] = "Escalation Status";
					jsonDataTableClosed["type"] = "Closed";
					jsonDataTableNew["type"] = "New";
					jsonDataTableOngoing["type"] = "Ongoing";
					var id = 0;
					data.results.forEach(function (object) {
						jsonDataTableClosed[id + "_column"] = object.month;
						jsonDataTableClosed[id] = object.closed;
						jsonDataTableNew[id] = object["new"]; //cannot be used, because "new" is a key wordobject.new;
						jsonDataTableOngoing[id] = object.ongoing;
						id++;
					});
					kpiCases.push(jsonDataTableClosed);
					kpiCases.push(jsonDataTableNew);
					kpiCases.push(jsonDataTableOngoing);
					model.setProperty("/casesKPIClosedNewOngoingEscalationsTable", kpiCases);
				},
				error: function (oError, response) {
					model.setProperty("/casesKPIClosedNewOngoingEscalations", null);
					model.setProperty("/casesKPIClosedNewOngoingEscalationsTable", null);
					//	that._showODataError(oError, settingsModel, oResourceBundle);
				}
			});

			//casesKPITop5Products
			model.setProperty("/casesKPITop5Products", null);
			dashboardModel.read("/KPITop5SolutionsSet", {
				filters: onlyRegionFilter.slice(0),
				success: function (data, response) {
					settingsModel.setProperty("/kpi_Top5Products_HasNoData", Boolean(true));
					model.setProperty("/casesKPITop5Products", data.results);

				},
				error: function (oError, response) {
					model.setProperty("/casesKPITop5Products", null);
					//	that._showODataError(oError, settingsModel, oResourceBundle);
				}
			});

			//casesKPIStrategicProducts
			//casesKPIStrategicProductsTable
			model.setProperty("/casesKPIStrategicProducts", null);
			//	model.setProperty("/casesKPIStrategicProductsTable", null);
			dashboardModel.read("/KPIStrategicProductLinesSet", {
				filters: onlyRegionFilter.slice(0),
				success: function (data, response) {
					settingsModel.setProperty("/kpi_StrategicProducts_HasNoData", Boolean(true));
					model.setProperty("/casesKPIStrategicProducts", data.results);

				},
				error: function (oError, response) {
					model.setProperty("/casesKPIStrategicProducts", null);
				}
			});

		},

		readCasesBWKPI: function (bInitialCall) { //model, bwp004TotalEscaCost13BWModel, bwp005AverageEscaCost13BWModel, bwp006CostOverviewBWModel,	bwp007EscCostPerProductCategoryBWModel,		bwp008TopProductsWithHighEscCostsBWModel,		bwp009EscCostsOfStrategicProductsBWModel,		oBWFilterModel,		oFilterModel,		settingsModel,		oResourceBundle,

			var model = this.oController.getOwnerComponent().getModel("KPICasesBW"),
				//bwp004TotalEscaCost13BWModel = this.oController.getOwnerComponent().getModel("bwp004TotalEscaCost13BWModel"),
				bwp004TotalEscaCost13BWModel = new sap.ui.model.odata.v2.ODataModel(
					sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCASE_COST_ODA_004N_SRV", {
					"metadataUrlParams": {
						"sap-documentation": "heading"
					},
					"defaultCountMode": true,
					"useBatch": false,
					"headers": {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					}
				}),
				//bwp005AverageEscaCost13BWModel = this.oController.getOwnerComponent().getModel("bwp005AverageEscaCost13BWModel"),
				bwp005AverageEscaCost13BWModel = new sap.ui.model.odata.v2.ODataModel(
					sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCASE_COST_ODA_005N_SRV", {
					"metadataUrlParams": {
						"sap-documentation": "heading"
					},
					"defaultCountMode": true,
					"useBatch": false,
					"headers": {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					}
				}),
				//bwp006CostOverviewBWModel = this.oController.getOwnerComponent().getModel("bwp006CostOverviewBWModel"),
				bwp006CostOverviewBWModel = new sap.ui.model.odata.v2.ODataModel(
					sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCASE_COST_ODA_006N_SRV", {
					"metadataUrlParams": {
						"sap-documentation": "heading"
					},
					"defaultCountMode": true,
					"useBatch": false,
					"headers": {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					}
				}),
				//bwp007EscCostPerProductCategoryBWModel = this.oController.getOwnerComponent().getModel("bwp007EscCostPerProductCategoryBWModel"),
				bwp007EscCostPerProductCategoryBWModel = new sap.ui.model.odata.v2.ODataModel(
					sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCASE_COST_ODA_007N_SRV", {
					"metadataUrlParams": {
						"sap-documentation": "heading"
					},
					"defaultCountMode": true,
					"useBatch": false,
					"headers": {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					}
				}),
				//bwp008TopProductsWithHighEscCostsBWModel = this.oController.getOwnerComponent().getModel("bwp008TopProductsWithHighEscCostsBWModel"),
				bwp008TopProductsWithHighEscCostsBWModel = new sap.ui.model.odata.v2.ODataModel(
					sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCASE_COST_ODA_008N_SRV", {
					"metadataUrlParams": {
						"sap-documentation": "heading"
					},
					"defaultCountMode": true,
					"useBatch": false,
					"headers": {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					}
				}),
				//bwp009EscCostsOfStrategicProductsBWModel = this.oController.getOwnerComponent().getModel("bwp009EscCostsOfStrategicProductsBWModel"),
				bwp009EscCostsOfStrategicProductsBWModel = new sap.ui.model.odata.v2.ODataModel(
					sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/bw/sap/opu/odata/sap/MCASE_COST_ODA_009N_SRV", {
					"metadataUrlParams": {
						"sap-documentation": "heading"
					},
					"defaultCountMode": true,
					"useBatch": false,
					"headers": {
						"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
					}
				}),
				oBWFilterModel = this.oController.getOwnerComponent().getModel("bwFilterModel"),
				oFilterModel = this.oController.getOwnerComponent().getModel("filterModel"),
				settingsModel = this.oController.getOwnerComponent().getModel("settings"),
				oResourceBundle = this.getResourceBundle();
			//	var filtersBefore = [],
			//	regionFilterBefore = [];
			//Chart data and table data needs to be restructured in order to meet the element requirements
			this.oController.getOwnerComponent().setModel(bwp006CostOverviewBWModel, "bwp006CostOverviewBWModel");
			var that = this;
			var kpiCasesChart = this.initializeBWPChartArrays("kpiCasesChart", oFilterModel);
			var kpiCasesTable = this.initializeBWPChartArrays("kpiCasesTableChart", oFilterModel, settingsModel);
			var kpiCasesTableIDs = [];
			var kpiCasesChartAvg = this.initializeBWPChartArrays("kpiCasesChart", oFilterModel);
			var kpiCasesTableAvg = this.initializeBWPChartArrays("kpiCasesTableChart", oFilterModel, settingsModel);
			var kpiCasesTableIDsAvg = [];
			var iCostReturnedOdataCount = 0,
				iAverageCostReturnedOdataCount = 0;
			//	settingsModel.setProperty("/kpi_TotalEscalationCosts_HasNoData", Boolean(true));
			//	settingsModel.setProperty("/kpi_AverageEscalationCosts_HasNoData", Boolean(true));
			var sRegion = oFilterModel.getProperty("/region"); //this.getRegionFilterModel();
			//var region = sRegion;
			// Cases
			//**************************
			//********  BW Tiles *******
			//**************************
			//filters cannot be implemented with standard means, because of the implementation in BW
			//" Search is used for variable filter on BW Query, I implement filter on hierarchy logics inside. Filter only works on Region who is not a hierarchy parent node, such as filter on country."
			//therefore I have to use the ?search here
			//filter=process_type%20eq%20%27ZSPRCTYP01%27%20and%20((master_code%20eq%20%2701%27)%20or%20(delivery_unit%20eq%20%270000167698%27%20or%20delivery_unit%20eq%20%270000167980%27))

			var bwFilters = oFilterModel.getProperty("/oFilterForBWCosts");

			//there could be a chart specific filter for global or prod down cases
			//	kpiTotalEscalationCostsFilter: "ALL", //initially show Global and Produkt Escalations
			//	kpiAverageEscaltaionCostsFilter: "ALL
			var finalFilterKpiTotalEscalationCostsFilter = bwFilters;
			if (settingsModel.getProperty("/kpiTotalEscalationCostsFilter") !== "ALL") {
				var tileSpecificFilters = new sap.ui.model.Filter([new sap.ui.model.Filter("A4MCASEX017CSM_STYP", sap.ui.model.FilterOperator.EQ,
					settingsModel.getProperty(
						"/kpiTotalEscalationCostsFilter"))].filter(Boolean), true);
				//finalFilterKpiTotalEscalationCostsFilter = oBWFilterModel.buildODataFilter("BWP", tileSpecificFilters).aFilters;
				if (finalFilterKpiTotalEscalationCostsFilter.aFilters) {
					finalFilterKpiTotalEscalationCostsFilter.aFilters.push(tileSpecificFilters);
				} else {
					finalFilterKpiTotalEscalationCostsFilter = [tileSpecificFilters];
				}
			}
			var finalFilterKpiAverageEscaltaionCostsFilter = bwFilters;
			if (settingsModel.getProperty("/kpiAverageEscaltaionCostsFilter") !== "ALL") {
				tileSpecificFilters = new sap.ui.model.Filter([new sap.ui.model.Filter("A4MCASEX017CSM_STYP", sap.ui.model.FilterOperator.EQ,
					settingsModel.getProperty(
						"/kpiAverageEscaltaionCostsFilter"))].filter(Boolean), true);
				//finalFilterKpiAverageEscaltaionCostsFilter = oBWFilterModel.buildODataFilter("BWP", tileSpecificFilters).aFilters;
				if (finalFilterKpiAverageEscaltaionCostsFilter.aFilters) {
					finalFilterKpiAverageEscaltaionCostsFilter.aFilters.push(tileSpecificFilters);
				} else {
					finalFilterKpiAverageEscaltaionCostsFilter = [tileSpecificFilters];
				}
			}

			///////////////////
			// Total Escalation Cost 13
			///////////////////

			this.readTotalEscalationCostsFromBWP(model, oBWFilterModel, sRegion, bwp004TotalEscaCost13BWModel,
				finalFilterKpiTotalEscalationCostsFilter, settingsModel, iCostReturnedOdataCount, kpiCasesChart, kpiCasesTable,
				kpiCasesTableIDs);

			///////////////////
			// Average Escalation Cost 13
			///////////////////
			this.readAverageEscalationCostsFromBWP(model, oBWFilterModel, sRegion, bwp005AverageEscaCost13BWModel,
				finalFilterKpiAverageEscaltaionCostsFilter, settingsModel, iAverageCostReturnedOdataCount, kpiCasesChartAvg, kpiCasesTableAvg,
				kpiCasesTableIDsAvg);

			var sRegionBW = "WORLD";
			if (sRegion && sRegion !== "") {
				sRegionBW = sRegion;
			}

			//functions needed, because for BW oData calls we cannot submit several Region filters in one call. We need to call it separately and the merge it.
			//only after all calls have been successful, we can update the data model for the ui

			var nRegionCallCounterBWTopProd = 0,
				nRegionCounterBWTopProd = 0,
				aoDataResultBWTopProd = [],
				bNotAddedYetBWTopProd = true;

			function mergeBWTopProdWithHighEscCost() {
				if (nRegionCallCounterBWTopProd !== nRegionCounterBWTopProd) {
					setTimeout(function () {
						jQuery.proxy(mergeBWTopProdWithHighEscCost(), this);
					}, 200);
					return null;
				} else {
					//get the top 5 out of all Region calls
					aoDataResultBWTopProd.sort(function (a, b) {
						return b.A00O2TFCW5W1NDHZ4Y26S87XP5 - a.A00O2TFCW5W1NDHZ4Y26S87XP5;
					});
					aoDataResultBWTopProd.length = 5;
					that._onFinishLoadingDataToModel(model, "/top5ProductsWithHighEscCosts", aoDataResultBWTopProd);
				}
			}
			//for the table
			var nRegionCallCounterBWTopProdT = 0,
				nRegionCounterBWTopProdT = 0,
				aoDataResultBWTopProdT = [];
			//bNotAddedYetBWTopProdT = true;

			function mergeBWTopProdWithHighEscCostT() {
				if (nRegionCallCounterBWTopProdT !== nRegionCounterBWTopProdT) {
					setTimeout(function () {
						jQuery.proxy(mergeBWTopProdWithHighEscCostT(), this);
					}, 200);
					return null;
				} else {
					that._onFinishLoadingDataToModel(model, "/top5ProductsWithHighEscCostsTable", aoDataResultBWTopProdT);
				}
			}

			var nRegionCallCounterBWStratProd = 0,
				nRegionCounterBWStratProd = 0,
				aoDataResultBWStratProd = [],
				bNotAddedYetBWStratProd = true;

			function mergeBWStratProdWithHighEscCost() {
				if (nRegionCallCounterBWStratProd !== nRegionCounterBWStratProd) {
					setTimeout(function () {
						jQuery.proxy(mergeBWStratProdWithHighEscCost(), this);
					}, 200);
					return null;
				} else {
					that._onFinishLoadingDataToModel(model, "/escCostsOfStrategicProducts", aoDataResultBWStratProd);
				}
			}

			var nRegionCallCounterBWStratProdT = 0,
				nRegionCounterBWStratProdT = 0,
				aoDataResultBWStratProdT = [];
			//bNotAddedYetBWStratProdT = true;

			function mergeBWStratProdWithHighEscCostT() {
				if (nRegionCallCounterBWStratProdT !== nRegionCounterBWStratProdT) {
					setTimeout(function () {
						jQuery.proxy(mergeBWStratProdWithHighEscCostT(), this);
					}, 200);
					return null;
				} else {
					that._onFinishLoadingDataToModel(model, "/escCostsOfStrategicProductsTable", aoDataResultBWStratProdT);
				}
			}

			var nRegionCallCounterBWProdCat = 0,
				nRegionCounterBWProdCat = 0,
				aoDataResultBWProdCat = [],
				bNotAddedYetBWProdCat = true;

			function mergeBWProdCatWithHighEscCost() {
				if (nRegionCallCounterBWProdCat !== nRegionCounterBWProdCat) {
					setTimeout(function () {
						jQuery.proxy(mergeBWProdCatWithHighEscCost(), this);
					}, 200);
					return null;
				} else {
					that._onFinishLoadingDataToModel(model, "/escCostsPerProductCategory", aoDataResultBWProdCat);
				}
			}

			var nRegionCallCounterBWProdCatT = 0,
				nRegionCounterBWProdCatT = 0,
				aoDataResultBWProdCatT = [],
				bNotAddedYetBWProdCatT = true;

			function mergeBWProdCatWithHighEscCostT() {
				if (nRegionCallCounterBWProdCatT !== nRegionCounterBWProdCatT) {
					setTimeout(function () {
						jQuery.proxy(mergeBWProdCatWithHighEscCostT(), this);
					}, 200);
					return null;
				} else {
					that._onFinishLoadingDataToModel(model, "/escCostsPerProductCategoryTable", aoDataResultBWProdCatT);
				}
			}

			if (settingsModel.oData.show_cost_data) {

				//-----------------------------
				//topProductsWithHighEscCosts
				//-----------------------------
				this._onBeginLoadingDataToModel(model, "/top5ProductsWithHighEscCosts");
				this._onBeginLoadingDataToModel(model, "/top5ProductsWithHighEscCostsTable");

				//for BW we need to read the data for each Region separately
				if (sRegionBW) {
					sRegionBW.split(",").forEach(function (region) {
						nRegionCounterBWTopProd++;
						var regionOnlyFilterForBWP = oBWFilterModel.buildRegionOnlyODataFilter("BWP", region).aFilters;
						var sBWPFilter = oBWFilterModel.buildURLVariableFilterForBWP(regionOnlyFilterForBWP, "");
						bwp008TopProductsWithHighEscCostsBWModel.read("/MCASE_COST_ODA_008N(" + sBWPFilter + ")/Results", {
							//jQuery.ajax("./json/topProductsWithHighEscCosts.json", { // load the data from a relative URL (the Data.json file in the same directory)
							urlParameters: "$select=A4MCASEX017PPMSPRLN_T,A00O2TFCW5W1NDHZ4Y26S87XP5",
							dataType: "json",
							success: function (oData) {
								oData.results.forEach(function (result) {
									bNotAddedYetBWTopProd = true;
									//	dSumOfAllCosts += parseFloat(result.A00O2TFCW5W1NDKQA1Y5ZL0248);
									aoDataResultBWTopProd.forEach(function (val, i) {
										if (aoDataResultBWTopProd[i].A4MCASEX017PPMSPRLN_T === result.A4MCASEX017PPMSPRLN_T) {
											bNotAddedYetBWTopProd = false;
											aoDataResultBWTopProd[i].A00O2TFCW5W1NDHZ4Y26S87XP5 += parseFloat(result.A00O2TFCW5W1NDHZ4Y26S87XP5); //costs
										}
									});
									if (bNotAddedYetBWTopProd) {
										var oNewEntry = {};
										oNewEntry.A4MCASEX017PPMSPRLN_T = result.A4MCASEX017PPMSPRLN_T;
										oNewEntry.A00O2TFCW5W1NDHZ4Y26S87XP5 = parseFloat(result.A00O2TFCW5W1NDHZ4Y26S87XP5);
										//append new entry to the structuredDataSet
										aoDataResultBWTopProd.push(oNewEntry);
									}

								}, this);
								nRegionCallCounterBWTopProd++;
								//that._onFinishLoadingDataToModel(model, "/top5ProductsWithHighEscCosts", oData.results);
							},
							error: function (oError, response) {
								nRegionCallCounterBWTopProd++;
								//	that._onFinishLoadingDataToModel(model, "/top5ProductsWithHighEscCosts", []);
								//	model.setProperty("/top5ProductsWithHighEscCostsTable", null);
							}
						});
					});

					mergeBWTopProdWithHighEscCost();
				}
				//read Case IDs from oData for Table https://mcsdashboard-sapitcloudt.dispatcher.hana.ondemand.com/webapp/destinations/int_bw
				///sap/MCASE_COST_ODA_008N_SRV/MCASE_COST_ODA_008N(MCASE_NMM_OY_003='0HIER_NODE%3ASUP_EMEA%20W%2FO%20MEE',MCASE_HCS_MY_01_0SALESORG='',MCASE_NAM_ON_01_0SALESORG='')/Results?$select=A4MCASEX017PPMSPRLN_T,A4MCASEX017CSM_EXID
				//for BW we need to read the data for each Region separately
				if (sRegionBW) {
					sRegionBW.split(",").forEach(function (region) {
						nRegionCounterBWTopProdT++;
						var regionOnlyFilterForBWP = oBWFilterModel.buildRegionOnlyODataFilter("BWP", region).aFilters;
						var sBWPFilter = oBWFilterModel.buildURLVariableFilterForBWP(regionOnlyFilterForBWP, "");

						bwp008TopProductsWithHighEscCostsBWModel.read("/MCASE_COST_ODA_008N(" + sBWPFilter + ")/Results", {
							//jQuery.ajax("./json/topProductsWithHighEscCosts.json", { // load the data from a relative URL (the Data.json file in the same directory)
							urlParameters: "$select=A4MCASEX017PPMSPRLN_T,A4MCASEX017CSM_EXID,A4MCASEX017CSM_STAT,A4MCASEX017CUSTOMER_T",
							dataType: "json",
							success: function (oData) {
								oData.results.forEach(function (result) {
									//bNotAddedYetBWTopProdT = true;
									//	dSumOfAllCosts += parseFloat(result.A00O2TFCW5W1NDKQA1Y5ZL0248);

									// aoDataResultBWTopProdT.forEach(function (val, i) {
									// 	if (aoDataResultBWTopProdT[i].A4MCASEX017PPMSPRLN_T === result.A4MCASEX017PPMSPRLN_T) {
									// 		bNotAddedYetBWTopProdT = false;
									// 		aoDataResultBWTopProdT[i].A00O2TFCW5W1NDHZ4Y26S87XP5 += parseFloat(result.A00O2TFCW5W1NDHZ4Y26S87XP5); //costs
									// 	}
									// });
									//if (bNotAddedYetBWTopProdT) {
									var oNewEntry = {};
									oNewEntry.A4MCASEX017PPMSPRLN_T = result.A4MCASEX017PPMSPRLN_T;
									oNewEntry.A4MCASEX017CSM_EXID = result.A4MCASEX017CSM_EXID;
									oNewEntry.A4MCASEX017CSM_STAT = result.A4MCASEX017CSM_STAT;
									oNewEntry.A4MCASEX017CUSTOMER_T = result.A4MCASEX017CUSTOMER_T;
									//append new entry to the structuredDataSet
									aoDataResultBWTopProdT.push(oNewEntry);
									//}

								}, this);
								nRegionCallCounterBWTopProdT++;
								// if (oData.d) {
								// 	oData = oData.d.results;
								// } else {
								// 	oData = null;
								// }
								//that._onFinishLoadingDataToModel(model, "/top5ProductsWithHighEscCostsTable", oData.results);
							},
							error: function (oError, response) {
								nRegionCallCounterBWTopProdT++;
								//that._onFinishLoadingDataToModel(model, "/top5ProductsWithHighEscCostsTable", []);
								//model.setProperty("/top5ProductsWithHighEscCostsTable", null);
							}
						});
					});

					mergeBWTopProdWithHighEscCostT();
				}
				//}

				//-----------------------------
				//escCostsOfStrategicProducts
				//-----------------------------
				//	if (settingsModel.oData.show_cost_data) {

				this._onBeginLoadingDataToModel(model, "/escCostsOfStrategicProducts");
				this._onBeginLoadingDataToModel(model, "/escCostsOfStrategicProductsTable");
				//for BW we need to read the data for each Region separately
				if (sRegionBW) {
					sRegionBW.split(",").forEach(function (region) {
						nRegionCounterBWStratProd++;
						var regionOnlyFilterForBWP = oBWFilterModel.buildRegionOnlyODataFilter("BWP", region).aFilters;
						var sBWPFilter = oBWFilterModel.buildURLVariableFilterForBWP(regionOnlyFilterForBWP, "");
						bwp009EscCostsOfStrategicProductsBWModel.read("/MCASE_COST_ODA_009N(" + sBWPFilter + ")/Results", {
							//jQuery.ajax("./json/escCostsOfStrategicProducts.json", { // load the data from a relative URL (the Data.json file in the same directory)
							urlParameters: "$select=A4MCASEX017PPMSPRLN_T,A00O2TFCW5W1NDHZ4Y40QFSB4P",
							dataType: "json",
							success: function (oData) {
								// if (oData.d) {
								// 	oData = oData.d.results;
								// } else {
								// 	oData = null;
								// }
								//	that._onFinishLoadingDataToModel(model, "/escCostsOfStrategicProducts", oData.results);
								oData.results.forEach(function (result) {
									bNotAddedYetBWStratProd = true;
									//	dSumOfAllCosts += parseFloat(result.A00O2TFCW5W1NDKQA1Y5ZL0248);
									aoDataResultBWStratProd.forEach(function (val, i) {
										if (aoDataResultBWStratProd[i].A4MCASEX017PPMSPRLN_T === result.A4MCASEX017PPMSPRLN_T) {
											bNotAddedYetBWStratProd = false;
											aoDataResultBWStratProd[i].A00O2TFCW5W1NDHZ4Y40QFSB4P += parseFloat(result.A00O2TFCW5W1NDHZ4Y40QFSB4P); //costs
										}
									});
									if (bNotAddedYetBWStratProd) {
										var oNewEntry = {};
										oNewEntry.A4MCASEX017PPMSPRLN_T = result.A4MCASEX017PPMSPRLN_T;
										oNewEntry.A00O2TFCW5W1NDHZ4Y40QFSB4P = parseFloat(result.A00O2TFCW5W1NDHZ4Y40QFSB4P);
										//append new entry to the structuredDataSet
										aoDataResultBWStratProd.push(oNewEntry);
									}

								}, this);
								nRegionCallCounterBWStratProd++;
							},
							error: function (oError, response) {
								nRegionCallCounterBWStratProd++;
								//	that._onFinishLoadingDataToModel(model, "/escCostsOfStrategicProducts", []);
								//	model.setProperty("/escCostsOfStrategicProductsTable", null);
							}
						});
					});
					mergeBWStratProdWithHighEscCost();
				}
				//read Case IDs from oData for Table https://mcsdashboard-sapitcloudt.dispatcher.hana.ondemand.com/webapp/destinations/int_bw/sap/MCASE_COST_ODA_008N_SRV/MCASE_COST_ODA_008N(MCASE_NMM_OY_003='0HIER_NODE%3ASUP_EMEA%20W%2FO%20MEE',MCASE_HCS_MY_01_0SALESORG='',MCASE_NAM_ON_01_0SALESORG='')/Results?$select=A4MCASEX017PPMSPRLN_T,A4MCASEX017CSM_EXID
				if (sRegionBW) {
					sRegionBW.split(",").forEach(function (region) {
						nRegionCounterBWStratProdT++;
						var regionOnlyFilterForBWP = oBWFilterModel.buildRegionOnlyODataFilter("BWP", region).aFilters;
						var sBWPFilter = oBWFilterModel.buildURLVariableFilterForBWP(regionOnlyFilterForBWP, "");
						bwp009EscCostsOfStrategicProductsBWModel.read("/MCASE_COST_ODA_009N(" + sBWPFilter + ")/Results", {
							//jQuery.ajax("./json/escCostsOfStrategicProducts.json", { // load the data from a relative URL (the Data.json file in the same directory)
							urlParameters: "$select=A4MCASEX017PPMSPRLN_T,A4MCASEX017CSM_EXID,A4MCASEX017CSM_STAT,A4MCASEX017CUSTOMER_T",
							dataType: "json",
							success: function (oData) {
								// if (oData.d) {
								// 	oData = oData.d.results;
								// } else {
								// 	oData = null;
								// }
								//	that._onFinishLoadingDataToModel(model, "/escCostsOfStrategicProductsTable", oData.results);
								oData.results.forEach(function (result) {
									//	bNotAddedYetBWStratProdT = true;
									//	dSumOfAllCosts += parseFloat(result.A00O2TFCW5W1NDKQA1Y5ZL0248);
									// aoDataResultBWStratProdT.forEach(function (val, i) {
									// 	if (aoDataResultBWStratProdT[i].A4MCASEX017PPMSPRLN_T === result.A4MCASEX017PPMSPRLN_T) {
									// 	//	bNotAddedYetBWStratProdT = false;
									// 		aoDataResultBWStratProdT[i].A00O2TFCW5W1NDHZ4Y40QFSB4P += parseFloat(result.A00O2TFCW5W1NDHZ4Y40QFSB4P); //costs
									// 	}
									// });
									//	if (bNotAddedYetBWStratProdT) {
									var oNewEntry = {};
									oNewEntry.A4MCASEX017PPMSPRLN_T = result.A4MCASEX017PPMSPRLN_T;
									oNewEntry.A4MCASEX017CSM_EXID = result.A4MCASEX017CSM_EXID;
									oNewEntry.A4MCASEX017CSM_STAT = result.A4MCASEX017CSM_STAT;
									oNewEntry.A4MCASEX017CUSTOMER_T = result.A4MCASEX017CUSTOMER_T;
									//append new entry to the structuredDataSet
									aoDataResultBWStratProdT.push(oNewEntry);
									//	}

								}, this);
								nRegionCallCounterBWStratProdT++;
							},
							error: function (oError, response) {
								nRegionCallCounterBWStratProdT++;
								//model.setProperty("/escCostsOfStrategicProductsTable", null);
							}
						});
					});
					mergeBWStratProdWithHighEscCostT();
				}
				//	}

				//-----------------------------
				//escCostPerProductCategory
				//-----------------------------

				//if (settingsModel.oData.show_cost_data) {
				this._onBeginLoadingDataToModel(model, "/escCostsPerProductCategory");
				this._onBeginLoadingDataToModel(model, "/escCostsPerProductCategoryTable");

				//for BW we need to read the data for each Region separately
				if (sRegionBW) {
					sRegionBW.split(",").forEach(function (region) {
						nRegionCounterBWProdCat++;
						var regionOnlyFilterForBWP = oBWFilterModel.buildRegionOnlyODataFilter("BWP", region).aFilters;
						var sBWPFilter = oBWFilterModel.buildURLVariableFilterForBWP(regionOnlyFilterForBWP, "");
						bwp007EscCostPerProductCategoryBWModel.read("/MCASE_COST_ODA_007N(" + sBWPFilter + ")/Results", {
							//jQuery.ajax("./json/escCostPerProductCategory.json", { // load the data from a relative URL (the Data.json file in the same directory)
							urlParameters: "$select=A4MCASEX017CSM_PCL1,A0CALYEAR,A00O2TFCW5W1NDHZ4Y26S86061",
							dataType: "json",
							success: function (oData) {
								// if (oData.d) {
								// 	oData = oData.d.results;
								// } else {
								// 	oData = null;
								// }
								//that._onFinishLoadingDataToModel(model, "/escCostsPerProductCategory", oData.results);
								oData.results.forEach(function (result) {
									bNotAddedYetBWProdCat = true;
									//	dSumOfAllCosts += parseFloat(result.A00O2TFCW5W1NDKQA1Y5ZL0248);
									aoDataResultBWProdCat.forEach(function (val, i) {
										if (aoDataResultBWProdCat[i].A4MCASEX017CSM_PCL1 === result.A4MCASEX017CSM_PCL1 && aoDataResultBWProdCat[i].A0CALYEAR ===
											result.A0CALYEAR) {
											bNotAddedYetBWProdCat = false;
											aoDataResultBWProdCat[i].A00O2TFCW5W1NDHZ4Y26S86061 += parseFloat(result.A00O2TFCW5W1NDHZ4Y26S86061); //costs
										}
									});
									if (bNotAddedYetBWProdCat) {
										var oNewEntry = {};
										oNewEntry.A4MCASEX017CSM_PCL1 = result.A4MCASEX017CSM_PCL1;
										oNewEntry.A0CALYEAR = result.A0CALYEAR;
										oNewEntry.A00O2TFCW5W1NDHZ4Y26S86061 = parseFloat(result.A00O2TFCW5W1NDHZ4Y26S86061);
										//append new entry to the structuredDataSet
										aoDataResultBWProdCat.push(oNewEntry);
									}

								}, this);
								nRegionCallCounterBWProdCat++;

							},
							error: function (oError, response) {
								//that._onFinishLoadingDataToModel(model, "/escCostsPerProductCategory", []);
								nRegionCallCounterBWProdCat++;
							}
						});
					});
					mergeBWProdCatWithHighEscCost();
				}
				if (sRegionBW) {
					sRegionBW.split(",").forEach(function (region) {
						nRegionCounterBWProdCatT++;
						var regionOnlyFilterForBWP = oBWFilterModel.buildRegionOnlyODataFilter("BWP", region).aFilters;
						var sBWPFilter = oBWFilterModel.buildURLVariableFilterForBWP(regionOnlyFilterForBWP, "");
						bwp007EscCostPerProductCategoryBWModel.read("/MCASE_COST_ODA_007N(" + sBWPFilter + ")/Results", {
							//jQuery.ajax("./json/escCostPerProductCategory.json", { // load the data from a relative URL (the Data.json file in the same directory)
							urlParameters: "$select=A4MCASEX017CSM_PCL1,A0CALYEAR,A4MCASEX017CSM_EXID,A4MCASEX017CSM_STAT,A4MCASEX017CUSTOMER_T",
							dataType: "json",
							success: function (oData) {
								// if (oData.d) {
								// 	oData = oData.d.results;
								// } else {
								// 	oData = null;
								// }
								//that._onFinishLoadingDataToModel(model, "/escCostsPerProductCategoryTable", oData.results);
								oData.results.forEach(function (result) {
									//	bNotAddedYetBWStratProdT = true;
									//	dSumOfAllCosts += parseFloat(result.A00O2TFCW5W1NDKQA1Y5ZL0248);
									// aoDataResultBWStratProdT.forEach(function (val, i) {
									// 	if (aoDataResultBWStratProdT[i].A4MCASEX017PPMSPRLN_T === result.A4MCASEX017PPMSPRLN_T) {
									// 	//	bNotAddedYetBWStratProdT = false;
									// 		aoDataResultBWStratProdT[i].A00O2TFCW5W1NDHZ4Y40QFSB4P += parseFloat(result.A00O2TFCW5W1NDHZ4Y40QFSB4P); //costs
									// 	}
									// });
									//	if (bNotAddedYetBWStratProdT) {
									var oNewEntry = {};
									oNewEntry.A4MCASEX017CSM_PCL1 = result.A4MCASEX017CSM_PCL1;
									oNewEntry.A0CALYEAR = result.A0CALYEAR;
									oNewEntry.A4MCASEX017CSM_EXID = result.A4MCASEX017CSM_EXID;
									oNewEntry.A4MCASEX017CSM_STAT = result.A4MCASEX017CSM_STAT;
									oNewEntry.A4MCASEX017CUSTOMER_T = result.A4MCASEX017CUSTOMER_T;
									//append new entry to the structuredDataSet
									aoDataResultBWProdCatT.push(oNewEntry);
									//	}

								}, this);
								nRegionCallCounterBWProdCatT++;
							},
							error: function (oError, response) {
								//that._onFinishLoadingDataToModel(model, "/escCostsPerProductCategoryTable", []);
								nRegionCallCounterBWProdCatT++;
							}
						});
					});
				}
				mergeBWProdCatWithHighEscCostT();
			}
			//////////////////
			//Escalation Cost Overview -->  moved back to MCSCharts controller, because only needs to be read initially, no filters apply
			/////////////////
			//readEscalationCostsOverviewFromBWP
			//if (bInitialCall) {
			//		this.readEscalationCostsOverviewFromBWP(model, oBWFilterModel, bwp006CostOverviewBWModel, settingsModel,
			//		iEscalationsCostOverviewReturnedOdataCount, oResourceBundle, kpiCasesOverviewCostsTable);
			//	}

		},

		readTotalEscalationCostsFromBWP: function (model, filtersModel, sRegion, bwp004TotalEscaCost13BWModel,
			bwFilters, settingsModel, iCostReturnedOdataCount, kpiCasesChart, kpiCasesTable, kpiCasesTableIDs) {
			this._onBeginLoadingDataToModel(model, "/casesKPITotalEscalationCosts");
			this._onBeginLoadingDataToModel(model, "/casesKPITotalEscalationCostsTable");

			//have to read each region and World separately, because not supported in a different way by BWP
			//var aRegions = ["EMEA", "MEE", "LAC","NA", "APJ", "GTC","World"];
			// var aRegions = ["0HIER_NODE:SUP_COUNTRY%20HIERARCHY", "0HIER_NODE:SUP_EMEA W%2FO MEE", "0HIER_NODE:SUP_MEE", "0HIER_NODE:SUP_LAC",
			// 	"0HIER_NODE:SUP_NA",
			// 	"0HIER_NODE:SUP_APJ W%2FO GC", "0HIER_NODE:SUP_GREATER CHINA"
			// ];
			//ONLY for local Testing needed	var aRegions = ["0HIER_NODE:SUP_COUNTRY%20HIERARCHY", "0HIER_NODE:SUP_EMEA W/O MEE", "0HIER_NODE:SUP_MEE"];
			//ONLY for local Testing needed	var aRegions = ["0HIER_NODE:SUP_MEE"];
			//ONLY for local Testing needed		var aRegionFiles = ["./json/MCASE_COST_ODA_004N_WORLD.json", "./json/MCASE_COST_ODA_004N_EMEA.json","./json/MCASE_COST_ODA_004N_MEE.json"				];
			//ONLY for local Testing needed	var aRegionFiles = ["./json/MCASE_COST_ODA_004N_MEE.json"		];

			// if (regionOnlyFilterForBWP !== null && regionOnlyFilterForBWP.length === 1 && regionOnlyFilterForBWP[0].oValue1 !==
			// 	"0HIER_NODE:SUP_COUNTRY%20HIERARCHY") {
			// 	aRegions = ["SPECIFIC_REGION_SELECTED"];
			// }

			//because of multiselect of Regions we need to add feed items manually
			if (sRegion !== "" || sRegion !== "World") {
				var oVizFrame = this.oView.byId("vizFrameTotalEscalationCostsRegion");
				if (oVizFrame) {
					oVizFrame.removeFeed(this.oView.byId("valueAxisTotalEscaCostMEE"));
					oVizFrame.removeFeed(this.oView.byId("valueAxisTotalEscaCostEMEA"));
					oVizFrame.removeFeed(this.oView.byId("valueAxisTotalEscaCostNA"));
					oVizFrame.removeFeed(this.oView.byId("valueAxisTotalEscaCostLAC"));
					oVizFrame.removeFeed(this.oView.byId("valueAxisTotalEscaCostAPJ"));
					oVizFrame.removeFeed(this.oView.byId("valueAxisTotalEscaCostGTC"));
					//	oVizFrame.removeFeed(this.oView.byId("valueAxisTotalEscaCostWORLD"));

					// if (sRegion === "") {
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisTotalEscaCostMEE"));
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisTotalEscaCostEMEA"));
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisTotalEscaCostNA"));
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisTotalEscaCostLAC"));
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisTotalEscaCostAPJ"));
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisTotalEscaCostGTC"));
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisTotalEscaCostWORLD"));
					// } else {
					sRegion.split(",").forEach(function (region) {
						if (region === "EMEA_NORTH" || region === "EMEA_SOUTH") {
							region = "EMEA";
						}
						oVizFrame.addFeed(this.oView.byId("valueAxisTotalEscaCost" + region));
					}, this);
				}
				//	}
			}
			var that = this;
			if (!sRegion) {
				sRegion = "EMEA,MEE,LAC,NA,APJ,GTC,WORLD";
			}
			sRegion.split(",").forEach(function (region) {

				var regionOnlyFilterForBWP = filtersModel.buildRegionOnlyODataFilter("BWP", region).aFilters;
				var sFilter = filtersModel.buildURLVariableFilterForBWP(regionOnlyFilterForBWP, "CostStandardStructure");

				//	for (var i = 0; i < aRegions.length; i++) {
				///	jQuery.ajax(aRegionFiles[i], { // load the data from a relative URL (the Data.json file in the same directory)
				// var sFinalURLFilter = filtersModel.buildURLVariableFilterForBWP(null, "CostStandardStructure", region); //sFilterPart1 + aRegions[i] + sFilterPart2;
				// if (regionOnlyFilterForBWP !== null && regionOnlyFilterForBWP.length === 1 && regionOnlyFilterForBWP[0].oValue1 !==
				// 	"0HIER_NODE:SUP_COUNTRY%20HIERARCHY") {
				// 	sFinalURLFilter = sFilter;
				// }
				bwp004TotalEscaCost13BWModel.read("/MCASE_COST_ODA_004N(" + sFilter + ")/Results", {
					filters: ((bwFilters.aFilters) ? bwFilters.aFilters.slice(0) : bwFilters), //bwFilters.slice(0),
					urlParameters: "$select=A0CALMONTH_T,A00O2TFCW5W1LNFTOKKOEG5UQT",
					dataType: "json",
					success: function (oData, response) {
						//if (settingsModel.getProperty("/selectedRegionFilter").toUpperCase() === "WORLD") {
						iCostReturnedOdataCount++;
						//	}
						settingsModel.setProperty("/kpi_TotalEscalationCosts_HasNoData", Boolean(true));
						//needed for local json file read
						// if (oData.d) {
						// 	oData.results = oData.d.results;
						// } else {
						// 	oData = null;
						// }
						//set current regio to World as initial value, this value is also needed for Region specific Chart display
						var sCurrentRegion = "World";
						//this is needed to check, to which Region the returned information belongs to
						if (oData.results.length > 0) {
							sCurrentRegion = that._transformBwRegionsfromoDataReturnURI(oData.results[0].__metadata.uri);
						}
						//on DEV system in order to use the dummy json test file
						// var oData = dataModelTotalEscalationCosts.getData();
						// oData.totalEscalationCosts.forEach(function(object) {
						oData.results.forEach(function (object) {
							//check if region filter has been selected, because different chart is shown for BW KPI charts and only one row in the table view for the specific region
							//charts data
							//not needed anymore, because a table with 0.00 values has already been created - it just needs to replace the correct columns var bElementAlreadyAdded = false;
							var jsonDataChartElement = {};
							kpiCasesChart.forEach(
								function (innerObject) {
									//WORKAROUND if (innerObject["Month"] === object.A0CALMONTH_T) {
									if (innerObject["MonthTEMPNumber"] === object.A0CALMONTH_T) {
										jsonDataChartElement = innerObject;
										//bElementAlreadyAdded = true;
										return;
									}
								}
							);
							//	if (selectedRegion.toUpperCase() !== "WORLD" || selectedRegion.toUpperCase() === object.REGION.toUpperCase()) {

							//WORKAROUND	jsonDataChartElement["Month"] = object.A0CALMONTH_T;
							//jsonDataChartElement[sCurrentRegion] = object.A00O2TFCW5W1LNFTOKKOEG5UQT;
							//oData Service sometimes return 0, yet 0.00 should be displayed
							if (sCurrentRegion === "EMEA") { //in case of EMEA_NORTh and EMEA_SOUTH we need to sum up both values
								jsonDataChartElement[sCurrentRegion] = (parseFloat(jsonDataChartElement[sCurrentRegion]) + parseFloat(object.A00O2TFCW5W1LNFTOKKOEG5UQT))
									.toString();
							} else {
								jsonDataChartElement[sCurrentRegion] = object.A00O2TFCW5W1LNFTOKKOEG5UQT === "0" ? "0.00" : object.A00O2TFCW5W1LNFTOKKOEG5UQT;
							}
							//we need to add the region specific value also to "WORLD", because the chart in the UI is mapped to this data value for the regional specific view
							// if (settingsModel.getProperty("/selectedRegionFilter").toUpperCase() !== "WORLD") {
							// 	jsonDataChartElement["World"] = object.A00O2TFCW5W1LNFTOKKOEG5UQT;
							// }
							//not needed anymore, because a table with 0.00 values has already been created - it just needs to replace the correct columns
							//if (!bElementAlreadyAdded) {
							//		kpiCasesChart.push(jsonDataChartElement);
							//}
							//table data
							//check if region filter has been selected, because different chart is shown for BW KPI charts and only one row in the table view for the specific region
							// if (settingsModel.getProperty("/selectedRegionFilter").toUpperCase() === "WORLD" || settingsModel.getProperty(
							// 		"/selectedRegionFilter").toUpperCase() === sCurrentRegion.toUpperCase()) {
							//var id = 0;
							//var jsonDataTableElementId = {};
							var jsonDataTableElement = {};
							//var bTableElementAlreadyAdded = false;
							kpiCasesTable.forEach(
								function (innerObject) {
									if (innerObject["type"] === sCurrentRegion) {
										jsonDataTableElement = innerObject;
										for (var iColumnCounter = 12; iColumnCounter >= 0; iColumnCounter--) {
											//WORKAROUND if (jsonDataTableElement[iColumnCounter + "_column"] === object.A0CALMONTH_T) {
											if (jsonDataTableElement[iColumnCounter + "_columnTEMP"] === object.A0CALMONTH_T) {
												//jsonDataTableElement[iColumnCounter] = object.A00O2TFCW5W1LNFTOKKOEG5UQT;
												//oData Service sometimes return 0, yet 0.00 should be displayed
												if (sCurrentRegion === "EMEA") { //in case of EMEA_NORTh and EMEA_SOUTH we need to sum up both values
													jsonDataTableElement[iColumnCounter] = (parseFloat(jsonDataTableElement[iColumnCounter]) + parseFloat(object.A00O2TFCW5W1LNFTOKKOEG5UQT))
														.toString();
												} else {
													jsonDataTableElement[iColumnCounter] = object.A00O2TFCW5W1LNFTOKKOEG5UQT === "0" ? "0.00" : object.A00O2TFCW5W1LNFTOKKOEG5UQT;
												}
											}
										}
										//bTableElementAlreadyAdded = true;
										return;
									}
								}
							);
							//}
						});
						//no data could be found for the selected filters
						/*
						if (data.results.length === 0) {
							var jsonDataChartElement = {};
							jsonDataChartElement["World"] = 0;
							kpiCasesChart.push(jsonDataChartElement);
							var jsonDataTableElement = {};
							jsonDataTableElement["0_column"] = 0;
							kpiCasesTable.push(jsonDataTableElement);
						}
						*/

						that._onFinishLoadingDataToModel(model, "/casesKPITotalEscalationCosts", kpiCasesChart, iCostReturnedOdataCount);
						that._onFinishLoadingDataToModel(model, "/casesKPITotalEscalationCostsTable", kpiCasesTable, iCostReturnedOdataCount);
						// model.setProperty(
						// 	"/casesKPITotalEscalationCostsTable",
						// 	kpiCasesTable);
						that.oController._setCostChartandTableVisibility();

					},
					error: function (oError, response) {
						that._onFinishLoadingDataToModel(model, "/casesKPITotalEscalationCosts", []);
						that._onFinishLoadingDataToModel(model, "/casesKPITotalEscalationCostsTable", null);
						//	model.setProperty("/casesKPITotalEscalationCostsTable", null);
						that.oController._setCostChartandTableVisibility();
					}
				});

			});

		},
		readAverageEscalationCostsFromBWP: function (model, filtersModel, sRegion, bwp005AverageEscaCost13BWModel,
			bwFilters, settingsModel, iAverageCostReturnedOdataCount, kpiCasesChartAvg, kpiCasesTableAvg, kpiCasesTableIDsAvg) {
			this._onBeginLoadingDataToModel(model, "/casesKPIAverageEscalationCosts");
			this._onBeginLoadingDataToModel(model, "/casesKPIAverageEscalationCostsTable");

			// var aRegions = ["0HIER_NODE:SUP_COUNTRY%20HIERARCHY", "0HIER_NODE:SUP_EMEA W%2FO MEE", "0HIER_NODE:SUP_MEE", "0HIER_NODE:SUP_LAC",
			// 	"0HIER_NODE:SUP_NA",
			// 	"0HIER_NODE:SUP_APJ W%2FO GC", "0HIER_NODE:SUP_GREATER CHINA"
			// ];
			// if (regionOnlyFilterForBWP !== null && regionOnlyFilterForBWP.length === 1 && regionOnlyFilterForBWP[0].oValue1 !==
			// 	"0HIER_NODE:SUP_COUNTRY%20HIERARCHY") {
			// 	aRegions = ["SPECIFIC_REGION_SELECTED"];
			// }

			//because of multiselect of Regions we need to add feed items manually
			if (sRegion !== "" || sRegion !== "World") {
				var oVizFrame = this.oView.byId("vizFrameAverageEscalationCostsRegion");
				if (oVizFrame) {
					oVizFrame.removeFeed(this.oView.byId("valueAxisAverageEscaCostMEE"));
					oVizFrame.removeFeed(this.oView.byId("valueAxisAverageEscaCostEMEA"));
					oVizFrame.removeFeed(this.oView.byId("valueAxisAverageEscaCostNA"));
					oVizFrame.removeFeed(this.oView.byId("valueAxisAverageEscaCostLAC"));
					oVizFrame.removeFeed(this.oView.byId("valueAxisAverageEscaCostAPJ"));
					oVizFrame.removeFeed(this.oView.byId("valueAxisAverageEscaCostGTC"));
					//oVizFrame.removeFeed(this.oView.byId("valueAxisAverageEscaCostWORLD"));

					// if (sRegion === "") {
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisAverageEscaCostMEE"));
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisAverageEscaCostEMEA"));
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisAverageEscaCostNA"));
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisAverageEscaCostLAC"));
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisAverageEscaCostAPJ"));
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisAverageEscaCostGTC"));
					// 	oVizFrame.addFeed(this.oView.byId("valueAxisAverageEscaCostWORLD"));
					// } else {
					sRegion.split(",").forEach(function (region) {
						if (region === "EMEA_NORTH" || region === "EMEA_SOUTH") {
							region = "EMEA";
						}
						oVizFrame.addFeed(this.oView.byId("valueAxisAverageEscaCost" + region));
					}, this);
				}
				//	}
			}

			var that = this;
			if (!sRegion) {
				sRegion = "EMEA,MEE,LAC,NA,APJ,GTC,WORLD";
			}
			sRegion.split(",").forEach(function (region) {

				var regionOnlyFilterForBWP = filtersModel.buildRegionOnlyODataFilter("BWP", region).aFilters;
				var sFilter = filtersModel.buildURLVariableFilterForBWP(regionOnlyFilterForBWP, "CostStandardStructure");

				//	for (var i = 0; i < aRegions.length; i++) {
				///	jQuery.ajax(aRegionFiles[i], { // load the data from a relative URL (the Data.json file in the same directory)
				// var sFinalURLFilter = filtersModel.buildURLVariableFilterForBWP(null, "CostStandardStructure", region); //sFilterPart1 + aRegions[i] + sFilterPart2;
				// if (regionOnlyFilterForBWP !== null && regionOnlyFilterForBWP.length === 1 && regionOnlyFilterForBWP[0].oValue1 !==
				// 	"0HIER_NODE:SUP_COUNTRY%20HIERARCHY") {
				// 	sFinalURLFilter = sFilter;
				// }
				bwp005AverageEscaCost13BWModel.read("/MCASE_COST_ODA_005N(" + sFilter + ")/Results", {
					filters: ((bwFilters.aFilters) ? bwFilters.aFilters.slice(0) : bwFilters), //bwFilters.slice(0),
					urlParameters: "$select=A4MCASEX017CSM_CLMO_T,A00O2TFB0LT47ODEL7PREYAUR4",
					dataType: "json",
					success: function (oData, response) {
						//	if (settingsModel.getProperty("/selectedRegionFilter").toUpperCase() === "WORLD") {
						iAverageCostReturnedOdataCount++;
						//	}
						settingsModel.setProperty("/kpi_AverageEscalationCosts_HasNoData", Boolean(true));
						//set current regio to World as initial value, this value is also needed for Region specific Chart display
						var sCurrentRegion = "World";
						//this is needed to check, to which Region the returned information belongs to
						if (oData.results.length > 0) {
							sCurrentRegion = that._transformBwRegionsfromoDataReturnURI(oData.results[0].__metadata.uri);
						}
						//on DEV system in order to use the dummy json test file
						// var oData = dataModelTotalEscalationCosts.getData();
						// oData.totalEscalationCosts.forEach(function(object) {
						oData.results.forEach(function (object) {
							//check if region filter has been selected, because different chart is shown for BW KPI charts and only one row in the table view for the specific region
							//charts data
							// not needed anymore, because a table with 0.00 values has already been created - it just needs to replace the correct columns var bElementAlreadyAdded = false;
							var jsonDataChartElement = {};
							//not needed anymore, because a table with 0.00 values has already been created - it just needs to replace the correct columns
							kpiCasesChartAvg.forEach(
								function (innerObject) {
									//WORKAROUND if (innerObject["Month"] === object.A4MCASEX017CSM_CLMO_T) {
									if (innerObject["MonthTEMPNumber"] === object.A4MCASEX017CSM_CLMO_T) {
										jsonDataChartElement = innerObject;
										// 			bElementAlreadyAdded = true;
										return;
									}
								}
							);
							//	if (selectedRegion.toUpperCase() !== "WORLD" || selectedRegion.toUpperCase() === object.REGION.toUpperCase()) {

							//WORKAROUND	jsonDataChartElement["Month"] = object.A4MCASEX017CSM_CLMO_T;
							//jsonDataChartElement[sCurrentRegion] = object.A00O2TFB0LT47ODEL7PREYAUR4;
							//oData Service sometimes return 0, yet 0.00 should be displayed
							if (sCurrentRegion === "EMEA") { //in case of EMEA_NORTh and EMEA_SOUTH we need to sum up both values
								jsonDataChartElement[sCurrentRegion] = (parseFloat(jsonDataChartElement[sCurrentRegion]) + parseFloat(object.A00O2TFB0LT47ODEL7PREYAUR4))
									.toString();
							} else {
								jsonDataChartElement[sCurrentRegion] = object.A00O2TFB0LT47ODEL7PREYAUR4 === "0" ? "0.00" : object.A00O2TFB0LT47ODEL7PREYAUR4;
							}
							//we need to add the region specific value also to "WORLD", because the chart in the UI is mapped to this data value for the regional specific view
							// if (settingsModel.getProperty("/selectedRegionFilter").toUpperCase() !== "WORLD") {
							// 	jsonDataChartElement["World"] = object.A00O2TFB0LT47ODEL7PREYAUR4;
							// }
							//Maybe not needed anymore, because a table with 0.00 values has already been created - it just needs to replace the correct columns
							// if (!bElementAlreadyAdded) {
							// 	kpiCasesChartAvg.push(jsonDataChartElement);
							// }
							//table data
							//check if region filter has been selected, because different chart is shown for BW KPI charts and only one row in the table view for the specific region
							// if (settingsModel.getProperty("/selectedRegionFilter").toUpperCase() === "WORLD" || settingsModel.getProperty(
							// 		"/selectedRegionFilter").toUpperCase() === sCurrentRegion.toUpperCase()) {
							//var id = 0;
							//var jsonDataTableElementId = {};
							var jsonDataTableElement = {};
							//var bTableElementAlreadyAdded = false;
							kpiCasesTableAvg.forEach(
								function (innerObject) {
									if (innerObject["type"] === sCurrentRegion) {
										jsonDataTableElement = innerObject;
										for (var iColumnCounter = 12; iColumnCounter >= 0; iColumnCounter--) {
											//WORKAROUND if (jsonDataTableElement[iColumnCounter + "_column"] === object.A4MCASEX017CSM_CLMO_T) {
											if (jsonDataTableElement[iColumnCounter + "_columnTEMP"] === object.A4MCASEX017CSM_CLMO_T) {
												//jsonDataTableElement[iColumnCounter] = object.A00O2TFB0LT47ODEL7PREYAUR4;
												//oData Service sometimes return 0, yet 0.00 should be displayed
												if (sCurrentRegion === "EMEA") { //in case of EMEA_NORTh and EMEA_SOUTH we need to sum up both values
													jsonDataTableElement[iColumnCounter] = (parseFloat(jsonDataTableElement[iColumnCounter]) + parseFloat(object.A00O2TFB0LT47ODEL7PREYAUR4))
														.toString();
												} else {
													jsonDataTableElement[iColumnCounter] = object.A00O2TFB0LT47ODEL7PREYAUR4 === "0" ? "0.00" : object.A00O2TFB0LT47ODEL7PREYAUR4;
												}
											}
										}
										//bTableElementAlreadyAdded = true;
										return;
									}
								}
							);
							//	}
						});

						that._onFinishLoadingDataToModel(model, "/casesKPIAverageEscalationCosts", kpiCasesChartAvg,
							iAverageCostReturnedOdataCount);
						that._onFinishLoadingDataToModel(model, "/casesKPIAverageEscalationCostsTable", kpiCasesTableAvg,
							iAverageCostReturnedOdataCount);
						//	model.setProperty("/casesKPIAverageEscalationCostsTable",kpiCasesTableAvg);
						that.oController._setCostChartandTableVisibility();
					},
					error: function (oError, response) {
						that._onFinishLoadingDataToModel(model, "/casesKPIAverageEscalationCosts", []);
						that._onFinishLoadingDataToModel(model, "/casesKPIAverageEscalationCostsTable", null);
						//model.setProperty("/casesKPIAverageEscalationCostsTable", null);
						that.oController._setCostChartandTableVisibility();
					}
				});
			});
		},
		//////////////////
		//Escalation Cost Overview
		/////////////////
		readEscalationCostsOverviewFromBWP: function () { //model, filtersModel, bwp006EscaCostOverviewBWModel, settingsModel,iEscalationsCostOverviewReturnedOdataCount, oResourceBundle, kpiCasesOverviewCostsTable
			var DebugMode = false,
				model = this.oController.getOwnerComponent().getModel("KPICasesBW"),
				bwp006EscaCostOverviewBWModel = this.oController.getOwnerComponent().getModel("bwp006CostOverviewBWModel"),
				filtersModel = this.oController.getOwnerComponent().getModel("bwFilterModel"),
				settingsModel = this.oController.getOwnerComponent().getModel("settings"),
				oResourceBundle = this.getResourceBundle(),
				kpiCasesOverviewCostsTable = this.initializeBWPOverviewCostTableArray(oResourceBundle),
				iEscalationsCostOverviewReturnedOdataCount = 0,
				oAppDepModel = this.oController.getOwnerComponent().getModel("appDepModel"),
				oSubModel = this.oController.getOwnerComponent().getModel("subModel");



			this._onBeginLoadingDataToModel(model, "/casesKPIEscalationOverviewCostsTable");
			var that = this;
			//set initial Data, all filled with 0.00
			model.setProperty("/casesKPIEscalationOverviewCostsTable/data",
				kpiCasesOverviewCostsTable);

			//regions need to be configured separately, because it's a different region structure
			//ESCA_WW	0HIER_NODE:ESCA_WW
			//EMEA		0HIER_NODE:ESCA_EME05
			//LATAM/LAC	0HIER_NODE:ESCA_LA
			//NA		0HIER_NODE:ESCA_NA
			//APJ		0HIER_NODE:ESCA_APA05
			//ESCA_PREP	0HIER_NODE: ESCA_PREPR
			//ESC_INTPR	0HIER_NODE:ESC_INTPR

			var aRegions = ["0HIER_NODE:ESCA_WW"];

			var sFinalURLFilter = filtersModel.buildURLVariableFilterForBWP(null, "CostOverviewStructure", aRegions[0]);
			//example
			///MCASE_COST_ODA_006N_SRV/MCASE_COST_ODA_006N(MCASE_CMS_MY_0001='EUR',MCASE_NMM_OY_0002='0HIER_NODE:ESCA_WW')/Results?$select=A0CALYEAR,A4MCASEX0210CALQUART1_T,A00O2TFB0LT45Y9YRJVIU291OU_F
			//A0CALYEAR  Calendar Year, A4MCASEX0210CALQUART1_T Fiscal Quarter Number, A00O2TFB0LT45Y9YRJVIU291OU Actual Cost 

			var currentDate = new Date();
			var currentYear = currentDate.getFullYear();
			var sFilterForBWP = "&$filter=A0CALYEAR%20eq%20%27" + currentYear + "%27%20or%20A0CALYEAR%20eq%20%27" + (currentYear - 1) + "%27%20or%20A0CALYEAR%20eq%20%27" + (currentYear - 2) + "%27%20or%20A0CALYEAR%20eq%20%27" + (currentYear - 3) + "%27";
			var sSelectForBWP = "$select=A0CALYEAR,A4MCASEX0210CALQUART1_T,A00O2TFB0LT45Y9YRJVIU291OU,A4MCASEX021PUSER3_T";
			var urlParametersForBWP = sSelectForBWP + sFilterForBWP;

			var bwp006EscaCostOverviewPromise = new Promise(function (resolve, reject) {
				if (DebugMode) {
					// AJAX call for Debug Mode
					$.ajax({
						url: "./json/mcs/BWTCostData.json",
						type: "GET",
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});

				} else {
					// World Wide Data
					bwp006EscaCostOverviewBWModel.read("/MCASE_COST_ODA_006N(" + sFinalURLFilter + ")/Results", {
						urlParameters: urlParametersForBWP,
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});
				}
			});

			var bwp006EscaCostOverviewPreprPromise = new Promise(function (resolve, reject) {
				var sFinalURLFilterPrepr = filtersModel.buildURLVariableFilterForBWP(null, "CostOverviewStructure", "0HIER_NODE:ESCA_PREPR");

				if (DebugMode) {
					// AJAX call for Debug Mode
					$.ajax({
						url: "./json/mcs/BWTCostDataPrepr.json",
						type: "GET",
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});

				} else {
					// PREPR Data
					bwp006EscaCostOverviewBWModel.read("/MCASE_COST_ODA_006N(" + sFinalURLFilterPrepr + ")/Results", {
						urlParameters: urlParametersForBWP,
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});
				}

			});

			var bwp006EscaCostOverviewIntprPromise = new Promise(function (resolve, reject) {
				var sFinalURLFilterIntpr = filtersModel.buildURLVariableFilterForBWP(null, "CostOverviewStructure", "0HIER_NODE:ESC_INTPR");

				if (DebugMode) {
					// AJAX call for Debug Mode
					$.ajax({
						url: "./json/mcs/BWTCostDataIntpr.json",
						type: "GET",
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});

				} else {

					// INTPR Data
					bwp006EscaCostOverviewBWModel.read("/MCASE_COST_ODA_006N(" + sFinalURLFilterIntpr + ")/Results", {
						urlParameters: urlParametersForBWP,
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});
				}

			});

			//BDM
			var bwp006EscaCostOverviewBDMPromise1 = new Promise(function (resolve, reject) {
				var sFinalURLFilterIntpr = filtersModel.buildURLVariableFilterForBWP(null, "CostOverviewStructure", "0HIER_NODE:ESC_MCSE");

				if (DebugMode) {
					// AJAX call for Debug Mode
					$.ajax({
						url: "./json/mcs/BWTCostDataESC_MCSE.json",
						type: "GET",
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});
				} else {
					bwp006EscaCostOverviewBWModel.read("/MCASE_COST_ODA_006N(" + sFinalURLFilterIntpr + ")/Results", {
						urlParameters: urlParametersForBWP,
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});
				}
			});

			var bwp006EscaCostOverviewBDMPromise2 = new Promise(function (resolve, reject) {
				var sFinalURLFilterIntpr = filtersModel.buildURLVariableFilterForBWP(null, "CostOverviewStructure", "0HIER_NODE:ESC_MCSL2");

				if (DebugMode) {
					// AJAX call for Debug Mode
					$.ajax({
						url: "./json/mcs/BWTCostDataESC_MCSL2.json",
						type: "GET",
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});
				} else {
					bwp006EscaCostOverviewBWModel.read("/MCASE_COST_ODA_006N(" + sFinalURLFilterIntpr + ")/Results", {
						urlParameters: urlParametersForBWP,
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});
				}
			});

			var bwp006EscaCostOverviewBDMPromise3 = new Promise(function (resolve, reject) {
				var sFinalURLFilterIntpr = filtersModel.buildURLVariableFilterForBWP(null, "CostOverviewStructure", "0HIER_NODE:ESC_MCSN");

				if (DebugMode) {
					// AJAX call for Debug Mode
					$.ajax({
						url: "./json/mcs/BWTCostDataESC_MCSN.json",
						type: "GET",
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});
				} else {
					bwp006EscaCostOverviewBWModel.read("/MCASE_COST_ODA_006N(" + sFinalURLFilterIntpr + ")/Results", {
						urlParameters: urlParametersForBWP,
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});
				}
			});

			var bwp006EscaCostOverviewBDMPromise4 = new Promise(function (resolve, reject) {
				var sFinalURLFilterIntpr = filtersModel.buildURLVariableFilterForBWP(null, "CostOverviewStructure", "0HIER_NODE:ESC_MCSA");

				if (DebugMode) {
					// AJAX call for Debug Mode
					$.ajax({
						url: "./json/mcs/BWTCostDataESC_MCSA.json",
						type: "GET",
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});
				} else {
					bwp006EscaCostOverviewBWModel.read("/MCASE_COST_ODA_006N(" + sFinalURLFilterIntpr + ")/Results", {
						urlParameters: urlParametersForBWP,
						dataType: "json",
						success: function (oData, response) {
							resolve(oData);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});
				}
			});


			// Case Set Data
			var oCaseSetPromise = new Promise(function (resolve, reject) {
				/* First Approach
					if (DebugMode) {
						$.ajax({
							url: "./json/mcs/CaseSetData.json",
							type: "GET",
							dataType: "json",
							success: function (oData, response) {
								resolve(oData);
							},
							error: function (oError, response) {
								reject(oError);
							}
						});
					} else {
						oAppDepModel.read("/CaseSet", {
							filters: [
								new sap.ui.model.Filter("CaseType", sap.ui.model.FilterOperator.EQ, "ZS01"),
								new sap.ui.model.Filter("CreateTime", sap.ui.model.FilterOperator.BT, new Date(lastSixYears[5], 0, 1), new Date(currentYear, 11, 31))
							],
							urlParameters: {
								"$select": "CaseID,SalesOrg,CreateTime"
							},
							success: function (oCaseData) {
								resolve(oCaseData);
							},
							error: function (error) {
								reject(error);
							}
						});
					}
					*/

				if (DebugMode) {
					$.ajax({
						url: "./json/mcs/CaseSetDataFromMCCToolsMCSCase.json",
						type: "GET",
						dataType: "json",
						success: function (data, response) {
							var aData = [];
							if (data.queryResults && data.queryResults.CL_MCC_TOOLS_MCS_CASE && data.queryResults.CL_MCC_TOOLS_MCS_CASE.rows.length > 0) {
								var aRows = data.queryResults.CL_MCC_TOOLS_MCS_CASE.rows;
								aRows.forEach(function (row) {
									var newData = {
										CaseID: row.Case_ID.key,
										SalesOrg: "O " + row.CRM_Sales_Organization.key,
										CRM_Sales_Organization: row.CRM_Sales_Organization.key,
										CRM_Service_Organization: row.CRM_Service_Organization.key,
										Creation_Date_Year_YYYY: row.Creation_Date_Year_YYYY.key,
										Case_Status: row.Case_Status
									};
									aData.push(newData);
								});
							}
							var results = { results: aData };
							resolve(results);
						},
						error: function (oError, response) {
							reject(oError);
						}
					});
				} else {

					var aYears = [];
					var iThisYear = new Date().getFullYear();
					for (var i = 0; i <= 5; i++) {
						aYears.push((iThisYear - i).toString());
					}

					$.ajax({
						method: "POST",
						headers: {
							"AppIdentifier": "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
						},
						url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/c4s/api/queries/v3?user-propagation=true",
						data: JSON.stringify([{
							"queryIdentifier": "CL_MCC_TOOLS_MCS_CASE",
							"elementList": [
								"Case_ID", "Case_Status", "Case_Process_Type", "Creation_Date_Year_YYYY", "CRM_Sales_Organization", "CRM_Service_Organization"
							],
							"filters": [{
								"filters": [{
									"operand1": {
										"elementIdentifier": "Case_Process_Type"
									},
									"operand2": {
										"values": [
											"ZSPRCTYP01"
										]
									},
									"operator": "EQ"
								}, {
									"operand1": {
										"elementIdentifier": "Case_Status"
									},
									"operand2": {
										"values": [
											"20", "30", "40", "98"
										]
									},
									"operator": "EQ"
								}, {
									"operand1": {
										"elementIdentifier": "Case_Type"
									},
									"operand2": {
										"values": [
											"ZS01"
										]
									},
									"operator": "EQ"
								}, {
									"operand1": {
										"elementIdentifier": "Creation_Date_Year_YYYY"
									},
									"operand2": {
										"values": aYears.reverse()
									},
									"operator": "EQ"
								}],
								"conjunctionOperator": "AND"
							}]
						}]),
						contentType: "application/json",
						success: function (data, response) {
							var aData = [];
							if (data.queryResults && data.queryResults.CL_MCC_TOOLS_MCS_CASE && data.queryResults.CL_MCC_TOOLS_MCS_CASE.rows.length > 0) {
								var aRows = data.queryResults.CL_MCC_TOOLS_MCS_CASE.rows;
								aRows.forEach(function (row) {
									//Only using the the CaseID, SalesOrg + Adapation to SalesOrg Table + Year + Case_Status
									var newData = {
										CaseID: row.Case_ID.key,
										SalesOrg: "O " + row.CRM_Sales_Organization.key,
										CRM_Sales_Organization: row.CRM_Sales_Organization.key,
										CRM_Service_Organization: row.CRM_Service_Organization.key,
										Creation_Date_Year_YYYY: row.Creation_Date_Year_YYYY.key,
										Case_Status: row.Case_Status
									};
									aData.push(newData);
								});
							}
							var results = { results: aData };
							resolve(results);
						},
						error: function (oError, response) {
							reject(oError);
						}
					})
				}
			});


			// Sales Org Mapping Data
			var oSalesOrgPromise = new Promise(function (resolve, reject) {
				oSubModel.read("/SalesOrgMapping", {
					urlParameters: {
						"$select": "SORGID1, MCCRegion"
					},
					success: function (oSalesOrgData) {
						resolve(oSalesOrgData);
					},
					error: function (error) {
						reject(error);
					}
				});
			});
			iEscalationsCostOverviewReturnedOdataCount++;

			// Waiting for all promises to resolve
			Promise.all([bwp006EscaCostOverviewPromise, bwp006EscaCostOverviewPreprPromise, bwp006EscaCostOverviewIntprPromise, bwp006EscaCostOverviewBDMPromise1, bwp006EscaCostOverviewBDMPromise2, bwp006EscaCostOverviewBDMPromise3, bwp006EscaCostOverviewBDMPromise4, oCaseSetPromise, oSalesOrgPromise])
				.then(function (values) {
					// All promises resolved successfully, values contains the data from all promises
					var bwp006EscaCostOverviewData = values[0];
					var bwp006EscaCostOverviewPreprData = values[1];
					var bwp006EscaCostOverviewIntprData = values[2];
					var bwp006EscaCostOverviewBDMData1 = values[3];
					var bwp006EscaCostOverviewBDMData2 = values[4];
					var bwp006EscaCostOverviewBDMData3 = values[5];
					var bwp006EscaCostOverviewBDMData4 = values[6];
					var oCaseData = values[7];
					var oSalesOrgData = values[8];

					// Filtering out entries where "A4MCASEX021PUSER3_T" is not a number
					bwp006EscaCostOverviewData = bwp006EscaCostOverviewData.results.filter(function (entry) {
						return !isNaN(parseFloat(entry.A4MCASEX021PUSER3_T));
					});

					//Remove SUM Entries for Years
					/*	bwp006EscaCostOverviewData = bwp006EscaCostOverviewData.results.filter(function (entry) {
							return entry.A4MCASEX0210CALQUART1_T === "Q1" ||
								entry.A4MCASEX0210CALQUART1_T === "Q2" ||
								entry.A4MCASEX0210CALQUART1_T === "Q3" ||
								entry.A4MCASEX0210CALQUART1_T === "Q4";
						}); */
					//bwp006EscaCostOverviewData = bwp006EscaCostOverviewData.results;

					// Merging SalesOrg from CaseSet to BW Data based on CaseID
					bwp006EscaCostOverviewData.forEach(function (bwEntry) {
						var matchingCase = oCaseData.results.find(function (caseEntry) {
							return caseEntry.CaseID === bwEntry.A4MCASEX021PUSER3_T;
						});
						if (matchingCase) {
							bwEntry.SalesOrg = matchingCase.SalesOrg;
						}
					});

					// Second merging: Adding MCCRegion based on SalesOrg from oSalesOrgData
					bwp006EscaCostOverviewData.forEach(function (bwEntry) {
						var matchingSalesOrg = oSalesOrgData.results.find(function (salesOrgEntry) {
							return salesOrgEntry.SORGID1 === bwEntry.SalesOrg;
						});
						if (matchingSalesOrg) {
							bwEntry.MCCRegion = matchingSalesOrg.MCCRegion;
						} else {
							// If no matching SalesOrg found, set MCCRegion to "Other"
							bwEntry.MCCRegion = "Others";
						}
					});

					// Third merge: Adding data from bwp006EscaCostOverviewPreprData
					bwp006EscaCostOverviewPreprData.results.forEach(function (preprEntry) {
						var isNumber = !isNaN(parseFloat(preprEntry.A4MCASEX021PUSER3_T));
						if (isNumber) {
							// Check if the Case already exists in bwp006EscaCostOverviewData
							var duplicateCaseIndex = bwp006EscaCostOverviewData.findIndex(function (bwEntry) {
								return bwEntry.A4MCASEX021PUSER3_T === preprEntry.A4MCASEX021PUSER3_T;
							});
							if (duplicateCaseIndex !== -1) {
								bwp006EscaCostOverviewData.splice(duplicateCaseIndex, 1);
							}
							var bwEntry = {
								A0CALYEAR: preprEntry.A0CALYEAR,
								A4MCASEX0210CALQUART1_T: preprEntry.A4MCASEX0210CALQUART1_T,
								A4MCASEX021PUSER3_T: preprEntry.A4MCASEX021PUSER3_T,
								A00O2TFB0LT45Y9YRJVIU291OU: preprEntry.A00O2TFB0LT45Y9YRJVIU291OU,
								MCCRegion: "Product Escalations" // MCCRegion set to "Product Escalations" for prepr data
							};
							bwp006EscaCostOverviewData.push(bwEntry);
						} else {
							var bwEntry = {
								A0CALYEAR: preprEntry.A0CALYEAR,
								A4MCASEX0210CALQUART1_T: preprEntry.A4MCASEX0210CALQUART1_T,
								A00O2TFB0LT45Y9YRJVIU291OU: preprEntry.A00O2TFB0LT45Y9YRJVIU291OU,
								MCCRegion: "Product Escalations" // MCCRegion set to "Product Escalations" for prepr data
							};
							bwp006EscaCostOverviewData.push(bwEntry);
						}
					});

					// Fourth merge: Adding data from bwp006EscaCostOverviewIntprData
					bwp006EscaCostOverviewIntprData.results.forEach(function (intprEntry) {
						var isNumber = !isNaN(parseFloat(intprEntry.A4MCASEX021PUSER3_T));
						if (isNumber) {
							// Check if the Case already exists in bwp006EscaCostOverviewData
							var duplicateCaseIndex = bwp006EscaCostOverviewData.findIndex(function (bwEntry) {
								return bwEntry.A4MCASEX021PUSER3_T === intprEntry.A4MCASEX021PUSER3_T;
							});
							if (duplicateCaseIndex !== -1) {
								bwp006EscaCostOverviewData.splice(duplicateCaseIndex, 1);
							}
							var bwEntry = {
								A0CALYEAR: intprEntry.A0CALYEAR,
								A4MCASEX0210CALQUART1_T: intprEntry.A4MCASEX0210CALQUART1_T,
								A4MCASEX021PUSER3_T: intprEntry.A4MCASEX021PUSER3_T,
								A00O2TFB0LT45Y9YRJVIU291OU: intprEntry.A00O2TFB0LT45Y9YRJVIU291OU,
								MCCRegion: "Product Escalations" // MCCRegion set to "Product Escalations" for intpr data
							};
							bwp006EscaCostOverviewData.push(bwEntry);
						} else {
							var bwEntry = {
								A0CALYEAR: intprEntry.A0CALYEAR,
								A4MCASEX0210CALQUART1_T: intprEntry.A4MCASEX0210CALQUART1_T,
								A00O2TFB0LT45Y9YRJVIU291OU: intprEntry.A00O2TFB0LT45Y9YRJVIU291OU,
								MCCRegion: "Product Escalations" // MCCRegion set to "Product Escalations" for intpr data
							};
							bwp006EscaCostOverviewData.push(bwEntry);
						}
					});

					// Merging for BDM Data
					bwp006EscaCostOverviewBDMData1.results.forEach(function (BDMEntry) {
						var bwEntry = {
							A0CALYEAR: BDMEntry.A0CALYEAR,
							A4MCASEX0210CALQUART1_T: BDMEntry.A4MCASEX0210CALQUART1_T,
							A00O2TFB0LT45Y9YRJVIU291OU: BDMEntry.A00O2TFB0LT45Y9YRJVIU291OU,
							MCCRegion: "Business Downs*" // MCCRegion set to "Business Downs" for BDM Data, since it can not be sorted to regions
						};
						bwp006EscaCostOverviewData.push(bwEntry);
					});

					bwp006EscaCostOverviewBDMData2.results.forEach(function (BDMEntry) {
						var bwEntry = {
							A0CALYEAR: BDMEntry.A0CALYEAR,
							A4MCASEX0210CALQUART1_T: BDMEntry.A4MCASEX0210CALQUART1_T,
							A00O2TFB0LT45Y9YRJVIU291OU: BDMEntry.A00O2TFB0LT45Y9YRJVIU291OU,
							MCCRegion: "Business Downs*" // MCCRegion set to "Business Downs" for BDM Data, since it can not be sorted to regions
						};
						bwp006EscaCostOverviewData.push(bwEntry);
					});

					bwp006EscaCostOverviewBDMData3.results.forEach(function (BDMEntry) {
						var bwEntry = {
							A0CALYEAR: BDMEntry.A0CALYEAR,
							A4MCASEX0210CALQUART1_T: BDMEntry.A4MCASEX0210CALQUART1_T,
							A00O2TFB0LT45Y9YRJVIU291OU: BDMEntry.A00O2TFB0LT45Y9YRJVIU291OU,
							MCCRegion: "Business Downs*" // MCCRegion set to "Business Downs" for BDM Data, since it can not be sorted to regions
						};
						bwp006EscaCostOverviewData.push(bwEntry);
					});
					bwp006EscaCostOverviewBDMData4.results.forEach(function (BDMEntry) {
						var bwEntry = {
							A0CALYEAR: BDMEntry.A0CALYEAR,
							A4MCASEX0210CALQUART1_T: BDMEntry.A4MCASEX0210CALQUART1_T,
							A00O2TFB0LT45Y9YRJVIU291OU: BDMEntry.A00O2TFB0LT45Y9YRJVIU291OU,
							MCCRegion: "Business Downs*" // MCCRegion set to "Business Downs" for BDM Data, since it can not be sorted to regions
						};
						bwp006EscaCostOverviewData.push(bwEntry);
					});

					bwp006EscaCostOverviewData.forEach(function (object) {
						// Find Year or Region in kpiCasesOverviewCostsTable
						var yearOrRegion = object.A0CALYEAR + " Global";
						var yearElement = kpiCasesOverviewCostsTable.elements.find(function (element) {
							return element.yearOrRegion === yearOrRegion;
						});

						if (yearElement) {
							// Finde das entsprechende Regionselement in kpiCasesOverviewCostsTable
							var regionElement = yearElement.elements.find(function (element) {
								return element.yearOrRegion === object.MCCRegion;
							});

							if (regionElement) {
								// Sum up values from bwp006EscaCostOverviewData to corresponding parts in kpiCasesOverviewCostsTable
								switch (object.A4MCASEX0210CALQUART1_T) {
									case "Q1":
										regionElement.q1 += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										regionElement.ytd += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										yearElement.q1 += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10); // Add Value to Q1
										yearElement.ytd += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10); // Add Value also to YTD
										break;
									case "Q2":
										regionElement.q2 += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										regionElement.ytd += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										yearElement.q2 += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										yearElement.ytd += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										break;
									case "Q3":
										regionElement.q3 += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										regionElement.ytd += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										yearElement.q3 += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										yearElement.ytd += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										break;
									case "Q4":
										regionElement.q4 += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										regionElement.ytd += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										yearElement.q4 += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										yearElement.ytd += parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
										break;
									default:
										break;
								}
							}
						}
					});

					// Nachdem alle Zuweisungen erfolgt sind, entferne die "Others"-Zeilen unter den jeweiligen Jahren, wenn alle ihre Werte 0 sind
					kpiCasesOverviewCostsTable.elements.forEach(function (yearElement) {
						yearElement.elements = yearElement.elements.filter(function (regionElement) {
							if (regionElement.yearOrRegion === "Others") {
								return regionElement.q1 !== 0 || regionElement.q2 !== 0 || regionElement.q3 !== 0 || regionElement.q4 !== 0 || regionElement.ytd !== 0;
							} else {
								return true;
							}
						});
					});

					// Nachdem alle Zuweisungen erfolgt sind, entferne die "BDM"-Zeilen unter den jeweiligen Jahren, wenn alle ihre Werte 0 sind
					kpiCasesOverviewCostsTable.elements.forEach(function (yearElement) {
						yearElement.elements = yearElement.elements.filter(function (regionElement) {
							if (regionElement.yearOrRegion === "Business Downs*") {
								return regionElement.q1 !== 0 || regionElement.q2 !== 0 || regionElement.q3 !== 0 || regionElement.q4 !== 0 || regionElement.ytd !== 0;
							} else {
								return true;
							}
						});
					});

					//finalDataSet.elements = aResult;
					that._onFinishLoadingDataToModel(model, "/casesKPIEscalationOverviewCostsTable", kpiCasesOverviewCostsTable,
						iEscalationsCostOverviewReturnedOdataCount);
				})
				.catch(function (error) {
					that._onFinishLoadingDataToModel(model, "/casesKPIEscalationOverviewCostsTable", []);
					model.setProperty("/casesKPIEscalationOverviewCostsTable", null);
				});


		},


		readEscalationCostsOverviewFromBWP____OLD: function () { //model, filtersModel, bwp006EscaCostOverviewBWModel, settingsModel,iEscalationsCostOverviewReturnedOdataCount, oResourceBundle, kpiCasesOverviewCostsTable
			var model = this.oController.getOwnerComponent().getModel("KPICasesBW"),
				bwp006EscaCostOverviewBWModel = this.oController.getOwnerComponent().getModel("bwp006CostOverviewBWModel"),
				filtersModel = this.oController.getOwnerComponent().getModel("bwFilterModel"),
				settingsModel = this.oController.getOwnerComponent().getModel("settings"),
				oResourceBundle = this.getResourceBundle(),
				kpiCasesOverviewCostsTable = this.initializeBWPOverviewCostTableArray(oResourceBundle),
				iEscalationsCostOverviewReturnedOdataCount = 0;
			this._onBeginLoadingDataToModel(model, "/casesKPIEscalationOverviewCostsTable");
			var that = this;
			//set initial Data, all filled with 0.00
			model.setProperty("/casesKPIEscalationOverviewCostsTable/data",
				kpiCasesOverviewCostsTable);

			//regions need to be configured separately, because it's a different region structure
			//ESCA_WW	0HIER_NODE:ESCA_WW
			//EMEA		0HIER_NODE:ESCA_EME05
			//LATAM/LAC	0HIER_NODE:ESCA_LA
			//NA		0HIER_NODE:ESCA_NA
			//APJ		0HIER_NODE:ESCA_APA05
			//ESCA_PREP	0HIER_NODE: ESCA_PREPR
			//ESC_INTPR	0HIER_NODE:ESC_INTPR

			var aRegions = ["0HIER_NODE:ESCA_WW", "0HIER_NODE:ESCA_EME05", "0HIER_NODE:ESCA_LA", "0HIER_NODE:ESCA_NA",
				"0HIER_NODE:ESCA_APA05",
				"0HIER_NODE:ESCA_PREPR", "0HIER_NODE:ESC_INTPR"
			];
			//get this year plus last six years
			var thisYearDate = new Date();
			thisYearDate.setHours(0, 0, 0, 0);
			//Get time of last 5 years
			//var last5Years = new Date(thisYearDate.setFullYear(thisYearDate.getFullYear() - 1)).getTime();
			//Get time of last 10 years
			var aYears = [thisYearDate.getFullYear()];
			for (var t = 0; t < 5; t++) {
				aYears.push(new Date(thisYearDate.setFullYear(thisYearDate.getFullYear() - 1)).getFullYear());
			}
			//var finalDataSet = {};
			//var aResult = [];
			//for (var k = 0; k < aYears.length; k++) {
			for (var iY = 0; iY < aRegions.length; iY++) {
				var sFinalURLFilter = filtersModel.buildURLVariableFilterForBWP(null, "CostOverviewStructure", aRegions[iY]);
				//example
				///MCASE_COST_ODA_006N_SRV/MCASE_COST_ODA_006N(MCASE_CMS_MY_0001='EUR',MCASE_NMM_OY_0002='0HIER_NODE:ESCA_WW')/Results?$select=A0CALYEAR,A4MCASEX0210CALQUART1_T,A00O2TFB0LT45Y9YRJVIU291OU_F
				//A0CALYEAR  Calendar Year, A4MCASEX0210CALQUART1_T Fiscal Quarter Number, A00O2TFB0LT45Y9YRJVIU291OU Actual Cost 
				bwp006EscaCostOverviewBWModel.read("/MCASE_COST_ODA_006N(" + sFinalURLFilter + ")/Results", {
					urlParameters: "$select=A0CALYEAR,A4MCASEX0210CALQUART1_T,A00O2TFB0LT45Y9YRJVIU291OU",
					dataType: "json",
					success: function (oData, response) {
						// if (settingsModel.getProperty("/selectedRegionFilter").toUpperCase() === "WORLD") {
						// 	iAverageCostReturnedOdataCount++;
						// }
						//set current regio to World as initial value, this value is also needed for Region specific Chart display
						that.sCurrentRegion = oResourceBundle.getText("esca_ww");
						//this is needed to check, to which Region the returned information belongs to
						if (oData.results.length > 0) {
							that.sCurrentRegion = that._transformBwRegionsfromoDataReturnURI(oData.results[0].__metadata.uri, true, oResourceBundle);
						}
						//counter to check if all oData calls have already been returned -->  used for busy indicator
						iEscalationsCostOverviewReturnedOdataCount++;
						if (that.sCurrentRegion === oResourceBundle.getText("esca_ww")) {
							oData.results.forEach(function (object) {
								kpiCasesOverviewCostsTable.elements.forEach(function (innerObject) {
									//if (object.A4MCASEX0210CALQUART1_T === "") {
									if (innerObject.yearOrRegion.startsWith(object.A0CALYEAR)) {
										switch (object.A4MCASEX0210CALQUART1_T) {
											case "Q1":
												innerObject.q1 = object.A00O2TFB0LT45Y9YRJVIU291OU;
												return;
											case "Q2":
												innerObject.q2 = object.A00O2TFB0LT45Y9YRJVIU291OU;
												return;
											case "Q3":
												innerObject.q3 = object.A00O2TFB0LT45Y9YRJVIU291OU;
												return;
											case "Q4":
												innerObject.q4 = object.A00O2TFB0LT45Y9YRJVIU291OU;
												return;
											default:
												innerObject.ytd = object.A00O2TFB0LT45Y9YRJVIU291OU;
												return;
										}
									}
									//	}
								});

							});
						} else {
							oData.results.forEach(function (object) {
								kpiCasesOverviewCostsTable.elements.forEach(function (innerObject) {
									//if (object.A4MCASEX0210CALQUART1_T === "") {
									if (innerObject.yearOrRegion.startsWith(object.A0CALYEAR)) {
										innerObject.elements.forEach(function (innerObjectL2) {
											//Regions "esca_prepr" and"esca_intpr" should be shown as one element in the chart-->   Product Escalations
											//therefore they need to be summed up
											if (that.sCurrentRegion === oResourceBundle.getText("esca_prepr_intpr")) {
												if (innerObjectL2.yearOrRegion.startsWith(this.sCurrentRegion)) {
													switch (object.A4MCASEX0210CALQUART1_T) {
														case "Q1":
															innerObjectL2.q1 = parseInt(innerObjectL2.q1, 10) + parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
															return;
														case "Q2":
															innerObjectL2.q2 = parseInt(innerObjectL2.q2, 10) + parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
															return;
														case "Q3":
															innerObjectL2.q3 = parseInt(innerObjectL2.q3, 10) + parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
															return;
														case "Q4":
															innerObjectL2.q4 = parseInt(innerObjectL2.q4, 10) + parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
															return;
														default:
															innerObjectL2.ytd = parseInt(innerObjectL2.ytd, 10) + parseInt(object.A00O2TFB0LT45Y9YRJVIU291OU, 10);
															return;
													}
												}
											} else {
												if (innerObjectL2.yearOrRegion.startsWith(this.sCurrentRegion)) {
													switch (object.A4MCASEX0210CALQUART1_T) {
														case "Q1":
															innerObjectL2.q1 = object.A00O2TFB0LT45Y9YRJVIU291OU;
															return;
														case "Q2":
															innerObjectL2.q2 = object.A00O2TFB0LT45Y9YRJVIU291OU;
															return;
														case "Q3":
															innerObjectL2.q3 = object.A00O2TFB0LT45Y9YRJVIU291OU;
															return;
														case "Q4":
															innerObjectL2.q4 = object.A00O2TFB0LT45Y9YRJVIU291OU;
															return;
														default:
															innerObjectL2.ytd = object.A00O2TFB0LT45Y9YRJVIU291OU;
															return;
													}
												}
											}
										}, that);
									}
								}, that);
							}, that);
						}
						//finalDataSet.elements = aResult;
						that._onFinishLoadingDataToModel(model, "/casesKPIEscalationOverviewCostsTable", kpiCasesOverviewCostsTable,
							iEscalationsCostOverviewReturnedOdataCount);

					},
					error: function (oError, response) {
						that._onFinishLoadingDataToModel(model, "/casesKPIEscalationOverviewCostsTable", []);
						model.setProperty("/casesKPIEscalationOverviewCostsTable", null);
					}
				});
			}

		},

		initializeBWPChartArrays: function (sArrayType, oFilterModel, settingsModel) {
			var monthNames = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
			var aResult = [];
			if (sArrayType === "kpiCasesChart") {
				for (var i = 12; i > 0; i--) {
					var oDate = new Date();
					oDate.setDate(1);
					oDate.setMonth(oDate.getMonth() - i);
					var oJsonDataElement = {};
					oJsonDataElement.Month = monthNames[oDate.getMonth()] + " " + oDate.getFullYear();
					oJsonDataElement.MonthTEMPNumber = ("0" + (oDate.getMonth() + 1)).slice(-2) + "." + oDate.getFullYear();
					oJsonDataElement.APJ = "0.00";
					oJsonDataElement.EMEA = "0.00";
					oJsonDataElement.GTC = "0.00";
					oJsonDataElement.LAC = "0.00";
					oJsonDataElement.MEE = "0.00";
					oJsonDataElement.NA = "0.00";
					oJsonDataElement.World = "0.00";
					aResult.push(oJsonDataElement);
				}
				return aResult;
			} else if (sArrayType === "kpiCasesTableChart") {
				var aRegions = [];

				var sRegion = oFilterModel.getProperty("/region"); //this.getRegionFilterModel();
				var bEMEAAlreadyAdded = false;
				if (sRegion !== "") {
					sRegion.split(",").forEach(function (region) {
						if (region.startsWith("EMEA")) {
							if (!bEMEAAlreadyAdded) {
								aRegions.push("EMEA");
							}
							bEMEAAlreadyAdded = true;
						} else {
							aRegions.push(region);
						}
					});
				} else {
					aRegions = ["EMEA", "MEE", "LAC", "NA", "APJ", "GTC", "World"];
				}

				//if (settingsModel.getProperty("/selectedRegionFilter") && settingsModel.getProperty("/selectedRegionFilter").toUpperCase() !==
				//	"WORLD") {
				//		aRegions = [settingsModel.getProperty("/selectedRegionFilter")];
				//	}
				for (var l = 0; l < aRegions.length; l++) {
					var oJsonDataElement = {};
					var iColumnCounter = 0;
					for (var k = 12; k > 0; k--) {
						var oDate = new Date();
						oDate.setDate(1);
						oDate.setMonth(oDate.getMonth() - k);
						oJsonDataElement[iColumnCounter + "_column"] = monthNames[oDate.getMonth()] + " " + oDate.getFullYear();
						oJsonDataElement[iColumnCounter + "_columnTEMP"] = ("0" + (oDate.getMonth() + 1)).slice(-2) + "." + oDate.getFullYear();
						oJsonDataElement[iColumnCounter] = "0.00";
						iColumnCounter++;
					}
					oJsonDataElement.type_column = "Region";
					oJsonDataElement.type = aRegions[l];
					aResult.push(oJsonDataElement);
				}
				return aResult;
			}

			// KPI Cases Table ID
			// counter: 12
			// region: "MEE"

			// KPI Cases Table
			// 0: "351.31"
			// 0_column: "MAY 2018"
			// 1: "472.27"
			// 1_column: "JUN 2018"
			// 2: "410.78"
			// 2_column: "JUL 2018"
			// 3: "454.82"
			// 3_column: "AUG 2018"
			// 4: "388.82"
			// 4_column: "SEP 2018"
			// 5: "481.33"
			// 5_column: "OCT 2018"
			// 6: "338.78"
			// 6_column: "NOV 2018"
			// 7: "248.17"
			// 7_column: "DEC 2018"
			// 8: "286.44"
			// 8_column: "JAN 2019"
			// 9: "306.35"
			// 9_column: "FEB 2019"
			// 10: "463.52"
			// 10_column: "MAR 2019"
			// 11: "492.19"
			// 11_column: "APR 2019"
			// 12: "320.55"
			// 12_column: "MAY 2019"
			// type: "MEE"
			// type_column: "Region"

		},
		initializeBWPOverviewCostTableArray: function (oResourceBundle) {
			/*var aRegions = [oResourceBundle.getText("esca_eme05"), oResourceBundle.getText("esca_la"),
			oResourceBundle.getText("esca_na"), oResourceBundle.getText("esca_apa05"),
			oResourceBundle.getText("esca_prepr"), oResourceBundle.getText("esca_intpr")
			]; */
			var aRegions = [oResourceBundle.getText("esca_emea"), oResourceBundle.getText("esca_mee"), oResourceBundle.getText("esca_la"),
			oResourceBundle.getText("esca_na"), oResourceBundle.getText("esca_apa05"), "Others", "Business Downs*",
			oResourceBundle.getText("esca_prepr"), oResourceBundle.getText("esca_intpr")
			];
			//get this year plus last six years
			var thisYearDate = new Date();
			thisYearDate.setHours(0, 0, 0, 0);
			//Get time of last 5 years
			//var last5Years = new Date(thisYearDate.setFullYear(thisYearDate.getFullYear() - 1)).getTime();
			//Get time of last 10 years
			var aYears = [thisYearDate.getFullYear()];
			for (var t = 0; t < 3; t++) {
				aYears.push(new Date(thisYearDate.setFullYear(thisYearDate.getFullYear() - 1)).getFullYear());
			}
			var finalDataSet = {};
			var aResult = [];
			//for (var k = 0; k < aYears.length; k++) {
			for (var iY = 0; iY < aYears.length; iY++) {
				var aResultElements = [];
				var oJsonDataElementL1 = {};
				//Regions "esca_prepr" and"esca_intpr" should be shown as one element in the chart-->   Product Escalations
				//therefore only loop through region size-1
				for (var i = 0; i < aRegions.length - 1; i++) {
					var oJsonDataElementL2 = {};
					// var oDate = new Date();
					// oDate.setDate(1);
					// oDate.setMonth(oDate.getMonth() - k);
					oJsonDataElementL2.yearOrRegion = aRegions[i]; //monthNames[oDate.getMonth()] + " " + oDate.getFullYear();
					//Regions "esca_prepr" and"esca_intpr" should be shown as one element in the chart-->   Product Escalations
					if (aRegions[i] === oResourceBundle.getText("esca_prepr")) {
						oJsonDataElementL2.yearOrRegion = oResourceBundle.getText("esca_prepr_intpr");
					}
					oJsonDataElementL2.q1 = 0;
					oJsonDataElementL2.q2 = 0;
					oJsonDataElementL2.q3 = 0;
					oJsonDataElementL2.q4 = 0;
					oJsonDataElementL2.ytd = 0;
					//oJsonDataElementL2[iColumnCounter] = "0.00";
					//iColumnCounter++;
					aResultElements.push(oJsonDataElementL2);
				}

				oJsonDataElementL1.elements = aResultElements;
				oJsonDataElementL1.yearOrRegion = aYears[iY] + " " + "Global";
				oJsonDataElementL1.q1 = 0;
				oJsonDataElementL1.q2 = 0;
				oJsonDataElementL1.q3 = 0;
				oJsonDataElementL1.q4 = 0;
				oJsonDataElementL1.ytd = 0;
				//oJsonDataElementL1.Q2 = aRegions[l];
				aResult.push(oJsonDataElementL1);

			}
			finalDataSet.elements = aResult;
			return finalDataSet;

		},

		//helper function to be executed before data is retrieved from oData service
		_onBeginLoadingDataToModel: function (oModel, sPropertyPath) {
			oModel.setProperty(sPropertyPath + "/data", null);
			oModel.setProperty(sPropertyPath + "/info/isBusy", Boolean(true));
		},

		//helper function to be executed after data is retrieved from oData service and placed inside of success: or error:
		_onFinishLoadingDataToModel: function (oModel, sPropertyPath, aData, iCostReturnedOdataCount, aDataCATSEMEANorth,
			aDataCATSEMEASouth) {
			var bAllDataRetrieved = true;
			var iRegionCount = 7;
			var sRegion = this.oView.getModel("filterModel").getProperty("/region");
			if (sRegion) {
				iRegionCount = sRegion.split(",").length;
			}
			if (iCostReturnedOdataCount && iCostReturnedOdataCount < iRegionCount) {
				bAllDataRetrieved = false;
			}
			if (sPropertyPath == "/casesKPIEscalationOverviewCostsTable" && iCostReturnedOdataCount && iCostReturnedOdataCount == 1) {
				bAllDataRetrieved = true;
			}

			if (bAllDataRetrieved) {
				if (sPropertyPath === "/casesKPITop5ProductsTable" || sPropertyPath === "/casesKPIStrategicProductsTable") {
					//for AGGR Profile -->  in this case case_title might be empty and therefore do not show cases, where case title is empty
					var tableData = [];
					for (var i = 0; i < aData.length; i++) {
						if (aData[i].case_title !== "") {
							tableData.push(aData[i]);
						}
					}
					oModel.setProperty(sPropertyPath + "/data", tableData);
				} //in case of cost pie charts - case detail information must be stored differently
				else if (sPropertyPath === "/top5ProductsWithHighEscCostsTable" || sPropertyPath === "/escCostsOfStrategicProductsTable") {
					var tableData = [];
					for (var i = 0; i < aData.length; i++) {
						var oDataElement = {};
						oDataElement.case_id = aData[i].A4MCASEX017CSM_EXID;
						oDataElement.customer_name = aData[i].A4MCASEX017CUSTOMER_T;
						oDataElement.product_line = aData[i].A4MCASEX017PPMSPRLN_T;
						oDataElement.status = aData[i].A4MCASEX017CSM_STAT;
						tableData.push(oDataElement);
					}
					oModel.setProperty(sPropertyPath + "/data", tableData);
				} else if (sPropertyPath === "/escCostsPerProductCategoryTable") {
					var tableData = [];
					for (var i = 0; i < aData.length; i++) {
						var oDataElement = {};
						oDataElement.case_id = aData[i].A4MCASEX017CSM_EXID;
						oDataElement.customer_name = aData[i].A4MCASEX017CUSTOMER_T;
						oDataElement.product_category = aData[i].A4MCASEX017CSM_PCL1;
						oDataElement.year = aData[i].A0CALYEAR;
						oDataElement.status = aData[i].A4MCASEX017CSM_STAT;
						tableData.push(oDataElement);
					}
					oModel.setProperty(sPropertyPath + "/data", tableData);
				} else if (sPropertyPath === "/casesKPIAverageEscalationCostsTable" || sPropertyPath === "/casesKPITotalEscalationCostsTable") {
					oModel.setProperty(sPropertyPath, aData);
				} else {
					oModel.setProperty(sPropertyPath + "/data", aData);
				}
				oModel.setProperty(sPropertyPath + "/info/hasData", Boolean(aData !== null && aData.length > 0));
				oModel.setProperty(sPropertyPath + "/info/isBusy", Boolean(false));
			}
		},

		_transformBwRegionsfromoDataReturnURI: function (sUriToCheck, bCostOverview, oResourceBundle) {
			function checkUri(term) {
				//oData.d.results[0].__metadata.uri.indexOf(term) > -1;
				return sUriToCheck.indexOf(term) > -1;
			}
			if (bCostOverview) {
				//ESCA_WW	0HIER_NODE:ESCA_WW
				//EMEA		0HIER_NODE:
				//LATAM/LAC	0HIER_NODE:
				//NA		0HIER_NODE:
				//APJ		0HIER_NODE:
				//ESCA_PREP	0HIER_NODE: 
				//ESC_INTPR	0HIER_NODE:
				switch (true) {
					case checkUri("ESCA_EME05"):
						return oResourceBundle.getText("esca_eme05");
					case checkUri("ESC_INTPR"):
						//Regions "esca_prepr" and"esca_intpr" should be shown as one element in the chart-->   Product Escalations
						return oResourceBundle.getText("esca_prepr_intpr");
					//return oResourceBundle.getText("esca_intpr");
					case checkUri("ESCA_LA"):
						return oResourceBundle.getText("esca_la");
					case checkUri("ESCA_NA"):
						return oResourceBundle.getText("esca_na");
					case checkUri("ESCA_APA05"):
						return oResourceBundle.getText("esca_apa05");
					case checkUri("ESCA_PREPR"):
						//Regions "esca_prepr" and"esca_intpr" should be shown as one element in the chart-->   Product Escalations
						return oResourceBundle.getText("esca_prepr_intpr");
					//return oResourceBundle.getText("esca_prepr");
					default:
						return oResourceBundle.getText("esca_ww");
				}
			} else {
				switch (true) {
					case checkUri("SUP_EMEA"):
						return "EMEA";
					case checkUri("SUP_MEE"):
						return "MEE";
					case checkUri("SUP_LAC"):
						return "LAC";
					case checkUri("SUP_NA"):
						return "NA";
					case checkUri("SUP_APJ"):
						return "APJ";
					case checkUri("SUP_GREATER"):
						return "GTC";
					default:
						return "World";
				}
			}
		},
		_transformRegionFilterSelectionFromVariantManagement: function (sStoredRegions) {
			//check if region is already stored as an array of key/value pairs == new implementation with facet Filter
			if (sStoredRegions.startsWith("{")) {
				return sStoredRegions;
			}
			//if not, then the region is still stored in the OLD way
			//region is stored as e.g. 'EMEA_NORTH,EMEA_SOUTH,GTC' for historic reasons, moreover we still need to support the MCS Dashboard
			var sFinalString = "{";
			sStoredRegions.split(",").forEach(function (region) {
				var sRegionText = "";
				if (sFinalString.length >= 2) {
					sFinalString += ",";
				}
				switch (region) {
					case "WORLD":
						sRegionText = this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonglobal");
						break;
					case "APJ":
						sRegionText = this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonapj");
						break;
					case "EMEA_NORTH":
						sRegionText = this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonemea_north");
						break;
					case "EMEA_SOUTH":
						sRegionText = this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonemea_south");
						break;
					case "GTC":
						sRegionText = this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttongtc");
						break;
					case "LAC":
						sRegionText = this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonlac");
						break;
					case "MEE":
						sRegionText = this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonmee");
						break;
					case "NA":
						sRegionText = this.oController.getOwnerComponent().getModel("i18n").getProperty("radiobuttonna");
						break;
				}
				sFinalString += "\"" + region + "\":\"" + sRegionText + "\"";
			}, this);
			//add closing tag
			sFinalString += "}";
			return sFinalString;
		},
		// _transformRegionFilterSelectionToRelatedSRegion: function (sRegion) {
		// 	//region is stored in Variant Management as {"APJ":"APJ","EMEA_NORTH":"EMEA North","EMEA_SOUTH":"EMEA South","GTC":"GTC","LAC":"LAC","MEE":"MEE","NA":"NA"}
		// 	//yet it should be transformed to fit the original implementation of sRegion to APJ,EMEA_NORTH,EMEA_SOUTH,GTC,LAC,MEE,NA
		// 	var sTempRegion = "";
		// 	sRegion.split(",").forEach(function (region) {
		// 		region.split(":").forEach(function (regionSegment) {
		// 			sTempRegion += regionSegment;
		// 		});
		// 	});
		// 	return sTempRegion;
		// }
	});
});