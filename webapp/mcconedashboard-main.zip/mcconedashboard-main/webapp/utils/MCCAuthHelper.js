sap.ui.define([
    "sap/base/Log"
], function (Logger) {
    "use strict";

    return {
        getAppIdentifier: function() {
            return "vFkzmhgGIsokhbTq20b492pFxGMABxLU";
        },
    }
    }
);