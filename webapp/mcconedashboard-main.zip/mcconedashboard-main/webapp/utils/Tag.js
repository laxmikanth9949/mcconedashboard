sap.ui.define([
    "com/sap/mcconedashboard/connector/SNOWConnector",
], function (SNOWConnector) {
    return {
        loadTags: function (oSNOWEscalation) {
            const sEscalationSysId = oSNOWEscalation["sys_id"]
            return new Promise((resolve, reject) => {
                SNOWConnector.getTags(sEscalationSysId).then((result) => {
                    let tags = result.filter((tag) => !!tag['label.name']);
                    let resultTags = tags.map((tag) => tag['label.name'])
                    oSNOWEscalation.CaseTag = resultTags.sort().join(", ")
                    resolve();
                }).catch(reject);
            });
        },
    }
});