/**
 * Util for processing downloaded data or user input
 * @public
 * @namespace com.sap.mcconedashboard.utils.DataProcessor
 */
sap.ui.define([

], function() {
    "use strict";
    // if no filter for personal or sensitive information is given, this array is used to filter the oData
    const aStandardFilter = 
        [
            "CaseGuid",
            "CaseId",
            "CustomerCrmNo",
            "CustomerErpNo",
            "Gu",
            "GuErpNo",
            "ImplementationPartner",
            "ImplementationPartnerT",
            "Responsible",
            "ResponsibleId",
            "SalesOrg",
            "SalesOrgT",
            "ServiceOrg",
            "ServiceOrgT",
            "ServiceTeam",
            "ServiceTeamT",
            "__metadata",
            "toNotes",
            "Processor",
            "ProcessorId",
            "ProcessorUrl",
            "LinkToCase",
            "CustomerGuid",
            "CustomerType",
            "DeliveryUnit",
            "DeliveryUnitT",
            "CreatedBy",
            "CreatedByName",
            "Tdname",
            "Tdobject",
            "CaseTitle",
            "CreateDate",
            "ChangeDate",
            "AgsBaseMaintenance",
            "AgsBaseMaintenanceT",
            "AgsPremiumMaintenance",
            "AgsPremiumMaintenanceT",
            "CaseTag",
            "Category",
            "CategoryT",
            "ChangedOn",
            "ClosingDate",
            "Country",
            "CreatedOn",
            "DbsGuSegment",
            "DbsGuSgementT",
            "DbsMaintenanceRanking",
            "Description",
            "EmplRespName",
            "HasNotes",
            "MasterCode",
            "ObjectId",
            "ObjectLink",
            "PlanEndDate",
            "Priority",
            "ProcessorLink",
            "CountryT",
            "CustomerName",
            "CustomerNo",
            "CustomerSegment",
            "GuText",
            "ProductCategory",
            "ProductKeys",
            "ProductLine",
            "ProductLineKeys",
            "ProductVer",
            "Rating",
            "Region",
            "SalesRegion",
            "Status",
            "ObjectType",
            "ChangedAt",
            "CreatedAt",
            "Product",
            "ProductCat",
            "ProductCatT",
            "ProductId",
            "ProductVersion",
            "ProductVersionT",
            "Reason",
            "ReasonT",
            "RatingT",
            "GoLiveDate",
            "priorityMatched"
        ];
    const parser = new DOMParser();
    return {

        /**
         * This internal helper function is used to filter the datasets for personal or sensitive information.
         * It is only a temporary solution and will be replaced by a dynamic filter.
         * @param {Object} oData : the data where the personal or sensitive information should be removed 
         * @param {Array} aFilter : An Array with the fields to remove
         */
        removeUserData : function(oData, aFilter){
            if(!aFilter){
                aFilter = aStandardFilter;
            }
            aFilter.forEach(filter => {
                delete oData[filter];
            });
            if(oData.toLastNotes && oData.toLastNotes.length > 0){
                oData.toLastNotes.results.forEach((oNote) => {
                    aFilter.forEach(filter => delete oNote[filter]);
                })
            }
            if(oData.toProducts && oData.toProducts.length > 0){
                oData.toProducts.results.forEach(oProduct => {
                    aFilter.forEach(filter => delete oProduct[filter]);
                })
            }
            for(let key in oData){
                if(oData[key] == "" || !oData[key]){
                    delete oData[key];
                }
                if(oData[key] instanceof Array || oData[key] instanceof Object){
                    this.removeUserData(oData[key], aFilter);
                }
            }
        },

        /**
         * This function is used to remove the personal or sensitive information in the first step and to serialize it in the second step, so that it can be sent to the 
         * anonymization service.
         * @param {Object} oView : the main view to get the model from
         * @returns 
         */
        prepareDataForAnonymization : function(oData, aFilter){
            this.createRequestMetaData(oData);
            Object.entries(oData)
                .filter((oCaseType => oCaseType[0] != 'RequestMetaData'))
                .forEach((oCaseType) => {
                    if((typeof(oCaseType[1])) == 'object'){
                        this.removeUserData(oCaseType[1], (aFilter != null) ? aFilter : null)
                    }else if((typeof(oCaseType[1]) == 'Array')){
                        oCaseType[1].forEach((Case) => {
                            this.removeUserData(Case, (aFilter != null) ? aFilter : null);
                        });
                    }
            });
            console.log(oData)
            return JSON.stringify(oData);
        },

        createRequestMetaData : function (oData){

            let oCustomerData = {};
            let oEngagementCount = {};

            // Identify Customer Data
            if(oData.CustomerDetails){
                oCustomerData = {
                    'Customer': oData.CustomerDetails.GuName1,
                    'CountryT': oData.CustomerDetails.CountryT,
                    'MasterCodeT': oData.CustomerDetails.CustomerSegment
                }
            }else if(oData.EscalationCases && oData.EscalationCases[0]){
                oCustomerData = {
                    'Customer': oData.EscalationCases[0].GuText,
                    'CountryT': oData.EscalationCases[0].CountryT,
                    'MasterCodeT': oData.EscalationCases[0].CustomerSegment
                }
            }else if(oData.EngagementCases && oData.EngagementCases[0]){
                oCustomerData = {
                    'Customer': oData.EngagementCases[0].GuText,
                    'CountryT': oData.EngagementCases[0].CountryT,
                    'MasterCodeT': oData.EngagementCases[0].CustomerSegment
                }
            }

            // Count Engagement Types
            for(let key in oData){
                try{
                    if(oData[key].results){
                        oEngagementCount[key] = oData[key].results.length;
                    }else if(oData[key]){
                        oEngagementCount[key] = oData[key].length;
                    }
                }catch(e){

                }
            }
            let oRequestMetadata = {...oCustomerData, ...oEngagementCount};
            oData.RequestMetaData = oRequestMetadata;
        }

    }
})