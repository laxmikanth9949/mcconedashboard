sap.ui.define([
        "sap/base/Log",
        "com/sap/mcconedashboard/utils/MCCAuthHelper",
        "com/sap/mcconedashboard/model/Constants",
        "com/sap/mcconedashboard/model/formatter",
    ], function (Logger, MCCAuthHelper, Constants, formatter) {
        "use strict";

        return {
            _readExecutiveEscalations: function (sCustomer, sFilterString, oController) {
                sFilterString += Constants.fieldsForExecutiveTable;

                return new Promise(function (resolve, reject) {
                    $.ajax({
                        method: "GET",
                        contentType: "application/json",
                        headers: {
                            "AppIdentifier": MCCAuthHelper.getAppIdentifier()
                        },
                        url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/sn_customerservice_escalation" + sFilterString,
                        success: (data) => {
                            const result = data.result
                            result.forEach((oRecord) => {
                                oRecord.ObjectId = oRecord.number
                                oRecord.EscalationRecordId = oRecord.number
                                oRecord.Description = oRecord['short_description']
                                oRecord.CustomerName = oRecord["u_customer_3.name"]
                                oRecord.CustomerNo = oRecord["u_customer_3.number"]
                                oRecord.Status = formatter.formatEscalationState(oRecord["state"])
                                oRecord.EmplRespName = oRecord["assigned_to.name"]
                                oRecord.CreatedOn = oRecord["sys_created_on"]
                                oRecord.ChangedOn = oRecord["u_last_user_updated_on"]
                                oRecord.Requestor = oRecord["requested_by.name"]
                                oRecord.RequestorId = oRecord["requested_by.employee_number"]
                                oRecord.ApprovalStatus = oRecord["approval"]
                                oRecord.EscalationStatus = oRecord.state
                                oRecord.NextUpdateTime = oRecord["u_next_update_time"]
                                oRecord.PlanEndDate = oRecord["u_planned_close_date"]
                                oRecord.GoLiveDate = oRecord["u_go_live_date"]
                                oRecord.PlanEndDate = oRecord["u_planned_service_start_date"]
                                oRecord.HasNotes = !!oRecord["u_business_impact"] || !!oRecord["u_executive_summary"] ? "X" : undefined
                                oRecord.SalesRegion = oRecord["u_customer_3.u_region"]
                                oRecord.CountryT = formatter.getCountryName(oRecord["u_customer_3.country"], oController)
                                oRecord.AssignmentGroup = oRecord["assignment_group.name"]
                            });

                            resolve(result);
                        },
                        error: (oError) => {
                            Logger.error("Error retrieving Executive Escalations", "", "", oError);
                            reject(oError)
                        }
                    });
                })
            },

            getTags: function (escalationSystemId) {
                return new Promise(function (resolve, reject) {
                    $.ajax({
                        method: "GET",
                        contentType: "application/json",
                        headers: {
                            'AppIdentifier': MCCAuthHelper.getAppIdentifier(),
                        },
                        url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apim/hcsm-low-lag-tu/api/now/table/label_entry?sysparm_query=table_key=" + escalationSystemId +
                            "&sysparm_fields=label.name,label,sys_id",
                        success: (tags) => {
                            resolve(tags.result);
                        },
                        error: (oError) => {
                            Logger.error("Error loading tags", "", "", oError)
                            reject(oError)
                        }
                    });
                });
            },
        }
    }
)
;