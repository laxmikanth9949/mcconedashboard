sap.ui.define([
    "com/sap/mcconedashboard/controller/BaseController.controller"

], function (BaseController) {
    "use strict";

    return {
        translateText: function (data, language) {
            return new Promise((resolve, reject) => {
                var sUrl = sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/DOCUMENTTRANSLATE/?strictMode=false&targetLanguage=" + language;

                $.ajax({
                    method: "POST",
                    contentType: "text/plain",
                    url: sUrl,
                    headers: {
                        "AppIdentifier": "HhvJF9wTaYMZsn8H7K8oL4CRUaqYXl9s"
                    },
                    data: data,
                    success: function (oData) {
                        resolve(oData);
                    }.bind(this),
                    error: function (oError) {
                        reject(oError);
                    }
                });
            });
        },

        createLanguageModel: function (sapLanguage) {

            const sapLanguageList = {
                ZH: "zh-CN",
                ZF: "zh-TW",
                SH: "sr-Latn-RS",
                '1P': "pt-BR",
                '1X': "es-ES",
                '3F': "fr-FR",
            };
            var defaultLanguage = "de-DE";
            //var sapLanguage = oUserProfileModel.mMetadataUrlParams['sap-language'];
            if (sapLanguage && sapLanguage != '6N' && sapLanguageList.hasOwnProperty(sapLanguage)) {
                defaultLanguage = sapLanguageList[sapLanguage];
            }

            var oLanguageModel = new sap.ui.model.json.JSONModel({
                "languageList": [
                    { "key": "ar-SA", "text": "Arabic" },
                    { "key": "bg-BG", "text": "Bulgarian" },
                    { "key": "ca-ES", "text": "Catalan" },
                    { "key": "zh-CN", "text": "Chinese (Simplified)" },
                    { "key": "zh-TW", "text": "Chinese (Traditional)" },
                    { "key": "hr-HR", "text": "Croatian" },
                    { "key": "cs-CZ", "text": "Czech" },
                    { "key": "da-DK", "text": "Danish" },
                    { "key": "nl-NL", "text": "Dutch" },
                    { "key": "et-EE", "text": "Estonian" },
                    { "key": "fi-FI", "text": "Finnish" },
                    { "key": "fr-FR", "text": "French (France)" },
                    { "key": "de-DE", "text": "German" },
                    { "key": "el-GR", "text": "Greek" },
                    { "key": "he-IL", "text": "Hebrew" },
                    { "key": "hi-IN", "text": "Hindi" },
                    { "key": "hu-HU", "text": "Hungarian" },
                    { "key": "it-IT", "text": "Italian" },
                    { "key": "ja-JP", "text": "Japanese" },
                    { "key": "kk-KZ", "text": "Kazakh" },
                    { "key": "ko-KR", "text": "Korean" },
                    { "key": "lv-LV", "text": "Latvian" },
                    { "key": "lt-LT", "text": "Lithuanian" },
                    { "key": "ms-MY", "text": "Malay" },
                    { "key": "nb-NO", "text": "Norwegian" },
                    { "key": "pl-PL", "text": "Polish" },
                    { "key": "pt-BR", "text": "Portuguese (Brazil)" },
                    { "key": "ro-RO", "text": "Romanian" },
                    { "key": "ru-RU", "text": "Russian" },
                    { "key": "sr-Latn-RS", "text": "Serbian (Latin)" },
                    { "key": "sk-SK", "text": "Slovak" },
                    { "key": "sl-SI", "text": "Slovenian" },
                    { "key": "es-ES", "text": "Spanish (Spain)" },
                    { "key": "sv-SE", "text": "Swedish" },
                    { "key": "th-TH", "text": "Thai" },
                    { "key": "tr-TR", "text": "Turkish" },
                    { "key": "uk-UA", "text": "Ukrainian" },
                    { "key": "vi-VN", "text": "Vietnamese" },
                    { "key": "id-ID", "text": "Indonesian" }
                ],
                "preselectedOption": defaultLanguage
            });
            return(oLanguageModel);
        }






    }
});