sap.ui.define([
    "sap/base/Log"
], function (Logger) {
    "use strict";

    return {
        loadFeatureFlags: function (featureFlags) {
            return new Promise(function (resolve, reject) {
                $.ajax({
                    method: "GET",
                    contentType: "application/json",
                    headers: {
                        AppIdentifier: "vFkzmhgGIsokhbTq20b492pFxGMABxLU"
                    },
                    url: sap.ui.require.toUrl("com/sap/mcconedashboard") + "/apimcf/mcc-featureflags",
                    success: (oData) => {
                        let result = new Map();
                        featureFlags.forEach((sFeatureFlag) => {
                            let aFlags = oData.flags.filter((oFlag) =>
                                oFlag.id === sFeatureFlag
                            );
                            if (!!aFlags && !!aFlags[0]) {
                                var currentFlag = aFlags[0];
                                switch (currentFlag.variationType) {
                                    case "BOOLEAN": {
                                        result.set(sFeatureFlag, currentFlag["enabled"]);
                                        break;
                                    }
                                    case "STRING": {
                                        const value = currentFlag["enabled"] ?
                                            currentFlag.variations[currentFlag.defaultVariationIndex] : currentFlag.variations[currentFlag.offVariationIndex]
                                        result.set(sFeatureFlag, value);
                                        break;
                                    }
                                }
                            } else result.set(sFeatureFlag, false);
                        });
                        resolve(Object.fromEntries(result))
                    },
                    error: (oError) => {
                        Logger.error("Error retrieving feature flags", "", "", oError);
                        let result = new Map();
                        featureFlags.forEach((sFeatureFlag) => {
                            result.set(sFeatureFlag, false);
                        });
                        resolve(Object.fromEntries(result))
                    }
                });

            });
        },
    };
});