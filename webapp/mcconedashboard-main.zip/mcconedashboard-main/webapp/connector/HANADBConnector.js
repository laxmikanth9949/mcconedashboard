sap.ui.define([
    "sap/base/Log",
    "com/sap/mcconedashboard/utils/MCCAuthHelper",
    "com/sap/mcconedashboard/model/Constants",
    "com/sap/mcconedashboard/model/formatter",
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
], function (Logger, MCCAuthHelper, Constants, formatter, Filter, FilterOperator) {
    "use strict";

    return {
        loadMCCObjects: function (that, aEscalations) {
            return new Promise(function (resolve, reject) {
                var oResourceModel = that.getView().getModel("mccIssueTracking");
                var aFilters = []
                aEscalations.forEach((oEscalation) => {
                    aFilters.push(new Filter('EscalationID', FilterOperator.EQ, oEscalation.number))
                })

                oResourceModel.read("/MCCObject", {
                    filters: [new Filter({
                        filters: aFilters,
                        and: false
                    })],
                    headers: {
                        AppIdentifier: MCCAuthHelper.getAppIdentifier(),
                    },
                    success: function (oData) {
                        resolve(oData.results);
                    },
                    error: function (oError) {
                        Logger.error("Error loading objects from HANA DB", "", "", oError)
                        reject(oError);
                    }
                });
            });
        },
    }
});